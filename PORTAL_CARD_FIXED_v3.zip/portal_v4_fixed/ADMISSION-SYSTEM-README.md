# 🎓 Admission Form System — v3.0
## St. Ann's School Portal

---

## ✅ What's New in v3.0

### 1. Frontend Admission Form (`frontend/pages/admission-form.html`)
- **Class + Section dropdowns** — student can pick preferred section (A/B/C)
- **Real-time phone validation** — enforces exactly 10 digits, numeric-only
- **Live duplicate phone check** — calls `/api/admissions/check-phone/:phone` with 600ms debounce
- **Visual feedback system** — green ✅ for valid, yellow ⚠️ for incomplete, red ❌ for error/duplicate
- **Alternate phone field** — optional, same 10-digit validation
- **Loading overlay** on submit — prevents double submission
- **Step-bar progress** — steps 1–4 with active/done states

### 2. Backend Routes (`backend/routes/admissions.js`)
- `GET  /api/admissions/check-phone/:phone` — public duplicate check endpoint
- `POST /api/admissions` — validates phone (10 digits), checks duplicate, rejects alternatePhone if invalid
- `PUT  /api/admissions/:id` — updates status, auto-sends WhatsApp, saves WA send status
- `POST /api/admissions/:id/resend-whatsapp` — manually retry failed WA notifications

### 3. Admission Model (`backend/models/Admission.js`)
- `section` field added
- `alternatePhone` field with optional 10-digit validation
- `whatsappStatus` — tracks 'not_sent' | 'sent' | 'failed'
- `whatsappSentAt` — timestamp of last WA send attempt
- `whatsappError` — error message if WA failed

### 4. Student Add (`backend/routes/students.js`)
- `guardianPhone` is now **required** when adding a student from admin panel
- Validates exactly 10 digits before saving
- Saves cleaned (digits-only) phone number

### 5. Admin Admissions Panel (`admin_panel/admissions.html`)
- Full table with all applications
- Filter by status (click stat card), class dropdown, WhatsApp status dropdown
- Search by name / phone / application ID
- Actions: Approve / Reject / Waitlist — auto-triggers WhatsApp
- WhatsApp badge per row (Sent ✅ / Failed ❌ / Not Sent)
- "Resend WA" button for failed/not-sent approved/rejected apps
- Detail modal with full info + notes editor
- Auto-refreshes every 30 seconds

---

## 🚀 Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure `.env`
```env
MONGO_URI=mongodb://127.0.0.1:27017/school_portal
JWT_SECRET=your_secret_key

# WhatsApp — Meta Cloud API (FREE tier: 1000 msg/month)
WHATSAPP_PROVIDER=meta
META_PHONE_NUMBER_ID=your_phone_number_id
META_ACCESS_TOKEN=your_access_token
META_API_VERSION=v19.0

SCHOOL_NAME=St. Ann's School
```

### 3. Run
```bash
npm start
# OR for development:
npm run dev
```

### 4. Access
- **Admission Form:** `http://localhost:3000/frontend/pages/admission-form.html`
- **Admin Panel:**  `http://localhost:3000/admin_panel/admissions.html`

---

## 📱 WhatsApp Setup (Meta Cloud API — Free)

1. Go to **Meta for Developers** → Create App → WhatsApp
2. Get your **Phone Number ID** and **Access Token**
3. Add to `.env` or **Admin Panel → WhatsApp Settings**
4. Test with `/api/whatsapp/test`

### Message Templates Sent:
| Event | Trigger |
|-------|---------|
| Admission Approved | When admin clicks Approve |
| Admission Rejected | When admin clicks Reject |
| Student Welcome | When admin adds new student |
| Fee Payment | When fee payment is recorded |
| Fee Reminder | Manual or scheduled |

---

## 🔒 Phone Number Rules

| Rule | Frontend | Backend |
|------|----------|---------|
| Required | ✅ | ✅ |
| Exactly 10 digits | ✅ real-time | ✅ |
| Numeric only | ✅ enforced on input | ✅ regex |
| Duplicate check | ✅ live API call | ✅ DB query |
| Auto-formats to +91 | For display | For WhatsApp send |

---

## 📂 Changed Files

```
backend/
  models/Admission.js          ← Added section, alternatePhone, whatsappStatus fields
  routes/admissions.js         ← New duplicate-check endpoint, phone validation, WA tracking
  routes/students.js           ← guardianPhone now required, 10-digit validation

frontend/
  pages/admission-form.html    ← Complete rewrite: real-time validation, section dropdown

admin_panel/
  admissions.html              ← NEW: Full admissions management dashboard
```
