===================================================
  DEMO DATA CLEANUP — PEHLE YEH PADHO
===================================================

Demo data delete karne ke liye:

  1. Terminal kholo portal_updated/backend/ folder mein
  2. Run karo:  node cleanup-demo-data.js

Yeh delete karega:
  - Dummy fee payments (RCP-2045, RCP-2046, RCP-2047)
  - Demo students (Rahul Sharma, Priya Gupta, Aman Khan)
  - Demo teachers (Dr. Sarah Johnson etc.)
  - Demo events & houses

Yeh SAFE rahega:
  - Admin login
  - School Settings
  - Fee Structure

===================================================
