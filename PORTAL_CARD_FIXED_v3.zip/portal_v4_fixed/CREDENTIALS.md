# 🔑 SCHOOL PORTAL — Login Credentials & Setup (v3.0)

## Admin Panel
- **URL:** `http://localhost:3000/admin_panel/login.html`
- **Username:** `admin`
- **Password:** `Admin@1234`
- ⚠️ Change password after first login: Settings → Change Password

---

## Teacher Panel (REBUILT v3.0)
- **URL:** `http://localhost:3000/teacher_panel/login.html`
- **Dashboard:** `http://localhost:3000/teacher_panel/dashboard.html`

### 🔐 Sample Teacher Credentials (after `npm run seed`)

| Username        | Password     | Assigned To         |
|-----------------|--------------|---------------------|
| `teacher_lkga`  | `Teacher@123`| LKG — Section A     |
| `teacher_lkgb`  | `Teacher@123`| LKG — Section B     |
| `teacher_ukga`  | `Teacher@123`| UKG — Section A     |
| `teacher_ukgb`  | `Teacher@123`| UKG — Section B     |
| `teacher_1a`    | `Teacher@123`| Class 1 — Section A |
| `teacher_1b`    | `Teacher@123`| Class 1 — Section B |
| `teacher_10a`   | `Teacher@123`| Class 10 — Section A|
| `teacher_12b`   | `Teacher@123`| Class 12 — Section B|
| *(and more…)*   | `Teacher@123`| All classes A & B   |

> ⚠️ Format: `teacher_{class}{section}` e.g. `teacher_5a`, `teacher_9b`  
> ⚠️ Change passwords after first login via Teacher Panel → My Profile

### Creating New Teacher Accounts
1. Login to Admin Panel → Click **Teacher Accounts** in sidebar  
2. Click **➕ Create Account**  
3. Fill: Name, Username, Password, Assigned Class, Section  
4. Save — teacher can now login immediately

---

## ✅ SETUP STEPS

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Install dependencies
```bash
cd school-portal-FINAL
npm install
```

### Step 3 — Seed database (creates admin + 28 teacher accounts + sample data)
```bash
npm run seed
```

### Step 4 — Start server
```bash
npm start
```

### Step 5 — Open browser
```
http://localhost:3000          ← School Website (Frontend)
http://localhost:3000/admin_panel/login.html    ← Admin Panel
http://localhost:3000/teacher_panel/login.html  ← Teacher Panel
```

---

## 📋 MongoDB Atlas
- **Cluster:** cluster0.mrvy3dq.mongodb.net
- **Database:** school_portal
- **Storage:** 500MB (Atlas Free Tier M0)
- **Status:** Configured in .env ✅

---

## Data Flow
| Component     | Data                            | Storage        |
|---------------|---------------------------------|----------------|
| Admin Panel   | All school data, teacher mgmt   | MongoDB Atlas  |
| Teacher Panel | Attendance, Marks, Students     | MongoDB Atlas  |
| Auth Tokens   | JWT (8h session)                | localStorage   |

---

## 🆕 What's New in v3.0 — Teacher Panel Rebuild

### Removed:
- Old basic teacher_panel/login.html (165 lines, minimal UI)
- Old basic teacher_panel/dashboard.html (1286 lines, broken layout)

### Built:
- New glassmorphism login page with animated background, eye toggle, Enter key support
- New full-featured dashboard (7 sections, sidebar navigation, professional UI)
- Teacher Student Update endpoint: `PUT /api/teacher/student/:id`
- Admin Teacher Accounts CRUD fully wired in admin panel
- Production-ready with JWT auth, session expiry handling, toast notifications


## Admin Panel
- **URL:** `http://localhost:3000/admin_panel/login.html`
- **Username:** `admin`
- **Password:** `Admin@1234`
- ⚠️ Change password after first login: Settings → Change Password

## Teacher Panel
- **URL:** `http://localhost:3000/teacher_panel/login.html`
- Teacher accounts created from: Admin Panel → Teacher Accounts

---

## ✅ SETUP STEPS (Run these on your PC)

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Install dependencies
```bash
cd school-portal-FINAL
npm install
```

### Step 3 — Seed the database (creates admin user + default data)
```bash
npm run seed
```

### Step 4 — Start the server
```bash
npm start
```

### Step 5 — Open browser
```
http://localhost:3000
```

---

## 📋 MongoDB Atlas
- **Cluster:** cluster0.mrvy3dq.mongodb.net
- **Database:** school_portal
- **Storage:** 500MB (Atlas Free Tier M0)
- **Status:** Configured in .env ✅

---

## Data Flow
| Component | Data | Storage |
|-----------|------|---------|
| Admin Panel | All school data | MongoDB Atlas |
| Auth Tokens | JWT (login session) | sessionStorage |
| Teacher Panel | Marks, Attendance | MongoDB Atlas |

---

## 🐛 Bug Fix Applied (v2.4.1)
- Fixed: Dashboard completely non-functional (no buttons/clicks working)
- Root Cause: `var` re-declaration of `const`/`let` variables caused SyntaxError
  that stopped ALL JavaScript from executing
- Fixed: Removed 750 lines of duplicate code from dashboard.html
- Result: All buttons, navigation, CRUD — fully functional
