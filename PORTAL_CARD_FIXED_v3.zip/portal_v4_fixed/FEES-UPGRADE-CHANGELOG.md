# Fees Management System — Upgrade Changelog

## 🚀 Version: Production-Ready Upgrade
## Files Changed: admin_panel/fees.html, admin_panel/dashboard.html, admin_panel/js/dashboard-patch.js, backend/routes/dashboard.js

---

## ✅ BUG FIXES

### 1. Dashboard Showing ₹0 (CRITICAL FIX)
- **Root cause**: `currentYear` in fees.html was hardcoded to `'2025-26'` but backend `currentAcademicYear()` returns `'2026-27'` (April 2026 → new academic year starts)
- **Fix**: Replaced hardcoded string with `computeAcademicYear()` function that mirrors exact backend logic (`month >= 4 → new year`)
- **Also fixed**: Year dropdown now includes `2026-27` as the default option; `init()` auto-syncs the dropdown

### 2. Defaulters API Response Unwrap Bug
- **Root cause**: `apiFetch()` auto-unwraps `.data` field, so `{data:[...], totalPending:N}` became just an array, losing `totalPending`
- **Fix**: Dashboard pending dues card now uses raw `fetch()` call to preserve full response object

### 3. Academic Year Consistency
- All year-related selects (`fs-year`, `inst-year`, `print-yr`) now include 2026-27

---

## ✅ NEW FEATURES

### 4. School Settings Page (Requirement #15–19)
- New "🏫 School Settings" tab in sidebar
- Fields: School Name (required), Phone, Email, Address, Principal, Board/Affiliation
- Saves to MongoDB under both `schoolInfo` and `schoolSettings` keys (backwards compatible)
- School name auto-used in WhatsApp messages and receipts
- Default fallback: "Your School" if nothing saved
- WhatsApp message preview panel shows live sample with current school name

### 5. Per-Student WhatsApp Button (Requirement #10–13)
- "💬 WA Reminder" button on every student fee card (shown only if balance > 0)
- "💬 WA Receipt" button on fee card (shown only if any payment exists)
- Two message types:
  - **Due Reminder**: includes Total Fees, Paid, Remaining, school name
  - **Receipt Confirmation**: payment confirmation with balance
- Auto-fetches parent phone number from `guardianPhone` field
- If no phone saved: copies message to clipboard with toast notification
- Opens `wa.me/91{phone}` link with pre-filled UTF-8 encoded message
- Works on mobile and desktop (WhatsApp Web / App auto-detected)

### 6. Delete Payment Button (Requirement #3)
- 🗑️ Delete button added to every row in Today's Transactions table
- 🗑️ Delete button added to every row in Student Fee Card payment history
- Calls `DELETE /api/fee-payments/:id` (backend was already complete)
- Marks receipt as cancelled, updates student balance automatically
- Shows confirmation dialog with student name before deleting
- Reloads dashboard after successful delete

### 7. Per-Row WhatsApp in Defaulters List (Requirement #10–11)
- 💬 WhatsApp link button on every defaulter row
- Message includes: student name, class, total fees, paid amount, remaining, school name
- Grayed out / shows "No phone" if student has no phone number on record

### 8. Installment Tracking in Student Fee Card (Requirement #5–6)
- Installment section loads asynchronously (non-blocking) inside fee card modal
- Shows all terms with due date, amount due (calculated from percentage), and status
- Status badges:
  - ✅ Paid (green) — cumulative payments cover this term
  - 🟡 Partial (yellow) — partially covered
  - 🔴 Overdue (red) — due date passed, not fully paid
  - 📅 Upcoming (blue) — due date not yet reached
- Works with existing `InstallmentSchedule` model and `/api/fee-structure/installments/:year` route

### 9. Real-Time Dashboard Fee Stats (Requirement #22)
- Admin main dashboard (`dashboard.html`) now shows three fee collection cards:
  - 💵 Today's Collection
  - 📆 This Month
  - 📊 This Year (current academic year)
- Clicking any card opens fees.html
- Powered by enhanced `/api/dashboard` route that aggregates `FeePayment` documents
- backend `dashboard.js` updated with `currentAcademicYear()` function and FeePayment aggregation

---

## ✅ UX IMPROVEMENTS

### 10. Fixed Student Field Names in Fee Card
- Fixed `stu.name` → `stu.fullName` (matches MongoDB Student model)
- Fixed `stu.fatherName` → `stu.guardianName` (matches model)
- Fixed `stu.phone` → `stu.guardianPhone` (matches model)
- Fixed `stu.admissionNo` → `stu.admissionNumber` (matches model)

### 11. Today's Transactions — Payment Mode Casing Fix
- Mode icons now match proper casing: `Cash`, `Cheque`, `UPI`, `Online`, `DD`
- Previously `r.paymentMode.toLowerCase()` was comparing against lowercase keys incorrectly

### 12. Defaulters List Enhancements
- Shows total pending amount in header (sum of all dues)
- Fixed API call to include `academicYear` and `section` parameters
- Removed demo data fallback (real data only)
- Action buttons compact: 💵 Collect, 🖨️ Notice, 💬 WhatsApp — all in one row

---

## ⚙️ BACKEND CHANGES

### dashboard.js
- Added `currentAcademicYear()` helper (matches frontend and feePayments.js)
- Added FeePayment aggregation for today/month/year collection stats
- New response fields: `fee_today`, `fee_month`, `fee_year`, `academicYear`
- Wrapped FeePayment require in try/catch (graceful if model missing)

---

## 📝 SETUP NOTES
- No new dependencies required
- No database migrations needed — uses existing collections
- School Settings page auto-creates MongoDB documents on first save
- All changes are backwards compatible with existing data
