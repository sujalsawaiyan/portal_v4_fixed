# 🖼️ Image Upload System — Setup Guide
## ST. ANN'S SCHOOL PORTAL

---

## ✅ What Was Fixed

| Section | Fix |
|---|---|
| School Logo | Real file upload → `/uploads/logo/` |
| Principal Photo | Real file upload → `/uploads/principal/` |
| Admission Banner | Real file upload → `/uploads/banners/` |
| Teacher Photos (Add) | Real file upload → `/uploads/teachers/` |
| Teacher Photos (Edit) | Replace + old file auto-deleted |
| Class Teacher Photo | Real file upload → `/uploads/class-teachers/` |
| Leadership Grid | Real file upload → `/uploads/leadership/` |
| Event Images | Real file upload → `/uploads/events/` |
| Gallery (Add) | Real file upload → `/uploads/gallery/` |
| Gallery (Edit) | Replace + old file auto-deleted |
| Gallery (Delete) | File deleted from disk + MongoDB |
| Top Student Images | Real file upload → `/uploads/students/` |

---

## 🚀 Setup Steps

### 1. Install dependencies
```bash
npm install
```
> This installs `sharp` (image compression) + all existing packages.

### 2. Copy environment file
```bash
cp .env.example .env
```
Edit `.env` and set:
- `MONGO_URI` — your MongoDB connection string
- `JWT_SECRET` — a strong random secret

### 3. Start MongoDB
Make sure MongoDB is running locally:
```bash
mongod
```
Or use MongoDB Atlas — paste the connection string in `.env`.

### 4. Start the server
```bash
npm start
# or for development with auto-reload:
npm run dev
```

### 5. Open admin panel
Go to: `http://localhost:3000/admin_panel/login.html`

---

## 📁 Upload Folder Structure

```
uploads/
├── logo/           ← School logo
├── principal/      ← Principal photo
├── banners/        ← Admission & other banners
├── teachers/       ← Teacher profile photos
├── class-teachers/ ← Class teacher photos
├── leadership/     ← Principal, VP, HoD, etc.
├── events/         ← Event images
├── gallery/        ← Gallery photos
└── students/       ← Top student photos
```

---

## 🔌 API Endpoints

| Method | URL | Purpose |
|---|---|---|
| `POST` | `/api/images/upload/:category` | Upload image |
| `GET` | `/api/images/:category` | Get image(s) |
| `DELETE` | `/api/images/:category/:id` | Delete image |
| `PUT` | `/api/images/gallery/:id` | Update gallery item |

**Valid categories:** `logo`, `principal`, `banners`, `teachers`, `class-teachers`, `leadership`, `events`, `gallery`, `students`

---

## 📋 Rules

- **Allowed formats:** JPG, PNG, WEBP
- **Max file size:** 5MB
- **Auto-compression:** Images are resized and compressed with `sharp` before saving
- **Old images deleted:** When you replace an image, the old file is automatically deleted from disk

---

## 🔧 How It Works

1. Admin selects a file → **instant preview** shown
2. On save → `FormData` sent to `/api/images/upload/:category`
3. Multer saves file to `/uploads/:category/`
4. Sharp compresses the image
5. File path saved to MongoDB
6. URL returned to frontend → stored in SchoolDB for homepage use
7. On delete → file removed from disk + MongoDB record cleared

---

## ⚠️ Notes

- The system falls back gracefully if MongoDB is unavailable (images still upload, metadata not persisted between restarts)
- Static image catalog (dropdown) still works alongside file uploads
- All existing UI/layout is unchanged — only functionality was fixed
