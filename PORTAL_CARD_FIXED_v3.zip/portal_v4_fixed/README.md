# 🏫 School Management Portal — v2.4.0

A complete, production-ready School Management System built with **Node.js + Express + MongoDB**.

---

## 🚀 Quick Start

```bash
# 1. Clone / extract the project
cd school-portal

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# → Edit .env and fill in your MongoDB URI, JWT secret, Cloudinary keys, etc.

# 4. Seed the database with demo data (optional)
npm run seed

# 5. Start the server
npm start
# Development (auto-restart):
npm run dev
```

Server runs at: **http://localhost:3000**

---

## 🔑 Default Login Credentials

> **Change all passwords immediately after first login!**

| Role       | URL                             | Username  | Password    |
|------------|----------------------------------|-----------|-------------|
| Admin      | `/admin_panel/login.html`        | `admin`   | `admin123`  |
| Teacher    | `/teacher_panel/login.html`      | Set by admin in Teacher Accounts section | Set by admin |
| Student    | `/frontend/pages/result.html`    | Student ID | Date of birth (YYYY-MM-DD) |
| Parent     | `/frontend/pages/parent-login.html` | StudentID | Guardian phone / date of birth |

---

## 📁 Project Structure

```
school-portal/
├── backend/
│   ├── server.js          — Express app entry point
│   ├── models/            — Mongoose schemas
│   ├── routes/            — All API route handlers
│   ├── middleware/        — Auth (JWT) + file upload
│   ├── utils/             — Cloudinary, sanitize, WhatsApp
│   └── jobs/              — Cron jobs (fee reminders)
├── admin_panel/
│   ├── login.html         — Admin login page
│   └── dashboard.html     — Full admin panel (all modules)
├── teacher_panel/
│   ├── login.html         — Teacher login
│   └── dashboard.html     — Teacher panel (attendance, marks, etc.)
├── frontend/
│   ├── css/style.css      — Main stylesheet
│   ├── js/                — Frontend scripts
│   └── pages/             — All public-facing pages
├── images/                — Static placeholder SVGs
├── uploads/               — User-uploaded files (gitignored)
├── .env.example           — Environment variable template
└── package.json
```

---

## ⚙️ Environment Variables

Copy `.env.example` → `.env` and configure:

| Variable | Description |
|---|---|
| `MONGO_URI` | MongoDB connection string |
| `JWT_SECRET` | Min 32-char random secret |
| `CLOUDINARY_*` | Image storage (get from cloudinary.com) |
| `RAZORPAY_*` | Online fee payments (optional) |
| `TWILIO_*` | WhatsApp fee reminders (optional) |

---

## 🧩 Admin Panel Modules

| Module | Features |
|---|---|
| **Dashboard** | Stats, house leaderboard, pending admissions |
| **Students** | Add/Edit/Delete, photo upload, parent account auto-create |
| **Teachers** | Full CRUD, Cloudinary photo management |
| **Teacher Accounts** | Create login credentials for teachers |
| **Classes** | Class-teacher assignments, student count |
| **Attendance** | Mark/view daily, monthly, yearly attendance |
| **Marks & Results** | Term-wise marks (Term1, Term2, Annual), grade auto-calc |
| **Events** | Add/Edit/Delete events with image upload |
| **Notices** | Pin, highlight, set expiry on announcements |
| **Fee Management** | Fee structure, payment receipts, Razorpay integration |
| **Gallery** | School photo gallery |
| **Houses** | House points system |
| **Security** | Visitor log, security alerts |
| **Image Manager** | Upload logo, banners, principal photo, etc. |
| **Settings** | School info, stats, social links, homepage content |
| **Backup & Restore** | Full database export/import |

---

## 👨‍🏫 Teacher Panel Features

- View assigned class student list
- Mark daily attendance (Present / Absent / Late)
- Enter marks per subject per term
- View monthly attendance reports
- Add discipline records (positive/negative)
- **Change password** (with strength indicator)
- View own profile details

---

## 🌐 Frontend Public Pages

| Page | Path |
|---|---|
| Home | `/index.html` |
| Teachers | `/frontend/pages/teachers.html` |
| Events | `/frontend/pages/events.html` |
| Attendance | `/frontend/pages/attendance.html` |
| Student Result | `/frontend/pages/result.html` |
| Parent Login | `/frontend/pages/parent-login.html` |
| Admission Form | `/frontend/pages/admission-form.html` |
| Houses | `/frontend/pages/houses.html` |
| Top Students | `/frontend/pages/topstudents.html` |
| Fee Payment | `/frontend/pages/payment.html` |

---

## 🔒 Security Features

- JWT authentication (8-hour expiry)
- bcrypt password hashing (cost factor 12)
- Helmet security headers
- Rate limiting (login: 20/15min, general API: 300/15min)
- MongoDB injection sanitization
- XSS input sanitization
- CORS origin whitelist
- Admin-only routes protected with role-based middleware

---

## 🆕 Changelog — v2.4.0

### Fixed
- **Student DELETE** now properly cleans up Cloudinary photo and deactivates parent account
- **Hindi error messages** in result.js replaced with English
- **Attendance endpoints** (`/class/:cls/:sec/...`) now require authentication
- **Dead Result model** removed from `models/index.js` (was conflicting with active `Marks` model)
- **Version mismatch** resolved — all files now consistently at v2.4.0

### Added
- **Teacher: `POST /api/teacher/change-password`** — teachers can now change their own password
- **Teacher: `GET /api/teacher/profile`** — dedicated profile endpoint
- **Teacher Dashboard: Change Password UI** — with live password strength meter, confirm field, auto-logout on success
- **Teacher Dashboard: Profile Info display** — read-only profile card in Settings page
- **Class DELETE endpoint** (`DELETE /api/classes/:id`) with enrolled-student safety guard
- **`.gitignore`** — prevents `.env`, `node_modules/`, `uploads/` from being committed
- **`.env.example`** fully documented with setup instructions

### Removed
- **`.env` file** removed from distribution (contained JWT secret — security risk)

---

## 📞 Support

For setup help, refer to `IMAGE-UPLOAD-SETUP.md` for Cloudinary configuration and `CREDENTIALS.md` for default credentials.
