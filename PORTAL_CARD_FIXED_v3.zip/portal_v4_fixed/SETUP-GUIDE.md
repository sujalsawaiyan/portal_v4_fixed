# 📘 School Portal — Complete Setup Guide
### MongoDB · Cloudinary · Razorpay · WhatsApp · Hosting

---

## ✅ Status Check — Kya Kya Already Available Hai

| Service | Code Taiyar Hai? | Aapko Kya Karna Hai |
|---|---|---|
| **MongoDB** | ✅ Fully integrated | Sirf URI dena hai `.env` mein |
| **Cloudinary** (Image Upload) | ✅ Fully integrated | Free account banao, 3 keys dalo |
| **Razorpay** (Fee Payment) | ✅ Fully integrated | Account banao, test→live key switch karo |
| **WhatsApp Notifications** | ✅ Fully integrated | Admin panel se hi configure hota hai (no code change) |
| **Hosting** | ✅ Code ready hai | Railway/Render pe deploy karo (guide neeche) |

---

---

# 📌 PART 1 — .env File Kaise Banayein

`.env` file aapke server ka "secret locker" hai. Ye file **kabhi GitHub pe upload mat karo**.

### Step 1 — File Banao
```bash
# Project folder mein yeh command chalaao:
cp .env.example .env
```

### Step 2 — File Open Karo
Koi bhi text editor se `.env` open karo (Notepad, VS Code, etc.)

### Step 3 — Values Fill Karo (neeche har service ka guide hai)

---

---

# 📌 PART 2 — MongoDB Setup

## Option A — Free Local MongoDB (Testing ke liye)
Agar aap apne computer pe test kar rahe ho:

```env
MONGO_URI=mongodb://127.0.0.1:27017/school_portal
```

**Install karo:** https://www.mongodb.com/try/download/community

---

## Option B — MongoDB Atlas (Production ke liye) ⭐ RECOMMENDED

**Ye free hai — 512MB free cluster milta hai!**

### Steps:
1. Jao: **https://cloud.mongodb.com**
2. "Sign Up" karo (Google se bhi ho sakta hai)
3. "Create a FREE cluster" click karo
   - Provider: AWS
   - Region: Mumbai (ap-south-1) — India ke liye best
   - Cluster Tier: **M0 Sandbox (FREE)**
4. "Create Cluster" click karo (2-3 min lagenge)
5. Left menu mein **"Database Access"** jao
   - "Add New Database User" click karo
   - Username: `schooladmin`
   - Password: koi strong password likho (yaad rakhna!)
   - Role: "Atlas Admin"
   - Save karo
6. Left menu mein **"Network Access"** jao
   - "Add IP Address" click karo
   - "Allow Access from Anywhere" click karo (0.0.0.0/0)
   - Confirm karo
7. "Database" pe wapas jao → "Connect" button dabao
   - "Connect your application" choose karo
   - Driver: Node.js
   - **Connection string copy karo** — kuch aisa dikhega:
   ```
   mongodb+srv://schooladmin:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
8. `<password>` ki jagah apna actual password daalo

### .env mein likho:
```env
MONGO_URI=mongodb+srv://schooladmin:YourPassword123@cluster0.xxxxx.mongodb.net/school_portal?retryWrites=true&w=majority
```

> ⚠️ URI ke end mein `/school_portal` zaroor likho — ye database ka naam hai

---

---

# 📌 PART 3 — Cloudinary Setup (Image Upload)

Cloudinary pe teachers, students, events ki photos store hoti hain.
**Free plan: 25GB storage, 25GB bandwidth/month — school ke liye kaafi hai!**

### Steps:
1. Jao: **https://cloudinary.com**
2. "Sign Up for Free" karo
3. Login karne ke baad **Dashboard** pe jao
4. Wahan ye teenon cheezein dikhti hain:
   - **Cloud Name** — e.g. `dxyz123abc`
   - **API Key** — e.g. `123456789012345`
   - **API Secret** — e.g. `abcDEFghiJKLmno_pqrSTU`

### .env mein likho:
```env
CLOUDINARY_CLOUD_NAME=dxyz123abc
CLOUDINARY_API_KEY=123456789012345
CLOUDINARY_API_SECRET=abcDEFghiJKLmno_pqrSTU
```

### Cloudinary mein kya-kya store hoga:
- Student photos (`school/students/`)
- Teacher photos (`school/teachers/`)
- Event images (`school/events/`)
- School logo, banners, principal photo (`school/logo/`, etc.)

> ✅ Koi aur setting change karne ki zarurat nahi — code already configured hai!

---

---

# 📌 PART 4 — Razorpay Setup (Online Fee Payment)

## Test Mode (Pehle Ye Karo — Free)

1. Jao: **https://dashboard.razorpay.com/signup**
2. Email se register karo
3. Dashboard pe jao → Left menu: **Settings → API Keys**
4. "Generate Test Key" click karo
5. **Key ID** aur **Key Secret** copy karo

### .env mein likho (Test ke liye):
```env
RAZORPAY_KEY_ID=rzp_test_XXXXXXXXXXXXXXXX
RAZORPAY_KEY_SECRET=your_test_secret_here
```

---

## Live/Production Mode (Real Payments ke liye)

> ⚠️ Live mode ke liye Razorpay KYC complete karni hogi

### Steps:
1. Dashboard mein **"Activate Your Account"** pe click karo
2. Business details fill karo:
   - Business Type: Trust / Educational Institution
   - PAN card upload karo
   - Bank account details dalo
3. Approval mein 2-3 din lagte hain
4. Approve hone ke baad: **Settings → API Keys → "Generate Live Key"**
5. Live key copy karo

### .env mein badlo (Live ke liye):
```env
RAZORPAY_KEY_ID=rzp_live_XXXXXXXXXXXXXXXX
RAZORPAY_KEY_SECRET=your_live_secret_here
```

> ⚠️ Test key se real payment nahi hoti. Live key se hi actual paise aate hain.
> ✅ Code mein koi change nahi karna — sirf .env mein key badlo!

---

---

# 📌 PART 5 — WhatsApp Notifications Setup (Twilio)

**Khushkhabri:** WhatsApp configuration Admin Panel se hi hoti hai — koi code change nahi!

## Step 1 — Twilio Account Banao

1. Jao: **https://www.twilio.com/try-twilio**
2. Free account banao
3. Phone number verify karo
4. Dashboard pe ye cheezein milegi:
   - **Account SID** — `ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - **Auth Token** — `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

## Step 2 — WhatsApp Sandbox Activate Karo (Testing)

1. Twilio Console mein: **Messaging → Try it out → Send a WhatsApp message**
2. Ek WhatsApp number milega — e.g. `+1 415 523 8886`
3. Apne phone se us number pe "join <code>" message bhejo
4. Sandbox activate ho jayegi

## Step 3 — Admin Panel Se Configure Karo

> ✅ .env mein Twilio keys daalna **OPTIONAL** hai — Admin panel se bhi ho sakta hai!

### Admin Panel Route:
1. Login karo Admin Panel pe
2. Left menu mein **"WhatsApp"** section dhundo
3. Wahan fill karo:
   - Twilio Account SID
   - Twilio Auth Token
   - WhatsApp Number (format: `whatsapp:+14155238886`)
   - School Name, Phone, Payment Link
4. Save karo
5. "Send Test Message" se test karo

### Ya .env mein bhi daal sakte ho:
```env
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
```

## WhatsApp Business (Production) ke liye:
- Twilio pe "WhatsApp Business" upgrade karo (~$0.005/message)
- Meta Business Account link karna hoga
- Ye zyada reliable hai for production use

---

---

# 📌 PART 6 — JWT Secret Generate Karo

Ye ek random secret key hai jo login tokens ko secure karti hai.

### Method 1 — Online Generator:
Jao: **https://www.allkeysgenerator.com/Random/Security-Encryption-Key-Generator.aspx**
- 256-bit key generate karo
- Copy karo

### Method 2 — Command Line:
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

### .env mein likho:
```env
JWT_SECRET=a1b2c3d4e5f6...64characters...here
```

> ⚠️ Ye key kabhi kisi ko mat batao aur .env file commit mat karo!

---

---

# 📌 PART 7 — Complete .env Example (Sab Fill Karke)

```env
# ── Server ──────────────────────────────────────────────────────
PORT=3000
NODE_ENV=production

# ── MongoDB Atlas ────────────────────────────────────────────────
MONGO_URI=mongodb+srv://schooladmin:MyPass123@cluster0.abc123.mongodb.net/school_portal?retryWrites=true&w=majority

# ── JWT ─────────────────────────────────────────────────────────
JWT_SECRET=a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456
JWT_EXPIRES=8h

# ── Cloudinary ───────────────────────────────────────────────────
CLOUDINARY_CLOUD_NAME=my_school_cloud
CLOUDINARY_API_KEY=123456789012345
CLOUDINARY_API_SECRET=abcDEFghiJKLmno_pqrSTUvwx

# ── Razorpay (Test) ──────────────────────────────────────────────
RAZORPAY_KEY_ID=rzp_test_XXXXXXXXXXXXXXXX
RAZORPAY_KEY_SECRET=test_secret_here

# ── Frontend URL ─────────────────────────────────────────────────
FRONTEND_URL=https://yourschool.com
FRONTEND_URL_2=https://www.yourschool.com

# ── School Info ──────────────────────────────────────────────────
SCHOOL_NAME=Delhi Public School

# ── WhatsApp / Twilio (Optional) ─────────────────────────────────
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
```

---

---

# 📌 PART 8 — Hosting (Website Live Kaise Karo)

## 🥇 Option A — Railway.app (BEST — Free + Easy) ⭐ RECOMMENDED

**Free plan:** $5 credit/month — ek school portal ke liye kaafi hai!

### Steps:
1. Jao: **https://railway.app**
2. "Login with GitHub" karo
3. GitHub pe apna code upload karo (ya ZIP se bhi ho sakta hai)
4. Railway Dashboard pe: **"New Project → Deploy from GitHub"**
5. Apna repo select karo
6. **"Variables"** tab mein jao — sari .env values yahan add karo (ek-ek karke)
7. Railway automatically detect karega ki ye Node.js app hai
8. Deploy ho jayegi! Domain milega: `yourapp.railway.app`

### Custom Domain Lagana (e.g. yourschool.com):
1. Railway Dashboard → Settings → Domains
2. "Add Custom Domain" → apna domain type karo
3. Apne domain provider (GoDaddy/Namecheap) pe CNAME record add karo jo Railway bataye

---

## 🥈 Option B — Render.com (Free, Thoda Slow)

1. Jao: **https://render.com**
2. "New → Web Service"
3. GitHub repo connect karo
4. Settings:
   - Build Command: `npm install`
   - Start Command: `npm start`
5. Environment Variables tab mein sari .env values add karo
6. Deploy!

> ⚠️ Free plan pe server 15 min inactivity ke baad "sleep" ho jata hai — pehli request slow hogi

---

## 🥉 Option C — VPS Server (Full Control — Paid)

Agar aapke paas **DigitalOcean / Hostinger VPS / AWS EC2** hai:

```bash
# Server pe SSH karo, phir:

# 1. Node.js install karo
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. Project upload karo (ya git clone)
git clone https://github.com/yourname/school-portal.git
cd school-portal

# 3. Dependencies install karo
npm install

# 4. .env file banao
nano .env
# (sari values paste karo)

# 5. PM2 se permanently run karo (server restart pe bhi chale)
npm install -g pm2
pm2 start backend/server.js --name "school-portal"
pm2 save
pm2 startup

# 6. Nginx se port 80/443 pe expose karo (optional)
sudo apt install nginx
# Nginx config setup karo
```

---

## 🌐 Domain + SSL (HTTPS) Kaise Lagayen

### Domain Kharido:
- **GoDaddy.com** ya **Namecheap.com** pe `.com` ya `.in` domain lo (~₹800-1500/year)

### Free SSL (HTTPS):
- Railway aur Render automatically SSL dete hain ✅
- VPS pe: `sudo apt install certbot` + Let's Encrypt (free)

---

---

# 📌 Quick Reference — Kaunsi Service Kahan Se Milegi

| Service | Website | Free Plan | Kab Lagao |
|---|---|---|---|
| **MongoDB Atlas** | cloud.mongodb.com | ✅ 512MB free | Abhi (zaruri) |
| **Cloudinary** | cloudinary.com | ✅ 25GB free | Abhi (zaruri) |
| **Railway** (Hosting) | railway.app | ✅ $5/month free | Jab deploy karna ho |
| **Razorpay** (Payment) | razorpay.com | ✅ Test free | Jab fees leni ho |
| **Twilio** (WhatsApp) | twilio.com | ✅ Trial free | Jab notifications chahiye |
| **Domain** | godaddy.com | ❌ ~₹800/year | Jab custom URL chahiye |

---

# ✅ Checklist — Sab Sahi Se Lagao

- [ ] MongoDB Atlas cluster banaya
- [ ] Cloudinary account banaya, 3 keys copy kiye
- [ ] `.env` file banai (`.env.example` se copy karke)
- [ ] JWT secret generate kiya (64 char random)
- [ ] `npm install` chalaaya
- [ ] `npm run seed` chalaaya (demo data ke liye)
- [ ] `npm start` se locally test kiya
- [ ] Railway/Render pe deploy kiya
- [ ] Sari .env variables hosting platform pe add ki
- [ ] Custom domain connect kiya (optional)
- [ ] Admin panel se login kiya, password badla
- [ ] WhatsApp settings admin panel se configure ki

---

*School Portal v2.4.0 — Setup Guide*
