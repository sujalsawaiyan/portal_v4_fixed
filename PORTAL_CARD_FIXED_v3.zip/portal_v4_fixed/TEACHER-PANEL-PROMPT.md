# ST. ANN'S SCHOOL PORTAL — Teacher Panel Implementation Prompt

## Project Overview

Full teacher portal for St. Ann's School management system.  
Stack: Node.js + Express + MongoDB (Mongoose).  
Frontend: Vanilla HTML/CSS/JS — same pink glassmorphism theme as admin panel.

---

## New Files Added

| File | Purpose |
|------|---------|
| `backend/models/TeacherAccount.js` | Teacher login accounts (username/password/class assignment) |
| `backend/models/Marks.js` | Student subject marks with auto % + grade calculation |
| `backend/models/Discipline.js` | Student behavior/discipline records |
| `backend/routes/teacher-panel.js` | All `/api/teacher/*` routes |
| `teacher_panel/login.html` | Teacher login page |
| `teacher_panel/dashboard.html` | Full teacher dashboard (5 sections) |

## Modified Files

| File | Change |
|------|--------|
| `backend/server.js` | Mount `/api/teacher` route |
| `admin_panel/dashboard.html` | Added Teacher Accounts section + nav item |
| `admin_panel/js/dashboard-patch.js` | Teacher account CRUD functions |

---

## Data Models

### TeacherAccount
```
username        String (unique, lowercase) — login ID
password        String (bcrypt hashed)
fullName        String
email           String
phone           String
photo           String (URL)
assignedClass   String  — "1" to "12", "LKG", "UKG"
assignedSection String  — "A" or "B"
subjects        [String]
role            "teacher"
isActive        Boolean
lastLogin       Date
```

### Marks
```
studentId           String (indexed)
class               String
section             String
subject             String (teacher writes freely)
term                String — "Term1" | "Term2" | "Annual"
academicYear        String — "2025-26"
marksObtained       Number
maxMarks            Number (default 100)
practicalObtained   Number (default 0)
maxPractical        Number (default 0)
totalObtained       Number (auto = theory + practical)
totalMax            Number (auto = maxMarks + maxPractical)
percentage          Number (auto = totalObtained/totalMax × 100)
grade               String (auto: A+/A/B+/B/C+/C/D/F)
gradePoint          Number (auto: 10/9/8/7/6/5/4/0)
remarks             String
enteredBy           String (teacher username)
```
**Grade Scale:**
- A+ = 91–100%, A = 81–90%, B+ = 71–80%, B = 61–70%
- C+ = 51–60%, C = 41–50%, D = 33–40%, F = below 33%

### Discipline
```
studentId     String
studentName   String
class/section String
date          String (YYYY-MM-DD)
academicYear  String
type          "positive" | "negative" | "neutral"
category      "Behavior"|"Punctuality"|"Academics"|"Sports"|"Cleanliness"|"Respect"|"Teamwork"|"General"
description   String
points        Number (+ve = good, -ve = bad)
recordedBy    String (teacher username)
```

---

## API Routes — `/api/teacher/*`

### Public (no auth needed)
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/login` | Teacher login → JWT token |

### Teacher Auth Required (`role: 'teacher'`)
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/me` | Teacher profile |
| GET | `/class/students` | All students in assigned class |
| GET | `/attendance?date=` | Attendance for assigned class on date |
| POST | `/attendance/mark` | Mark attendance (bulk) |
| GET | `/marks/subjects` | List subjects used for this class (autocomplete) |
| GET | `/marks?subject=&term=` | Marks for all students in subject |
| POST | `/marks/save` | Save marks (bulk upsert, auto % + grade) |
| GET | `/marks/report?studentId=&term=` | Full marks for one student |
| GET | `/discipline` | Discipline records for class |
| POST | `/discipline/add` | Add discipline record |
| DELETE | `/discipline/:id` | Delete own record |
| GET | `/reports/attendance/monthly?month=` | Monthly summary |
| GET | `/overview` | Dashboard stats |

### Admin Auth Required (`role: 'admin'`)
| Method | Route | Description |
|--------|-------|-------------|
| POST | `/admin/create` | Create teacher account |
| GET | `/admin/list` | List all teacher accounts |
| PUT | `/admin/update/:id` | Update teacher account |
| DELETE | `/admin/delete/:id` | Delete teacher account |

---

## Teacher Dashboard Sections

### 1. Overview
- Greeting by time of day
- 4 stat cards: Total Students, Present Today, Absent Today, Subjects Entered
- Today's attendance summary pills
- Quick links to Attendance and Marks pages

### 2. My Class
- Class teacher profile card (photo, name, class, email)
- Student search/filter
- Student grid: avatar initial, name, roll, gender, house

### 3. Attendance
- Date picker with ◀ Prev / ▶ Next / Today buttons
- Student grid cards with P / A / L toggle buttons
- Color: P = green card, A = red card, L = yellow card
- Summary pills: Present N, Absent N, Late N, Not marked N, %
- ✅ All Present | ❌ All Absent | 💾 Save buttons
- Saves to MongoDB via `/api/teacher/attendance/mark`

### 4. Marks & Results
- Subject name input (free text, teacher writes subject name)
  - Datalist autocomplete from previously used subjects
- Term selector (Term 1 / Term 2 / Annual)
- Max Theory Marks + Max Practical Marks (0 = no practical)
- Marks table per student:
  - Roll | Name | Theory input | Practical input | Total (auto) | % (auto) | Grade (auto) | Remarks
  - Live calculation on every keystroke
  - Color-coded % bar below percentage
  - Grade pill color: A+=green, B=blue, C=yellow, D=orange, F=red
- Class average shown in header
- 💾 Save All Marks → bulk upsert to MongoDB

### 5. Discipline
- Add Record form: Student, Date, Type (⭐Positive/⚠Negative/📝Neutral), Category, Points, Description
- Records list with filter by student
- Each record shows: type badge, category, student name, description, points, date
- 🗑 Delete button (own records only)

### 6. Reports
- Monthly Attendance Report with month picker
- Table: Roll, Name, Present, Absent, Late, Total, %, Status emoji
- Low attendance alert: count of students below 75%
- ⬇ CSV Export button

---

## Admin Panel — Teacher Accounts Management

New section "🔑 Teacher Accounts" in admin sidebar.

Features:
- List all teacher accounts (name, username, assigned class, active status, last login)
- ➕ Create Account: fullName, username, password, class, section, email, phone
- ✏ Edit Account: update any field, reset password (leave blank = keep)
- 🗑 Delete Account: with confirmation

Admin must create teacher accounts before teachers can login.

---

## Teacher Login Flow

1. Teacher goes to `/teacher_panel/login.html`
2. Enters username + password
3. POST `/api/teacher/login` → returns JWT token
4. Token stored in `localStorage.getItem('teacher_token')`
5. Redirect to `dashboard.html`
6. On every API call: `Authorization: Bearer <token>`
7. Token expires in 8 hours → auto redirect to login

---

## Subject System

- **Free-text input** — teacher types any subject name
- Past subjects for the class auto-suggest via `<datalist>` (from MongoDB Marks.distinct)
- No predefined list — works for any country's curriculum
- Subject names are stored exactly as typed (e.g., "Mathematics", "Hindi", "Science", "Art & Craft")

---

## Constraints

1. No localStorage for any academic data — MongoDB only
2. Teacher can only see/edit their own assigned class
3. Admin can see all data and manage teacher accounts
4. Marks auto-calculate on every input (live, no submit needed for preview)
5. Attendance uses same Attendance model as admin panel (fully compatible)
6. Grades follow Indian CBSE-style scale (A+/A/B+/B/C+/C/D/F)
7. Academic year: April to March (auto-detected from date)
