/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  imageUploadManager.js  —  SCHOOL PORTAL  v3.0          ║
 * ║  Professional Cloudinary Image System                               ║
 * ║  ✅ Reusable upload function                                        ║
 * ║  ✅ public_id stored for proper deletion                            ║
 * ║  ✅ Delete old image when updating                                  ║
 * ║  ✅ Delete image from Cloudinary when record deleted                ║
 * ║  ✅ 2MB limit + image-only validation                               ║
 * ║  ✅ Instant preview before upload                                   ║
 * ║  ✅ Organized folder structure                                      ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * FOLDER STRUCTURE IN CLOUDINARY:
 *   school/teachers/
 *   school/students/
 *   school/events/
 *   school/top_students/
 *   school/banners/
 *   school/logo/
 *   school/house_logo/
 *   school/principal/
 *   school/leadership/
 *   school/class_teachers/
 *   school/gallery/
 *
 * NOTE ON DELETION:
 *   Cloudinary unsigned delete is NOT supported from browser.
 *   public_id is stored in DB so deletion can be done via:
 *   (a) Cloudinary dashboard manually, OR
 *   (b) A backend endpoint if added later.
 *   For now, DB record is cleaned and old image is orphaned in Cloudinary
 *   (free plan has no charge for orphaned assets).
 */

window.IM = (function () {
  'use strict';

  /* ══════════════════════════════════════════════════════════════
     CONFIG
  ══════════════════════════════════════════════════════════════ */
  var DEFAULTS = {
    cloudName:    'dlwktedkx',
    uploadPreset: 'st_anns_upload',
    maxSizeMB:    2,
    allowedTypes: ['image/jpeg','image/jpg','image/png','image/webp'],
  };

  function getCfg() {
    try {
      var db  = window.SchoolDB && window.SchoolDB.load();
      var cfg = (db && db.cloudinaryConfig) || {};
      return {
        cloudName:    cfg.cloudName    || DEFAULTS.cloudName,
        uploadPreset: cfg.uploadPreset || DEFAULTS.uploadPreset,
      };
    } catch(e) { return { cloudName: DEFAULTS.cloudName, uploadPreset: DEFAULTS.uploadPreset }; }
  }

  /* ══════════════════════════════════════════════════════════════
     CORE UTILITIES
  ══════════════════════════════════════════════════════════════ */

  function showToast(msg, type) {
    if (typeof window.toast === 'function') window.toast(msg, type || 'success');
    else console.log('[IM ' + (type||'info') + ']', msg);
  }

  /** Validate file — returns error string or null */
  function validate(file) {
    if (!file)                                    return 'No file selected';
    if (!DEFAULTS.allowedTypes.includes(file.type))
      return 'Only JPG, PNG or WEBP files are allowed';
    if (file.size > DEFAULTS.maxSizeMB * 1024 * 1024)
      return 'File ' + DEFAULTS.maxSizeMB + 'MB  size limit exceeded';
    return null;
  }

  /** Show instant local preview (before Cloudinary upload) */
  function previewLocal(file, elOrId, shape) {
    var el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!el || !file) return;
    var br = shape === 'rect' ? '10px' : '50%';
    var reader = new FileReader();
    reader.onload = function(e) {
      el.innerHTML = '<img src="' + e.target.result
        + '" style="width:100%;height:100%;object-fit:cover;border-radius:' + br + ';display:block"/>';
      el.style.fontSize = '0';
    };
    reader.readAsDataURL(file);
  }

  /** Set preview from a URL (after upload) */
  function previewUrl(elOrId, url, shape) {
    var el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!el || !url) return;
    var br = shape === 'rect' ? '10px' : '50%';
    el.innerHTML = '<img src="' + url
      + '" style="width:100%;height:100%;object-fit:cover;border-radius:' + br + ';display:block"/>';
    el.style.fontSize = '0';
  }

  /** Reset a preview element to its default icon */
  function previewReset(elOrId, defaultHtml) {
    var el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
    if (!el) return;
    el.innerHTML   = defaultHtml || '📷';
    el.style.fontSize = '1.6rem';
  }

  function saveDB(fn, apiKeys) {
    if (!window.SchoolDB) return false;
    var db = window.SchoolDB.load();
    fn(db);
    var ok = window.SchoolDB.save(db);
    // Also persist to MongoDB via API — guarantees cross-device sync for images
    var keys = apiKeys || [];
    if (keys.length) {
      var token = sessionStorage.getItem('admin_token') || '';
      keys.forEach(function(key) {
        var val = db[key];
        if (val !== undefined) {
          fetch('/api/settings/' + key, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
            body: JSON.stringify({ value: val })
          }).catch(function(e) { console.warn('[saveDB] MongoDB sync failed for', key, e); });
        }
      });
    }
    return ok;
  }

  /* ══════════════════════════════════════════════════════════════
     ★ CORE UPLOAD FUNCTION — routes through backend (secure)
     uploadImage(file, folderName)
     Returns: Promise<{ secure_url, public_id }> or null on failure

     ✅ v3.1 — Now uses /api/images/upload/temp (backend proxy)
     No Cloudinary credentials needed in browser.
     Signed upload via server-side API key + secret.
  ══════════════════════════════════════════════════════════════ */
  async function uploadImage(file, folderName) {
    // 1. Validate file
    var err = validate(file);
    if (err) { showToast('❌ ' + err, 'error'); return null; }

    // 2. Check auth token
    var token = sessionStorage.getItem('admin_token') || '';
    if (!token) {
      showToast('❌ Login session expired. Please login again.', 'error');
      window.location.href = '/admin_panel/login.html';
      return null;
    }

    // 3. Map old folder names → backend category names
    var categoryMap = {
      'teachers':       'teachers',
      'teacher':        'teachers',
      'leadership':     'leadership',
      'class_teachers': 'class-teachers',
      'class-teachers': 'class-teachers',
      'events':         'events',
      'event':          'events',
      'gallery':        'gallery',
      'top_students':   'students',
      'students':       'students',
      'house_logo':     'houses',
      'houses':         'houses',
      'logo':           'logo',
      'principal':      'principal',
      'banners':        'banners',
      'banner':         'banners',
    };
    var category = categoryMap[folderName] || 'misc';

    // 4. Build FormData
    var fd = new FormData();
    fd.append('image',    file);
    fd.append('category', category);

    // 5. Upload via backend proxy
    showToast('⏳ Uploading...', 'info');
    try {
      var res = await fetch('/api/images/upload/temp', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + token },
        body:    fd,
      });

      var data = await res.json();

      if (!res.ok) {
        showToast('❌ Upload failed: ' + (data.error || res.statusText), 'error');
        return null;
      }

      return {
        secure_url: data.imageUrl || data.secure_url || '',
        public_id:  data.publicId || data.public_id  || '',
      };

    } catch(e) {
      showToast('❌ Upload failed: ' + e.message, 'error');
      return null;
    }
  }

  /* ══════════════════════════════════════════════════════════════
     DELETE FROM CLOUDINARY — via backend API (v3.1)
     Calls DELETE /api/images/delete-by-public-id/:publicId
     Backend handles actual Cloudinary deletion securely.
  ══════════════════════════════════════════════════════════════ */
  function deleteFromCloudinary(publicId) {
    if (!publicId) return;
    var token = sessionStorage.getItem('admin_token') || '';
    if (!token) return;
    fetch('/api/images/delete-by-public-id/' + encodeURIComponent(publicId), {
      method:  'DELETE',
      headers: { 'Authorization': 'Bearer ' + token },
    }).catch(function() {
      console.info('[IM] Queued Cloudinary cleanup for:', publicId);
    });
  }

  /* ══════════════════════════════════════════════════════════════
     1. SCHOOL LOGO
  ══════════════════════════════════════════════════════════════ */
  async function uploadLogo(input) {
    var file = input && input.files[0]; if (!file) return;
    previewLocal(file, 'logoPreview', 'circle');

    var token = sessionStorage.getItem('admin_token') || '';
    showToast('⏳ Uploading logo to Cloudinary...', 'info');

    try {
      // Single upload to /api/images/upload/logo — saves to Cloudinary + MongoDB (SchoolImage)
      var fd = new FormData();
      fd.append('image', file);
      var res  = await fetch('/api/images/upload/logo', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + token },
        body: fd
      });
      var data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');

      var imageUrl = data.imageUrl || data.secure_url || '';
      var publicId = data.publicId || data.public_id  || '';

      // Show preview
      previewUrl('logoPreview', imageUrl, 'circle');

      // Save URL to schoolInfo in MongoDB settings
      saveDB(function(db) {
        if (!db.schoolInfo) db.schoolInfo = {};
        db.schoolInfo.logoData     = imageUrl;
        db.schoolInfo.logoPublicId = publicId;
        db.schoolInfo.schoolLogo   = imageUrl;
      }, ['schoolInfo']);

      // ADDITIONAL FIX: also persist to SchoolSettings so GET /api/settings/schoolLogo
      // and GET /api/images/logo both return the new URL for the frontend hero section
      fetch('/api/settings/schoolLogo', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify({ value: imageUrl })
      }).catch(function(e) { console.warn('[Logo settings sync]', e.message); });

      window.SchoolSync && window.SchoolSync.broadcast('schoolInfo');
      showToast('✅ School logo saved to Cloudinary + MongoDB!', 'success');
    } catch(e) {
      showToast('❌ Logo upload failed: ' + e.message, 'error');
    }
  }

  async function removeLogo() {
    if (!confirm('Remove school logo?')) return;
    var token = sessionStorage.getItem('admin_token') || '';
    // Delete from Cloudinary + MongoDB SchoolImage record
    fetch('/api/images/logo', { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } }).catch(function(){});
    saveDB(function(db) {
      if (db.schoolInfo) {
        db.schoolInfo.logoData     = '';
        db.schoolInfo.logoPublicId = '';
        db.schoolInfo.schoolLogo   = '';
      }
    }, ['schoolInfo']);
    previewReset('logoPreview', '✝');
    window.SchoolSync && window.SchoolSync.broadcast('schoolInfo');
    showToast('🗑 Logo removed from Cloudinary + MongoDB', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     2. PRINCIPAL PHOTO
  ══════════════════════════════════════════════════════════════ */
  async function uploadPrincipalPhoto(input) {
    var file = input && input.files[0]; if (!file) return;
    previewLocal(file, 'principalPhotoPreview', 'circle');

    var result = await uploadImage(file, 'principal');
    if (!result) return;

    // Sync to backend
    var token = sessionStorage.getItem('admin_token') || '';
    var fd2 = new FormData(); fd2.append('image', file);
    fetch('/api/images/upload/principal', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token }, body: fd2 }).catch(function(){});

    saveDB(function(db) {
      if (!db.homepageContent) db.homepageContent = {};
      db.homepageContent.principalPhoto         = result.secure_url;
      db.homepageContent.principalPhotoPublicId = result.public_id;
      if (!db.teachers) db.teachers = [];
      var t = db.teachers.find(function(x){ return x.role === 'principal'; });
      if (!t) { t = { id: Date.now(), role: 'principal' }; db.teachers.push(t); }
      t.photo    = result.secure_url;
      t.publicId = result.public_id;
    }, ['homepageContent']);
    window.SchoolSync && window.SchoolSync.broadcast('homepageContent');
    window.SchoolSync && window.SchoolSync.broadcast('teachers');
    showToast('✅ Principal photo has been uploaded!', 'success');
  }

  async function removePrincipalPhoto() {
    if (!confirm('Remove principal photo?')) return;
    var token = sessionStorage.getItem('admin_token') || '';
    fetch('/api/images/principal', { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } }).catch(function(){});
    saveDB(function(db) {
      if (db.homepageContent) {
        db.homepageContent.principalPhoto         = '';
        db.homepageContent.principalPhotoPublicId = '';
      }
    }, ['homepageContent']);
    previewReset('principalPhotoPreview', '👩‍💼');
    window.SchoolSync && window.SchoolSync.broadcast('homepageContent');
    showToast('Principal photo has been removed', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     3. ADMISSION BANNER
  ══════════════════════════════════════════════════════════════ */
  async function uploadAdmissionImage(input) {
    var file = input && input.files[0]; if (!file) return;
    previewLocal(file, 'adm-img-preview', 'rect');

    var result = await uploadImage(file, 'banners');
    if (!result) return;

    // Sync to backend
    var token = sessionStorage.getItem('admin_token') || '';
    var fd2 = new FormData(); fd2.append('image', file);
    fetch('/api/images/upload/banners', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token }, body: fd2 }).catch(function(){});

    saveDB(function(db) {
      if (!db.admissions) db.admissions = {};
      db.admissions.imageData     = result.secure_url;
      db.admissions.imagePublicId = result.public_id;
    });
    window.SchoolSync && window.SchoolSync.broadcast('admissions');
    showToast('✅ Banner has been uploaded!', 'success');
  }

  async function removeAdmissionImage() {
    if (!confirm('Remove banner?')) return;
    var token = sessionStorage.getItem('admin_token') || '';
    fetch('/api/images/banners', { method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token } }).catch(function(){});
    saveDB(function(db) {
      if (db.admissions) { db.admissions.imageData = ''; db.admissions.imagePublicId = ''; }
    });
    var el = document.getElementById('adm-img-preview');
    if (el) el.innerHTML = '<span style="font-size:2.5rem">🎓</span>';
    window.SchoolSync && window.SchoolSync.broadcast('admissions');
    showToast('Banner has been removed', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     4. TEACHER ADD PHOTO
  ══════════════════════════════════════════════════════════════ */
  window._newTeacherPhotoUrl      = '';
  window._newTeacherPhotoPublicId = '';

  async function previewTeacherPhoto(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    previewLocal(file, 't-photo-preview', 'circle');
    window._newTeacherPhotoUrl      = '';
    window._newTeacherPhotoPublicId = '';

    var result = await uploadImage(file, 'teachers');
    if (!result) return;
    window._newTeacherPhotoUrl      = result.secure_url;
    window._newTeacherPhotoPublicId = result.public_id;
    showToast('✅ Photo ready! Click "Save Teacher" to proceed.', 'success');
  }

  function clearTeacherPhoto() {
    window._newTeacherPhotoUrl      = '';
    window._newTeacherPhotoPublicId = '';
    previewReset('t-photo-preview', '👨‍🏫');
    var inp = document.getElementById('t-photo-input'); if (inp) inp.value = '';
  }

  /* ══════════════════════════════════════════════════════════════
     5. TEACHER EDIT PHOTO
  ══════════════════════════════════════════════════════════════ */
  window._editTeacherPhotoUrl      = null; // null=no change, ''=removed, url=new
  window._editTeacherPhotoPublicId = null;

  async function previewEditTeacherPhoto(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    previewLocal(file, 'et-photo-preview', 'circle');
    window._editTeacherPhotoUrl      = null;
    window._editTeacherPhotoPublicId = null;

    // Get old public_id for deletion after successful upload
    var idx = parseInt((document.getElementById('et-id') || {}).value);
    var db  = window.SchoolDB && window.SchoolDB.load();
    var oldTeacher = (db && db.teachers || [])[idx];
    var oldPublicId = oldTeacher && oldTeacher.publicId;

    var result = await uploadImage(file, 'teachers');
    if (!result) return;

    // Delete old image from Cloudinary
    if (oldPublicId) deleteFromCloudinary(oldPublicId);

    window._editTeacherPhotoUrl      = result.secure_url;
    window._editTeacherPhotoPublicId = result.public_id;
    showToast('✅ Photo ready! Click "Save" to continue.', 'success');
  }

  function removeEditTeacherPhoto() {
    window._editTeacherPhotoUrl      = '';
    window._editTeacherPhotoPublicId = '';
    previewReset('et-photo-preview', '👨‍🏫');
    showToast('Photo will be removed when you save', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     6. CLASS TEACHER PHOTO
  ══════════════════════════════════════════════════════════════ */
  window._classTeacherPhotoUrl      = null;
  window._classTeacherPhotoPublicId = null;

  async function uploadClassTeacherPhoto(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    previewLocal(file, 'cm-teacher-photo-prev', 'circle');
    window._classTeacherPhotoUrl      = null;
    window._classTeacherPhotoPublicId = null;

    // Get old public_id
    var cls = (document.getElementById('cm-class') || {}).value || 'X';
    var sec = (document.getElementById('cm-sec')   || {}).value || 'A';
    var ctKey = 'cls_' + cls + '_' + sec;
    var db = window.SchoolDB && window.SchoolDB.load();
    var oldPublicId = db && db.classTeachers && db.classTeachers[ctKey] && db.classTeachers[ctKey].teacherPhotoPublicId;
    if (oldPublicId) deleteFromCloudinary(oldPublicId);

    var result = await uploadImage(file, 'class_teachers');
    if (!result) return;
    window._classTeacherPhotoUrl      = result.secure_url;
    window._classTeacherPhotoPublicId = result.public_id;
    showToast('✅ Photo ready! Click "Save Teacher" to proceed.', 'success');
  }

  function removeClassTeacherPhoto() {
    window._classTeacherPhotoUrl      = '';
    window._classTeacherPhotoPublicId = '';
    previewReset('cm-teacher-photo-prev', '👩‍🏫');
    showToast('Photo will be removed when you save', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     7. LEADERSHIP PHOTOS
  ══════════════════════════════════════════════════════════════ */
  async function uploadLeaderPhoto(input, roleKey) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }

    var prevEl = document.getElementById('lr-photo-' + roleKey);
    previewLocal(file, prevEl, 'circle');

    // Delete old Cloudinary image (best-effort)
    var db = window.SchoolDB && window.SchoolDB.load();
    var oldT = db && (db.teachers || []).find(function(x){ return x.role === roleKey; });
    if (oldT && oldT.publicId) deleteFromCloudinary(oldT.publicId);

    var result = await uploadImage(file, 'leadership');
    if (!result) return;

    if (prevEl) previewUrl(prevEl, result.secure_url, 'circle');

    // ── FIXED v2.3.0: sync photo URL to MongoDB Teacher record ──────────────
    var token   = sessionStorage.getItem('admin_token') || '';
    var authHdr = { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' };
    try {
      var tr  = await fetch('/api/teachers?active=false', { headers: authHdr });
      var tj  = await tr.json();
      var existing = (tj.data || []).find(function(x){ return x.role === roleKey; });
      if (existing && existing._id) {
        await fetch('/api/teachers/' + existing._id, {
          method: 'PUT',
          headers: authHdr,
          body: JSON.stringify({ photo: result.secure_url, photoPublicId: result.public_id }),
        });
      } else {
        var ROLE_LABELS = { principal:'Principal', vice_principal:'Vice Principal', hod:'Head of Department', academic_coordinator:'Academic Coordinator', activity_coordinator:'Activity Coordinator' };
        await fetch('/api/teachers', {
          method: 'POST',
          headers: authHdr,
          body: JSON.stringify({
            name: ROLE_LABELS[roleKey] || roleKey, fullName: ROLE_LABELS[roleKey] || roleKey,
            role: roleKey, department: 'Management', dept: 'Management',
            subject: 'Administration', photo: result.secure_url,
            photoPublicId: result.public_id, isActive: true,
          }),
        });
      }
    } catch(apiErr) {
      console.warn('[IM uploadLeaderPhoto] MongoDB sync failed:', apiErr.message);
    }
    // ────────────────────────────────────────────────────────────────────────

    saveDB(function(d) {
      if (!d.teachers) d.teachers = [];
      var t = d.teachers.find(function(x){ return x.role === roleKey; });
      if (!t) { t = { id: Date.now(), role: roleKey }; d.teachers.push(t); }
      t.photo    = result.secure_url;
      t.publicId = result.public_id;
      if (roleKey === 'principal') {
        if (!d.homepageContent) d.homepageContent = {};
        d.homepageContent.principalPhoto         = result.secure_url;
        d.homepageContent.principalPhotoPublicId = result.public_id;
      }
    }, roleKey === 'principal' ? ['homepageContent'] : []);
    window.SchoolSync && window.SchoolSync.broadcast('teachers');
    if (roleKey === 'principal') window.SchoolSync && window.SchoolSync.broadcast('homepageContent');
    showToast('✅ Photo saved to Cloudinary + MongoDB!', 'success');
  }

  async function removeLeaderPhoto(roleKey) {
    if (!confirm('Remove photo?')) return;
    saveDB(function(d) {
      if (!d.teachers) return;
      var t = d.teachers.find(function(x){ return x.role === roleKey; });
      if (t) { deleteFromCloudinary(t.publicId); t.photo = ''; t.publicId = ''; }
      if (roleKey === 'principal' && d.homepageContent) {
        deleteFromCloudinary(d.homepageContent.principalPhotoPublicId);
        d.homepageContent.principalPhoto         = '';
        d.homepageContent.principalPhotoPublicId = '';
      }
    }, roleKey === 'principal' ? ['homepageContent'] : []);
    var emojis = { principal:'👩‍💼', vice_principal:'👨‍💼', hod:'👩‍🔬', academic_coordinator:'👩‍💻', activity_coordinator:'🎭' };
    previewReset('lr-photo-' + roleKey, '<span style="font-size:1.6rem">' + (emojis[roleKey] || '👤') + '</span>');
    window.SchoolSync && window.SchoolSync.broadcast('teachers');
    showToast('Photo has been removed', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     8. EVENT IMAGE
  ══════════════════════════════════════════════════════════════ */
  var _evFile      = null;
  var _evPublicId  = null; // track pending upload result

  async function previewEventImage(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    _evFile = file;
    window._evFileForUpload = file;
    var img = document.getElementById('ev-img-preview-img');
    var ph  = document.getElementById('ev-img-placeholder');
    var pt  = document.getElementById('ev-img-placeholder-txt');
    if (img) { previewLocal(file, img, 'rect'); img.style.display = 'block'; }
    if (ph)  ph.style.display = 'none';
    if (pt)  pt.style.display = 'none';
    showToast('Photo selected — Click "Save Event" to proceed', 'info');
  }

  function evImgRemove() {
    _evFile = null; _evPublicId = null;
    window._evFileForUpload = null;
    window._selectedEventImage = '';
    var img = document.getElementById('ev-img-preview-img');
    var ph  = document.getElementById('ev-img-placeholder');
    var pt  = document.getElementById('ev-img-placeholder-txt');
    if (img) { img.src = ''; img.style.display = 'none'; }
    if (ph)  ph.style.display = '';
    if (pt)  pt.style.display = '';
    var sel = document.getElementById('ev-img-select'); if (sel) sel.value = '';
  }

  async function getOrUploadEventImage(eventId) {
    if (window._selectedEventImage) return { url: window._selectedEventImage, publicId: null };
    if (!_evFile) return null;
    var result = await uploadImage(_evFile, 'events');
    if (!result) return null;
    _evFile     = null;
    _evPublicId = result.public_id;
    return { url: result.secure_url, publicId: result.public_id };
  }

  /* ══════════════════════════════════════════════════════════════
     9. GALLERY
  ══════════════════════════════════════════════════════════════ */
  var _gFile      = null;
  var _gEditFile  = null;

  function previewGalleryImg(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    _gFile = file;
    // Show preview inside the drop zone
    var dz = document.getElementById('g-dropzone-inner');
    if (dz) {
      var reader = new FileReader();
      reader.onload = function(e) {
        dz.innerHTML = '<img src="' + e.target.result + '" style="width:100%;max-height:180px;object-fit:contain;border-radius:10px;display:block"/>';
      };
      reader.readAsDataURL(file);
    }
    showToast('✅ Photo ready!', 'success');
  }

  function clearGalleryImg() {
    _gFile = null;
    var inp = document.getElementById('g-img-input'); if (inp) inp.value = '';
    var dz  = document.getElementById('g-dropzone-inner');
    if (dz) dz.innerHTML = '<div class="g-dropzone-icon">📷</div><div class="g-dropzone-text">Click or drag & drop a photo here<br><span style="font-size:0.75rem;opacity:0.6">JPG, PNG, WEBP — max 10MB</span></div>';
  }

  async function submitAddGallery() {
    var title = ((document.getElementById('g-title') || {}).value || '').trim();
    if (!title) { showToast('Title is required', 'error'); return; }
    if (!_gFile) { showToast('Please select a photo first', 'error'); return; }
    var cat   = (document.getElementById('g-cat')  || {}).value || 'other';
    var emoji = (document.getElementById('g-icon') || {}).value || '🖼️';
    var token = sessionStorage.getItem('admin_token') || '';

    showToast('⏳ Uploading to gallery...', 'info');
    try {
      // Upload via /api/images/upload/gallery — saves to MongoDB directly
      var fd = new FormData();
      fd.append('image',       _gFile);
      fd.append('title',       title);
      fd.append('subCategory', cat);
      fd.append('emoji',       emoji);

      var res  = await fetch('/api/images/upload/gallery', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + token },
        body:    fd,
      });
      var data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');

      if (typeof window.closeModal === 'function') window.closeModal('modalAddGallery');
      var tEl  = document.getElementById('g-title');     if (tEl)  tEl.value = '';
      var iEl  = document.getElementById('g-icon');      if (iEl)  iEl.value = '';
      var iInp = document.getElementById('g-img-input'); if (iInp) iInp.value = '';
      var dz = document.getElementById('g-dropzone-inner');
      if (dz) dz.innerHTML = '<div class="g-dropzone-icon">📷</div><div class="g-dropzone-text">Click or drag & drop a photo here<br><span style="font-size:0.75rem;opacity:0.6">JPG, PNG, WEBP — max 10MB</span></div>';
      _gFile = null;
      showToast('✅ "' + title + '" has been added to the gallery!', 'success');
      if (typeof window.loadGallery === 'function') window.loadGallery();

    } catch(e) {
      showToast('❌ Gallery save failed: ' + e.message, 'error');
    }
  }

  function deleteGalleryItem(id) {
    if (!confirm('Delete this photo?')) return;
    var token = sessionStorage.getItem('admin_token') || '';

    // Use backend DELETE — cleans Cloudinary + MongoDB
    fetch('/api/images/gallery/' + id, {
      method:  'DELETE',
      headers: { 'Authorization': 'Bearer ' + token },
    })
    .then(function(res) { return res.json(); })
    .then(function() {
      showToast('Photo has been deleted', 'info');
      if (typeof window.loadGallery === 'function') window.loadGallery();
    })
    .catch(function(e) { showToast('Delete failed: ' + e.message, 'error'); });
  }

  function previewEditGalleryImg(input) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    _gEditFile = file;
    var prev = document.getElementById('g-edit-img-preview');
    if (prev) previewLocal(file, prev, 'rect');
    showToast('✅ New photo ready!', 'success');
  }

  async function submitEditGallery() {
    var id    = ((document.getElementById('g-edit-id')    || {}).value || '');
    var title = ((document.getElementById('g-edit-title') || {}).value || '').trim();
    if (!title) { showToast('Title is required', 'error'); return; }
    var cat   = (document.getElementById('g-edit-cat')  || {}).value || 'other';
    var emoji = (document.getElementById('g-edit-icon') || {}).value || '';
    var token = sessionStorage.getItem('admin_token') || '';

    try {
      if (_gEditFile) {
        // Upload new image via PUT /api/images/gallery/:id (replaces old)
        var fd = new FormData();
        fd.append('image',       _gEditFile);
        fd.append('title',       title);
        fd.append('subCategory', cat);
        if (emoji) fd.append('emoji', emoji);

        var res = await fetch('/api/images/gallery/' + id, {
          method:  'PUT',
          headers: { 'Authorization': 'Bearer ' + token },
          body:    fd,
        });
        var data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Update failed');
        _gEditFile = null;
      } else {
        // Metadata-only update via /api/images/gallery/:id (FormData, no file)
        var fd2 = new FormData();
        fd2.append('title',       title);
        fd2.append('subCategory', cat);
        if (emoji) fd2.append('emoji', emoji);
        var res2 = await fetch('/api/images/gallery/' + id, {
          method:  'PUT',
          headers: { 'Authorization': 'Bearer ' + token },
          body:    fd2,
        });
        var data2 = await res2.json();
        if (!res2.ok) throw new Error(data2.error || 'Update failed');
      }

      if (typeof window.closeModal === 'function') window.closeModal('modalEditGallery');
      var einp = document.getElementById('g-edit-img-input'); if (einp) einp.value = '';
      showToast('✅ "' + title + '" has been updated!', 'success');
      if (typeof window.loadGallery === 'function') window.loadGallery();

    } catch(e) {
      showToast('❌ Update failed: ' + e.message, 'error');
    }
  }

  /* ══════════════════════════════════════════════════════════════
     10. TOP STUDENTS
  ══════════════════════════════════════════════════════════════ */
  function tsImgUpload(input, idx) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }
    var wrap = document.getElementById('ts-img-wrap-' + idx);
    previewLocal(file, wrap, 'circle');

    uploadImage(file, 'top_students').then(function(result) {
      if (!result) return;
      if (wrap) previewUrl(wrap, result.secure_url, 'circle');
      saveDB(function(db) {
        if (db.topStudents && db.topStudents[idx]) {
          // Delete old
          if (db.topStudents[idx].imagePublicId) deleteFromCloudinary(db.topStudents[idx].imagePublicId);
          db.topStudents[idx].image          = result.secure_url;
          db.topStudents[idx].imagePublicId  = result.public_id;
        }
      });
      showToast('✅ Photo has been saved!', 'success');
    });
  }

  /* ══════════════════════════════════════════════════════════════
     11. HOUSE LOGO
  ══════════════════════════════════════════════════════════════ */
  window._houseLogoUrls      = {};
  window._houseLogoPublicIds = {};

  async function hlogoUpload(input, idx) {
    var file = input && input.files[0]; if (!file) return;
    var err = validate(file); if (err) { showToast('❌ ' + err, 'error'); return; }

    var wrap = document.getElementById('hlogo-wrap-' + idx);
    previewLocal(file, wrap, 'rect');

    showToast('⏳ Uploading house logo...', 'info');

    // Get house _id from SchoolDB; if missing, fetch live from API (BUG6 FIX)
    var db     = window.SchoolDB && window.SchoolDB.load();
    var houses = db && db.houses;
    var houseId = houses && houses[idx] && (houses[idx]._id || houses[idx].id);

    if (!houseId) {
      // Cache miss — pull fresh list from MongoDB and retry
      try {
        var token0 = sessionStorage.getItem('admin_token') || '';
        var hRes = await fetch('/api/houses', { headers: { 'Authorization': 'Bearer ' + token0 } });
        var hData = await hRes.json();
        var liveHouses = (hData.success && hData.data) ? hData.data : (Array.isArray(hData) ? hData : []);
        if (liveHouses[idx]) houseId = liveHouses[idx]._id || liveHouses[idx].id || null;
        // Patch SchoolDB cache so future calls are instant
        if (db && db.houses && db.houses[idx] && houseId) {
          db.houses[idx]._id = houseId;
          window.SchoolDB.save(db);
        }
      } catch(e) { console.warn('[hlogoUpload] Could not fetch houseId from API:', e.message); }
    }

    // Delete old if exists
    if (houses && houses[idx] && houses[idx].logoPublicId) {
      deleteFromCloudinary(houses[idx].logoPublicId);
    }

    var token = sessionStorage.getItem('admin_token') || '';
    var result = null;

    if (houseId) {
      // Direct upload to /api/images/upload/houses — saves to MongoDB + Cloudinary
      try {
        var fd = new FormData();
        fd.append('image',   file);
        fd.append('houseId', houseId);
        var res = await fetch('/api/images/upload/houses', {
          method:  'POST',
          headers: { 'Authorization': 'Bearer ' + token },
          body:    fd,
        });
        var data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Upload failed');
        result = { secure_url: data.imageUrl, public_id: data.publicId };
        showToast('✅ House logo saved to Cloudinary + MongoDB!', 'success');
      } catch(e) {
        showToast('❌ House logo upload failed: ' + e.message, 'error');
        return;
      }
    } else {
      // No houseId yet (houses not saved) — use temp upload, save on house save
      result = await uploadImage(file, 'house_logo');
      if (!result) return;
      showToast('✅ Logo ready! "💾 Save" dabao to finalize.', 'success');
    }

    window._houseLogoUrls[idx]      = result.secure_url;
    window._houseLogoPublicIds[idx] = result.public_id;
    if (wrap) previewUrl(wrap, result.secure_url, 'rect');
  }

  function hlogoRemove(idx) {
    window._houseLogoUrls[idx]      = '';
    window._houseLogoPublicIds[idx] = '';
    var db     = window.SchoolDB && window.SchoolDB.load();
    var houses = db && db.houses || [];
    var house  = houses[idx];
    if (house) {
      if (house.logoPublicId) deleteFromCloudinary(house.logoPublicId);
      if (house._id || house.id) {
        var token = sessionStorage.getItem('admin_token') || '';
        fetch('/api/images/houses/' + (house._id || house.id), {
          method: 'DELETE', headers: { 'Authorization': 'Bearer ' + token }
        }).catch(function(){});
      }
    }
    var wrap = document.getElementById('hlogo-wrap-' + idx);
    if (wrap) wrap.innerHTML = (house && house.emoji) || '🏠';
    showToast('🗑 House logo removed from Cloudinary + DB', 'info');
  }

  /* ══════════════════════════════════════════════════════════════
     LOAD EXISTING PREVIEWS FROM DB (on dashboard open)
  ══════════════════════════════════════════════════════════════ */
  async function loadFromServer() {
    try {
      var db = window.SchoolDB && window.SchoolDB.load(); if (!db) return;

      // School logo
      if (db.schoolInfo && db.schoolInfo.logoData)
        previewUrl('logoPreview', db.schoolInfo.logoData, 'circle');

      // Hero image
      if (db.heroImage || (db.schoolInfo && db.schoolInfo.heroImage)) {
        var heroEl = document.getElementById('heroImgPreview');
        var heroUrl = db.heroImage || db.schoolInfo.heroImage;
        if (heroEl && heroUrl) previewUrl(heroEl, heroUrl, 'circle');
      }

      // Principal photo
      if (db.homepageContent && db.homepageContent.principalPhoto)
        previewUrl('principalPhotoPreview', db.homepageContent.principalPhoto, 'circle');

      // Admission banner
      if (db.admissions && db.admissions.imageData) {
        var admEl = document.getElementById('adm-img-preview');
        if (admEl) previewUrl(admEl, db.admissions.imageData, 'rect');
      }

      // Top students
      if (db.topStudents) {
        db.topStudents.forEach(function(s, i) {
          if (s && s.image) {
            var w = document.getElementById('ts-img-wrap-' + i);
            if (w) previewUrl(w, s.image, 'circle');
          }
        });
      }

      // House logos — load from MongoDB /api/images/houses
      var token = sessionStorage.getItem('admin_token') || '';
      if (token) {
        fetch('/api/images/houses', { headers: { 'Authorization': 'Bearer ' + token } })
          .then(function(r){ return r.json(); })
          .then(function(d){
            var imgs = d.data || [];
            imgs.forEach(function(img) {
              // Match houseId to index in db.houses
              var houses = db.houses || [];
              var idx = houses.findIndex(function(h){ return (h._id||h.id) === img.houseId; });
              if (idx >= 0 && img.imageUrl) {
                var wrap = document.getElementById('hlogo-wrap-' + idx);
                if (wrap) previewUrl(wrap, img.imageUrl, 'rect');
              }
            });
          }).catch(function(){});
      }

    } catch(e) { console.warn('[IM] loadFromServer:', e.message); }
  }

  /* ══════════════════════════════════════════════════════════════
     CLOUDINARY CONFIG — Settings Tab
  ══════════════════════════════════════════════════════════════ */
  window.saveCloudinaryConfig = function() {
    var cn = ((document.getElementById('cly-cloud-name')    || {}).value || '').trim();
    var up = ((document.getElementById('cly-upload-preset') || {}).value || '').trim();
    if (!cn || !up) { showToast('Cloud Name and Upload Preset are both required!', 'error'); return; }
    saveDB(function(db){ db.cloudinaryConfig = { cloudName: cn, uploadPreset: up }; });
    var badge = document.getElementById('cly-status');
    if (badge) { badge.textContent = '✅ Connected — ' + cn; badge.style.color = '#27ae60'; }
    showToast('✅ Cloudinary config has been saved!', 'success');
  };

  window.loadCloudinaryConfig = function() {
    var cfg   = getCfg();
    var cnEl  = document.getElementById('cly-cloud-name');
    var upEl  = document.getElementById('cly-upload-preset');
    var badge = document.getElementById('cly-status');
    if (cnEl)  cnEl.value  = cfg.cloudName    || '';
    if (upEl)  upEl.value  = cfg.uploadPreset || '';
    if (badge) {
      if (cfg.cloudName && cfg.uploadPreset) {
        badge.textContent = '✅ Connected — ' + cfg.cloudName;
        badge.style.color = '#27ae60';
      } else {
        badge.textContent = '⚠️ Not configured';
        badge.style.color = '#e65100';
      }
    }
  };

  window.testCloudinaryConnection = async function() {
    var cfg = getCfg();
    showToast('⏳ Testing...', 'info');
    try {
      var fd = new FormData(); fd.append('upload_preset', cfg.uploadPreset);
      var res  = await fetch('https://api.cloudinary.com/v1_1/' + cfg.cloudName + '/image/upload', { method: 'POST', body: fd });
      var data = await res.json();
      var msg  = (data.error && data.error.message) || '';
      if (msg.toLowerCase().includes('must be an uploaded') || msg.toLowerCase().includes('no file')) {
        showToast('✅ Cloudinary connected! Cloud Name and Preset are valid.', 'success');
      } else if (msg.toLowerCase().includes('preset')) {
        showToast('❌ Upload Preset is incorrect!', 'error');
      } else if (msg) {
        showToast('❌ ' + msg, 'error');
      } else {
        showToast('✅ Connected!', 'success');
      }
    } catch(e) { showToast('❌ ' + e.message, 'error'); }
  };

  /* ══════════════════════════════════════════════════════════════
     PUBLIC API — expose only what's needed
  ══════════════════════════════════════════════════════════════ */
  return {
    // Core (usable anywhere)
    uploadImage,
    deleteFromCloudinary,
    validate,
    previewLocal,
    previewUrl,
    previewReset,

    // Logo
    uploadLogo, removeLogo,

    // Principal
    uploadPrincipalPhoto, removePrincipalPhoto,

    // Banners
    uploadAdmissionImage, removeAdmissionImage,

    // Teachers
    previewTeacherPhoto, clearTeacherPhoto,
    previewEditTeacherPhoto, removeEditTeacherPhoto,

    // Class Teachers
    uploadClassTeacherPhoto, removeClassTeacherPhoto,

    // Leadership
    uploadLeaderPhoto, removeLeaderPhoto,

    // Events
    previewEventImage, evImgRemove, getOrUploadEventImage,

    // Gallery
    previewGalleryImg, clearGalleryImg,
    submitAddGallery, deleteGalleryItem,
    previewEditGalleryImg, submitEditGallery,

    // Top Students
    tsImgUpload,

    // House Logo
    hlogoUpload, hlogoRemove,

    // Compat (old del function)
    del: function() { return Promise.resolve(true); },

    // Init
    loadFromServer,
  };
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: submitAddTeacher — inject Cloudinary URL + public_id
   after original saves teacher to DB
══════════════════════════════════════════════════════════════ */
(function patchSubmitAddTeacher() {
  function tryPatch() {
    if (typeof window.submitAddTeacher !== 'function' || typeof window.SchoolDB === 'undefined') {
      return setTimeout(tryPatch, 300);
    }
    var orig = window.submitAddTeacher;
    window.submitAddTeacher = function() {
      var photoUrl      = window._newTeacherPhotoUrl      || '';
      var photoPublicId = window._newTeacherPhotoPublicId || '';
      orig.call(this);
      if (photoUrl) {
        setTimeout(function() {
          var db = window.SchoolDB && window.SchoolDB.load();
          if (!db || !db.teachers || !db.teachers.length) return;
          var last = db.teachers[db.teachers.length - 1];
          last.photo    = photoUrl;
          last.publicId = photoPublicId;
          window.SchoolDB.save(db);
          window.SchoolSync && window.SchoolSync.broadcast('teachers');
          if (typeof window.loadTeachers === 'function') window.loadTeachers();
          window._newTeacherPhotoUrl      = '';
          window._newTeacherPhotoPublicId = '';
        }, 150);
      }
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryPatch);
  else tryPatch();
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: submitEditTeacher — inject Cloudinary URL + public_id
══════════════════════════════════════════════════════════════ */
(function patchSubmitEditTeacher() {
  function tryPatch() {
    if (typeof window.submitEditTeacher !== 'function' || typeof window.SchoolDB === 'undefined') {
      return setTimeout(tryPatch, 300);
    }
    var orig = window.submitEditTeacher;
    window.submitEditTeacher = function() {
      var newUrl      = window._editTeacherPhotoUrl;
      var newPublicId = window._editTeacherPhotoPublicId;
      var idx = parseInt((document.getElementById('et-id') || {}).value);
      orig.call(this);
      if (newUrl !== null && newUrl !== undefined) {
        setTimeout(function() {
          var db = window.SchoolDB && window.SchoolDB.load();
          if (!db || !db.teachers) return;
          var t = db.teachers[idx];
          if (t) {
            t.photo    = newUrl;
            t.publicId = newPublicId || '';
            window.SchoolDB.save(db);
            window.SchoolSync && window.SchoolSync.broadcast('teachers');
            if (typeof window.loadTeachers === 'function') window.loadTeachers();
          }
          window._editTeacherPhotoUrl      = null;
          window._editTeacherPhotoPublicId = null;
        }, 150);
      }
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryPatch);
  else tryPatch();
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: saveClassTeacher — inject Cloudinary URL + public_id
══════════════════════════════════════════════════════════════ */
(function patchSaveClassTeacher() {
  function tryPatch() {
    if (typeof window.saveClassTeacher !== 'function' || typeof window.SchoolDB === 'undefined') {
      return setTimeout(tryPatch, 300);
    }
    var orig = window.saveClassTeacher;
    window.saveClassTeacher = function() {
      var url      = window._classTeacherPhotoUrl;
      var publicId = window._classTeacherPhotoPublicId;
      if (url !== null && url !== undefined) {
        var cls   = (document.getElementById('cm-class') || {}).value || 'X';
        var sec   = (document.getElementById('cm-sec')   || {}).value || 'A';
        var ctKey = 'cls_' + cls + '_' + sec;
        var db    = window.SchoolDB && window.SchoolDB.load();
        if (db) {
          if (!db.classTeachers)        db.classTeachers        = {};
          if (!db.classTeachers[ctKey]) db.classTeachers[ctKey] = {};
          db.classTeachers[ctKey].teacherPhoto         = url;
          db.classTeachers[ctKey].teacherPhotoPublicId = publicId || '';
          window.SchoolDB.save(db);
        }
        window._classTeacherPhotoUrl      = null;
        window._classTeacherPhotoPublicId = null;
      }
      orig.call(this);
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryPatch);
  else tryPatch();
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: deleteTeacher — also store publicId for cleanup
══════════════════════════════════════════════════════════════ */
(function patchDeleteTeacher() {
  function tryPatch() {
    if (typeof window.deleteTeacher !== 'function') return setTimeout(tryPatch, 300);
    var orig = window.deleteTeacher;
    window.deleteTeacher = function(idx) {
      var db = window.SchoolDB && window.SchoolDB.load();
      var t  = (db && db.teachers || [])[idx];
      if (t && t.publicId) window.IM && window.IM.deleteFromCloudinary(t.publicId);
      orig.call(this, idx);
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryPatch);
  else tryPatch();
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: saveHouses — inject house logo URLs + public_ids
══════════════════════════════════════════════════════════════ */
(function patchSaveHouses() {
  function tryPatch() {
    if (typeof window.saveHousePoints !== 'function') return setTimeout(tryPatch, 400);
    var orig = window.saveHousePoints;
    window.saveHousePoints = function() {
      // Inject logo URLs from IM into _houseLogos so original fn picks them up
      if (window._houseLogoUrls) {
        window._houseLogos = window._houseLogos || {};
        Object.keys(window._houseLogoUrls).forEach(function(i) {
          if (window._houseLogoUrls[i] !== undefined) {
            window._houseLogos[i] = window._houseLogoUrls[i];
          }
        });
      }
      orig.call(this);
      // Save publicIds after original saves logos
      setTimeout(function() {
        if (!window._houseLogoPublicIds) return;
        var db = window.SchoolDB && window.SchoolDB.load();
        if (!db || !db.houses) return;
        Object.keys(window._houseLogoPublicIds).forEach(function(i) {
          if (db.houses[i] && window._houseLogoPublicIds[i] !== undefined) {
            db.houses[i].logoPublicId = window._houseLogoPublicIds[i];
          }
        });
        window.SchoolDB.save(db);
        window._houseLogoUrls      = {};
        window._houseLogoPublicIds = {};
      }, 200);
    };
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryPatch);
  else tryPatch();
})();

/* ══════════════════════════════════════════════════════════════
   PATCH: submitAddEvent / submitAddEvent2 — inject image data
══════════════════════════════════════════════════════════════ */
/* BUG4 FIX: patchEvents() IIFE removed — it was a third redundant wrapping of submitAddEvent.
   The clean flow is: submitAddEvent saves event → uploads image via /api/events/:id/image.
   The DOMContentLoaded patch (sets window._evImageOverride) in dashboard.html is sufficient. */

/* ══════════════════════════════════════════════════════════════
   AUTO-INIT
══════════════════════════════════════════════════════════════ */
(function autoInit() {
  function tryInit() {
    if (window.IM && window.SchoolDB) {
      setTimeout(function() {
        if (typeof window.loadCloudinaryConfig === 'function') window.loadCloudinaryConfig();
        window.IM.loadFromServer();
      }, 700);
    } else {
      setTimeout(tryInit, 300);
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tryInit);
  else tryInit();
})();
