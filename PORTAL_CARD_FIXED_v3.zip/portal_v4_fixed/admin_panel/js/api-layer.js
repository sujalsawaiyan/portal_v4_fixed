// =============================================================
//  api-layer.js — SCHOOL PORTAL
//
//  PURPOSE: Replace window.SchoolDB (localStorage) with real
//  API calls to the MongoDB backend.
//
//  HOW IT WORKS:
//  1. On load: fetches ALL data from backend into _cache
//  2. window.SchoolDB.load() → returns _cache (no localStorage)
//  3. window.SchoolDB.save(data) → diffs and calls relevant APIs
//  4. Exposes window.API for direct use by new dashboard code
//
//  LOAD THIS SCRIPT BEFORE dashboard.html's inline scripts.
//  Add to dashboard.html: <script src="/admin_panel/js/api-layer.js"></script>
// =============================================================

(function () {
  'use strict';

  // ── Config ──────────────────────────────────────────────────
  const BASE = '';   // same-origin: backend serves frontend

  // ── Auth token helper ───────────────────────────────────────
  function getToken() {
    return sessionStorage.getItem('admin_token') || '';
  }

  function authHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + getToken(),
    };
  }

  // ── Low-level fetch helpers ──────────────────────────────────
  async function apiFetch(path, options) {
    const res = await fetch(BASE + path, {
      headers: authHeaders(),
      ...options,
    });
    if (res.status === 401) {
      sessionStorage.clear();
      window.location.href = '/admin_panel/login.html';
      throw new Error('Unauthorized');
    }
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || res.statusText);
    return json;
  }

  function apiGet(path)         { return apiFetch(path); }
  function apiPost(path, body)  { return apiFetch(path, { method: 'POST', body: JSON.stringify(body) }); }
  function apiPut(path, body)   { return apiFetch(path, { method: 'PUT',  body: JSON.stringify(body) }); }
  function apiDelete(path)      { return apiFetch(path, { method: 'DELETE' }); }

  // ── In-memory data cache (replaces localStorage) ─────────────
  let _cache = null;         // null until first load
  let _loading = false;
  let _loadPromise = null;

  // ── Load ALL data from backend into _cache ───────────────────
  async function loadAllFromBackend() {
    const [
      settingsRes, teachersRes, eventsRes,
      announcementsRes, housesRes, galleryRes,
      studentsRes, classesRes, dashboardRes,
    ] = await Promise.allSettled([
      apiGet('/api/settings/schoolInfo'),
      apiGet('/api/teachers'),
      apiGet('/api/events'),
      apiGet('/api/announcements'),
      apiGet('/api/houses'),
      apiGet('/api/gallery'),
      apiGet('/api/students?limit=500'),
      apiGet('/api/classes'),
      apiGet('/api/dashboard'),
    ]);

    const val = (r, key) => r.status === 'fulfilled' ? (key ? r.value[key] : r.value) : null;

    // Build settings map from individual keys
    const settingsMap = {};
    const settingKeys = [
      'schoolInfo', 'homepageContent', 'schoolTiming', 'stats',
      'topStudents', 'feeStructure', 'socialLinks', 'upiPayment',
      'admissions', 'lockdown', 'onlineLinks', 'calendar', 'scores',
      'heroImage', 'classTeachers', 'subjectConfig',
    ];

    await Promise.allSettled(
      settingKeys.map(async (key) => {
        try {
          const r = await apiGet('/api/settings/' + key);
          if (r.value !== null) settingsMap[key] = r.value;
        } catch (_) {}
      })
    );

    // Normalize teachers from API to dashboard format
    const teachersRaw = val(teachersRes, 'data') || [];
    const teachers = teachersRaw.map(t => ({
      id:           t._id,
      _id:          t._id,
      name:         t.name || t.fullName || '',
      full_name:    t.name || t.fullName || '',
      subject:      t.subject || '',
      dept:         t.dept || t.department || '',
      department:   t.department || t.dept || '',
      qual:         t.qual || t.qualification || '',
      qualification:t.qualification || t.qual || '',
      exp:          t.exp || t.experience || 0,
      experience:   t.experience || t.exp || 0,
      role:         t.role || 'teacher',
      email:        t.email || '',
      phone:        t.phone || '',
      photo:        t.photo || '',
      photoPublicId: t.photoPublicId || '',   // ← needed for Cloudinary cleanup
      publicId:      t.photoPublicId || '',   // alias used by imageUploadManager
      order:        t.order || 0,
    }));

    // Normalize events
    const eventsRaw = val(eventsRes, 'data') || [];
    const events = eventsRaw.map(e => ({
      id:          e._id,
      _id:         e._id,
      title:       e.title || '',
      type:        e.type || 'other',
      date:        e.date || '',
      event_date:  e.date || '',
      endDate:     e.endDate || '',
      description: e.description || '',
      venue:       e.venue || '',
      featured:    !!(e.featured || e.is_featured),
      is_featured: !!(e.featured || e.is_featured),
      image:       e.image || '',
      highlighted: !!e.highlighted,
    }));

    // Normalize announcements
    const annsRaw = val(announcementsRes, 'data') || [];
    const announcements = annsRaw.map(a => ({
      id:          a._id,
      _id:         a._id,
      title:       a.title || '',
      body:        a.body || a.content || '',
      content:     a.body || a.content || '',
      category:    a.category || 'General',
      date:        a.date || a.publish_date || '',
      publish_date:a.date || a.publish_date || '',
      is_pinned:   a.is_pinned || (a.isPinned ? 1 : 0),
      pinned:      !!(a.is_pinned || a.isPinned),
      highlighted: !!a.highlighted,
    }));

    // Normalize houses
    const housesRaw = val(housesRes, 'data') || [];
    const houses = housesRaw.map(h => ({
      id:          h.id || h._id,
      _id:         h._id,
      name:        h.name || '',
      color:       h.color || '#6C63FF',
      gradient:    h.gradient || '',
      emoji:       h.emoji || '',
      tagline:     h.tagline || '',        // ✅ FIX: was missing, caused tagline to be wiped on re-save
      logo:        h.logo || '',           // ✅ FIX: was missing, caused logo to be wiped on re-save
      logoPublicId:h.logoPublicId || '',   // ✅ FIX: was missing
      captain:     h.captain || '',
      viceCaptain: h.viceCaptain || '',
      sports:      h.sports || 0,
      study:       h.study || 0,
      activities:  h.activities || 0,
      discipline:  h.discipline || 0,
      points:      (h.sports||0)+(h.study||0)+(h.activities||0)+(h.discipline||0),
      contributors:h.contributors || [],
    }));

    // Normalize gallery (for IndexedDB compatibility)
    const galleryRaw = val(galleryRes, 'data') || [];
    const gallery = galleryRaw.map(g => ({
      id:        g._id,
      _id:       g._id,
      _serverId: g._id,
      title:     g.title || '',
      category:  g.category || 'general',
      url:       g.url || '',
      emoji:     g.emoji || '🖼️',
    }));

    // Normalize students
    const studentsRaw = val(studentsRes, 'data') || [];
    const students = studentsRaw.map(s => ({
      id:          s._id,
      _id:         s._id,
      student_id:  s.studentId || '',
      full_name:   s.fullName || '',
      class_number:s.class || '',
      section:     s.section || 'A',
      roll:        s.rollNumber || '',
      house_name:  s.house || '',
      date_of_birth:s.dateOfBirth || '',
      gender:      s.gender || '',
      email:       s.email || '',
      guardianName:s.guardianName || '',
      guardianPhone:s.guardianPhone || '',
      address:     s.address || '',
    }));

    // Normalize classes into classTeachers map format
    const classesRaw = val(classesRes, 'data') || [];
    const classTeachers = settingsMap.classTeachers || {};
    classesRaw.forEach(c => {
      const key = 'cls_' + c.className + '_' + c.section;
      classTeachers[key] = {
        teacherName:    c.teacherName || '',
        teacherPhoto:   c.teacherPhoto || '',
        teacherExp:     c.teacherExp || 0,
        teacherSubject: c.teacherSubject || '',
      };
    });

    // Dashboard stats
    const dash = val(dashboardRes) || {};

    // Build the full cache object matching DEFAULT_DATA shape
    _cache = {
      schoolInfo:       settingsMap.schoolInfo       || {},
      homepageContent:  settingsMap.homepageContent  || {},
      schoolTiming:     settingsMap.schoolTiming      || {},
      stats:            settingsMap.stats             || { students: dash.total_students||0, teachers: dash.total_teachers||0 },
      topStudents:      settingsMap.topStudents       || [],
      feeStructure:     settingsMap.feeStructure      || { heading:'', categories:[] },
      socialLinks:      settingsMap.socialLinks       || {},
      upiPayment:       settingsMap.upiPayment        || {},
      admissions:       settingsMap.admissions        || {},
      lockdown:         settingsMap.lockdown          || { active:false },
      onlineLinks:      settingsMap.onlineLinks       || {},
      calendar:         settingsMap.calendar          || {},
      scores:           settingsMap.scores            || {},
      heroImage:        settingsMap.heroImage         || '',
      teachers,
      events,
      announcements,
      houses,
      gallery,
      students,
      classTeachers,
      subjectConfig:    settingsMap.subjectConfig || {},
      attendance:       {},
      admissionApplications: [],
      _dashStats: {
        total_students:      dash.total_students || 0,
        total_teachers:      dash.total_teachers || 0,
        total_events:        dash.total_events   || events.length,
        total_announcements: dash.total_announcements || announcements.length,
        pending_admissions:  dash.pending_admissions || 0,
      },
    };

    return _cache;
  }

  // ── Ensure data is loaded ────────────────────────────────────
  function ensureLoaded() {
    // ✅ FIXED v2.2.0: If _cache already has real data, return it.
    // If _cache is only defaults (no teachers/events etc), allow reload.
    const hasRealData = _cache && (
      (_cache.teachers  && _cache.teachers.length  > 0) ||
      (_cache.events    && _cache.events.length    > 0) ||
      (_cache.students  && _cache.students.length  > 0) ||
      (_cache.announcements && _cache.announcements.length > 0)
    );
    if (hasRealData) return Promise.resolve(_cache);
    if (_loadPromise) return _loadPromise;
    _loading = true;
    _loadPromise = loadAllFromBackend()
      .then(data => {
        _loading     = false;
        _loadPromise = null;   // allow future reloads
        _cache       = data;
        return data;
      })
      .catch(err => {
        _loading     = false;
        _loadPromise = null;
        console.error('[API] Load failed:', err.message);
        return _cache || _buildDefaults();
      });
    return _loadPromise;
  }

  // ── Diff helper: detect which sections changed ───────────────
  function detectChangedSections(oldData, newData) {
    // ⚠️  CRITICAL: Collections (teachers, events, announcements, houses) are
    // intentionally EXCLUDED from save()-based diff.
    // Reason: save() is called with whatever snapshot load() returned at that
    // moment.  If that snapshot was taken BEFORE the async MongoDB fetch
    // completed, collections will be empty — causing a bulk/replace with []
    // that wipes all records from the database.
    //
    // Collections are managed ONLY via their dedicated CRUD API endpoints:
    //   POST/PUT/DELETE /api/teachers, /api/events, /api/announcements, etc.
    // classTeachers IS safe here because it's always rewritten intentionally.

    const sections = [
      'schoolInfo','homepageContent','schoolTiming','stats','topStudents',
      'feeStructure','socialLinks','upiPayment','admissions','lockdown',
      'onlineLinks','calendar','heroImage', 'scores',
    ];
    const changed = [];
    sections.forEach(key => {
      if (JSON.stringify(oldData[key]) !== JSON.stringify(newData[key])) {
        changed.push(key);
      }
    });

    // classTeachers: only push if both sides have real data
    // (never push if newData.classTeachers is empty — that means stale snapshot)
    const newCT = newData.classTeachers || {};
    const oldCT = oldData.classTeachers || {};
    if (Object.keys(newCT).length > 0 &&
        JSON.stringify(oldCT) !== JSON.stringify(newCT)) {
      changed.push('classTeachers');
    }

    return changed;
  }

  // ── Persist a single section to backend ─────────────────────
  async function persistSection(section, data) {
    try {
      switch (section) {
        case 'teachers':
          await apiPut('/api/teachers/bulk/replace', { teachers: data.teachers });
          break;
        case 'events':
          await apiPut('/api/events/bulk/replace', { events: data.events });
          break;
        case 'announcements':
          await apiPut('/api/announcements/bulk/replace', { announcements: data.announcements });
          break;
        case 'houses':
          await apiPut('/api/houses/bulk/replace', { houses: data.houses });
          break;
        case 'classTeachers':
          await apiPut('/api/classes/bulk/replace', { classTeachers: data.classTeachers });
          break;
        default:
          // All scalar sections go to /api/settings
          if (data[section] !== undefined) {
            await apiPost('/api/settings/' + section, { value: data[section] });
          }
      }
    } catch (err) {
      console.error('[API] Failed to persist section "' + section + '":', err.message);
      throw err;
    }
  }

  // ================================================================
  // window.SchoolDB REPLACEMENT
  // Drop-in replacement for the localStorage-based SchoolDB.
  // All existing dashboard code calls .load() / .save() / .get() / .set()
  // — those now talk to the backend instead of localStorage.
  // ================================================================
  window.SchoolDB = {
    _key: 'school_school_data_v2',  // kept for reference, not used

    // ── load() ── synchronous wrapper around the async cache ────
    // ✅ FIXED v2.2.0: _cache is pre-populated with defaults immediately,
    // so callers NEVER get an empty object. Real data replaces defaults
    // once ensureLoaded() resolves — then triggers a re-render event.
    load() {
      if (!_cache) {
        // Pre-populate with safe defaults so dashboard code gets
        // a valid structure immediately (no blank page flash)
        _cache = _buildDefaults();
        // Kick off async load; update _cache in-place when done
        ensureLoaded().then(data => {
          _cache = data;
          // Signal dashboard to re-render with real data
          window.dispatchEvent(new CustomEvent('schooldb:refreshed', { detail: data }));
        }).catch(() => {});
      }
      return JSON.parse(JSON.stringify(_cache));  // deep clone
    },

    // ── save(data) ── persist changed sections to backend ───────
    // Dashboard calls this after every mutation.
    // We detect what changed and call the relevant APIs.
    save(newData) {
      // ── CRITICAL GUARD ────────────────────────────────────────
      // If _cache was never loaded (API data not yet fetched),
      // calling save() with partial data would bulk-replace MongoDB
      // with empty arrays, wiping all existing records.
      // Solution: if oldData is empty (cache not loaded), SKIP bulk
      // persistence — only update in-memory cache.
      const oldData = _cache;
      const cacheWasEmpty = !oldData || Object.keys(oldData).length === 0;
      if (cacheWasEmpty) {
        console.log('[API] save() called before cache loaded — in-memory only, skipping bulk persist');
        return true;
      }

      // ── STALE SNAPSHOT GUARD ──────────────────────────────────
      // Protect collections from being wiped by a stale save().
      // If _cache has data for a collection but newData has 0, it means
      // save() was called with a snapshot taken before MongoDB data arrived.
      // In that case, restore the live collection into newData before diffing.
      const protectedCollections = ['teachers', 'events', 'announcements', 'houses', 'gallery', 'students'];
      protectedCollections.forEach(col => {
        const liveCount = (oldData && oldData[col] && oldData[col].length) || 0;
        const newCount  = (newData[col] && newData[col].length) || 0;
        if (liveCount > 0 && newCount === 0) {
          console.warn('[API] save() stale snapshot detected for "' + col + '" — preserving live data (' + liveCount + ' records)');
          newData[col] = JSON.parse(JSON.stringify(oldData[col]));
        }
      });
      _cache = JSON.parse(JSON.stringify(newData));  // re-sync with corrected data

      const changed = detectChangedSections(oldData, newData);
      if (!changed.length) return true;

      // Fire and forget — but surface errors via toast
      Promise.all(changed.map(s => persistSection(s, newData)))
        .then(() => {
          console.log('[API] Saved sections:', changed.join(', '));
        })
        .catch(err => {
          console.error('[API] Save error:', err.message);
          if (window.showToast) {
            window.showToast('⚠️ Backend save failed: ' + err.message, 'error');
          }
        });

      return true;   // optimistic — return true so existing code continues
    },

    // ── get(section) ── read one section ────────────────────────
    get(section) {
      const d = this.load();
      return d[section];
    },

    // ── set(section, value) ── write one section ─────────────────
    set(section, value) {
      const d = this.load();
      d[section] = value;
      return this.save(d);
    },

    // ── update(sec, key, val) ─────────────────────────────────────
    update(sec, key, val) {
      const d = this.load();
      if (!d[sec]) d[sec] = {};
      d[sec][key] = val;
      return this.save(d);
    },

    // ── Stubs for methods no longer needed ──────────────────────
    getStorageUsageKB() { return 0; },
    reset()             { _cache = null; },

    // ── Public: force reload from backend ───────────────────────
    reload()  { _cache = null; _loadPromise = null; return ensureLoaded(); },

    // ── waitForLoad: used by dashboard init ─────────────────────
    // ✅ FIXED: waitForLoad returns promise that resolves with REAL data
    waitForLoad() {
      return ensureLoaded().then(data => {
        _cache = data;
        return data;
      });
    },
  };

  // ================================================================
  // window.AdminAuth REPLACEMENT
  // Replaces the localStorage-based AdminAuth with JWT API calls.
  // ================================================================
  window.AdminAuth = {
    getCredentials() {
      const user = JSON.parse(sessionStorage.getItem('admin_user') || '{}');
      return { username: user.username || 'admin', full_name: user.fullName || 'Admin' };
    },

    async login(username, password) {
      try {
        const data = await apiPost('/api/auth/login', { studentId: username, password, role: 'admin' });
        sessionStorage.setItem('admin_token', data.token);
        sessionStorage.setItem('admin_user', JSON.stringify(data.user));
        return { success: true, user: data.user };
      } catch (err) {
        return { success: false, error: err.message || 'Invalid credentials' };
      }
    },

    isLoggedIn() {
      return !!sessionStorage.getItem('admin_token');
    },

    logout() {
      sessionStorage.clear();
    },

    async update(newUsername, newPassword, currentPassword) {
      try {
        await apiPost('/api/auth/change-password', {
          currentPassword: currentPassword,
          newPassword:     newPassword || undefined,
        });
        // If username changed, we'd need a separate endpoint — for now update display only
        if (newUsername) {
          const user = JSON.parse(sessionStorage.getItem('admin_user') || '{}');
          user.username = newUsername;
          sessionStorage.setItem('admin_user', JSON.stringify(user));
        }
        return { success: true };
      } catch (err) {
        return { success: false, error: err.message };
      }
    },
  };

  // ================================================================
  // window.GalleryDB REPLACEMENT
  // Replaces the IndexedDB-based GalleryDB with MongoDB API calls.
  // ================================================================
  window.GalleryDB = {
    loadAll() {
      return apiGet('/api/gallery')
        .then(r => (r.data || []).map(g => ({
          id:       g._id,
          _serverId:g._id,
          title:    g.title,
          category: g.category,
          url:      g.url,
          emoji:    g.emoji || '🖼️',
        })))
        .catch(() => []);
    },

    addItem(item) {
      return apiPost('/api/gallery', {
        title:    item.title,
        category: item.category || 'general',
        url:      item.url || '',
        emoji:    item.emoji || '🖼️',
      })
      .then(() => true)
      .catch(() => false);
    },

    deleteItem(id) {
      return apiDelete('/api/gallery/' + id)
        .then(() => true)
        .catch(() => false);
    },

    updateItem(id, updates) {
      return apiPut('/api/gallery/' + id, updates)
        .then(() => true)
        .catch(() => false);
    },

    // Compatibility stubs — api-layer overrides IndexedDB GalleryDB,
    // but main.js calls open() + migrateFromLocalStorage() at startup.
    open() {
      return Promise.resolve();
    },
    migrateFromLocalStorage() {
      console.log('[GalleryDB] migrateFromLocalStorage: skipped — MongoDB is the source of truth.');
      return Promise.resolve();
    },
  };

  // ================================================================
  // window.API — Direct API access for new dashboard code
  // ================================================================
  window.API = {
    // Auth
    login:          (u, p)      => apiPost('/api/auth/login', { studentId: u, password: p, role: 'admin' }),
    changePassword: (cur, next) => apiPost('/api/auth/change-password', { currentPassword: cur, newPassword: next }),

    // Settings (any key)
    getSetting:  key        => apiGet('/api/settings/' + key).then(r => r.value),
    saveSetting: (key, val) => apiPost('/api/settings/' + key, { value: val }),

    // Dashboard
    getStats:    ()  => apiGet('/api/dashboard'),

    // Students
    getStudents: (params) => apiGet('/api/students?' + new URLSearchParams(params || {})),
    addStudent:  (data)   => apiPost('/api/students', data),
    updateStudent:(id, d) => apiPut('/api/students/' + id, d),
    deleteStudent:(id)    => apiDelete('/api/students/' + id),
    // B1 FIX: Upload student photo to Cloudinary
    uploadStudentPhoto: function(studentId, fd) {
      return fetch('/api/students/' + studentId + '/photo', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body: fd,
      }).then(function(res) {
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },

    // Teachers
    getTeachers: ()        => apiGet('/api/teachers'),
    addTeacher:  (data)    => apiPost('/api/teachers', data),
    updateTeacher:(id, d)  => apiPut('/api/teachers/' + id, d),
    deleteTeacher:(id)     => apiDelete('/api/teachers/' + id),
    replaceTeachers:(list) => apiPut('/api/teachers/bulk/replace', { teachers: list }),

    // Teacher Photo — multipart upload
    uploadTeacherPhoto: function(teacherId, fd) {
      return fetch('/api/teachers/' + teacherId + '/photo', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body:    fd,
      }).then(function(res) {
        if (res.status === 401) { sessionStorage.clear(); window.location.href = '/admin_panel/login.html'; }
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },
    removeTeacherPhoto: (id) => apiDelete('/api/teachers/' + id + '/photo'),

    // Events — CRUD
    getEvents:    ()       => apiGet('/api/events'),
    addEvent:     (data)   => apiPost('/api/events', data),
    updateEvent:  (id, d)  => apiPut('/api/events/' + id, d),
    deleteEvent:  (id)     => apiDelete('/api/events/' + id),
    replaceEvents:(list)   => apiPut('/api/events/bulk/replace', { events: list }),

    // Events — Image (multipart: must NOT set Content-Type, browser sets boundary)
    uploadEventImg: function(id, fd) {
      return fetch('/api/events/' + id + '/image', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token') || '') },
        body:    fd,
      }).then(function(res) {
        if (res.status === 401) { sessionStorage.clear(); window.location.href = '/admin_panel/login.html'; }
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },
    removeEventImg:       (id)      => apiDelete('/api/events/' + id + '/image'),

    // Events — Toggle helpers via PUT
    toggleEventFeatured:  (id, val) => apiPut('/api/events/' + id, { featured: val, is_featured: val }),
    toggleEventHighlight: (id, val) => apiPut('/api/events/' + id, { highlighted: val }),

    // Announcements
    getAnnouncements:  ()       => apiGet('/api/announcements'),
    addAnnouncement:   (data)   => apiPost('/api/announcements', data),
    updateAnnouncement:(id, d)  => apiPut('/api/announcements/' + id, d),
    deleteAnnouncement:(id)     => apiDelete('/api/announcements/' + id),

    // Houses
    getHouses:    ()        => apiGet('/api/houses'),
    addHouse:     (data)    => apiPost('/api/houses', data),
    updateHouse:  (id, d)   => apiPut('/api/houses/' + id, d),
    deleteHouse:  (id)      => apiDelete('/api/houses/' + id),
    replaceHouses:(list)    => apiPut('/api/houses/bulk/replace', { houses: list }),

    // House Logo — multipart upload
    uploadHouseLogo: function(houseId, fd) {
      return fetch('/api/houses/' + houseId + '/logo', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body:    fd,
      }).then(function(res) {
        if (res.status === 401) { sessionStorage.clear(); window.location.href = '/admin_panel/login.html'; }
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },
    removeHouseLogo: (id) => apiDelete('/api/houses/' + id + '/logo'),

    // Generic temp upload — returns Cloudinary URL without DB save
    uploadTemp: function(file, category) {
      var fd = new FormData();
      fd.append('image', file);
      fd.append('category', category || 'misc');
      return fetch('/api/images/upload/temp', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body:    fd,
      }).then(function(res) {
        if (res.status === 401) { sessionStorage.clear(); window.location.href = '/admin_panel/login.html'; }
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },

    // Gallery image upload (multipart)
    uploadGalleryImg: function(fd) {
      return fetch('/api/images/upload/gallery', {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body:    fd,
      }).then(function(res) {
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },

    // School images (logo / principal / banners) — multipart
    uploadSchoolImage: function(category, fd) {
      return fetch('/api/images/upload/' + category, {
        method:  'POST',
        headers: { 'Authorization': 'Bearer ' + getToken() },
        body:    fd,
      }).then(function(res) {
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },

    // Gallery
    getGallery:   ()        => apiGet('/api/gallery'),
    addGallery:   (data)    => apiPost('/api/gallery', data),
    updateGallery:(id, d)   => apiPut('/api/gallery/' + id, d),
    deleteGallery:(id)      => apiDelete('/api/gallery/' + id),

    // Classes
    getClasses:        ()   => apiGet('/api/classes'),
    replaceClasses:(map)    => apiPut('/api/classes/bulk/replace', { classTeachers: map }),

    // Admissions
    getAdmissions:     ()   => apiGet('/api/admissions'),
    updateAdmission:(id,d)  => apiPut('/api/admissions/' + id, d),
    deleteAdmission:  (id)  => apiDelete('/api/admissions/' + id),

    // Attendance
    getAttendance: (sid)    => apiGet('/api/attendance/' + sid),
    markAttendance:(data)   => apiPost('/api/attendance/mark', data),

    // Top Students (year-wise system)
    getTopStudents:      (params)    => apiGet('/api/topstudents' + (params || '')),
    getTopStudentYears:  ()          => apiGet('/api/topstudents/years'),
    getTopStudent:       (id)        => apiGet('/api/topstudents/' + id),
    addTopStudent:       (data)      => apiPost('/api/topstudents', data),
    updateTopStudent:    (id, d)     => apiPut('/api/topstudents/' + id, d),
    deleteTopStudent:    (id)        => apiDelete('/api/topstudents/' + id),
    removeTopStudentImg: (id)        => apiDelete('/api/topstudents/' + id + '/image'),
    uploadTopStudentImg: function(id, fd) {
      // Multipart upload: must NOT set Content-Type (browser sets it with boundary)
      return fetch('/api/topstudents/' + id + '/image', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token') || '') },
        body: fd,
      }).then(function(res) {
        if (res.status === 401) { sessionStorage.clear(); window.location.href = '/admin_panel/login.html'; }
        return res.json().then(function(json) {
          if (!res.ok) throw new Error(json.error || res.statusText);
          return json;
        });
      });
    },

    // Raw access
    get:    apiGet,
    post:   apiPost,
    put:    apiPut,
    delete: apiDelete,
  };

  // ================================================================
  // INIT — Load data immediately and patch dashboard
  // ================================================================
  function _buildDefaults() {
    return {
      schoolInfo: {}, homepageContent: {}, schoolTiming: {}, stats: {},
      topStudents: [], feeStructure: { categories: [] }, socialLinks: {},
      upiPayment: {}, admissions: {}, lockdown: { active: false },
      onlineLinks: {}, calendar: {}, heroImage: '', scores: {},
      teachers: [], events: [], announcements: [], houses: [],
      gallery: [], students: [], classTeachers: {}, attendance: {},
      admissionApplications: [],
    };
  }

  // Kick off the initial load
  ensureLoaded().then(data => {
    console.log('[API Layer] ✅ Data loaded from MongoDB');

    // Patch dashboard stats display if already rendered
    if (data._dashStats) {
      const { total_students, total_teachers, total_events, total_announcements, pending_admissions } = data._dashStats;
      const trySet = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
      trySet('d-students', total_students);
      trySet('d-teachers', total_teachers);
      trySet('d-events',   total_events);
      trySet('d-announce', total_announcements);
      const badge = document.getElementById('app-badge');
      if (badge) {
        badge.textContent = pending_admissions || 0;
        if (badge.style) badge.style.display = (pending_admissions > 0) ? 'inline' : 'none';
      }
    }

    // Broadcast that data is ready (for any listeners)
    window.dispatchEvent(new CustomEvent('schooldb:ready', { detail: data }));

  }).catch(err => {
    console.error('[API Layer] Failed to load data:', err.message);
    if (!_cache) _cache = _buildDefaults();
  });

  // Remove the localStorage storage indicator (no longer relevant)
  document.addEventListener('DOMContentLoaded', () => {
    const indic = document.getElementById('storage-indicator');
    if (indic) indic.style.display = 'none';

    const warn = document.getElementById('storage-warn');
    if (warn) warn.style.display = 'none';

    // Remove "localStorage" warning text from credentials card
    document.querySelectorAll('p').forEach(p => {
      if (p.textContent && p.textContent.includes('localStorage')) {
        p.textContent = '✅ Credentials are securely stored in MongoDB with bcrypt hashing.';
      }
    });
  });

  // SchoolSync stub (real-time — no longer uses BroadcastChannel for storage events)
  // Data changes go to MongoDB and are visible to all devices immediately on next load
  window.SchoolSync = {
    init() {},
    broadcast(section) {
      console.log('[SchoolSync] Section updated:', section);
      window.dispatchEvent(new CustomEvent('schoolsync:update', { detail: { section } }));
    },
    _apply() {},
  };

  console.log('[API Layer] ✅ SchoolDB, AdminAuth, GalleryDB, SchoolSync overridden with API backend');

})();
