// =============================================================
//  admin_panel/js/attendance-patch.js
//  Full Attendance Management System — MongoDB API only
//  Version: 2.0 — Complete Rewrite
// =============================================================

window._attState = {
  students:    [],
  record:      {},
  monthlyData: null,
  yearlyData:  null,
};

Object.defineProperty(window, '_dashAttRecord', {
  get() { return window._attState.record; },
  configurable: true,
});

function _attTok() { return sessionStorage.getItem('admin_token') || ''; }
function _attHdr() {
  return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _attTok() };
}

(function injectStyles() {
  if (document.getElementById('att-patch-style')) return;
  const s = document.createElement('style');
  s.id = 'att-patch-style';
  s.textContent = `
    @keyframes att-spin { to { transform: rotate(360deg); } }
    .att-spinner { width:28px;height:28px;border:3px solid var(--border);border-top-color:var(--primary);border-radius:50%;animation:att-spin .8s linear infinite;margin:0 auto 8px; }
    .att-card-row:hover { background: rgba(255,255,255,.05) !important; cursor:pointer; }
    .att-view-table { width:100%; border-collapse:collapse; font-size:.84rem; }
    .att-view-table th { text-align:left; padding:10px 12px; font-size:.75rem; font-weight:600; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; border-bottom:1px solid var(--border); background:rgba(255,255,255,.03); }
    .att-view-table td { padding:9px 12px; border-bottom:1px solid rgba(255,255,255,.04); vertical-align:middle; }
    .att-view-table tr:hover td { background:rgba(255,255,255,.03); }
    .att-badge-P { display:inline-block; padding:3px 10px; border-radius:20px; font-size:.75rem; font-weight:700; background:rgba(46,204,113,.18); color:#2ecc71; border:1px solid rgba(46,204,113,.3); }
    .att-badge-A { display:inline-block; padding:3px 10px; border-radius:20px; font-size:.75rem; font-weight:700; background:rgba(244,67,54,.15); color:#f44336; border:1px solid rgba(244,67,54,.25); }
    .att-badge-L { display:inline-block; padding:3px 10px; border-radius:20px; font-size:.75rem; font-weight:700; background:rgba(255,193,7,.18); color:#ffc107; border:1px solid rgba(255,193,7,.3); }
    .att-badge-none { display:inline-block; padding:3px 10px; border-radius:20px; font-size:.75rem; color:var(--muted); border:1px solid var(--border); }
    .att-pct-bar-wrap { background:rgba(255,255,255,.07); border-radius:20px; height:6px; width:80px; overflow:hidden; display:inline-block; vertical-align:middle; margin-left:6px; }
    .att-pct-bar { height:6px; border-radius:20px; transition:width .4s; }
    #att-student-modal { position:fixed; inset:0; z-index:10000; background:rgba(0,0,0,.6); backdrop-filter:blur(4px); display:flex; align-items:center; justify-content:center; padding:20px; }
    #att-student-modal .att-modal-box { background:var(--surface); border:1px solid var(--border); border-radius:16px; padding:28px; max-width:620px; width:100%; max-height:80vh; overflow-y:auto; }
    .att-tab-btn { padding:10px 18px; background:none; border:none; border-bottom:2px solid transparent; color:var(--muted); font-family:'Outfit',sans-serif; font-size:.85rem; font-weight:500; cursor:pointer; margin-bottom:-1px; transition:color .2s, border-color .2s; }
    .att-tab-btn.active { border-bottom-color:var(--primary); color:var(--primary); font-weight:600; }
    .att-mark-btn { padding:5px 12px; border-radius:8px; cursor:pointer; font-family:'Outfit',sans-serif; font-size:.78rem; font-weight:600; border:1.5px solid; transition:all .15s; }
    .att-mark-btn.P { border-color:rgba(46,204,113,.4); color:#2ecc71; background:rgba(46,204,113,.1); }
    .att-mark-btn.P.active { background:linear-gradient(135deg,#2ecc71,#27ae60); color:#fff; border-color:transparent; }
    .att-mark-btn.A { border-color:rgba(244,67,54,.35); color:#f44336; background:rgba(244,67,54,.08); }
    .att-mark-btn.A.active { background:linear-gradient(135deg,#f44336,#d32f2f); color:#fff; border-color:transparent; }
    .att-mark-btn.L { border-color:rgba(255,193,7,.35); color:#ffc107; background:rgba(255,193,7,.08); }
    .att-mark-btn.L.active { background:linear-gradient(135deg,#ffc107,#f57f17); color:#fff; border-color:transparent; }
  `;
  document.head.appendChild(s);
})();

// ── Tab switching ─────────────────────────────────────────────
function attSwitchTab(tab) {
  ['daily','view','monthly','yearly'].forEach(function(t) {
    var panel = document.getElementById('att-panel-' + t);
    var btn   = document.getElementById('att-tab-' + t);
    var active = t === tab;
    if (panel) panel.style.display = active ? '' : 'none';
    if (btn)   btn.classList.toggle('active', active);
  });
  if (tab === 'view') {
    var vDate = document.getElementById('attViewDate');
    if (vDate && !vDate.value) vDate.value = new Date().toISOString().slice(0,10);
  }
  if (tab === 'monthly') {
    var mp = document.getElementById('attMonthPicker');
    if (mp && !mp.value) mp.value = new Date().toISOString().slice(0,7);
    loadAttMonthly();
  }
  if (tab === 'yearly') loadAttYearly();
}

// ── Day navigation ────────────────────────────────────────────
window.attPrevDay = function() {
  var el = document.getElementById('dashAttDate');
  if (!el) return;
  var d = new Date((el.value || new Date().toISOString().slice(0,10)) + 'T12:00');
  d.setDate(d.getDate()-1); el.value = d.toISOString().slice(0,10);
  loadDashAttendance();
};
window.attNextDay = function() {
  var el = document.getElementById('dashAttDate');
  if (!el) return;
  var d = new Date((el.value || new Date().toISOString().slice(0,10)) + 'T12:00');
  d.setDate(d.getDate()+1); el.value = d.toISOString().slice(0,10);
  loadDashAttendance();
};
window.attGoToday = function() {
  var el = document.getElementById('dashAttDate');
  if (el) { el.value = new Date().toISOString().slice(0,10); loadDashAttendance(); }
};

// ── Load + Mark attendance (Daily tab) ───────────────────────
async function loadDashAttendance() {
  var cls  = document.getElementById('dashAttClass')?.value || '';
  var sec  = document.getElementById('dashAttSec')?.value   || 'A';
  var date = document.getElementById('dashAttDate')?.value  || new Date().toISOString().slice(0,10);
  if (!cls) return;

  var grid = document.getElementById('dash-att-grid');
  if (grid) grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:32px;color:var(--muted)"><div class="att-spinner"></div>Loading students…</div>';

  try {
    var sRes  = await fetch('/api/students?class='+encodeURIComponent(cls)+'&section='+encodeURIComponent(sec)+'&limit=200');
    var sData = await sRes.json();
    var students = (sData.data||[]).sort(function(a,b){
      var na=parseInt((a.rollNumber||'').replace(/\D/g,''))||0;
      var nb=parseInt((b.rollNumber||'').replace(/\D/g,''))||0;
      return na-nb;
    });

    if (!students.length) {
      if (grid) grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--muted)"><div style="font-size:2.5rem;margin-bottom:12px">👥</div><div style="font-weight:600;margin-bottom:6px">No students found</div><div style="font-size:.85rem">Class '+cls+'-'+sec+' has no students.</div></div>';
      window._attState.students=[]; window._attState.record={};
      updateDashAttSummary(); return;
    }

    var aRes  = await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/'+date);
    var aData = await aRes.json();
    var savedMap = aData.map || {};

    window._attState.students = students;
    var rec = {};
    students.forEach(function(s){ rec[s.studentId] = savedMap[s.studentId]||''; });
    window._attState.record = rec;
    window.dashAttStudents = students;
    window.dashAttRecord   = rec;

    renderDashAttGrid();
    updateDashAttSummary();
    renderDashWeekly(cls, sec);
  } catch(err) {
    if (grid) grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:32px;color:#f44336">⚠️ Could not load: '+err.message+'</div>';
  }
}

function renderDashAttGrid() {
  var grid = document.getElementById('dash-att-grid');
  if (!grid) return;
  var students = window._attState.students;
  var rec      = window._attState.record;
  if (!students.length) {
    grid.innerHTML='<div style="grid-column:1/-1;text-align:center;padding:24px;color:var(--muted)"><div style="font-size:1.5rem;margin-bottom:8px">📋</div>Select class, section and date to mark attendance</div>';
    return;
  }
  grid.innerHTML = students.map(function(s){
    var id=s.studentId, status=rec[id]||'';
    var initials=(s.fullName||'').split(' ').map(function(w){return w[0]||'';}).join('').slice(0,2).toUpperCase();
    return '<div style="background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:12px;padding:14px;transition:background .2s">'+
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">'+
        '<div style="width:34px;height:34px;border-radius:50%;background:rgba(233,30,140,.2);display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:var(--primary);flex-shrink:0">'+initials+'</div>'+
        '<div style="min-width:0">'+
          '<div style="font-size:.86rem;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+(s.fullName||'—')+'</div>'+
          '<div style="font-size:.7rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace">'+(s.rollNumber||'—')+'</div>'+
        '</div>'+
      '</div>'+
      '<div style="display:flex;gap:6px">'+
        '<button onclick="setDashAtt(\''+id+'\',\'P\',this)" class="att-mark-btn P'+(status==='P'?' active':'')+'" style="flex:1">✅ P</button>'+
        '<button onclick="setDashAtt(\''+id+'\',\'A\',this)" class="att-mark-btn A'+(status==='A'?' active':'')+'" style="flex:1">❌ A</button>'+
        '<button onclick="setDashAtt(\''+id+'\',\'L\',this)" class="att-mark-btn L'+(status==='L'?' active':'')+'" style="flex:1">⏰ L</button>'+
      '</div>'+
    '</div>';
  }).join('');
}

function setDashAtt(studentId, status, btn) {
  var cur = window._attState.record[studentId];
  var nv  = cur===status ? '' : status;
  window._attState.record[studentId]=nv;
  var grp = btn.closest('div[style*="display:flex"]');
  if (grp) grp.querySelectorAll('.att-mark-btn').forEach(function(b){
    var s=b.classList.contains('P')?'P':b.classList.contains('A')?'A':'L';
    b.classList.toggle('active', nv===s);
  });
  updateDashAttSummary();
}

function updateDashAttSummary() {
  var rec=window._attState.record, total=window._attState.students.length;
  var present=Object.values(rec).filter(function(v){return v==='P';}).length;
  var absent =Object.values(rec).filter(function(v){return v==='A';}).length;
  var late   =Object.values(rec).filter(function(v){return v==='L';}).length;
  var rate   =total?Math.round((present+late)/total*100):0;
  var el=document.getElementById('dash-att-summary');
  if (!el) return;
  el.innerHTML=[
    {label:'Total',val:total,color:'var(--primary)'},
    {label:'Present',val:present,color:'#2ecc71'},
    {label:'Absent',val:absent,color:'#f44336'},
    {label:'Late',val:late,color:'#ffc107'},
    {label:'Rate',val:rate+'%',color:rate>=75?'#2ecc71':rate>=50?'#ffc107':'#f44336'},
  ].map(function(x){
    return '<div style="background:rgba(255,255,255,.07);border:1px solid var(--border);border-radius:8px;padding:8px 16px;text-align:center;min-width:64px">'+
      '<div style="font-family:\'JetBrains Mono\',monospace;font-size:1.15rem;font-weight:700;color:'+x.color+'">'+x.val+'</div>'+
      '<div style="font-size:.7rem;color:var(--muted)">'+x.label+'</div></div>';
  }).join('');
}

function markAllDash(status) {
  window._attState.students.forEach(function(s){ window._attState.record[s.studentId]=status; });
  renderDashAttGrid(); updateDashAttSummary();
  if (typeof toast==='function') toast('All students marked '+(status==='P'?'Present':status==='A'?'Absent':'Late')+'!','success');
}

async function saveAttendanceDash() {
  var cls  = document.getElementById('dashAttClass')?.value;
  var sec  = document.getElementById('dashAttSec')?.value   || 'A';
  var date = document.getElementById('dashAttDate')?.value  || new Date().toISOString().slice(0,10);
  if (!cls) { if(typeof toast==='function') toast('Please select a class first','error'); return; }
  var rec=window._attState.record;
  var records=Object.entries(rec).filter(function(e){return e[1];}).map(function(e){
    return {studentId:e[0],date:date,status:e[1],class:cls,section:sec};
  });
  if (!records.length) { if(typeof toast==='function') toast('No attendance marked yet','warning'); return; }
  var btn=document.querySelector('button[onclick="saveAttendanceDash()"]');
  if (btn) { btn.disabled=true; btn.innerHTML='⏳ Saving…'; }
  try {
    var res=await fetch('/api/attendance/mark',{method:'POST',headers:_attHdr(),body:JSON.stringify({records:records})});
    var data=await res.json();
    if (!res.ok) throw new Error(data.error||'Save failed');
    if (typeof toast==='function') toast('✅ Saved! '+(data.saved||records.length)+' records for '+date,'success');
    renderDashWeekly(cls,sec);
  } catch(err) {
    if (typeof toast==='function') toast('❌ '+err.message,'error');
  } finally {
    if (btn) { btn.disabled=false; btn.innerHTML='💾 Save'; }
  }
}

// ── 7-day history table ───────────────────────────────────────
async function renderDashWeekly(cls, sec) {
  var el=document.getElementById('dash-att-weekly');
  if (!el||!window._attState.students.length) return;
  var days=Array.from({length:7},function(_,i){
    var d=new Date(); d.setDate(d.getDate()-i); return d.toISOString().slice(0,10);
  }).reverse();
  el.innerHTML='<div style="text-align:center;padding:16px;color:var(--muted)"><div class="att-spinner"></div>Loading history…</div>';
  try {
    var months=[...new Set(days.map(function(d){return d.slice(0,7);}))];
    var allRecords=[];
    for (var m of months) {
      var r=await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/monthly?month='+m);
      var d=await r.json(); if (d.records) allRecords=allRecords.concat(d.records);
    }
    var dayMap={};
    allRecords.forEach(function(r){
      if (!dayMap[r.date]) dayMap[r.date]={};
      dayMap[r.date][r.studentId]=r.status;
    });
    var students=window._attState.students.slice(0,30);
    var colHeaders=days.map(function(d){
      return '<th style="font-size:.66rem;text-align:center;padding:6px 3px;color:var(--muted);font-weight:500;white-space:nowrap">'+
        new Date(d+'T12:00').toLocaleDateString('en-IN',{weekday:'short',day:'numeric'})+'</th>';
    }).join('');
    var today=new Date().toISOString().slice(0,10);
    var rows=students.map(function(s){
      var todayStatus=(dayMap[today]||{})[s.studentId]||'';
      var todayBadge=todayStatus==='P'?'<span class="att-badge-P" style="padding:1px 7px;font-size:.7rem;margin-left:5px">P</span>':
                     todayStatus==='A'?'<span class="att-badge-A" style="padding:1px 7px;font-size:.7rem;margin-left:5px">A</span>':
                     todayStatus==='L'?'<span class="att-badge-L" style="padding:1px 7px;font-size:.7rem;margin-left:5px">L</span>':'';
      var cells=days.map(function(d){
        var v=(dayMap[d]||{})[s.studentId]||'';
        var chip=v==='P'?'<span class="att-badge-P" style="padding:1px 6px;font-size:.68rem">P</span>':
                 v==='A'?'<span class="att-badge-A" style="padding:1px 6px;font-size:.68rem">A</span>':
                 v==='L'?'<span class="att-badge-L" style="padding:1px 6px;font-size:.68rem">L</span>':
                         '<span style="color:var(--border);font-size:.65rem">·</span>';
        return '<td style="text-align:center;padding:5px 3px">'+chip+'</td>';
      }).join('');
      return '<tr class="att-card-row" onclick="openStudentHistory(\''+s.studentId+'\',\''+s.fullName.replace(/'/g,"\\'")+'\')">' +
        '<td style="padding:6px 8px;font-size:.8rem;font-weight:500;white-space:nowrap">'+s.fullName+'</td>'+
        '<td style="padding:6px 4px;font-size:.72rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace;white-space:nowrap">'+(s.rollNumber||'—')+todayBadge+'</td>'+
        cells+'</tr>';
    }).join('');
    el.innerHTML='<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.8rem">'+
      '<thead><tr style="border-bottom:1px solid var(--border)">'+
        '<th style="text-align:left;padding:6px 8px;font-size:.7rem;color:var(--muted)">Student</th>'+
        '<th style="text-align:left;padding:6px 4px;font-size:.7rem;color:var(--muted)">Roll / Today</th>'+
        colHeaders+'</tr></thead><tbody>'+rows+'</tbody></table>'+
      (window._attState.students.length>30?'<div style="text-align:center;padding:8px;font-size:.73rem;color:var(--muted)">Showing first 30 · <a href="../frontend/pages/attendance.html" target="_blank" style="color:var(--primary)">View full page →</a></div>':'')+
    '</div>';
  } catch(err) {
    el.innerHTML='<div style="color:#f44336;padding:12px;font-size:.8rem">❌ Could not load history: '+err.message+'</div>';
  }
}

// ── View attendance by date (read-only) ───────────────────────
async function loadAttView() {
  var cls  = document.getElementById('attViewClass')?.value || '';
  var sec  = document.getElementById('attViewSec')?.value   || 'A';
  var date = document.getElementById('attViewDate')?.value  || new Date().toISOString().slice(0,10);
  var container=document.getElementById('att-view-result');
  if (!container) return;
  if (!cls) {
    container.innerHTML='<div style="text-align:center;padding:32px;color:var(--muted)"><div style="font-size:2rem;margin-bottom:8px">🔍</div>Select class, section and date, then click View Attendance</div>';
    return;
  }
  container.innerHTML='<div style="text-align:center;padding:32px;color:var(--muted)"><div class="att-spinner"></div>Loading attendance for '+date+'…</div>';
  try {
    var sRes=await fetch('/api/students?class='+encodeURIComponent(cls)+'&section='+encodeURIComponent(sec)+'&limit=200');
    var sData=await sRes.json();
    var students=(sData.data||[]).sort(function(a,b){
      return (parseInt((a.rollNumber||'').replace(/\D/g,''))||0)-(parseInt((b.rollNumber||'').replace(/\D/g,''))||0);
    });
    var aRes=await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/'+date);
    var aData=await aRes.json();
    var attMap=aData.map||{};
    var dateLabel=new Date(date+'T12:00').toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    var present=Object.values(attMap).filter(function(v){return v==='P';}).length;
    var absent =Object.values(attMap).filter(function(v){return v==='A';}).length;
    var late   =Object.values(attMap).filter(function(v){return v==='L';}).length;
    var total=students.length, marked=Object.keys(attMap).length;
    var rate=total?Math.round((present+late)/total*100):0;
    var summaryHtml='<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">'+
      [{l:'Class',v:cls+'-'+sec,c:'var(--primary)'},{l:'Total',v:total,c:'var(--text)'},{l:'Present',v:present,c:'#2ecc71'},{l:'Absent',v:absent,c:'#f44336'},{l:'Late',v:late,c:'#ffc107'},{l:'Rate',v:rate+'%',c:rate>=75?'#2ecc71':'#f44336'}]
      .map(function(x){return '<div style="background:rgba(255,255,255,.07);border:1px solid var(--border);border-radius:10px;padding:10px 16px;text-align:center;min-width:70px"><div style="font-family:\'JetBrains Mono\',monospace;font-size:1.2rem;font-weight:700;color:'+x.c+'">'+x.v+'</div><div style="font-size:.7rem;color:var(--muted);margin-top:2px">'+x.l+'</div></div>';}).join('')+
    '</div>';
    if (!students.length) { container.innerHTML=summaryHtml+'<div style="text-align:center;padding:24px;color:var(--muted)">No students found for Class '+cls+'-'+sec+'.</div>'; return; }
    var rows=students.map(function(s,i){
      var status=attMap[s.studentId]||'';
      var badge=status?('<span class="att-badge-'+status+'">'+(status==='P'?'Present':status==='A'?'Absent':'Late')+'</span>'):('<span class="att-badge-none">Not Marked</span>');
      return '<tr><td style="font-size:.8rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace">'+(i+1)+'</td>'+
        '<td style="font-size:.8rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace">'+(s.rollNumber||'—')+'</td>'+
        '<td style="font-weight:600">'+(s.fullName||'—')+'</td>'+
        '<td>'+badge+'</td></tr>';
    }).join('');
    container.innerHTML=summaryHtml+
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:8px">'+
        '<div style="font-size:.85rem;font-weight:600;color:var(--text)">Attendance · '+cls+'-'+sec+' · '+dateLabel+(marked===0?' <span style="margin-left:8px;font-size:.75rem;color:#ffc107">⚠ Not marked yet</span>':'')+'</div>'+
        '<button onclick="exportViewCSV(\''+cls+'\',\''+sec+'\',\''+date+'\')" style="background:rgba(102,187,106,.15);border:1px solid rgba(102,187,106,.4);border-radius:9px;padding:7px 14px;color:#2e7d32;font-family:\'Outfit\',sans-serif;font-size:.8rem;cursor:pointer;font-weight:600">⬇ Export CSV</button>'+
      '</div>'+
      '<div style="overflow-x:auto"><table class="att-view-table"><thead><tr><th style="width:40px">#</th><th>Roll No.</th><th>Student Name</th><th>Status</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
  } catch(err) {
    container.innerHTML='<div style="text-align:center;padding:32px;color:#f44336">⚠️ Error: '+err.message+'</div>';
  }
}

async function exportViewCSV(cls, sec, date) {
  try {
    var sRes=await fetch('/api/students?class='+encodeURIComponent(cls)+'&section='+encodeURIComponent(sec)+'&limit=200');
    var sData=await sRes.json();
    var students=(sData.data||[]).sort(function(a,b){return (parseInt((a.rollNumber||'').replace(/\D/g,''))||0)-(parseInt((b.rollNumber||'').replace(/\D/g,''))||0);});
    var aRes=await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/'+date);
    var aData=await aRes.json();
    var attMap=aData.map||{};
    var rows=[['#','Roll No','Student Name','Status','Date','Class','Section']].concat(
      students.map(function(s,i){return [i+1,s.rollNumber||'',s.fullName||'',attMap[s.studentId]||'Not Marked',date,cls,sec];}));
    var csv=rows.map(function(r){return r.map(function(v){return '"'+v+'"';}).join(',');}).join('\n');
    var blob=new Blob([csv],{type:'text/csv'});
    var a=document.createElement('a'); a.href=URL.createObjectURL(blob);
    a.download='attendance_'+cls+'_'+sec+'_'+date+'.csv'; a.click();
  } catch(err) { if(typeof toast==='function') toast('Export failed: '+err.message,'error'); }
}

// ── Monthly tab ───────────────────────────────────────────────
async function loadAttMonthly() {
  var cls  =document.getElementById('attMonthClass')?.value  || '';
  var sec  =document.getElementById('attMonthSec')?.value    || 'A';
  var month=document.getElementById('attMonthPicker')?.value || new Date().toISOString().slice(0,7);
  if (!cls) return;
  var calEl=document.getElementById('att-monthly-calendar');
  var tblEl=document.getElementById('att-monthly-table');
  if (calEl) calEl.innerHTML='<div style="text-align:center;padding:24px;color:var(--muted)"><div class="att-spinner"></div>Loading…</div>';
  if (tblEl) tblEl.innerHTML='';
  try {
    var res=await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/monthly?month='+month);
    var data=await res.json();
    window._attState.monthlyData=data;
    _renderMonthlyCalendar(data,month,cls,sec);
    _renderMonthlyTable(data,month);
  } catch(err) {
    if (calEl) calEl.innerHTML='<div style="color:#f44336;padding:16px">❌ '+err.message+'</div>';
  }
}

function _renderMonthlyCalendar(data, month, cls, sec) {
  var el=document.getElementById('att-monthly-calendar'); if (!el) return;
  var parts=month.split('-').map(Number), yr=parts[0], mo=parts[1];
  var firstDay=new Date(yr,mo-1,1).getDay(), lastDay=new Date(yr,mo,0).getDate();
  var dayMap={};
  (data.records||[]).forEach(function(r){
    var d=r.date.slice(8,10);
    if (!dayMap[d]) dayMap[d]={P:0,A:0,L:0};
    if (r.status==='P') dayMap[d].P++;
    else if (r.status==='A') dayMap[d].A++;
    else if (r.status==='L') dayMap[d].L++;
  });
  var monthLabel=new Date(yr,mo-1,1).toLocaleDateString('en-IN',{month:'long',year:'numeric'});
  var dayNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  var dayHeaders=dayNames.map(function(d){return '<div style="font-size:.72rem;font-weight:600;color:var(--muted);text-align:center;padding:6px 0">'+d+'</div>';}).join('');
  var cells='';
  for (var i=0;i<firstDay;i++) cells+='<div></div>';
  var todayStr=new Date().toISOString().slice(0,10);
  for (var day=1;day<=lastDay;day++) {
    var key=String(day).padStart(2,'0');
    var dd=dayMap[key], total=dd?dd.P+dd.A+dd.L:0, pct=total?Math.round(dd.P/total*100):null;
    var isToday=todayStr===(month+'-'+key);
    var bg=dd&&total>0?(pct>=75?'rgba(46,204,113,.12)':pct>=50?'rgba(255,193,7,.12)':'rgba(244,67,54,.1)'):'rgba(255,255,255,.04)';
    var col=dd&&total>0?(pct>=75?'#2ecc71':pct>=50?'#ffc107':'#f44336'):'var(--muted)';
    var dot=dd&&total>0?('<div style="font-size:.62rem;color:'+col+';margin-top:2px">'+pct+'%</div>'):'';
    cells+='<div onclick="window.loadDashAttForDate(\''+month+'-'+key+'\')" style="background:'+bg+';border:1.5px solid '+(isToday?'var(--primary)':'var(--border)')+';border-radius:10px;padding:8px 4px;text-align:center;cursor:pointer" title="'+(dd?'P:'+dd.P+' A:'+dd.A+' L:'+dd.L:'No data')+'">'+
      '<div style="font-size:.82rem;font-weight:'+(isToday?'700':'500')+';color:'+(isToday?'var(--primary)':'var(--text)')+'">'+day+'</div>'+dot+'</div>';
  }
  el.innerHTML='<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px">'+
    '<div style="font-weight:600;font-size:.95rem">'+monthLabel+' — Class '+cls+'-'+sec+'</div>'+
    '<div style="display:flex;gap:12px;font-size:.75rem"><span style="color:#2ecc71">● ≥75%</span><span style="color:#ffc107">● 50–74%</span><span style="color:#f44336">● &lt;50%</span></div>'+
  '</div>'+
  '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:8px">'+dayHeaders+'</div>'+
  '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">'+cells+'</div>'+
  '<div style="font-size:.72rem;color:var(--muted);margin-top:8px">Click any date to jump to daily view</div>';
}

function _renderMonthlyTable(data) {
  var el=document.getElementById('att-monthly-table'); if (!el) return;
  var students=data.students||[];
  if (!students.length) { el.innerHTML='<div style="text-align:center;padding:24px;color:var(--muted)">No attendance data for this month</div>'; return; }
  var rows=students.map(function(s,i){
    var pct=s.percentage||0, col=pct>=75?'#2ecc71':pct>=50?'#ffc107':'#f44336';
    return '<tr class="att-card-row" onclick="openStudentHistory(\''+s.studentId+'\',\''+((s.name||'').replace(/'/g,"\\'"))+'\')">' +
      '<td style="padding:9px 12px;font-size:.78rem;color:var(--muted)">'+(i+1)+'</td>'+
      '<td style="padding:9px 8px;font-size:.78rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace">'+(s.roll||'—')+'</td>'+
      '<td style="padding:9px 12px;font-weight:600">'+(s.name||'—')+'</td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-P" style="padding:2px 8px">'+s.present+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-A" style="padding:2px 8px">'+s.absent+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-L" style="padding:2px 8px">'+(s.late||0)+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center;color:var(--muted);font-size:.8rem">'+s.totalDays+'</td>'+
      '<td style="padding:9px 12px"><div style="display:flex;align-items:center;gap:8px">'+
        '<span style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:'+col+';font-size:.85rem;min-width:38px">'+pct+'%</span>'+
        '<div class="att-pct-bar-wrap"><div class="att-pct-bar" style="width:'+pct+'%;background:'+col+'"></div></div>'+
      '</div></td></tr>';
  }).join('');
  el.innerHTML='<div style="font-size:.85rem;font-weight:600;color:var(--text);margin-bottom:12px">Student-wise Attendance Report · '+students.length+' students</div>'+
    '<div style="overflow-x:auto"><table class="att-view-table"><thead><tr><th style="width:36px">#</th><th>Roll</th><th>Student Name</th><th style="text-align:center">Present</th><th style="text-align:center">Absent</th><th style="text-align:center">Late</th><th style="text-align:center">Days</th><th>Attendance %</th></tr></thead><tbody>'+rows+'</tbody></table></div>'+
    '<div style="font-size:.73rem;color:var(--muted);margin-top:8px">Click any student to see full history</div>';
}

window.loadDashAttForDate = function(date) {
  attSwitchTab('daily');
  var el=document.getElementById('dashAttDate');
  if (el) { el.value=date; loadDashAttendance(); }
};

function exportMonthlyCSV() {
  var data=window._attState.monthlyData;
  if (!data||!data.students) { if(typeof toast==='function') toast('Load monthly data first','warning'); return; }
  var rows=[['#','Roll','Student','Present','Absent','Late','Total Days','Percentage']].concat(
    data.students.map(function(s,i){return [i+1,s.roll||'',s.name||'',s.present,s.absent,s.late||0,s.totalDays,s.percentage+'%'];}));
  var csv=rows.map(function(r){return r.map(function(v){return '"'+v+'"';}).join(',');}).join('\n');
  var blob=new Blob([csv],{type:'text/csv'}), a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='attendance_monthly_'+(data.class||'')+'_'+(data.section||'')+'_'+(data.month||'')+'.csv'; a.click();
}

// ── Yearly tab ────────────────────────────────────────────────
async function loadAttYearly() {
  var cls=document.getElementById('attYearClass')?.value||'';
  var sec=document.getElementById('attYearSec')?.value||'A';
  var yearEl=document.getElementById('attYearPicker');
  var year=yearEl?.value||'';
  if (!year) {
    var now=new Date(), m=now.getMonth()+1, y=now.getFullYear();
    year=m>=4?y+'-'+String(y+1).slice(-2):(y-1)+'-'+String(y).slice(-2);
    if (yearEl) yearEl.value=year;
  }
  if (!cls) return;
  var barsEl=document.getElementById('att-yearly-bars');
  var tblEl=document.getElementById('att-yearly-table');
  if (barsEl) barsEl.innerHTML='<div style="text-align:center;padding:24px;color:var(--muted)"><div class="att-spinner"></div>Loading…</div>';
  if (tblEl)  tblEl.innerHTML='';
  try {
    var res=await fetch('/api/attendance/class/'+encodeURIComponent(cls)+'/'+encodeURIComponent(sec)+'/yearly?year='+year);
    var data=await res.json();
    window._attState.yearlyData=data;
    _renderYearlyBars(data,year,cls,sec);
    _renderYearlyTable(data);
  } catch(err) {
    if (barsEl) barsEl.innerHTML='<div style="color:#f44336;padding:16px">❌ '+err.message+'</div>';
  }
}

function _renderYearlyBars(data,year,cls,sec) {
  var el=document.getElementById('att-yearly-bars'); if (!el) return;
  var months=data.months||[];
  var bars=months.map(function(m){
    var pct=m.percentage, col=pct===null?'var(--border)':pct>=75?'#2ecc71':pct>=50?'#ffc107':'#f44336';
    return '<div style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;min-width:40px">'+
      '<div style="font-size:.7rem;font-weight:600;color:'+(pct===null?'var(--muted)':col)+'">'+(pct===null?'—':pct+'%')+'</div>'+
      '<div style="width:100%;background:rgba(255,255,255,.07);border-radius:6px;height:80px;display:flex;align-items:flex-end;overflow:hidden">'+
        '<div style="width:100%;background:'+col+';border-radius:6px;height:'+(pct===null?0:pct)+'%;transition:height .6s;opacity:'+(m.hasData?1:.4)+'"></div></div>'+
      '<div style="font-size:.65rem;color:var(--muted);text-align:center">'+m.month+'</div>'+
      '<div style="font-size:.6rem;color:var(--muted)">'+m.workingDays+'d</div></div>';
  }).join('');
  el.innerHTML='<div style="font-weight:600;font-size:.9rem;margin-bottom:14px">Monthly Overview · Class '+cls+'-'+sec+' · '+year+'</div>'+
    '<div style="display:flex;gap:6px;align-items:flex-end;overflow-x:auto;padding-bottom:8px">'+bars+'</div>'+
    '<div style="display:flex;gap:16px;font-size:.75rem;margin-top:8px"><span style="color:#2ecc71">● ≥75%</span><span style="color:#ffc107">● 50–74%</span><span style="color:#f44336">● &lt;50%</span><span style="color:var(--muted)">● No data</span></div>';
}

function _renderYearlyTable(data) {
  var el=document.getElementById('att-yearly-table'); if (!el) return;
  var students=data.students||[];
  if (!students.length) { el.innerHTML='<div style="text-align:center;padding:24px;color:var(--muted)">No data for this year</div>'; return; }
  var rows=students.map(function(s,i){
    var pct=s.percentage||0, col=pct>=75?'#2ecc71':pct>=50?'#ffc107':'#f44336';
    return '<tr class="att-card-row" onclick="openStudentHistory(\''+s.studentId+'\',\''+((s.name||'').replace(/'/g,"\\'"))+'\')">' +
      '<td style="padding:9px 12px;font-size:.78rem;color:var(--muted)">'+(i+1)+'</td>'+
      '<td style="padding:9px 8px;font-size:.78rem;color:var(--muted);font-family:\'JetBrains Mono\',monospace">'+(s.roll||'—')+'</td>'+
      '<td style="padding:9px 12px;font-weight:600">'+(s.name||'—')+'</td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-P" style="padding:2px 8px">'+s.present+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-A" style="padding:2px 8px">'+s.absent+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center"><span class="att-badge-L" style="padding:2px 8px">'+(s.late||0)+'</span></td>'+
      '<td style="padding:9px 8px;text-align:center;color:var(--muted);font-size:.8rem">'+s.totalDays+'</td>'+
      '<td style="padding:9px 12px"><div style="display:flex;align-items:center;gap:8px">'+
        '<span style="font-family:\'JetBrains Mono\',monospace;font-weight:700;color:'+col+';font-size:.88rem;min-width:42px">'+pct+'%</span>'+
        '<div class="att-pct-bar-wrap" style="width:100px"><div class="att-pct-bar" style="width:'+pct+'%;background:'+col+'"></div></div>'+
      '</div></td></tr>';
  }).join('');
  el.innerHTML='<div style="font-size:.85rem;font-weight:600;margin-bottom:12px">Annual Student Report · '+students.length+' students</div>'+
    '<div style="overflow-x:auto"><table class="att-view-table"><thead><tr><th style="width:36px">#</th><th>Roll</th><th>Student Name</th><th style="text-align:center">Present</th><th style="text-align:center">Absent</th><th style="text-align:center">Late</th><th style="text-align:center">Total</th><th>Annual %</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
}

// ── Student history modal ─────────────────────────────────────
async function openStudentHistory(studentId, name) {
  var existing=document.getElementById('att-student-modal'); if (existing) existing.remove();
  var modal=document.createElement('div'); modal.id='att-student-modal';
  modal.innerHTML='<div class="att-modal-box">'+
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">'+
      '<div><div style="font-weight:700;font-size:1rem">'+(name||'Student')+'</div>'+
      '<div style="font-size:.78rem;color:var(--muted)">Attendance History</div></div>'+
      '<button onclick="document.getElementById(\'att-student-modal\').remove()" style="background:rgba(255,255,255,.1);border:1px solid var(--border);border-radius:8px;padding:6px 12px;cursor:pointer;color:var(--text);font-family:\'Outfit\',sans-serif">✕ Close</button>'+
    '</div><div id="att-hist-body" style="text-align:center;padding:24px;color:var(--muted)"><div class="att-spinner"></div>Loading…</div></div>';
  modal.addEventListener('click',function(e){ if(e.target===modal) modal.remove(); });
  document.body.appendChild(modal);
  try {
    var res=await fetch('/api/attendance/'+studentId,{headers:_attHdr()});
    var data=await res.json();
    var body=document.getElementById('att-hist-body'); if (!body) return;
    var s=data.summary||{}, total=s.total||0;
    var monthly=(data.monthly||[]).slice(0,12);
    var monthRows=monthly.map(function(m){
      var pct=m.percentage||0, col=pct>=75?'#2ecc71':pct>=50?'#ffc107':'#f44336';
      return '<tr><td style="padding:7px 10px;font-size:.8rem">'+m.month+'</td>'+
        '<td style="padding:7px 8px;text-align:center"><span class="att-badge-P" style="padding:1px 7px">'+m.present+'</span></td>'+
        '<td style="padding:7px 8px;text-align:center"><span class="att-badge-A" style="padding:1px 7px">'+m.absent+'</span></td>'+
        '<td style="padding:7px 8px;text-align:center;font-weight:700;color:'+col+'">'+pct+'%</td></tr>';
    }).join('');
    body.innerHTML='<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">'+
      [{l:'Total',v:total,c:'var(--text)'},{l:'Present',v:s.present||0,c:'#2ecc71'},{l:'Absent',v:s.absent||0,c:'#f44336'},{l:'Late',v:s.late||0,c:'#ffc107'},{l:'Overall',v:(s.percentage||0)+'%',c:(s.percentage||0)>=75?'#2ecc71':'#f44336'}]
      .map(function(x){return '<div style="background:rgba(255,255,255,.07);border:1px solid var(--border);border-radius:10px;padding:10px 16px;text-align:center;flex:1"><div style="font-family:\'JetBrains Mono\',monospace;font-size:1.1rem;font-weight:700;color:'+x.c+'">'+x.v+'</div><div style="font-size:.68rem;color:var(--muted);margin-top:2px">'+x.l+'</div></div>';}).join('')+
    '</div>'+(monthly.length?'<div style="font-size:.82rem;font-weight:600;margin-bottom:10px">Monthly Breakdown</div>'+
      '<div style="overflow-x:auto"><table class="att-view-table"><thead><tr><th>Month</th><th style="text-align:center">Present</th><th style="text-align:center">Absent</th><th style="text-align:center">%</th></tr></thead><tbody>'+monthRows+'</tbody></table></div>':
      '<div style="color:var(--muted);text-align:center;padding:16px">No monthly data available</div>');
  } catch(err) {
    var body=document.getElementById('att-hist-body');
    if (body) body.innerHTML='<div style="color:#f44336">❌ '+err.message+'</div>';
  }
}

// ── loadAttendanceMgmt — called by admin nav ──────────────────
function loadAttendanceMgmt() {
  var today=new Date().toISOString().slice(0,10);
  var monthNow=today.slice(0,7);
  var dateEl=document.getElementById('dashAttDate');
  var vDateEl=document.getElementById('attViewDate');
  var mPicker=document.getElementById('attMonthPicker');
  if (dateEl  && !dateEl.value)  dateEl.value=today;
  if (vDateEl && !vDateEl.value) vDateEl.value=today;
  if (mPicker && !mPicker.value) mPicker.value=monthNow;
  attSwitchTab('daily');
}

console.log('[attendance-patch v2.0] ✅ MongoDB-backed attendance system loaded');
