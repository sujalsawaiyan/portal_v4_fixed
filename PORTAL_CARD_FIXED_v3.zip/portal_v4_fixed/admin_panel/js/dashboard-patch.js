// ================================================================
// SCHOOL PORTAL — PRODUCTION API PATCH
// ================================================================
// This block runs LAST, after all dashboard functions are defined.
// It overrides localStorage-based CRUD with direct MongoDB API calls.
// The UI/UX is completely unchanged — only the data layer is replaced.
// ================================================================

(function () {
  'use strict';

  // ── Wait until api-layer is ready, then patch ─────────────────
  // ✅ FIXED v2.2.0: Also listen for schooldb:refreshed so the dashboard
  // re-renders automatically once real MongoDB data replaces the defaults.
  function onReady(fn) {
    if (window.API && window.SchoolDB) return fn();
    window.addEventListener('schooldb:ready',     fn, { once: true });
    window.addEventListener('schooldb:refreshed', function(e) {
      // Re-render the currently active section with fresh data
      var activeSection = document.querySelector('.page-section.active');
      if (activeSection && typeof window.navTo === 'function') {
        var pageId = activeSection.id.replace('page-', '');
        window.navTo(pageId);
      } else if (typeof window.loadDashboard === 'function') {
        window.loadDashboard();
      }
    });
    // setTimeout removed — caused navTo to be wrapped twice after 3s
  }

  onReady(function () {

    // ══════════════════════════════════════════════════════════════
    // DASHBOARD INIT — Wait for API data before loading sections
    // ══════════════════════════════════════════════════════════════
    // showSection doesn't exist in this dashboard — navTo() is used instead
    // So we patch navTo to always reload data after section switch
    if (window._navToPatchApplied) return;  // prevent double-wrapping
    window._navToPatchApplied = true;
    var _origNavTo = window.navTo;
    if (typeof _origNavTo === 'function') {
      window.navTo = function (id) {
        _origNavTo(id);
        // Re-load the section data from fresh cache after navigation
        var loaders = {
          'dashboard':       function () { window.SchoolDB.waitForLoad().then(function(){ loadDashboard(); }); },
          'teachers':        function () { window.SchoolDB.waitForLoad().then(function(){ loadTeachers(); }); },
          'events':          function () { window.SchoolDB.waitForLoad().then(function(){ loadEvents(); }); },
          'announcements':   function () { window.SchoolDB.waitForLoad().then(function(){ loadAnnouncements(); }); },
          'students':        function () { window.SchoolDB.waitForLoad().then(function(){ loadStudents(); }); },
          'student-mgmt':    function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadStudentMgmt==='function') loadStudentMgmt(); }); },
          'class-mgmt':      function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadClassMgmt==='function') loadClassMgmt(); }); },
          'houses':          function () { window.SchoolDB.reload().then(function(){ loadHouses(); }); },
          'gallery':         function () { window.SchoolDB.waitForLoad().then(function(){ loadGallery(); }); },
          'school-info':     function () { window.SchoolDB.waitForLoad().then(function(){ loadSchoolInfo(); }); },
          'homepage':        function () { window.SchoolDB.waitForLoad().then(function(){ loadHomepageContent(); }); },
          'timing':          function () { window.SchoolDB.waitForLoad().then(function(){ loadTiming(); }); },
          'stats':           function () { window.SchoolDB.waitForLoad().then(function(){ loadStats(); }); },
          'top-students':    function () { window.SchoolDB.waitForLoad().then(function(){ window.loadTopStudentsAdmin ? window.loadTopStudentsAdmin() : loadTopStudents(); }); },
          'admissions':      function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadAdmissions==='function') loadAdmissions(); if(typeof loadAdmissionsPage==='function') loadAdmissionsPage(); }); },
          'fee-structure':   function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadFeeStructure==='function') loadFeeStructure(); }); },
          'online':          function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadOnlineSection==='function') loadOnlineSection(); }); },
          'social':          function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadSocialSection==='function') loadSocialSection(); }); },
          'upi-qr':          function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadUpiSection==='function') loadUpiSection(); }); },
          'exam-schedule':   function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadExamSchedule==='function') loadExamSchedule(); }); },
          'attendance-mgmt': function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadAttendanceMgmt==='function') loadAttendanceMgmt(); }); },
          'fees':            function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadFeeRecords==='function') loadFeeRecords(); }); },
          'school-settings': function () { window.SchoolDB.waitForLoad().then(function(){ if(typeof loadSchoolSettings==='function') loadSchoolSettings(); }); },
          'whatsapp-settings':function(){ if(typeof loadWhatsappSettings==='function') loadWhatsappSettings(); },
          'security':        function () { if(typeof loadSecurityDashboard==='function') loadSecurityDashboard(); },
          'applications':    function () { if(typeof loadApplications==='function') loadApplications(); },
          'backup':          function () { if(typeof loadBackupList==='function') loadBackupList(); },
          'subjects':        function () { /* loaded on class select */ },
          'teacher-accounts':function () { if(typeof loadTeacherAccounts==='function') loadTeacherAccounts(); },
          'marks':           function () { /* user selects class manually */ },
          'account':         function () {
            var c = window.AdminAuth ? window.AdminAuth.getCredentials() : {};
            var el = document.getElementById('acc-curr-user');
            if (el) el.value = c.username || 'admin';
          },
        };
        if (loaders[id]) loaders[id]();
      };
    }

    // Trigger initial dashboard load after data is ready
    var initSection = document.querySelector('.page-section.active');
    if (initSection && initSection.id) {
      try { loadDashboard(); } catch (e) {}
    }

    // ══════════════════════════════════════════════════════════════
    // STUDENTS — Full API-driven CRUD
    // ══════════════════════════════════════════════════════════════

    window.submitAddStudent = async function () {
      var roll    = (document.getElementById('s-roll')?.value    || '').trim();
      var name    = (document.getElementById('s-name')?.value    || '').trim();
      var cls     = (document.getElementById('s-class')?.value   || '');
      var section = (document.getElementById('s-section')?.value || 'A').trim().toUpperCase();
      var dob     = (document.getElementById('s-dob')?.value     || '');
      if (!roll || !name || !cls) { toast('Roll number, name and class are required', 'error'); return; }

      // Default password = Roll No. + Section  e.g. "01A"
      var defaultPassword = roll + section;

      var payload = {
        fullName:      name,
        rollNumber:    roll,
        class:         cls,
        section:       section,
        dateOfBirth:   dob,
        gender:        document.getElementById('s-gender')?.value || '',
        house:         document.getElementById('s-house')?.value  || '',
        guardianName:  document.getElementById('s-guardian')?.value?.trim() || '',
        guardianPhone: document.getElementById('s-phone')?.value?.trim()    || '',
        email:         document.getElementById('s-email')?.value?.trim()    || '',
        password:      defaultPassword,
      };

      try {
        var r = await window.API.addStudent(payload);
        var genId = r.studentId || (r.student && r.student.studentId) || '';

        // B1 FIX: Show generated ID in the form field
        var idEl = document.getElementById('s-student-id');
        if (idEl && genId) idEl.value = genId;

        // B1 FIX: Upload student photo if one was selected
        var photoFile = window._newStudentPhotoFile || null;
        if (photoFile && genId) {
          try {
            var fd = new FormData();
            fd.append('photo', photoFile);
            await window.API.uploadStudentPhoto(genId, fd);
          } catch (pErr) { console.warn('Photo upload failed:', pErr.message); }
        }
        window._newStudentPhotoFile = null;

        toast('✅ "' + name + '" added! ID: ' + genId + ' | Parent pass: ' + defaultPassword, 'success');
        ['s-roll','s-name','s-dob','s-guardian','s-phone','s-email']
          .forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
        closeModal('modalAddStudent');
        window.SchoolDB.reload().then(loadStudents);
        loadDashboard();
      } catch (err) {
        toast('❌ ' + (err.message || 'Save failed'), 'error');
      }
    };

    window.deleteStudent = function (idx) {
      if (!confirm('Are you sure you want to delete this student?')) return;
      var db = window.SchoolDB.load();
      var s  = (db.students || [])[idx];
      if (!s) { toast('Student not found', 'error'); return; }
      // FIX B2: use MongoDB studentId field for API call
      var apiId = s.studentId || s.student_id || s._id || s.id;
      if (!apiId) { toast('Student ID not found', 'error'); return; }
      window.API.deleteStudent(apiId)
        .then(function () {
          toast('✅ Student deleted.', 'success');
          window.SchoolDB.reload().then(loadStudents);
          loadDashboard();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    // Student Management CRUD (class-wise view) — delegates to deleteStudent
    window.deleteStudentMgmt = function (idx) {
      window.deleteStudent(idx);
    };

    // ── BUG FIX B3: submitEditStudent — use API not SchoolDB ──────
    window.submitEditStudent = async function () {
      var idx   = parseInt(document.getElementById('ese-idx').value);
      var name  = document.getElementById('ese-name').value.trim();
      var roll  = document.getElementById('ese-roll').value.trim();
      var cls   = document.getElementById('ese-class').value.trim();
      var sec   = document.getElementById('ese-section').value;
      var house = document.getElementById('ese-house').value;
      var fees  = document.getElementById('ese-fees').value;
      var gname = document.getElementById('ese-guardian').value.trim();
      var gphone= document.getElementById('ese-phone').value.trim();
      if (!name) { toast('Name is required', 'error'); return; }
      var db = window.SchoolDB.load();
      var s  = (db.students || [])[idx];
      if (!s) { toast('Student not found', 'error'); return; }
      var apiId = s.studentId || s.student_id || s._id || s.id;
      if (!apiId) { toast('Student ID not found', 'error'); return; }
      try {
        await window.API.updateStudent(apiId, {
          fullName: name, rollNumber: roll,
          class: cls, section: sec,
          house: house, fees_status: fees,
          guardianName: gname, guardianPhone: gphone,
        });
        toast('✅ ' + name + ' updated!', 'success');
        closeModal('modalEditStudent');
        window.SchoolDB.reload().then(function() {
          if (typeof loadStudentMgmt === 'function') loadStudentMgmt();
          if (typeof loadStudents === 'function') loadStudents();
          if (typeof renderCMStudents === 'function') renderCMStudents();
        });
        loadDashboard();
      } catch (err) { toast('❌ ' + err.message, 'error'); }
    };

    // ── BUG FIX B4: submitAddStudentMgmt — use API not SchoolDB ──
    window.submitAddStudentMgmt = async function () {
      var cls   = document.getElementById('stuMgmtClass')?.value
               || document.getElementById('cm-class')?.value || '';
      var sec   = (document.getElementById('stuMgmtSec')?.value
               || document.getElementById('cm-sec')?.value   || 'A').trim().toUpperCase();
      var roll  = (document.getElementById('sma-roll')?.value  || '').trim();
      var name  = (document.getElementById('sma-name')?.value  || '').trim();
      var dob   = (document.getElementById('sma-dob')?.value   || '');
      var gname = (document.getElementById('sma-guardian')?.value || '').trim();
      var gphone= (document.getElementById('sma-phone')?.value  || '').trim();
      if (!cls)  { toast('Please select a class first', 'error'); return; }
      if (!roll || !name) { toast('Roll number and name are required', 'error'); return; }
      // Default password = Roll No. + Section  e.g. "01A"
      var defaultPassword = roll + sec;
      try {
        var r = await window.API.addStudent({
          fullName: name, rollNumber: roll,
          class: cls, section: sec,
          dateOfBirth: dob, password: defaultPassword,
          guardianName: gname, guardianPhone: gphone,
        });
        var genId = r.studentId || (r.student && r.student.studentId) || '';
        closeModal('modalAddStudentMgmt');
        ['sma-roll','sma-name','sma-dob','sma-guardian','sma-phone']
          .forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
        toast('✅ "' + name + '" added! ID: ' + genId + ' | Password: ' + defaultPassword, 'success');
        window.SchoolDB.reload().then(function() {
          if (typeof loadStudentMgmt === 'function') loadStudentMgmt();
          if (typeof renderCMStudents === 'function') renderCMStudents();
        });
        loadDashboard();
      } catch (err) { toast('❌ ' + err.message, 'error'); }
    };

    // ── BUG FIX B5: saveClassTeacher — use MongoDB API not SchoolDB ──
    window.saveClassTeacher = async function () {
      var cls  = document.getElementById('cm-class')?.value;
      var sec  = document.getElementById('cm-sec')?.value   || 'A';
      var name = (document.getElementById('cm-teacher-name')?.value    || '').trim();
      var subj = (document.getElementById('cm-teacher-subject')?.value || '').trim();
      var exp  = parseInt(document.getElementById('cm-teacher-exp')?.value || '0') || 0;
      var total= parseInt(document.getElementById('cm-total-students')?.value || '0') || 0;
      var photo = window._selectedClassTeacherPhoto
               || (window._cmTeacherPhotoData !== null ? window._cmTeacherPhotoData : '');
      if (!cls)  { toast('Please select a class first', 'error'); return; }
      if (!name) { toast('Teacher name is required', 'error'); return; }
      var ctKey = 'cls_' + cls + '_' + sec;
      // Save to MongoDB via classes bulk replace
      var db = window.SchoolDB.load();
      if (!db.classTeachers) db.classTeachers = {};
      var existing = db.classTeachers[ctKey] || {};
      db.classTeachers[ctKey] = {
        teacherName: name, teacherSubject: subj,
        teacherExp: exp, totalStudents: total,
        teacherPhoto: photo || existing.teacherPhoto || '',
        updatedAt: new Date().toISOString(),
      };
      try {
        await window.API.replaceClasses(db.classTeachers);
        window._selectedClassTeacherPhoto = undefined;
        window._cmTeacherPhotoData = null;
        toast('✅ Class ' + cls + '-' + sec + ' teacher "' + name + '" saved!', 'success');
        window.SchoolDB.reload();
      } catch (err) { toast('❌ ' + err.message, 'error'); }
    };

    // ══════════════════════════════════════════════════════════════
    // FEATURE M1: Fill teacher dropdown in Class Management from DB
    // ══════════════════════════════════════════════════════════════
    window.fillClassTeacherFromDropdown = function(teacherName) {
      if (!teacherName) return;
      var db = window.SchoolDB.load();
      var t  = (db.teachers || []).find(function(x) {
        return (x.name || x.full_name || x.fullName) === teacherName;
      });
      if (!t) return;
      var nameEl  = document.getElementById('cm-teacher-name');
      var subjEl  = document.getElementById('cm-teacher-subject');
      var expEl   = document.getElementById('cm-teacher-exp');
      var prevEl  = document.getElementById('cm-teacher-photo-prev');
      if (nameEl) nameEl.value = t.name || t.fullName || '';
      if (subjEl) subjEl.value = t.subject || '';
      if (expEl)  expEl.value  = t.experience || t.exp || '';
      if (prevEl && t.photo) {
        prevEl.innerHTML = '<img src="' + t.photo + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>';
        window._selectedClassTeacherPhoto = t.photo;
      }
      toast('Teacher info ready! Click "Save Teacher" to continue.', 'success');
    };

    // Populate teacher dropdown whenever class-mgmt page loads
    var _origLoadClassMgmt = window.loadClassMgmt;
    window.loadClassMgmt = function() {
      if (_origLoadClassMgmt) _origLoadClassMgmt();
      var sel = document.getElementById('cm-teacher-dropdown');
      if (!sel) return;
      var db  = window.SchoolDB.load();
      var teachers = db.teachers || [];
      sel.innerHTML = '<option value="">— Select a Teacher —</option>';
      teachers.forEach(function(t) {
        var n = t.name || t.fullName || '';
        if (!n) return;
        var opt = document.createElement('option');
        opt.value = n;
        opt.textContent = n + (t.subject ? ' (' + t.subject + ')' : '');
        sel.appendChild(opt);
      });
    };

    // ══════════════════════════════════════════════════════════════
    // FEATURE M2: Student photo upload in Add Student modal
    // ══════════════════════════════════════════════════════════════
    window._newStudentPhotoFile = null;

    window.previewNewStudentPhoto = function(input) {
      var file = input && input.files && input.files[0];
      if (!file) return;
      window._newStudentPhotoFile = file;
      var reader = new FileReader();
      reader.onload = function(e) {
        var prev = document.getElementById('s-photo-preview');
        if (prev) {
          prev.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%"/>';
        }
      };
      reader.readAsDataURL(file);
    };

    // ══════════════════════════════════════════════════════════════
    // FEATURE M3: saveClassSubjects — also save to MongoDB via API
    // ══════════════════════════════════════════════════════════════
    var _origSaveClassSubjects = window.saveClassSubjects;
    window.saveClassSubjects = async function() {
      // Run original save first
      if (_origSaveClassSubjects) _origSaveClassSubjects();
      // Also persist subjects to MongoDB via school settings
      try {
        var db  = window.SchoolDB.load();
        var cls = document.getElementById('cm-class')?.value;
        if (!cls) return;
        // Save subjects as part of classTeachers metadata in MongoDB
        var ctKey = 'cls_' + cls + '_' + (document.getElementById('cm-sec')?.value || 'A');
        if (db.classTeachers && db.classTeachers[ctKey]) {
          db.classTeachers[ctKey].subjects = (db.subjects || {})[cls] || [];
          await window.API.replaceClasses(db.classTeachers);
        }
      } catch (e) { console.warn('Subject API sync:', e.message); }
    };

    // ══════════════════════════════════════════════════════════════
    // FIX: _patchedSubmitEditStudent for fallback
    // ══════════════════════════════════════════════════════════════
    window._patchedSubmitEditStudent = window.submitEditStudent;


    // ══════════════════════════════════════════════════════════════
    // TEACHERS — Full API-driven CRUD  [FIXED v2]
    // ══════════════════════════════════════════════════════════════

    window.submitAddTeacher = function () {
      var name = (document.getElementById('t-name')?.value    || '').trim();
      var subj = (document.getElementById('t-subject')?.value || '').trim();
      var dept = (document.getElementById('t-dept')?.value    || '').trim();
      var qual = (document.getElementById('t-qual')?.value    || '').trim();
      var exp  = parseInt(document.getElementById('t-exp')?.value || '0') || 0;
      var role = (document.getElementById('t-role')?.value    || 'teacher');
      var email= (document.getElementById('t-email')?.value   || '').trim();
      // Check all possible photo URL variables
      var photo = window._newTeacherPhotoUrl || window._selectedTeacherPhoto || window._teacherPhotoData || '';

      if (!name) { toast('Teacher name is required', 'error'); return; }
      if (!subj) { toast('Subject is required', 'error'); return; }

      var guessedDept = dept || (typeof guessDept === 'function' ? guessDept(subj) : 'General') || 'General';

      window.API.addTeacher({
        name:          name,
        fullName:      name,
        subject:       subj,
        department:    guessedDept,
        dept:          guessedDept,
        qualification: qual,
        qual:          qual,
        experience:    exp,
        exp:           exp,
        role:          role,
        email:         email,
        photo:         photo,
      })
      .then(function (r) {
        var savedTeacher = r.data || {};
        var savedId = savedTeacher._id || '';
        // Apply class teacher assignments using DIRECT API calls (no SchoolDB.save)
        var assignments = window._addTeacherAssignments || window._newTeacherAssignments || [];
        if (assignments.length) {
          _saveClassAssignmentsDirect(assignments, name, photo, subj, exp);
        }
        // Reset form state
        window._newTeacherPhotoUrl  = '';
        window._selectedTeacherPhoto = '';
        window._teacherPhotoData    = '';
        window._addTeacherAssignments = [];
        window._newTeacherAssignments = [];
        if (typeof _renderClassTags === 'function') _renderClassTags('t');
        closeModal('modalAddTeacher');
        ['t-name','t-subject','t-dept','t-qual','t-exp','t-email']
          .forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
        var roleEl = document.getElementById('t-role');
        if (roleEl) roleEl.value = 'teacher';
        var prev = document.getElementById('t-photo-preview');
        if (prev) { prev.innerHTML = '👨\u200d🏫'; prev.style.fontSize = '1.6rem'; }
        toast('✅ "' + name + '" added successfully!', 'success');
        window.SchoolDB.reload().then(function() {
          if (typeof loadTeachers === 'function') loadTeachers();
        });
        if (typeof loadDashboard === 'function') loadDashboard();
      })
      .catch(function (err) {
        toast('❌ Save failed: ' + (err.message || 'Server error'), 'error');
        console.error('[AddTeacher]', err);
      });
    };

    window.submitEditTeacher = function () {
      // ── FIX: et-id now stores MongoDB _id (not array index) ──
      var teacherId = (document.getElementById('et-id')?.value || '').trim();
      var name = (document.getElementById('et-name')?.value    || '').trim();
      var subj = (document.getElementById('et-subject')?.value || '').trim();
      var exp  = parseInt(document.getElementById('et-exp')?.value || '0') || 0;
      var qual = (document.getElementById('et-qual')?.value    || '').trim();
      var role = (document.getElementById('et-role')?.value    || 'teacher');

      if (!name) { toast('Teacher name is required', 'error'); return; }
      if (!teacherId) { toast('Teacher not found — please re-open edit dialog', 'error'); return; }

      // Find teacher in cache by _id to get current photo as fallback
      var db = window.SchoolDB.load();
      var t  = (db.teachers || []).find(function(x) {
        return (x._id || x.id || '') === teacherId;
      });
      var currentPhoto = t ? (t.photo || '') : '';

      // Photo precedence: new upload > selected from catalog > cleared > existing
      var photo = window._editTeacherPhotoUrl
        || window._selectedTeacherPhoto
        || (window._editTeacherPhotoData !== null && window._editTeacherPhotoData !== undefined
            ? window._editTeacherPhotoData
            : currentPhoto);

      var guessedDept = (typeof guessDept === 'function' ? guessDept(subj) : '') || (t ? (t.dept || 'General') : 'General');

      window.API.updateTeacher(teacherId, {
        name:          name,
        fullName:      name,
        subject:       subj,
        department:    guessedDept,
        dept:          guessedDept,
        qualification: qual,
        qual:          qual,
        experience:    exp,
        exp:           exp,
        role:          role,
        photo:         photo,
      })
      .then(function () {
        var editAssignments = window._editTeacherAssignments || [];
        if (editAssignments.length) {
          _saveClassAssignmentsDirect(editAssignments, name, photo, subj, exp);
        }
        window._editTeacherPhotoUrl   = null;
        window._selectedTeacherPhoto  = '';
        window._editTeacherPhotoData  = null;
        window._editTeacherAssignments = [];
        if (typeof _renderClassTags === 'function') _renderClassTags('et');
        closeModal('modalEditTeacher');
        toast('✅ "' + name + '" updated!', 'success');
        window.SchoolDB.reload().then(function() {
          if (typeof loadTeachers === 'function') loadTeachers();
        });
      })
      .catch(function (err) {
        toast('❌ Update failed: ' + (err.message || 'Server error'), 'error');
        console.error('[EditTeacher]', err);
      });
    };

    window.deleteTeacher = function (idx) {
      var db   = window.SchoolDB.load();
      var t    = (db.teachers||[])[idx];
      // Fallback: try to find by idx if cache not loaded
      if (!t && db.teachers && db.teachers.length) t = db.teachers[idx];
      var name = (t && (t.name || t.full_name)) || 'this teacher';
      if (!confirm('Delete "' + name + '"? This cannot be undone.')) return;
      if (!t) { toast('Teacher not found — please reload the page', 'error'); return; }
      var id = t._id || t.id;
      if (!id) { toast('Teacher ID missing — please reload the page', 'error'); return; }
      window.API.deleteTeacher(id)
        .then(function () {
          toast('✅ "' + name + '" deleted.', 'success');
          window.SchoolDB.reload().then(function() {
            if (typeof loadTeachers === 'function') loadTeachers();
          });
          if (typeof loadDashboard === 'function') loadDashboard();
        })
        .catch(function (err) {
          toast('❌ Delete failed: ' + (err.message || 'Server error'), 'error');
          console.error('[DeleteTeacher]', err);
        });
    };

    // ══════════════════════════════════════════════════════════════
    // ATTENDANCE — Full API-driven (Yearly System)
    // ══════════════════════════════════════════════════════════════

    // Override saveAttendanceDash → use MongoDB API
    window.saveAttendanceDash = async function () {
      var cls  = document.getElementById('dashAttClass')?.value;
      var sec  = document.getElementById('dashAttSec')?.value   || 'A';
      var date = document.getElementById('dashAttDate')?.value  || new Date().toISOString().slice(0,10);
      if (!cls) { toast('Please select a class first', 'error'); return; }

      // dashAttRecord = { studentId/roll: 'P'|'A'|'L' }
      // We need MongoDB studentId — get from cached students
      var db       = window.SchoolDB.load();
      var students = (db.students || []).filter(function(s){
        return String(s.class_number||s.class) === cls && (s.section||'A') === sec;
      });

      var records = students.map(function(s) {
        var sid = s.studentId || s.student_id || '';
        var key = sid || s.id || s.roll;
        var st  = window._dashAttRecord ? window._dashAttRecord[key] : (dashAttRecord[key] || '');
        if (!st) return null;
        return { studentId: sid || s.id || s.roll, date: date, status: st, class: cls, section: sec };
      }).filter(Boolean);

      if (!records.length) { toast('No attendance has been marked', 'error'); return; }

      try {
        var res = await fetch('/api/attendance/mark', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token')||''),
          },
          body: JSON.stringify({ records: records }),
        });
        var json = await res.json();
        if (!res.ok) throw new Error(json.error || 'Save failed');
        toast('✅ Attendance saved! ' + (json.saved||records.length) + ' records — ' + date, 'success');
        // MongoDB is the source of truth — no localStorage write needed
      } catch (err) {
        toast('❌ ' + err.message, 'error');
      }
    };

    // Override loadDashAttendance → load from MongoDB API
    var _origLoadDashAtt = window.loadDashAttendance;
    window.loadDashAttendance = async function () {
      var cls  = document.getElementById('dashAttClass')?.value || '';
      var sec  = document.getElementById('dashAttSec')?.value   || 'A';
      var date = document.getElementById('dashAttDate')?.value  || new Date().toISOString().slice(0,10);
      if (!cls) return;

      // Load students from MongoDB
      var students = [];
      try {
        var sr = await fetch('/api/students?class=' + cls + '&section=' + sec + '&limit=200', {
          headers: { 'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token')||'') }
        });
        var sj = await sr.json();
        students = (sj.data || []).sort(function(a,b){
          return (parseInt(a.rollNumber)||0) - (parseInt(b.rollNumber)||0);
        });
      } catch(e){}

      // Load existing attendance for this date
      var attMap = {};
      try {
        var ar = await fetch('/api/attendance/class/' + cls + '/' + sec + '/' + date, {
          headers: { 'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token')||'') }
        });
        if (ar.ok) { var aj = await ar.json(); attMap = aj.map || {}; }
      } catch(e){}

      // Build dashAttStudents format compatible with existing UI
      dashAttStudents = students.map(function(s){
        return { id: s.studentId, roll: s.rollNumber, full_name: s.fullName, name: s.fullName, studentId: s.studentId };
      });

      // If no students from API, fallback to SchoolDB
      if (!dashAttStudents.length) {
        var db2 = window.SchoolDB.load();
        var stuLocal = (db2.students||[]).filter(function(s){
          return String(s.class_number||s.class)===cls && (s.section||'A')===sec;
        });
        dashAttStudents = stuLocal;
      }

      dashAttRecord = {};
      window._dashAttRecord = {};
      dashAttStudents.forEach(function(s){
        var sid = s.studentId || s.student_id || s.id || s.roll;
        var st  = attMap[sid] || attMap[s.id] || attMap[s.roll] || '';
        dashAttRecord[sid] = st;
        window._dashAttRecord[sid] = st;
      });

      renderDashAttGrid();
      updateDashAttSummary();
      renderDashWeekly(cls, sec);
    };


    // ══════════════════════════════════════════════════════════════
    // EVENTS — Full MongoDB + Cloudinary CRUD
    // ══════════════════════════════════════════════════════════════

    window.submitAddEvent = async function () {
      var title = (document.getElementById('ev-title')?.value || '').trim();
      var date  = (document.getElementById('ev-date')?.value  || '');
      if (!title || !date) { toast('Title and Date are required', 'error'); return; }

      var editId  = (document.getElementById('ev-edit-id')?.value || '').trim();
      var payload = {
        title,
        type:        document.getElementById('ev-type')?.value        || 'other',
        date,
        venue:       (document.getElementById('ev-venue')?.value      || '').trim(),
        description: (document.getElementById('ev-desc')?.value       || '').trim(),
        featured:    !!(document.getElementById('ev-featured')?.checked),
        is_featured: !!(document.getElementById('ev-featured')?.checked),
      };

      // Step 1: Save event metadata to MongoDB
      var savedEvent;
      try {
        var apiRes = editId
          ? await window.API.updateEvent(editId, payload)
          : await window.API.addEvent(payload);
        savedEvent = apiRes.data || apiRes;
      } catch (err) {
        toast('Error: ' + err.message, 'error');
        return;
      }

      var eventId = savedEvent._id || editId;

      // Step 2: Upload image to Cloudinary if a file was selected
      var evFile = window._evFileForUpload || null;
      if (evFile && eventId) {
        try {
          var fd = new FormData();
          fd.append('image', evFile);
          await window.API.uploadEventImg(eventId, fd);
          toast(editId ? 'Event updated with image!' : 'Event added with image!', 'success');
        } catch (imgErr) {
          toast('Event saved. Image upload failed: ' + imgErr.message, 'info');
        }
      } else {
        toast(editId ? 'Event updated!' : 'Event added!', 'success');
      }

      // Step 3: Cleanup and refresh UI
      window._evFileForUpload     = null;
      window._evImg               = '';
      window._selectedEventImage  = '';
      var evSel = document.getElementById('ev-img-select');
      if (evSel) evSel.value = '';
      closeModal('modalAddEvent');
      window.SchoolDB.reload().then(loadEvents);
      loadDashboard();
    };

    window.deleteEvent = function (eventId) {
      if (!confirm('Delete this event? This cannot be undone.')) return;
      window.API.deleteEvent(eventId)
        .then(function () {
          toast('Event deleted.', 'success');
          window.SchoolDB.reload().then(loadEvents);
          loadDashboard();
        })
        .catch(function (err) { toast('Error: ' + err.message, 'error'); });
    };

    window.evToggleFeatured = function (eventId, currentVal) {
      var newVal = !currentVal;
      window.API.toggleEventFeatured(eventId, newVal)
        .then(function () {
          toast(newVal ? 'Event featured on homepage!' : 'Event unfeatured', 'success');
          window.SchoolDB.reload().then(loadEvents);
        })
        .catch(function (err) { toast('Error: ' + err.message, 'error'); });
    };

    window.toggleEventHighlight = function (eventId, currentVal) {
      var newVal = !currentVal;
      window.API.toggleEventHighlight(eventId, newVal)
        .then(function () {
          toast(newVal ? 'Glow effect enabled!' : 'Glow effect removed', 'success');
          window.SchoolDB.reload().then(loadEvents);
        })
        .catch(function (err) { toast('Error: ' + err.message, 'error'); });
    };
    // ══════════════════════════════════════════════════════════════
    // ANNOUNCEMENTS — Full API-driven CRUD
    // ══════════════════════════════════════════════════════════════

    window.submitAddAnnouncement = function () {
      var title = (document.getElementById('an-title')?.value || '').trim();
      var body  = (document.getElementById('an-body')?.value  || '').trim();
      if (!title || !body) { toast('Title and message are required', 'error'); return; }

      var db  = window.SchoolDB.load();
      var idx = parseInt(document.getElementById('an-edit-idx')?.value ?? '-1');
      var pin = !!(document.getElementById('an-pin')?.checked);
      var cat = (document.getElementById('an-cat')?.value || 'General');

      var existing = idx >= 0 ? (db.announcements||[])[idx] : null;
      var promise;

      if (existing && (existing._id || existing.id)) {
        promise = window.API.updateAnnouncement(existing._id || existing.id,
          { title, body, content: body, category: cat, is_pinned: pin });
      } else {
        promise = window.API.addAnnouncement({ title, body, content: body, category: cat, is_pinned: pin });
      }

      promise
        .then(function () {
          closeModal('modalAddAnnouncement');
          toast(existing ? '✅ Announcement updated!' : '✅ Announcement posted!', 'success');
          window.SchoolDB.reload().then(loadAnnouncements);
          loadDashboard();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.deleteAnnouncement = function (idx) {
      if (!confirm('Delete this announcement?')) return;
      var db = window.SchoolDB.load();
      var a  = (db.announcements||[])[idx];
      if (!a) { toast('Announcement not found', 'error'); return; }
      var id = a._id || a.id;
      window.API.deleteAnnouncement(id)
        .then(function () {
          toast('✅ Announcement deleted.', 'success');
          window.SchoolDB.reload().then(loadAnnouncements);
          loadDashboard();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.anToggleGlow = function (idx) {
      var db = window.SchoolDB.load();
      var a  = (db.announcements||[])[idx];
      if (!a) return;
      var id = a._id || a.id;
      var newHighlighted = !a.highlighted;
      window.API.updateAnnouncement(id, { highlighted: newHighlighted })
        .then(function () {
          toast(newHighlighted ? '✨ Glow on!' : 'Glow off', 'success');
          window.SchoolDB.reload().then(loadAnnouncements);
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    // ══════════════════════════════════════════════════════════════
    // GALLERY — Full API-driven CRUD
    // ══════════════════════════════════════════════════════════════

    window.submitAddGallery = function () {
      var title = (document.getElementById('g-title')?.value || '').trim();
      if (!title) { toast('Title is required', 'error'); return; }

      var item = {
        title,
        category: document.getElementById('g-cat')?.value || 'general',
        emoji:    document.getElementById('g-icon')?.value || '🖼️',
        url:      window._galleryImgData || '',
      };

      window.GalleryDB.addItem(item)
        .then(function (ok) {
          if (!ok) { toast('❌ Save failed', 'error'); return; }
          closeModal('modalAddGallery');
          ['g-title','g-icon'].forEach(function(id){ var el=document.getElementById(id); if(el) el.value=''; });
          window._galleryImgData = '';
          var inp = document.getElementById('g-img-input');
          if (inp) inp.value = '';
          var prev = document.getElementById('g-img-preview');
          if (prev) prev.innerHTML = '📸';
          toast('✅ "' + title + '" has been added to the gallery!', 'success');
          loadGallery();
        });
    };

    window.deleteGalleryItem = function (id) {
      if (!confirm('Are you sure you want to delete this photo?')) return;
      window.GalleryDB.deleteItem(id)
        .then(function () { toast('✅ Photo deleted.', 'success'); loadGallery(); })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    // ══════════════════════════════════════════════════════════════
    // HOUSES — Full API-driven save
    // ══════════════════════════════════════════════════════════════

    function _saveHousesToAPI(db, successMsg) {
      window.API.replaceHouses(db.houses)
        .then(function () {
          toast('✅ ' + successMsg, 'success');
          window.SchoolDB.reload().then(loadHouses);
          loadDashboard();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    }

    window.saveHouseInfo = function () {
      var db = window.SchoolDB.load();
      if (!db.houses || !db.houses.length) {
        toast('❌ House data not loaded yet. Please wait a moment.', 'error');
        return;
      }
      db.houses.forEach(function (h, i) {
        // ── House Name (new editable field) ──────────────────
        var nameEl = document.getElementById('hinfo-name-' + i);
        if (nameEl && nameEl.value.trim()) h.name = nameEl.value.trim();

        // ── Tagline ───────────────────────────────────────────
        var tagEl = document.getElementById('hinfo-tagline-' + i);
        if (tagEl) h.tagline = tagEl.value.trim();

        // ── Logo URL — check imageUploadManager's store first,
        //    then fall back to legacy _houseLogos store ─────────
        var fromIM   = window._houseLogoUrls      && window._houseLogoUrls[i];
        var fromLeg  = window._houseLogos         && window._houseLogos[i];
        var pubIdIM  = window._houseLogoPublicIds && window._houseLogoPublicIds[i];

        if (fromIM  !== undefined && fromIM  !== null) h.logo         = fromIM;
        if (fromLeg !== undefined && fromLeg !== null) h.logo         = fromLeg;   // legacy fallback
        if (pubIdIM !== undefined && pubIdIM !== null) h.logoPublicId = pubIdIM;
      });

      // Clear all logo staging stores after collecting
      window._houseLogos         = {};
      window._houseLogoUrls      = {};
      window._houseLogoPublicIds = {};

      _saveHousesToAPI(db, 'House info saved! Frontend has been updated.');
    };

    window.saveHousePoints = function () {
      var db = window.SchoolDB.load();
      if (!db.houses || !db.houses.length) { toast('❌ House data not loaded yet.', 'error'); return; }
      var nm = { blue:'Blue House', green:'Green House', red:'Red House', yellow:'Yellow House' };
      ['blue','green','red','yellow'].forEach(function (key) {
        var h = (db.houses||[]).find(function(x){ return x.name===nm[key]; });
        if (!h) return;
        h.sports     = parseInt(document.getElementById('hp-sports-' + key)?.value) || 0;
        h.study      = parseInt(document.getElementById('hp-study-'  + key)?.value) || 0;
        h.activities = parseInt(document.getElementById('hp-act-'    + key)?.value) || 0;
        h.discipline = parseInt(document.getElementById('hp-disc-'   + key)?.value) || 0;
        h.points     = h.sports + h.study + h.activities + h.discipline;
      });
      _saveHousesToAPI(db, 'House points saved! Frontend has been updated.');
    };

    window.saveHouseCaptains = function () {
      var db = window.SchoolDB.load();
      (db.houses||[]).forEach(function (h, hi) {
        h.captain     = (document.getElementById('hc-cap-'+hi)?.value || '').trim() || h.captain;
        h.viceCaptain = (document.getElementById('hc-vc-'+hi)?.value  || '').trim() || h.viceCaptain;
        h.contributors = (h.contributors||[]).map(function(c,ci){
          return Object.assign({}, c, {
            name:   (document.getElementById('hc-cname-'+hi+'-'+ci)?.value || '').trim() || c.name,
            points: parseInt(document.getElementById('hc-cpts-'+hi+'-'+ci)?.value) || c.points,
          });
        });
      });
      _saveHousesToAPI(db, 'Captains & contributors saved!');
    };

    // ══════════════════════════════════════════════════════════════
    // SCHOOL INFO, TIMING, STATS, HOMEPAGE — API save
    // ══════════════════════════════════════════════════════════════

    window.saveSchoolInfo = function () {
      var d    = window.SchoolDB.load();
      var prev = d.schoolInfo || {};
      var name    = (document.getElementById('si-name')?.value    || '').trim() || prev.name    || '';
      var tagline = (document.getElementById('si-tagline')?.value || '').trim() || prev.tagline || '';
      var estd    = (document.getElementById('si-estd')?.value    || '').trim() || prev.established || '';
      var cbse    = (document.getElementById('si-cbse')?.value    || '').trim() || prev.cbseCode    || '';
      var website = (document.getElementById('si-website')?.value || '').trim() || prev.website     || '';
      var phone   = (document.getElementById('si-phone')?.value   || '').trim() || prev.phone   || '';
      var email   = (document.getElementById('si-email')?.value   || '').trim() || prev.email   || '';
      var address = (document.getElementById('si-address')?.value || '').trim() || prev.address || '';
      // Save BOTH formats so school-info page AND school-settings/result pages all work
      var newInfo = Object.assign({}, prev, {
        name: name, tagline: tagline, established: estd, cbseCode: cbse,
        website: website, phone: phone, email: email, address: address,
        logoData: prev.logoData || '',
        schoolName: name, schoolTagline: tagline, schoolAddress: address,
        schoolPhone: phone, schoolEmail: email, affiliationNo: cbse,
        principalName: prev.principalName || '',
      });
      window.API.saveSetting('schoolInfo', newInfo)
        .then(function () {
          d.schoolInfo = newInfo;
          window.SchoolDB.save(d);
          var el = document.getElementById('sb-school-name');
          if (el) el.textContent = newInfo.name;
          toast('✅ School info saved!', 'success');
          saveBtnFeedback && saveBtnFeedback('si-save-btn');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.saveTiming = function () {
      var val = {
        workingDays: (document.getElementById('t-working')?.value || '').trim(),
        schoolHours: (document.getElementById('t-hours')?.value   || '').trim(),
        lkgUkgHours: (document.getElementById('t-lkg')?.value     || '').trim(),
        lunchBreak:  (document.getElementById('t-lunch')?.value   || '').trim(),
        officeHours: (document.getElementById('t-office')?.value  || '').trim(),
      };
      window.API.saveSetting('schoolTiming', val)
        .then(function () {
          var d = window.SchoolDB.load();
          d.schoolTiming = val;
          window.SchoolDB.save(d);
          window.SchoolSync && window.SchoolSync.broadcast('schoolTiming');
          toast('✅ Timings saved! Homepage has been updated.', 'success');
          saveBtnFeedback && saveBtnFeedback('tim-save-btn');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.saveStats = function () {
      var val = {
        students: parseInt(document.getElementById('st-students')?.value) || 0,
        teachers: parseInt(document.getElementById('st-teachers')?.value) || 0,
        years:    parseInt(document.getElementById('st-years')?.value)    || 0,
        alumni:   parseInt(document.getElementById('st-alumni')?.value)   || 0,
        awards:   parseInt(document.getElementById('st-awards')?.value)   || 0,
        passRate: parseInt(document.getElementById('st-pass')?.value)     || 0,
      };
      window.API.saveSetting('stats', val)
        .then(function () {
          var d = window.SchoolDB.load();
          d.stats = val;
          window.SchoolDB.save(d);
          window.SchoolSync && window.SchoolSync.broadcast('stats');
          toast('✅ Stats saved! Homepage counters have been updated.', 'success');
          saveBtnFeedback && saveBtnFeedback('stats-save-btn');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.saveHomepageContent = function () {
      var d   = window.SchoolDB.load();
      var old = d.homepageContent || {};
      var getV = function(id){ return (document.getElementById(id)?.value||'').trim(); };
      var val = {
        heroTitle:     getV('hc-hero-title')     || old.heroTitle     || '',
        heroSubtitle:  getV('hc-hero-sub')       || old.heroSubtitle  || '',
        aboutUs:       getV('hc-about')          || old.aboutUs       || '',
        academicText:  getV('hc-academic')       || old.academicText  || '',
        principalName: getV('hc-p-name')     || old.principalName || '',
        principalTitle:getV('hc-p-title')    || old.principalTitle|| '',
        principalQual: getV('hc-p-qual')     || old.principalQual || '',
        principalMsg:  getV('hc-p-msg')      || old.principalMsg  || '',
        principalMsg2: getV('hc-p-msg2')     || old.principalMsg2 || '',
        principalPhoto:old.principalPhoto || '',
      };
      window.API.saveSetting('homepageContent', val)
        .then(function () {
          d.homepageContent = val;
          window.SchoolDB.save(d);
          toast('✅ Homepage content saved!', 'success');
          saveBtnFeedback && saveBtnFeedback('hc-save-btn');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.saveTopStudents = function () {
      var db = window.SchoolDB.load();
      if (!db.topStudents) return;
      var updated = db.topStudents.map(function (s, i) {
        var catSel = document.getElementById('ts-img-sel-' + i);
        var img = catSel && catSel.value
          ? catSel.value
          : (window._tsImages && window._tsImages[i] !== undefined ? window._tsImages[i] : (s.image||s.photo||''));
        return {
          rank:  i + 1,
          name:  (document.getElementById('ts-name-'  + i)?.value || '').trim() || s.name  || '',
          class: (document.getElementById('ts-class-' + i)?.value || '').trim() || s.class || '',
          score: parseFloat(document.getElementById('ts-score-' + i)?.value) || s.score || 0,
          house: document.getElementById('ts-house-' + i)?.value || s.house || '',
          image: img, photo: img,
          avatar: s.avatar || '👨‍🎓',
        };
      });
      window.API.saveSetting('topStudents', updated)
        .then(function () {
          db.topStudents = updated;
          window.SchoolDB.save(db);
          toast('✅ Top students saved! Homepage leaderboard has been updated.', 'success');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    window.saveAdmissions = function () {
      var db = window.SchoolDB.load();
      var existingImage = (db.admissions || {}).imageData || '';
      var val = {
        visible:     !!(document.getElementById('adm-visible')?.checked),
        heading:     (document.getElementById('adm-heading')?.value  || '').trim() || 'Admissions Open 2025-26',
        session:     (document.getElementById('adm-session')?.value  || '').trim() || '2025–2026',
        subtext:     (document.getElementById('adm-subtext')?.value  || '').trim(),
        deadline:    (document.getElementById('adm-deadline')?.value || ''),
        phone:       (document.getElementById('adm-phone')?.value    || '').trim(),
        classes:     (document.getElementById('adm-classes')?.value  || '').trim(),
        glowEnabled: !!(document.getElementById('adm-glow')?.checked),
        imageData:   existingImage,
        updatedAt:   new Date().toISOString(),
      };
      window.API.saveSetting('admissions', val)
        .then(function () {
          db.admissions = val;
          window.SchoolDB.save(db);
          toast('✅ Admission data saved! Homepage banner updated.', 'success');
          saveBtnFeedback && saveBtnFeedback('adm-save-btn');
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    // ══════════════════════════════════════════════════════════════
    // ADMISSIONS PAGE — Load from API
    // ══════════════════════════════════════════════════════════════

    window.loadAdmissionsPage = function () {
      // Load settings (banner config)
      if (typeof loadAdmissions === 'function') {
        try { loadAdmissions(); } catch(e) {}
      }
      // Load admission applications from API
      window.API.getAdmissions()
        .then(function (r) {
          var apps = r.data || [];
          // Update db cache for existing rendering code
          var db = window.SchoolDB.load();
          db.admissionApplications = apps.map(function(a){
            return {
              id:           a._id,
              _id:          a._id,
              applicationId:a.applicationId || a._id,
              studentName:  a.studentName   || '',
              applyingClass:a.applyingClass || '',
              phone:        a.phone         || '',
              email:        a.email         || '',
              fatherName:   a.fatherName    || '',
              status:       a.status        || 'pending',
              createdAt:    a.createdAt,
            };
          });
          window.SchoolDB.save(db);
          // Refresh the apps table if the render function exists
          if (typeof renderAdmissionApplications === 'function') {
            renderAdmissionApplications(db.admissionApplications);
          }
          // Update badge
          var pending = apps.filter(function(a){ return a.status==='pending'; }).length;
          var badge = document.getElementById('app-badge');
          if (badge) { badge.textContent=pending; badge.style.display=pending>0?'inline':'none'; }
          var pendEl = document.getElementById('d-pending');
          if (pendEl) pendEl.textContent = pending;
        })
        .catch(function (err) { console.error('[Admissions]', err.message); });
    };

    // Application approve/reject
    var _origApproveApp = window.approveApp;
    window.approveApp = function (idx, status) {
      var db  = window.SchoolDB.load();
      var app = (db.admissionApplications||[])[idx];
      if (!app) return;
      var id = app._id || app.id;
      window.API.updateAdmission(id, { status })
        .then(function () {
          toast('✅ Application ' + status + '!', 'success');
          window.loadAdmissionsPage();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    var _origDeleteApp = window.deleteApplication;
    window.deleteApplication = function (idx) {
      if (!confirm('Delete this application?')) return;
      var db  = window.SchoolDB.load();
      var app = (db.admissionApplications||[])[idx];
      if (!app) return;
      var id = app._id || app.id;
      window.API.deleteAdmission(id)
        .then(function () {
          toast('✅ Application deleted.', 'success');
          window.loadAdmissionsPage();
        })
        .catch(function (err) { toast('❌ ' + err.message, 'error'); });
    };

    // ══════════════════════════════════════════════════════════════
    // CREDENTIALS — API-driven password change
    // ══════════════════════════════════════════════════════════════

    window.saveCredentials = function () {
      var currPass = (document.getElementById('acc-curr-pass')?.value || '');
      var newPass  = (document.getElementById('acc-new-pass')?.value  || '');
      if (!currPass) { toast('Current password is required', 'error'); return; }
      if (newPass && newPass.length < 6) { toast('New password min 6 characters', 'error'); return; }

      window.API.changePassword(currPass, newPass || currPass)
        .then(function () {
          toast('✅ Password updated!', 'success');
          document.getElementById('acc-curr-pass').value = '';
          document.getElementById('acc-new-pass').value  = '';
          var newUser = (document.getElementById('acc-new-user')?.value || '').trim();
          if (document.getElementById('acc-new-user')) document.getElementById('acc-new-user').value = '';
        })
        .catch(function (err) { toast('❌ ' + (err.message||'Update failed'), 'error'); });
    };

    // ══════════════════════════════════════════════════════════════
    // SOCIAL LINKS, UPI, LOCKDOWN, ONLINE LINKS
    // ══════════════════════════════════════════════════════════════

    // Patch: these all call SchoolDB.set() which now routes to API automatically
    // No override needed — window.SchoolDB.set() → api-layer → /api/settings/:key

    // ══════════════════════════════════════════════════════════════
    // CLASSES / CLASS TEACHERS — API-driven save  [FIXED v2]
    // ══════════════════════════════════════════════════════════════

    // ── Helper: save class assignments DIRECTLY to API ─────────
    // Uses individual upsert calls — safe, doesn't wipe other classes
    function _saveClassAssignmentsDirect(assignments, teacherName, teacherPhoto, teacherSubject, teacherExp) {
      if (!assignments || !assignments.length) return;
      var classTeachersMap = {};
      assignments.forEach(function(a) {
        var ctKey = 'cls_' + a.cls + '_' + a.sec;
        classTeachersMap[ctKey] = {
          teacherName:    teacherName    || '',
          teacherPhoto:   teacherPhoto   || '',
          teacherSubject: teacherSubject || '',
          teacherExp:     teacherExp     || 0,
          updatedAt:      new Date().toISOString(),
        };
        // Also update local _cache immediately
        if (window.SchoolDB._cache_ref) {
          if (!window.SchoolDB._cache_ref.classTeachers) window.SchoolDB._cache_ref.classTeachers = {};
          window.SchoolDB._cache_ref.classTeachers[ctKey] = classTeachersMap[ctKey];
        }
      });
      window.API.replaceClasses(classTeachersMap)
        .catch(function(err) { console.warn('[ClassAssign]', err.message); });
    }

    // ── Patch applyClassTeacherAssignments to use direct API ───
    window.applyClassTeacherAssignments = function (assignments, teacherName, teacherPhoto, teacherSubject, teacherExp) {
      if (!assignments || !assignments.length) return;
      // Update local cache via SchoolDB (safe: only updates classTeachers if cache is loaded)
      try {
        var db = window.SchoolDB.load();
        if (!db.classTeachers) db.classTeachers = {};
        assignments.forEach(function(a) {
          var ctKey = 'cls_' + a.cls + '_' + a.sec;
          db.classTeachers[ctKey] = Object.assign({}, db.classTeachers[ctKey] || {}, {
            teacherName:    teacherName    || '',
            teacherPhoto:   teacherPhoto   || '',
            teacherSubject: teacherSubject || '',
            teacherExp:     teacherExp     || 0,
            updatedAt:      new Date().toISOString(),
          });
        });
        window.SchoolDB.save(db);
      } catch(e) { console.warn('[ClassTeacher local update]', e); }
      // Always also call API directly
      _saveClassAssignmentsDirect(assignments, teacherName, teacherPhoto, teacherSubject, teacherExp);
    };

    // ── Patch saveClassTeacher (Classes tab in admin) ──────────
    var _origSaveClassTeacher = window.saveClassTeacher;
    window.saveClassTeacher = function () {
      var cls  = document.getElementById('cm-class')?.value;
      var sec  = document.getElementById('cm-sec')?.value  || 'A';
      var name = (document.getElementById('cm-teacher-name')?.value || '').trim();
      var subj = (document.getElementById('cm-teacher-subject')?.value || '').trim();
      var exp  = parseInt(document.getElementById('cm-teacher-exp')?.value) || 0;
      var total= parseInt(document.getElementById('cm-total-students')?.value) || 0;
      var photo = window._selectedClassTeacherPhoto
        || (window._cmTeacherPhotoData !== null && window._cmTeacherPhotoData !== undefined ? window._cmTeacherPhotoData : '');

      if (!cls)  { toast('Please select a class first', 'error'); return; }
      if (!name) { toast('Teacher name is required', 'error'); return; }

      var ctKey = 'cls_' + cls + '_' + sec;
      var classTeachersMap = {};
      classTeachersMap[ctKey] = {
        teacherName:    name,
        teacherPhoto:   photo,
        teacherSubject: subj,
        teacherExp:     exp,
        totalStudents:  total,
        updatedAt:      new Date().toISOString(),
      };

      window.API.replaceClasses(classTeachersMap)
        .then(function() {
          // Also update local cache
          var db = window.SchoolDB.load();
          if (!db.classTeachers) db.classTeachers = {};
          db.classTeachers[ctKey] = classTeachersMap[ctKey];
          window.SchoolDB.save(db);
          window._selectedClassTeacherPhoto = undefined;
          window._cmTeacherPhotoData = null;
          if (window.SchoolSync) window.SchoolSync.broadcast('classTeachers');
          toast('✅ Class ' + cls + '-' + sec + ' teacher "' + name + '" saved!', 'success');
          if (typeof showSaveFeedback === 'function') showSaveFeedback(document.activeElement);
        })
        .catch(function(err) {
          toast('❌ Save failed: ' + (err.message || 'Server error'), 'error');
          console.error('[SaveClassTeacher]', err);
        });
    };

    // ══════════════════════════════════════════════════════════════
    // DASHBOARD STATS — Live from API
    // ══════════════════════════════════════════════════════════════

    var _origLoadDashboard = window.loadDashboard;
    window.loadDashboard = function () {
      // Call original for UI rendering (reads from local cache)
      if (_origLoadDashboard) _origLoadDashboard();
      // Also fetch live stats from API
      window.API.getStats()
        .then(function (r) {
          var trySet = function(id, val) { var el=document.getElementById(id); if(el) el.textContent=val; };
          trySet('d-students', r.total_students || 0);
          trySet('d-teachers', r.total_teachers || 0);
          trySet('d-events',   r.total_events   || 0);
          trySet('d-announce', r.total_announcements || 0);
          var pending = r.pending_admissions || 0;
          var badge = document.getElementById('app-badge');
          if (badge) { badge.textContent=pending; badge.style.display=pending>0?'inline':'none'; }
          trySet('d-pending', pending);

          // Fee collection stats — show if elements exist (may be added by admin panel)
          function inr(n){ return '₹'+(Number(n)||0).toLocaleString('en-IN'); }
          if (r.fee_today  !== undefined) trySet('d-fee-today',  inr(r.fee_today));
          if (r.fee_month  !== undefined) trySet('d-fee-month',  inr(r.fee_month));
          if (r.fee_year   !== undefined) trySet('d-fee-year',   inr(r.fee_year));
        })
        .catch(function () {}); // silently fail — cached values still show
    };

    console.log('✅ Production API Patch loaded — all CRUD routes to MongoDB');

  }); // end onReady

})();

// ================================================================
// TOP STUDENTS — Year-wise Admin System
// SCHOOL PORTAL
// ================================================================

(function () {
  'use strict';

  var _currentEditId  = null;   // student _id being edited
  var _currentYear    = null;   // currently selected year in admin
  var _allStudents    = [];     // cached list

  // ── Load years dropdown & students ───────────────────────────
  window.loadTopStudentsAdmin = function () {
    if (!window.API || !window.API.getTopStudentYears) return;

    window.API.getTopStudentYears()
      .then(function (res) {
        var years = res.years || [];
        var sel = document.getElementById('ts-year-select');
        if (!sel) return;

        sel.innerHTML = '<option value="">— Select Year —</option>';
        years.forEach(function (yr) {
          var opt = document.createElement('option');
          opt.value = yr;
          opt.textContent = yr;
          sel.appendChild(opt);
        });

        // Auto-select the latest year
        if (years.length && !_currentYear) {
          _currentYear = years[0];
          sel.value = _currentYear;
          window.switchAdminYear(_currentYear);
        } else if (_currentYear) {
          sel.value = _currentYear;
          window.switchAdminYear(_currentYear);
        }
      })
      .catch(function (err) {
        toast('Failed to load years: ' + err.message, 'error');
      });
  };

  // ── Switch year view ──────────────────────────────────────────
  window.switchAdminYear = function (year) {
    _currentYear = year;
    if (!year) {
      document.getElementById('ts-admin-content').innerHTML =
        '<div style="text-align:center;padding:3rem;color:var(--muted)">Select a year to view students.</div>';
      return;
    }
    renderYearAdmin(year);
  };

  function renderYearAdmin(year) {
    var cont = document.getElementById('ts-admin-content');
    cont.innerHTML = '<div style="text-align:center;padding:2rem;color:var(--muted)"><div class="spinner" style="margin:0 auto 10px"></div>Loading…</div>';

    window.API.getTopStudents('?year=' + year)
      .then(function (res) {
        _allStudents = res.data || [];
        renderYearGroups(_allStudents, year, cont);
      })
      .catch(function (err) {
        cont.innerHTML = '<div style="color:#f87171;padding:2rem;text-align:center">Error: ' + err.message + '</div>';
      });
  }

  function renderYearGroups(students, year, cont) {
    // Group by classLabel
    var groups = {};
    students.forEach(function (s) {
      if (!groups[s.classLabel]) groups[s.classLabel] = [];
      groups[s.classLabel].push(s);
    });

    var classes = Object.keys(groups).sort();
    var html    = [];

    if (!classes.length) {
      html.push('<div style="text-align:center;padding:3rem;color:var(--muted)">No students added for ' + year + ' yet.<br>Click <strong>+ Add Student</strong> to begin.</div>');
    }

    classes.forEach(function (cls) {
      var studs = groups[cls].slice().sort(function (a, b) { return a.rank - b.rank; });
      html.push('<div class="glass-card" style="margin-bottom:20px">');
      html.push('<div class="card-head"><h4 style="margin:0">📚 ' + cls + '</h4>');
      html.push('<button class="btn btn-primary btn-sm" onclick="openAddStudentModal(\'' + year + '\',\'' + cls + '\')">+ Add Student</button>');
      html.push('</div>');
      html.push('<div class="tbl-wrap"><table><thead><tr>');
      html.push('<th>Rank</th><th>Photo</th><th>Name</th><th>Score</th><th>House</th><th>Achievement</th><th>Actions</th>');
      html.push('</tr></thead><tbody>');

      studs.forEach(function (s) {
        var medal = s.rank === 1 ? '🥇' : s.rank === 2 ? '🥈' : s.rank === 3 ? '🥉' : '#' + s.rank;
        var img   = s.image
          ? '<img src="' + s.image + '" style="width:36px;height:36px;border-radius:50%;object-fit:cover" />'
          : '<span style="font-size:1.4rem">👤</span>';
        html.push('<tr>');
        html.push('<td>' + medal + '</td>');
        html.push('<td>' + img + '</td>');
        html.push('<td><strong>' + s.name + '</strong><br><span style="font-size:0.75rem;color:var(--muted)">' + (s.subjects || '') + '</span></td>');
        html.push('<td>' + (s.score ? s.score + '%' : '—') + '</td>');
        html.push('<td>' + (s.house || '—') + '</td>');
        html.push('<td>' + (s.achievement || '—') + '</td>');
        html.push('<td style="display:flex;gap:6px">');
        html.push('<button class="btn btn-ghost btn-sm" onclick="openEditStudentModal(\'' + s._id + '\')">✏️ Edit</button>');
        html.push('<button class="btn btn-danger btn-sm" onclick="deleteTopStudent(\'' + s._id + '\')">🗑</button>');
        html.push('</td></tr>');
      });

      html.push('</tbody></table></div>');
      html.push('</div>');
    });

    // Bottom: add new class category
    html.push('<div style="text-align:center;padding:1rem">');
    html.push('<button class="btn btn-ghost" onclick="openAddStudentModal(\'' + year + '\',\'\')">➕ Add Student to a New Class</button>');
    html.push('</div>');

    cont.innerHTML = html.join('');
  }

  // ── Prompt for new year ───────────────────────────────────────
  window.promptAddYear = function () {
    var yr = prompt('Enter academic year (e.g. 2026):');
    if (!yr || !/^\d{4}$/.test(yr.trim())) {
      toast('Please enter a valid 4-digit year.', 'error');
      return;
    }
    _currentYear = yr.trim();
    var sel = document.getElementById('ts-year-select');
    // Add option if not present
    var exists = Array.from(sel.options).some(function (o) { return o.value === _currentYear; });
    if (!exists) {
      var opt = document.createElement('option');
      opt.value = _currentYear;
      opt.textContent = _currentYear;
      sel.appendChild(opt);
    }
    sel.value = _currentYear;
    window.switchAdminYear(_currentYear);
  };

  // ── Open Add Student Modal ────────────────────────────────────
  window.openAddStudentModal = function (year, classLabel) {
    _currentEditId = null;
    document.getElementById('ts-modal-title').textContent = '➕ Add Top Student';

    // Reset fields
    document.getElementById('ts-f-year').value        = year || _currentYear || '';
    document.getElementById('ts-f-class').value       = classLabel || '';
    document.getElementById('ts-f-rank').value        = '';
    document.getElementById('ts-f-name').value        = '';
    document.getElementById('ts-f-score').value       = '';
    document.getElementById('ts-f-subjects').value    = '';
    document.getElementById('ts-f-house').value       = '';
    document.getElementById('ts-f-achievement').value = '';

    // Photo row — hide upload until saved
    document.getElementById('ts-photo-preview').innerHTML = '👤';
    document.getElementById('ts-upload-btn').style.display    = 'none';
    document.getElementById('ts-remove-photo-btn').style.display = 'none';
    document.getElementById('ts-photo-note').textContent = 'Save student first, then upload a photo.';

    openModal('modalTopStudent');
  };

  // ── Open Edit Student Modal ───────────────────────────────────
  window.openEditStudentModal = function (studentId) {
    _currentEditId = studentId;
    var s = _allStudents.find(function (x) { return x._id === studentId; });
    if (!s) { toast('Student not found.', 'error'); return; }

    document.getElementById('ts-modal-title').textContent = '✏️ Edit Top Student';

    document.getElementById('ts-f-year').value        = s.year        || '';
    document.getElementById('ts-f-class').value       = s.classLabel  || '';
    document.getElementById('ts-f-rank').value        = s.rank        || '';
    document.getElementById('ts-f-name').value        = s.name        || '';
    document.getElementById('ts-f-score').value       = s.score       || '';
    document.getElementById('ts-f-subjects').value    = s.subjects    || '';
    document.getElementById('ts-f-house').value       = s.house       || '';
    document.getElementById('ts-f-achievement').value = s.achievement || '';

    // Photo
    var preview = document.getElementById('ts-photo-preview');
    if (s.image) {
      preview.innerHTML = '<img src="' + s.image + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%" />';
      document.getElementById('ts-remove-photo-btn').style.display = '';
    } else {
      preview.innerHTML = '👤';
      document.getElementById('ts-remove-photo-btn').style.display = 'none';
    }
    document.getElementById('ts-upload-btn').style.display = '';
    document.getElementById('ts-photo-note').textContent = '';

    openModal('modalTopStudent');
  };

  // ── Save (POST or PUT) ────────────────────────────────────────
  window.saveTopStudent = function () {
    var year        = (document.getElementById('ts-f-year').value        || '').trim();
    var classLabel  = (document.getElementById('ts-f-class').value       || '').trim();
    var rank        = parseInt(document.getElementById('ts-f-rank').value  || '0');
    var name        = (document.getElementById('ts-f-name').value        || '').trim();
    var score       = parseFloat(document.getElementById('ts-f-score').value || '0') || 0;
    var subjects    = (document.getElementById('ts-f-subjects').value    || '').trim();
    var house       = document.getElementById('ts-f-house').value        || '';
    var achievement = (document.getElementById('ts-f-achievement').value || '').trim();

    if (!year || !classLabel || !rank || !name) {
      toast('Year, Class, Rank, and Name are required.', 'error');
      return;
    }

    var payload = { year, classLabel, rank, name, score, subjects, house, achievement };

    var isNew = !_currentEditId;
    var apiCall = _currentEditId
      ? window.API.updateTopStudent(_currentEditId, payload)
      : window.API.addTopStudent(payload);

    apiCall
      .then(function (res) {
        toast(isNew ? 'Student added! ✅ Now you can upload a photo.' : 'Student updated! ✅', 'success');
        if (_currentYear) renderYearAdmin(_currentYear);

        if (isNew && res.data && res.data._id) {
          // After creating, re-open in edit mode so photo upload is immediately available
          _allStudents.push(res.data);
          closeModal('modalTopStudent');
          setTimeout(function() { openEditStudentModal(res.data._id); }, 200);
        } else {
          closeModal('modalTopStudent');
        }
      })
      .catch(function (err) {
        toast('Error: ' + err.message, 'error');
      });
  };

  // ── Delete ────────────────────────────────────────────────────
  window.deleteTopStudent = function (id) {
    if (!confirm('Delete this student? This cannot be undone.')) return;
    window.API.deleteTopStudent(id)
      .then(function () {
        toast('Student deleted.', 'success');
        if (_currentYear) renderYearAdmin(_currentYear);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  };

  // ── Upload photo ──────────────────────────────────────────────
  window.uploadTopStudentImg = function (file) {
    if (!file || !_currentEditId) {
      toast('Save student first before uploading a photo.', 'error');
      return;
    }
    var fd = new FormData();
    fd.append('image', file);

    toast('Uploading photo…', 'info');

    window.API.uploadTopStudentImg(_currentEditId, fd)
      .then(function (res) {
        var preview = document.getElementById('ts-photo-preview');
        if (res.imageUrl) {
          preview.innerHTML = '<img src="' + res.imageUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%" />';
          document.getElementById('ts-remove-photo-btn').style.display = '';
        }
        toast('Photo uploaded! ✅', 'success');
        if (_currentYear) renderYearAdmin(_currentYear);
      })
      .catch(function (err) { toast('Upload failed: ' + err.message, 'error'); });
  };

  // ── Remove photo ──────────────────────────────────────────────
  window.removeTopStudentImg = function () {
    if (!_currentEditId) return;
    if (!confirm('Remove student photo?')) return;

    window.API.removeTopStudentImg(_currentEditId)
      .then(function () {
        document.getElementById('ts-photo-preview').innerHTML = '👤';
        document.getElementById('ts-remove-photo-btn').style.display = 'none';
        toast('Photo removed.', 'success');
        if (_currentYear) renderYearAdmin(_currentYear);
      })
      .catch(function (err) { toast('Error: ' + err.message, 'error'); });
  };

  // loadTopStudentsAdmin is already wired via the main showSection patch above.

})();

// ================================================================
// ATTENDANCE — 3-TAB SYSTEM
// Tab switching, Daily date nav, Monthly Calendar, Yearly Overview
// ================================================================
(function () {
  'use strict';

  var AUTH_HEADER = function () {
    return { 'Authorization': 'Bearer ' + (sessionStorage.getItem('admin_token') || '') };
  };

  // ── Tab Switcher ───────────────────────────────────────────────
  window.attSwitchTab = function (tab) {
    ['daily','monthly','yearly'].forEach(function(t) {
      var panel = document.getElementById('att-panel-' + t);
      var btn   = document.getElementById('att-tab-' + t);
      if (!panel || !btn) return;
      if (t === tab) {
        panel.style.display = '';
        btn.style.borderBottomColor = 'var(--primary)';
        btn.style.color             = 'var(--primary)';
        btn.style.fontWeight        = '600';
      } else {
        panel.style.display         = 'none';
        btn.style.borderBottomColor = 'transparent';
        btn.style.color             = 'var(--muted)';
        btn.style.fontWeight        = '500';
      }
    });
    if (tab === 'monthly' && !document.getElementById('attMonthPicker').value) {
      document.getElementById('attMonthPicker').value = new Date().toISOString().slice(0,7);
      loadAttMonthly();
    }
    if (tab === 'yearly') loadAttYearly();
  };

  // ── Daily date navigation ──────────────────────────────────────
  window.attPrevDay = function () {
    var el = document.getElementById('dashAttDate');
    if (!el) return;
    var d = new Date((el.value || new Date().toISOString().slice(0,10)) + 'T12:00:00');
    d.setDate(d.getDate() - 1);
    el.value = d.toISOString().slice(0,10);
    window.loadDashAttendance && window.loadDashAttendance();
  };
  window.attNextDay = function () {
    var el = document.getElementById('dashAttDate');
    if (!el) return;
    var d = new Date((el.value || new Date().toISOString().slice(0,10)) + 'T12:00:00');
    d.setDate(d.getDate() + 1);
    el.value = d.toISOString().slice(0,10);
    window.loadDashAttendance && window.loadDashAttendance();
  };
  window.attGoToday = function () {
    var el = document.getElementById('dashAttDate');
    if (!el) return;
    el.value = new Date().toISOString().slice(0,10);
    window.loadDashAttendance && window.loadDashAttendance();
  };

  // ── Init date picker to today ──────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    var dateEl = document.getElementById('dashAttDate');
    if (dateEl && !dateEl.value) dateEl.value = new Date().toISOString().slice(0,10);
    var monthEl = document.getElementById('attMonthPicker');
    if (monthEl && !monthEl.value) monthEl.value = new Date().toISOString().slice(0,7);
  });

  // ══════════════════════════════════════════════════════════════
  // TAB 2 — MONTHLY CALENDAR VIEW
  // ══════════════════════════════════════════════════════════════
  var _monthlyData = null;

  window.loadAttMonthly = async function () {
    var cls   = document.getElementById('attMonthClass')?.value || '';
    var sec   = document.getElementById('attMonthSec')?.value   || 'A';
    var month = document.getElementById('attMonthPicker')?.value || new Date().toISOString().slice(0,7);
    var calEl = document.getElementById('att-monthly-calendar');
    var tblEl = document.getElementById('att-monthly-table');
    if (!cls) { if(calEl) calEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">Select a class to view monthly data</div>'; return; }
    if (calEl) calEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">⏳ Loading monthly data...</div>';

    try {
      var r   = await fetch('/api/attendance/class/' + cls + '/' + sec + '/monthly?month=' + month, { headers: AUTH_HEADER() });
      var data = r.ok ? await r.json() : {};
      _monthlyData = data;
      renderMonthlyCalendar(cls, sec, month, data);
      renderMonthlyTable(data);
    } catch(e) {
      if (calEl) calEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">❌ Could not load data. Is the server running?</div>';
    }
  };

  function renderMonthlyCalendar(cls, sec, month, data) {
    var calEl = document.getElementById('att-monthly-calendar');
    if (!calEl) return;

    // Build day → aggregate stats from individual attendance records
    var dayStats = {};
    var records = data.records || [];
    records.forEach(function(rec) {
      var d = (rec.date || '').slice(0,10);
      if (!d) return;
      if (!dayStats[d]) dayStats[d] = {P:0,A:0,L:0,total:0};
      if (rec.status) dayStats[d][rec.status] = (dayStats[d][rec.status]||0) + 1;
      dayStats[d].total++;
    });

    var year  = parseInt(month.slice(0,4));
    var mIdx  = parseInt(month.slice(5,7)) - 1;
    var first = new Date(year, mIdx, 1);
    var days  = new Date(year, mIdx+1, 0).getDate();
    var monthName = first.toLocaleString('en-IN', {month:'long', year:'numeric'});

    var dowNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    var html = '<div style="font-size:.8rem;font-weight:600;color:var(--muted);margin-bottom:10px;text-transform:uppercase;letter-spacing:1px">' + monthName + '</div>';
    html += '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;margin-bottom:4px">';
    dowNames.forEach(function(n){ html += '<div style="text-align:center;font-size:.7rem;font-weight:600;color:var(--muted);padding:4px 0">' + n + '</div>'; });
    html += '</div>';
    html += '<div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px">';

    var startDow = first.getDay(); // 0=Sun
    for (var i=0; i<startDow; i++) html += '<div></div>';

    for (var d=1; d<=days; d++) {
      var dateStr = month + '-' + String(d).padStart(2,'0');
      var dow     = new Date(year, mIdx, d).getDay();
      var st      = dayStats[dateStr];
      var pct     = st && st.total ? Math.round(st.P / st.total * 100) : null;
      var bg, textc;
      if (dow === 0) { bg = 'rgba(255,255,255,0.06)'; textc = 'var(--muted)'; }
      else if (pct === null) { bg = 'rgba(255,255,255,0.06)'; textc = 'var(--muted)'; }
      else if (pct >= 90)   { bg = 'rgba(102,187,106,0.22)'; textc = '#2e7d32'; }
      else if (pct >= 75)   { bg = 'rgba(255,179,0,0.22)';   textc = '#b45309'; }
      else                  { bg = 'rgba(244,67,54,0.20)';   textc = '#c62828'; }

      var label = pct !== null && dow !== 0 ? '<div style="font-size:.58rem;margin-top:1px">' + pct + '%</div>' : (dow === 0 ? '<div style="font-size:.55rem;margin-top:1px">Sun</div>' : '');
      var clickAttr = (pct !== null || dow !== 0) ? 'onclick="attJumpToDaily(\'' + dateStr + '\')" style="cursor:pointer"' : '';

      html += '<div ' + clickAttr + ' style="background:' + bg + ';border:1px solid rgba(255,255,255,0.12);border-radius:7px;padding:6px 2px;text-align:center;transition:transform .15s" onmouseover="this.style.transform=\'scale(1.05)\'" onmouseout="this.style.transform=\'\'"><div style="font-size:.78rem;font-weight:600;color:' + textc + '">' + d + '</div>' + label + '</div>';
    }
    html += '</div>';

    // Legend
    html += '<div style="display:flex;gap:12px;margin-top:10px;flex-wrap:wrap">';
    [['#2e7d32','rgba(102,187,106,0.22)','≥90% Excellent'],['#b45309','rgba(255,179,0,0.22)','75–89% Good'],['#c62828','rgba(244,67,54,0.20)','<75% Low'],['var(--muted)','rgba(255,255,255,0.06)','No data']].forEach(function(l){
      html += '<div style="display:flex;align-items:center;gap:5px;font-size:.72rem;color:' + l[0] + '"><div style="width:12px;height:12px;border-radius:3px;background:' + l[1] + ';border:1px solid rgba(255,255,255,.15)"></div>' + l[2] + '</div>';
    });
    html += '</div>';
    calEl.innerHTML = html;
  }

  function renderMonthlyTable(data) {
    var tblEl = document.getElementById('att-monthly-table');
    if (!tblEl) return;
    var students = data.students || [];
    if (!students.length) {
      tblEl.innerHTML = '<div style="text-align:center;padding:16px;color:var(--muted);font-size:.85rem">No student data found for this month.</div>';
      return;
    }
    var html = '<div style="font-size:.75rem;font-weight:600;color:var(--muted);margin-bottom:8px;text-transform:uppercase;letter-spacing:.8px">Per-Student Monthly Summary</div>';
    html += '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.82rem">';
    html += '<thead><tr style="border-bottom:1px solid var(--border)">';
    ['Roll','Name','Present','Absent','Late','%','Status'].forEach(function(h){
      html += '<th style="text-align:' + (h==='Name'?'left':'center') + ';padding:8px 10px;font-size:.7rem;color:var(--muted);font-weight:600;white-space:nowrap">' + h + '</th>';
    });
    html += '</tr></thead><tbody>';
    students.forEach(function(s) {
      var pct  = s.percentage !== undefined ? Math.round(s.percentage) : (s.totalDays ? Math.round((s.present||0)/s.totalDays*100) : null);
      var pctColor = pct === null ? 'var(--muted)' : pct >= 75 ? '#2e7d32' : pct >= 50 ? '#b45309' : '#c62828';
      var badge = pct === null ? '' : pct >= 75 ? '🟢' : pct >= 50 ? '🟡' : '🔴';
      var pill = '<span style="background:' + (pct===null?'rgba(255,255,255,.08)':pct>=75?'rgba(102,187,106,.18)':pct>=50?'rgba(255,179,0,.18)':'rgba(244,67,54,.18)') + ';color:' + pctColor + ';padding:2px 8px;border-radius:20px;font-weight:700;font-family:monospace;font-size:.78rem">' + (pct !== null ? pct+'%' : '—') + '</span>';
      html += '<tr style="border-bottom:1px solid rgba(255,255,255,.06)">';
      html += '<td style="text-align:center;padding:8px 10px;font-weight:600;font-family:monospace">' + (s.roll||s.rollNumber||'—') + '</td>';
      html += '<td style="padding:8px 10px;font-weight:500">' + (s.name||s.fullName||'—') + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#2e7d32;font-weight:600">' + (s.present||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#c62828;font-weight:600">' + (s.absent||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#b45309;font-weight:600">' + (s.late||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px">' + pill + '</td>';
      html += '<td style="text-align:center;padding:8px 10px">' + badge + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table></div>';
    tblEl.innerHTML = html;
  }

  window.attJumpToDaily = function (dateStr) {
    attSwitchTab('daily');
    var el = document.getElementById('dashAttDate');
    if (el) { el.value = dateStr; window.loadDashAttendance && window.loadDashAttendance(); }
  };

  window.exportMonthlyCSV = function () {
    if (!_monthlyData || !(_monthlyData.students||[]).length) { toast('Please load monthly data first', 'error'); return; }
    var rows = [['Roll','Name','Present','Absent','Late','Percentage']];
    (_monthlyData.students||[]).forEach(function(s){
      var pct = s.percentage !== undefined ? Math.round(s.percentage) : (s.totalDays ? Math.round((s.present||0)/s.totalDays*100) : '');
      rows.push([s.roll||s.rollNumber||'',s.name||s.fullName||'',s.present||0,s.absent||0,s.late||0,pct]);
    });
    var csv = rows.map(function(r){ return r.join(','); }).join('\n');
    var a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    a.download = 'attendance_' + (document.getElementById('attMonthClass')?.value||'class') + '_' + (document.getElementById('attMonthPicker')?.value||'month') + '.csv';
    a.click();
    toast('CSV downloaded ✅', 'success');
  };

  // ══════════════════════════════════════════════════════════════
  // TAB 3 — YEARLY OVERVIEW
  // ══════════════════════════════════════════════════════════════
  window.loadAttYearly = async function () {
    var cls  = document.getElementById('attYearClass')?.value  || '';
    var sec  = document.getElementById('attYearSec')?.value    || 'A';
    var year = document.getElementById('attYearPicker')?.value || '2025-26';
    var alertEl = document.getElementById('att-yearly-alert');
    var barsEl  = document.getElementById('att-yearly-bars');
    var tblEl   = document.getElementById('att-yearly-table');
    if (!cls) {
      if(barsEl) barsEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">Select a class to view yearly data</div>';
      if(alertEl) alertEl.style.display = 'none';
      return;
    }
    if (barsEl) barsEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">⏳ Loading yearly data...</div>';

    try {
      var r    = await fetch('/api/attendance/class/' + cls + '/' + sec + '/yearly?year=' + year, { headers: AUTH_HEADER() });
      var data = r.ok ? await r.json() : {};
      renderYearlyBars(data);
      renderYearlyTable(data);
    } catch(e) {
      if (barsEl) barsEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--muted)">❌ Could not load data.</div>';
    }
  };

  function renderYearlyBars(data) {
    var barsEl = document.getElementById('att-yearly-bars');
    if (!barsEl) return;
    var months = data.months || [];
    var MONTH_NAMES = ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'];
    if (!months.length) {
      barsEl.innerHTML = '<div style="text-align:center;padding:20px;color:var(--muted);font-size:.85rem">No monthly data found for this year.</div>';
      return;
    }
    var maxPct = 100;
    var html = '<div style="font-size:.75rem;font-weight:600;color:var(--muted);margin-bottom:12px;text-transform:uppercase;letter-spacing:.8px">Month-wise Attendance %</div>';
    html += '<div style="display:flex;align-items:flex-end;gap:6px;height:100px;padding-bottom:20px;position:relative">';
    MONTH_NAMES.forEach(function(mn, i) {
      // Backend now returns months array in academic order with percentage
      var mData = months.find(function(m){ return m.month === mn || m.monthIndex === i; }) || {};
      var pct   = (mData.hasData && mData.percentage !== null && mData.percentage !== undefined) ? Math.round(mData.percentage) : null;
      var h     = pct !== null ? Math.max(4, Math.round(pct/maxPct*80)) : 4;
      var color = pct === null ? 'rgba(255,255,255,.1)' : pct >= 90 ? 'rgba(102,187,106,.7)' : pct >= 75 ? 'rgba(255,179,0,.7)' : 'rgba(244,67,54,.65)';
      html += '<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:2px">';
      html += '<div style="font-size:.6rem;font-weight:600;color:' + (pct!==null?'var(--text)':'var(--muted)') + '">' + (pct!==null?pct+'%':'') + '</div>';
      html += '<div style="width:100%;height:' + h + 'px;background:' + color + ';border-radius:4px 4px 0 0;transition:height .3s" title="' + mn + ': ' + (pct!==null?pct+'%':'No data') + '"></div>';
      html += '<div style="font-size:.6rem;color:var(--muted);margin-top:2px">' + mn + '</div>';
      html += '</div>';
    });
    html += '</div>';
    barsEl.innerHTML = html;
  }

  function renderYearlyTable(data) {
    var tblEl   = document.getElementById('att-yearly-table');
    var alertEl = document.getElementById('att-yearly-alert');
    if (!tblEl) return;
    var students = data.students || [];
    if (!students.length) {
      tblEl.innerHTML = '<div style="text-align:center;padding:16px;color:var(--muted);font-size:.85rem">No student data found for this year.</div>';
      if (alertEl) alertEl.style.display = 'none';
      return;
    }
    var lowCount = students.filter(function(s){ return (s.percentage||0) < 75; }).length;
    if (alertEl) {
      if (lowCount > 0) {
        alertEl.style.display = '';
        alertEl.innerHTML = '<div style="background:rgba(244,67,54,.12);border:1px solid rgba(244,67,54,.3);border-radius:10px;padding:12px 16px;color:#c62828;font-size:.85rem;font-weight:600">🔴 Low Attendance Alert — <strong>' + lowCount + ' student' + (lowCount>1?'s':''+'') + '</strong> below 75% this year</div>';
      } else {
        alertEl.style.display = 'none';
      }
    }
    var html = '<div style="font-size:.75rem;font-weight:600;color:var(--muted);margin-bottom:8px;text-transform:uppercase;letter-spacing:.8px">Student-wise Yearly Summary</div>';
    html += '<table style="width:100%;border-collapse:collapse;font-size:.82rem">';
    html += '<thead><tr style="border-bottom:1px solid var(--border)">';
    ['Roll','Student Name','Total Days','Present','Absent','Late','%','Status'].forEach(function(h){
      html += '<th style="text-align:' + (h==='Student Name'?'left':'center') + ';padding:8px 10px;font-size:.7rem;color:var(--muted);font-weight:600;white-space:nowrap">' + h + '</th>';
    });
    html += '</tr></thead><tbody>';
    students.forEach(function(s) {
      var pct   = s.percentage !== undefined ? Math.round(s.percentage) : null;
      var isLow = pct !== null && pct < 75;
      var rowBg = isLow ? 'rgba(244,67,54,.07)' : '';
      var badge, badgeColor;
      if      (pct === null)   { badge = '—';          badgeColor = 'var(--muted)'; }
      else if (pct >= 75)      { badge = '🟢 Good';    badgeColor = '#2e7d32'; }
      else if (pct >= 60)      { badge = '🟡 Warning'; badgeColor = '#b45309'; }
      else                     { badge = '🔴 Low';     badgeColor = '#c62828'; }
      html += '<tr style="border-bottom:1px solid rgba(255,255,255,.06);background:' + rowBg + '">';
      html += '<td style="text-align:center;padding:8px 10px;font-weight:600;font-family:monospace">' + (s.roll||s.rollNumber||'—') + '</td>';
      html += '<td style="padding:8px 10px;font-weight:500">' + (s.name||s.fullName||'—') + '</td>';
      html += '<td style="text-align:center;padding:8px 10px">' + (s.totalDays||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#2e7d32;font-weight:600">' + (s.present||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#c62828;font-weight:600">' + (s.absent||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px;color:#b45309;font-weight:600">' + (s.late||0) + '</td>';
      html += '<td style="text-align:center;padding:8px 10px"><span style="background:' + (pct===null?'rgba(255,255,255,.08)':pct>=75?'rgba(102,187,106,.18)':pct>=60?'rgba(255,179,0,.18)':'rgba(244,67,54,.18)') + ';color:' + (pct===null?'var(--muted)':pct>=75?'#2e7d32':pct>=60?'#b45309':'#c62828') + ';padding:2px 8px;border-radius:20px;font-weight:700;font-family:monospace;font-size:.78rem">' + (pct!==null?pct+'%':'—') + '</span></td>';
      html += '<td style="text-align:center;padding:8px 10px;color:' + badgeColor + ';font-size:.8rem;font-weight:600;white-space:nowrap">' + badge + '</td>';
      html += '</tr>';
    });
    html += '</tbody></table>';
    tblEl.innerHTML = html;
  }

})();

// ================================================================
// TEACHER ACCOUNTS — Admin Management
// Create/edit/delete teacher login accounts
// ================================================================
(function () {
  'use strict';

  function adminToken() {
    return sessionStorage.getItem('admin_token') || '';
  }
  function adminHeaders() {
    return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + adminToken() };
  }

  // Load all teacher accounts
  window.loadTeacherAccounts = async function () {
    const el = document.getElementById('teacher-accounts-list');
    if (!el) return;
    el.innerHTML = '<div style="text-align:center;padding:20px;color:var(--muted)">Loading...</div>';
    try {
      const r    = await fetch('/api/teacher/admin/list', { headers: adminHeaders() });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Failed');
      renderTeacherAccountsList(data.teachers || []);
    } catch(e) {
      el.innerHTML = '<div style="text-align:center;padding:16px;color:#c62828">Error: ' + e.message + '</div>';
    }
  };

  function renderTeacherAccountsList(teachers) {
    const el = document.getElementById('teacher-accounts-list');
    if (!el) return;
    if (!teachers.length) {
      el.innerHTML = `<div style="text-align:center;padding:24px;color:var(--muted)">
        <div style="font-size:2rem;margin-bottom:8px">🔑</div>
        <div style="font-weight:600;margin-bottom:4px">No teacher accounts yet</div>
        <div style="font-size:.83rem">Click "Create Account" to add a teacher login</div>
      </div>`;
      return;
    }
    const CLASS_LABELS = {LKG:'LKG',UKG:'UKG','1':'I','2':'II','3':'III','4':'IV','5':'V','6':'VI','7':'VII','8':'VIII','9':'IX','10':'X','11':'XI','12':'XII'};
    el.innerHTML = '<div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse;font-size:.83rem">' +
      '<thead><tr style="border-bottom:1px solid var(--border)">' +
      ['Name','Username','Class','Status','Last Login','Actions'].map(h =>
        `<th style="text-align:left;padding:8px 10px;font-size:.7rem;color:var(--muted);font-weight:600;text-transform:uppercase">${h}</th>`
      ).join('') +
      '</tr></thead><tbody>' +
      teachers.map(t => {
        const cls     = t.assignedClass ? `Class ${CLASS_LABELS[t.assignedClass]||t.assignedClass}-${t.assignedSection||'A'}` : '—';
        const lastLogin = t.lastLogin ? new Date(t.lastLogin).toLocaleDateString('en-IN') : 'Never';
        const status  = t.isActive
          ? '<span style="background:rgba(102,187,106,.18);color:#2e7d32;padding:2px 8px;border-radius:10px;font-size:.72rem;font-weight:600">Active</span>'
          : '<span style="background:rgba(244,67,54,.12);color:#c62828;padding:2px 8px;border-radius:10px;font-size:.72rem;font-weight:600">Inactive</span>';
        return `<tr style="border-bottom:1px solid rgba(255,255,255,.06)">
          <td style="padding:10px;font-weight:600">${t.fullName}</td>
          <td style="padding:10px;font-family:'JetBrains Mono',monospace;font-size:.78rem">${t.username}</td>
          <td style="padding:10px">${cls}</td>
          <td style="padding:10px">${status}</td>
          <td style="padding:10px;font-size:.75rem;color:var(--muted)">${lastLogin}</td>
          <td style="padding:10px">
            <div style="display:flex;gap:6px">
              <button class="btn btn-ghost btn-sm" onclick="editTeacherAccount('${t._id}')">✏ Edit</button>
              <button class="btn btn-danger btn-sm" onclick="deleteTeacherAccount('${t._id}', '${t.fullName}')">🗑</button>
            </div>
          </td>
        </tr>`;
      }).join('') +
      '</tbody></table></div>';
  }

  window.openAddTeacherAccount = function () {
    const html = `
      <div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px" id="ta-modal-overlay" onclick="if(event.target.id==='ta-modal-overlay')closeTeacherAccountModal()">
        <div style="background:var(--surface-2);backdrop-filter:blur(20px);border:1px solid var(--border);border-radius:16px;padding:24px;width:100%;max-width:480px;max-height:90vh;overflow-y:auto">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
            <h3 style="font-family:'Cormorant Garamond',serif;font-size:1.2rem;font-weight:700">➕ Create Teacher Account</h3>
            <button onclick="closeTeacherAccountModal()" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:var(--muted)">✕</button>
          </div>
          ${taFormHTML('', '', '', '', 'A', '', '', '', true)}
          <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
            <button class="btn btn-ghost" onclick="closeTeacherAccountModal()">Cancel</button>
            <button class="btn btn-primary" onclick="submitTeacherAccount(null)">Create Account</button>
          </div>
        </div>
      </div>`;
    document.body.insertAdjacentHTML('beforeend', html);
  };

  function taFormHTML(id, fullName, username, assignedClass, assignedSection, email, phone, photo, showPassword) {
    const classOpts = ['','LKG','UKG','1','2','3','4','5','6','7','8','9','10','11','12'];
    const clsSelect = classOpts.map(c => `<option value="${c}" ${c===assignedClass?'selected':''}>${c||'-- No class assigned --'}</option>`).join('');
    return `
      <div id="ta-edit-id" style="display:none">${id}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div style="grid-column:1/-1">
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Full Name *</label>
          <input id="ta-fullname" value="${fullName}" placeholder="Teacher Full Name" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Username *</label>
          <input id="ta-username" value="${username}" placeholder="e.g. teacher01" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>
        ${showPassword ? `<div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Password *</label>
          <input id="ta-password" type="password" placeholder="Min 6 characters" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>` : `<div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">New Password (blank = keep)</label>
          <input id="ta-password" type="password" placeholder="Leave blank to keep" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>`}
        <div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Assigned Class</label>
          <select id="ta-class" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none">${clsSelect}</select>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Section</label>
          <select id="ta-section" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none">
            <option value="A" ${assignedSection==='A'?'selected':''}>Section A</option>
            <option value="B" ${assignedSection==='B'?'selected':''}>Section B</option>
          </select>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Email</label>
          <input id="ta-email" value="${email}" type="email" placeholder="teacher@school.com" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>
        <div>
          <label style="font-size:.72rem;color:var(--muted);display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:.5px">Phone</label>
          <input id="ta-phone" value="${phone}" placeholder="Mobile number" style="width:100%;padding:9px 12px;background:var(--surface);border:1px solid var(--border);border-radius:9px;font-family:'Outfit',sans-serif;font-size:.85rem;color:var(--text);outline:none"/>
        </div>
      </div>`;
  }

  window.closeTeacherAccountModal = function () {
    const el = document.getElementById('ta-modal-overlay');
    if (el) el.remove();
  };

  window.submitTeacherAccount = async function (existingId) {
    const fullName        = (document.getElementById('ta-fullname')?.value || '').trim();
    const username        = (document.getElementById('ta-username')?.value || '').trim();
    const password        = (document.getElementById('ta-password')?.value || '').trim();
    const assignedClass   = document.getElementById('ta-class')?.value   || '';
    const assignedSection = document.getElementById('ta-section')?.value || 'A';
    const email           = document.getElementById('ta-email')?.value   || '';
    const phone           = document.getElementById('ta-phone')?.value   || '';

    if (!fullName || !username) { toast('Name aur username required', 'error'); return; }
    if (!existingId && !password) { toast('Password required', 'error'); return; }
    if (password && password.length < 6) { toast('Password minimum 6 characters', 'error'); return; }

    const body = { fullName, username, assignedClass, assignedSection, email, phone };
    if (password) body.password = password;

    try {
      let r, data;
      if (existingId) {
        r    = await fetch('/api/teacher/admin/update/' + existingId, { method:'PUT', headers: adminHeaders(), body: JSON.stringify(body) });
        data = await r.json();
      } else {
        r    = await fetch('/api/teacher/admin/create', { method:'POST', headers: adminHeaders(), body: JSON.stringify(body) });
        data = await r.json();
      }
      if (!r.ok) throw new Error(data.error || 'Failed');
      toast('✅ ' + (existingId ? 'Account updated!' : 'Account created!'), 'success');
      closeTeacherAccountModal();
      loadTeacherAccounts();
    } catch(e) {
      toast('❌ ' + e.message, 'error');
    }
  };

  window.editTeacherAccount = async function (id) {
    try {
      const r    = await fetch('/api/teacher/admin/list', { headers: adminHeaders() });
      const data = await r.json();
      const t    = (data.teachers || []).find(x => x._id === id);
      if (!t) { toast('Account not found', 'error'); return; }

      const html = `
        <div style="position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px" id="ta-modal-overlay" onclick="if(event.target.id==='ta-modal-overlay')closeTeacherAccountModal()">
          <div style="background:var(--surface-2);backdrop-filter:blur(20px);border:1px solid var(--border);border-radius:16px;padding:24px;width:100%;max-width:480px;max-height:90vh;overflow-y:auto">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px">
              <h3 style="font-family:'Cormorant Garamond',serif;font-size:1.2rem;font-weight:700">✏ Edit: ${t.fullName}</h3>
              <button onclick="closeTeacherAccountModal()" style="background:none;border:none;font-size:1.2rem;cursor:pointer;color:var(--muted)">✕</button>
            </div>
            ${taFormHTML(t._id, t.fullName, t.username, t.assignedClass||'', t.assignedSection||'A', t.email||'', t.phone||'', t.photo||'', false)}
            <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:16px">
              <button class="btn btn-ghost" onclick="closeTeacherAccountModal()">Cancel</button>
              <button class="btn btn-primary" onclick="submitTeacherAccount('${t._id}')">Save Changes</button>
            </div>
          </div>
        </div>`;
      document.body.insertAdjacentHTML('beforeend', html);
    } catch(e) {
      toast('❌ ' + e.message, 'error');
    }
  };

  window.deleteTeacherAccount = async function (id, name) {
    if (!confirm(`Delete teacher account for "${name}"? This cannot be undone.`)) return;
    try {
      const r    = await fetch('/api/teacher/admin/delete/' + id, { method:'DELETE', headers: adminHeaders() });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Failed');
      toast('Account deleted', 'info');
      loadTeacherAccounts();
    } catch(e) {
      toast('❌ ' + e.message, 'error');
    }
  };

})();
