// =============================================================
//  cleanup-demo-data.js
//  Ye script MongoDB se SIRF demo/dummy data delete karega
//  
//  Kaise chalao:
//  1. Is file ko portal_updated/backend/ folder mein copy karo
//  2. Terminal mein: cd portal_updated/backend
//  3. Run karo: node cleanup-demo-data.js
// =============================================================

require('dotenv').config();
const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI;

async function cleanup() {
  console.log('🔌 MongoDB se connect ho raha hoon...');
  await mongoose.connect(MONGO_URI);
  console.log('✅ Connected!\n');

  // ── 1. FeePayments — sab delete karo (demo receipts RCP-2045 etc) ──
  const FeePayment = require('./models/FeePayment');
  const fpCount = await FeePayment.countDocuments();
  await FeePayment.deleteMany({});
  console.log(`🗑️  FeePayments deleted: ${fpCount}`);

  // ── 2. LedgerEntry — sab delete karo ──
  let LedgerEntry;
  try {
    LedgerEntry = require('./models/LedgerEntry');
    const leCount = await LedgerEntry.countDocuments();
    await LedgerEntry.deleteMany({});
    console.log(`🗑️  LedgerEntries deleted: ${leCount}`);
  } catch(e) { console.log('ℹ️  LedgerEntry model nahi mila — skip'); }

  // ── 3. Demo Students (Rahul Sharma, Priya Gupta, Aman Khan) ──
  const Student = require('./models/Student');
  const demoNames = ['Rahul Sharma', 'Priya Gupta', 'Aman Khan'];
  const stuResult = await Student.deleteMany({ fullName: { $in: demoNames } });
  console.log(`🗑️  Demo students deleted: ${stuResult.deletedCount}`);

  // ── 4. Demo Teachers (Dr. Sarah Johnson etc) ──
  const Teacher = require('./models/Teacher');
  const demoTeachers = [
    'Dr. Sarah Johnson', 'Mr. David Williams', 'Mrs. Priya Sharma',
    'Mr. Rahul Verma', 'Mrs. Anita Mehta', 'Mr. Suresh Kumar',
    'Mr. Anil Tiwari', 'Mrs. Deepa Singh'
  ];
  const tchResult = await Teacher.deleteMany({ name: { $in: demoTeachers } });
  console.log(`🗑️  Demo teachers deleted: ${tchResult.deletedCount}`);

  // ── 5. Demo Events ──
  const Event = require('./models/Event');
  const evtResult = await Event.deleteMany({
    title: { $in: ['Annual Sports Day', 'Parent-Teacher Meeting', 'Science Exhibition', 'Annual Day & Prize Giving'] }
  });
  console.log(`🗑️  Demo events deleted: ${evtResult.deletedCount}`);

  // ── 6. Demo Houses (Blue/Green/Red/Yellow) ──
  const House = require('./models/House');
  const houseResult = await House.deleteMany({
    name: { $in: ['Blue House', 'Green House', 'Red House', 'Yellow House'] }
  });
  console.log(`🗑️  Demo houses deleted: ${houseResult.deletedCount}`);

  // ── Kya bacha ──
  console.log('\n✅ Cleanup complete! Ab real data enter kar sakte ho.');
  console.log('📌 Admin user aur School Settings delete NAHI kiye — woh safe hain.\n');

  await mongoose.disconnect();
  process.exit(0);
}

cleanup().catch(err => {
  console.error('❌ Error:', err.message);
  process.exit(1);
});
