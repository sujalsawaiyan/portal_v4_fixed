// =============================================================
//  feeReminderCron.js — Automatic Daily Fee Reminder Job v4.0.0
//  Only runs when feeReminderMode === 'automatic' in MongoDB
//
//  FIXES APPLIED:
//  1. Duplicate academicYear logic → shared utils/academicYear.js
//  2. Duplicate balance logic → shared utils/balanceCalculator.js
//     Pehle: 2 nested try-catch mein manual calculation thi
//     Ab: getStudentBalance() ek call mein sab handle karta hai
//         (ledger → calculated → error safe fallback)
//  3. Discount bhi ab consider hota hai (pehle sirf totalFee - paid)
// =============================================================

'use strict';

let cronTask = null;

async function startCron() {
  let cron;
  try {
    cron = require('node-cron');
  } catch (_) {
    console.warn('[FeeReminderCron] node-cron not installed — run: npm install node-cron');
    return;
  }

  if (cronTask) {
    cronTask.stop();
    cronTask = null;
    console.log('[FeeReminderCron] Previous cron task stopped.');
  }

  const SchoolSettings = require('../models/SchoolSettings');
  const cfg = (await SchoolSettings.findOne({ key: 'whatsappConfig' }))?.value || {};

  const mode        = cfg.feeReminderMode || 'manual';
  const timeStr     = cfg.feeReminderTime || '08:00';
  const [hour, min] = timeStr.split(':').map(Number);

  if (mode !== 'automatic') {
    console.log(`[FeeReminderCron] Mode is "${mode}" — cron disabled.`);
    return;
  }

  const cronExpr = `${min || 0} ${hour || 8} * * *`;
  console.log(`[FeeReminderCron] Scheduling daily reminders at ${timeStr} (cron: ${cronExpr})`);

  cronTask = cron.schedule(cronExpr, runFeeReminders, {
    scheduled: true,
    timezone:  'Asia/Kolkata',
  });

  console.log('[FeeReminderCron] ✅ Cron task started.');
}

async function restartCron() {
  console.log('[FeeReminderCron] Restarting...');
  await startCron();
}

/**
 * Core reminder logic
 * ✅ FIX: Ab balanceCalculator use karta hai — consistent, discount-aware
 */
async function runFeeReminders() {
  console.log('[FeeReminderCron] 🔔 Running daily fee reminder check...');

  try {
    const Student               = require('../models/Student');
    const { sendFeeReminder }   = require('../utils/whatsappService');
    // ✅ FIX 1: Shared academic year (duplicate function hataya)
    const { currentAcademicYear }  = require('../utils/academicYear');
    // ✅ FIX 2: Central balance calculator (nested try-catch hataya)
    const { getStudentBalance }    = require('../utils/balanceCalculator');

    const academicYear = currentAcademicYear();
    const students     = await Student.find({ isActive: true }).lean();
    let sent = 0, failed = 0, skipped = 0;

    for (const student of students) {
      // Phone nahi hai toh WhatsApp nahi bhej sakte
      if (!student.guardianPhone) { skipped++; continue; }

      // ✅ FIX: Ek clean call — ledger → calculated → safe fallback
      // Discount bhi ab consider hoti hai (pehle nahi hoti thi)
      const bal = await getStudentBalance(student.studentId, academicYear);

      if (bal.remainingDue <= 0) { skipped++; continue; }

      const result = await sendFeeReminder({
        student,
        amountDue:    bal.remainingDue,
        totalFee:     bal.totalFee,
        totalPaid:    bal.totalPaid,
        totalDiscount: bal.totalDiscount,
        sentBy:       'auto-cron',
      });

      if (result?.success) sent++;
      else                 failed++;

      // Rate limit protection — WhatsApp 400ms gap
      await new Promise(r => setTimeout(r, 400));
    }

    console.log(`[FeeReminderCron] ✅ Done — Sent: ${sent}, Failed: ${failed}, Skipped: ${skipped}`);
  } catch (err) {
    console.error('[FeeReminderCron] ❌ Error:', err.message);
  }
}

module.exports = { startCron, restartCron, runFeeReminders };
