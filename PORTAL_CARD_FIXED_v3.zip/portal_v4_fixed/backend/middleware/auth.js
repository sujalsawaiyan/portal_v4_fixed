// =============================================================
//  middleware/auth.js — JWT Authentication & Authorization
//  SCHOOL PORTAL v2.3.0
// =============================================================
const jwt = require('jsonwebtoken');

// Single source of truth for JWT secret
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error('FATAL: JWT_SECRET not set in .env — server will not start.');
  process.exit(1);
}

// ── Verify JWT token ─────────────────────────────────────────
function auth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token. Please login again.' });
  }
}

// ── Only allow admin role ────────────────────────────────────
function adminOnly(req, res, next) {
  if (req.user && req.user.role === 'admin') return next();
  return res.status(403).json({ error: 'Access denied. Admin only.' });
}

// ── Combined: auth + adminOnly in one middleware ─────────────
// Use this as verifyAdminToken for cleaner route definitions
function verifyAdminToken(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Access denied. Admin authentication required.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied. Admin only.' });
    }
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token. Please login again.' });
  }
}

// ── Allow admin or parent ────────────────────────────────────
function parentOrAdmin(req, res, next) {
  if (req.user && (req.user.role === 'admin' || req.user.role === 'parent')) return next();
  return res.status(403).json({ error: 'Access denied.' });
}

module.exports = { auth, adminOnly, verifyAdminToken, parentOrAdmin, JWT_SECRET };
