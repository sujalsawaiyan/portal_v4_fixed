// =============================================================
//  middleware/parentAuth.js — Parent JWT Verification
//  SCHOOL PORTAL
//  Only allows tokens with role: 'parent'
//  Admin JWT will be rejected here for security.
// =============================================================
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('./auth');

function parentAuth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ error: 'Login required. Please login as parent/student.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    // Only allow parent or student role — NOT admin
    if (decoded.role !== 'parent' && decoded.role !== 'student') {
      return res.status(403).json({ error: 'Access denied. Parent or student login required.' });
    }

    req.parent = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Session expired. Please login again.' });
  }
}

module.exports = parentAuth;
