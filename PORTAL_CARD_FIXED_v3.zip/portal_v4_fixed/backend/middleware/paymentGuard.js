// =============================================================
//  middleware/paymentGuard.js
//  Protects /frontend/pages/payment.html via MongoDB toggle.
//  If admin sets paymentVisible = false  → serves "unavailable"
//  page instead of the real payment HTML.
//  Cache: re-reads MongoDB every 30 seconds (performance).
//  SCHOOL PORTAL v2.4.1
// =============================================================

const SchoolSettings = require('../models/SchoolSettings');

// ── Simple in-memory cache ─────────────────────────────────────
let _cache = { value: true, expiresAt: 0 }; // default ON

async function isPaymentEnabled() {
  const now = Date.now();
  if (now < _cache.expiresAt) return _cache.value; // cache hit

  try {
    const doc = await SchoolSettings.findOne({ key: 'paymentVisible' }).lean();
    // If no setting saved yet → treat as enabled (ON by default)
    const enabled = doc ? doc.value !== false : true;
    _cache = { value: enabled, expiresAt: now + 30_000 }; // cache 30s
    return enabled;
  } catch (err) {
    console.warn('[paymentGuard] MongoDB read failed, defaulting to enabled:', err.message);
    return true; // fail open — don't break payments on DB error
  }
}

// ── Call this from Admin API to bust cache instantly ──────────
function bustPaymentCache() {
  _cache.expiresAt = 0;
}

// ── The unavailable page HTML ─────────────────────────────────
function unavailablePage(schoolName = 'School Portal') {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Payment Unavailable — ${schoolName}</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg: #0f1117; --card: rgba(255,255,255,.05);
      --border: rgba(255,255,255,.10);
      --text: #f1f1f1; --muted: #888;
      --red: #f44336; --red-soft: rgba(244,67,54,.12);
    }
    body {
      font-family: 'Segoe UI', system-ui, sans-serif;
      background: var(--bg); color: var(--text);
      min-height: 100vh;
      display: flex; flex-direction: column;
      align-items: center; justify-content: center;
      padding: 2rem;
    }
    .card {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 20px;
      padding: 3rem 2.5rem;
      max-width: 480px; width: 100%;
      text-align: center;
      animation: fadeUp .5s ease;
    }
    @keyframes fadeUp {
      from { opacity:0; transform:translateY(24px); }
      to   { opacity:1; transform:translateY(0); }
    }
    .icon-wrap {
      width: 88px; height: 88px; border-radius: 50%;
      background: var(--red-soft);
      border: 2px solid rgba(244,67,54,.25);
      display: flex; align-items: center; justify-content: center;
      font-size: 2.6rem; margin: 0 auto 1.6rem;
    }
    h1 {
      font-size: 1.55rem; font-weight: 800;
      margin-bottom: .6rem; color: var(--text);
    }
    p {
      font-size: .95rem; color: var(--muted);
      line-height: 1.6; margin-bottom: 1.8rem;
    }
    .badge {
      display: inline-flex; align-items: center; gap: .4rem;
      background: var(--red-soft);
      border: 1px solid rgba(244,67,54,.3);
      color: var(--red); border-radius: 20px;
      padding: .35rem 1rem; font-size: .78rem; font-weight: 700;
      margin-bottom: 2rem;
    }
    .btn {
      display: inline-block; padding: .75rem 1.8rem;
      background: rgba(255,255,255,.08);
      border: 1px solid var(--border);
      color: var(--text); border-radius: 10px;
      text-decoration: none; font-weight: 600;
      font-size: .9rem; transition: background .2s;
    }
    .btn:hover { background: rgba(255,255,255,.14); }
    .divider { margin: 1.4rem 0; border: none; border-top: 1px solid var(--border); }
    .contact-note { font-size: .82rem; color: var(--muted); }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon-wrap">🔒</div>
    <span class="badge">⚠️ Service Unavailable</span>
    <h1>Payment Portal is Currently Unavailable</h1>
    <p>
      Online fee payment has been temporarily disabled by the school administration.
      Please contact the school office to make your payment or for further assistance.
    </p>
    <a href="/" class="btn">← Back to Home</a>
    <hr class="divider" />
    <p class="contact-note">
      If you believe this is an error, please reach out to the school administration.
    </p>
  </div>
</body>
</html>`;
}

// ── Middleware ─────────────────────────────────────────────────
async function paymentGuard(req, res, next) {
  try {
    const enabled = await isPaymentEnabled();
    if (enabled) return next();

    // Payment is OFF — serve the unavailable page
    res.status(503).send(unavailablePage());
  } catch (err) {
    // Fail open — don't break payments on unexpected error
    next();
  }
}

module.exports = { paymentGuard, bustPaymentCache };
