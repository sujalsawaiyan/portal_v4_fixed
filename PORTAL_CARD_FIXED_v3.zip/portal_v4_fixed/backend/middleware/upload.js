// =============================================================
//  upload.js — Multer Middleware for Image Uploads
//  SCHOOL PORTAL
//  Supports: logo, principal, banners, teachers, class-teachers,
//            leadership, events, gallery, students
// =============================================================

const multer = require('multer');
const path   = require('path');
const fs     = require('fs');

// ── Allowed categories → folder mapping ──────────────────────
const ALLOWED_CATEGORIES = [
  'logo', 'principal', 'banners', 'teachers',
  'class-teachers', 'leadership', 'events', 'gallery', 'students', 'houses'
];

// ── Allowed MIME types ────────────────────────────────────────
const ALLOWED_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

// ── Ensure upload directory exists ───────────────────────────
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

// ── Dynamic storage engine ────────────────────────────────────
const storage = multer.diskStorage({
  destination(req, _file, cb) {
    const category = req.params.category || req.body.category || 'gallery';
    if (!ALLOWED_CATEGORIES.includes(category)) {
      return cb(new Error(`Invalid category: ${category}`));
    }
    const uploadDir = path.join(__dirname, '../../uploads', category);
    ensureDir(uploadDir);
    cb(null, uploadDir);
  },

  filename(_req, file, cb) {
    const ext      = path.extname(file.originalname).toLowerCase() || '.jpg';
    const safeName = file.originalname
      .replace(/\.[^/.]+$/, '')
      .replace(/[^a-z0-9_-]/gi, '_')
      .substring(0, 40);
    const unique = `${safeName}_${Date.now()}${ext}`;
    cb(null, unique);
  },
});

// ── File filter ───────────────────────────────────────────────
function fileFilter(_req, file, cb) {
  if (ALLOWED_TYPES.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Only JPG, PNG, and WEBP images are allowed'));
  }
}

// ── Export multer instance ────────────────────────────────────
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_SIZE_BYTES },
});

module.exports = { upload, ALLOWED_CATEGORIES, ensureDir };
