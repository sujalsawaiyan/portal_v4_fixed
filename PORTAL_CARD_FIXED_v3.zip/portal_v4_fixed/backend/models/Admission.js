// =============================================================
//  Admission.js — Mongoose Model v3.0
//  SCHOOL PORTAL — Enhanced with phone validation, section,
//  alternatePhone, and WhatsApp notification log fields
// =============================================================
const mongoose = require('mongoose');

// Phone validation: exactly 10 digits
function validatePhone(v) {
  return /^\d{10}$/.test(String(v || '').replace(/\D/g, ''));
}

const AdmissionSchema = new mongoose.Schema({
  applicationId:  { type: String, unique: true, sparse: true },

  // Student Info
  studentName:    { type: String, required: true, trim: true },
  dateOfBirth:    { type: String, default: '' },
  gender:         { type: String, default: '' },

  // Academic
  applyingClass:    { type: String, required: true },
  section:          { type: String, default: '' },
  previousSchool:   { type: String, default: '' },
  previousClass:    { type: String, default: '' },
  previousMarks:    { type: String, default: '' },
  previousBoard:    { type: String, default: '' },
  reasonForJoining: { type: String, default: '' },
  howDidYouHear:    { type: String, default: '' },
  specialNeeds:     { type: String, default: '' },

  // Family
  fatherName:     { type: String, default: '' },
  motherName:     { type: String, default: '' },

  // Contact — phone is required + validated
  phone: {
    type:     String,
    required: [true, 'Parent phone number is required.'],
    validate: {
      validator: validatePhone,
      message:   'Phone must be exactly 10 digits.',
    },
  },
  alternatePhone: {
    type:    String,
    default: '',
    validate: {
      validator: (v) => !v || validatePhone(v),
      message:   'Alternate phone must be exactly 10 digits.',
    },
  },

  email:         { type: String, default: '' },
  address:       { type: String, default: '' },
  annualIncome:  { type: String, default: '' },

  // Status & Admin
  status: {
    type:    String,
    enum:    ['pending', 'approved', 'rejected', 'waitlisted'],
    default: 'pending',
  },
  notes:   { type: String, default: '' },
  session: { type: String, default: '' },

  // WhatsApp notification tracking
  whatsappStatus:  { type: String, enum: ['not_sent', 'sent', 'failed'], default: 'not_sent' },
  whatsappSentAt:  { type: Date,   default: null },
  whatsappError:   { type: String, default: '' },

  updatedAt: { type: Date, default: null },
}, { timestamps: true });

// Indexes
AdmissionSchema.index({ phone: 1 });
AdmissionSchema.index({ status: 1 });
AdmissionSchema.index({ createdAt: -1 });

// Auto-generate applicationId
AdmissionSchema.pre('save', async function(next) {
  if (!this.applicationId) {
    const year  = new Date().getFullYear();
    const count = await this.constructor.countDocuments();
    this.applicationId = `APP${year}${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

module.exports = mongoose.model('Admission', AdmissionSchema);
