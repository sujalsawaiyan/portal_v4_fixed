// =============================================================
//  Class.js — Mongoose Model
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const ClassSchema = new mongoose.Schema({
  className:      { type: String, required: true },
  // LKG, UKG, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
  section:        { type: String, default: 'A' },
  teacherName:    { type: String, default: '' },
  teacherPhoto:   { type: String, default: '' },
  teacherExp:     { type: Number, default: 0 },
  teacherSubject: { type: String, default: '' },
  teacherQual:    { type: String, default: '' },
  totalStudents:  { type: Number, default: 0 },
  room:           { type: String, default: '' },
  isActive:       { type: Boolean, default: true },
}, { timestamps: true });

ClassSchema.index({ className: 1, section: 1 }, { unique: true });

module.exports = mongoose.model('Class', ClassSchema);
