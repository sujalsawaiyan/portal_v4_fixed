// =============================================================
//  ClassSubjects.js — Dynamic Subject List per Class/Section
//  SCHOOL PORTAL
//  Stores which subjects are defined for each class.
//  This allows teachers to define subjects BEFORE entering marks.
//  Subject list is board/class specific — no hardcoded subjects.
// =============================================================
const mongoose = require('mongoose');

const SubjectEntrySchema = new mongoose.Schema({
  name:          { type: String, required: true, trim: true },
  code:          { type: String, default: '' },
  maxMarks:      { type: Number, default: 100 },
  maxPractical:  { type: Number, default: 0 },
  isOptional:    { type: Boolean, default: false },
  order:         { type: Number, default: 0 },        // for display ordering
}, { _id: false });

const ClassSubjectsSchema = new mongoose.Schema({
  class:        { type: String, required: true },      // "LKG","1"..."12"
  section:      { type: String, default: 'A' },        // "A" or "B"
  academicYear: { type: String, required: true },      // "2025-26"
  subjects:     { type: [SubjectEntrySchema], default: [] },
  updatedBy:    { type: String, default: '' },         // teacher username
}, { timestamps: true });

// Unique per class+section+year
ClassSubjectsSchema.index({ class: 1, section: 1, academicYear: 1 }, { unique: true });

module.exports = mongoose.model('ClassSubjects', ClassSubjectsSchema);
