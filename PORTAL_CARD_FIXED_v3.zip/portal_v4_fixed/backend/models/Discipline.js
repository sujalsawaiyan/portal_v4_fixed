// =============================================================
//  Discipline.js — Student Discipline Records
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const DisciplineSchema = new mongoose.Schema({
  studentId:    { type: String, required: true, index: true },
  studentName:  { type: String, default: '' },
  class:        { type: String, default: '' },
  section:      { type: String, default: '' },
  date:         { type: String, required: true },       // YYYY-MM-DD
  academicYear: { type: String, default: '' },

  type:         { type: String, enum: ['positive', 'negative', 'neutral'], default: 'neutral' },
  category:     { type: String, default: 'General' },
  // Categories: Behavior, Punctuality, Academics, Sports, Cleanliness, Respect, Teamwork, OverallRemark

  description:  { type: String, required: true, trim: true },
  points:       { type: Number, default: 0 },           // +ve = good, -ve = bad
  term:         { type: String, default: '' },           // Term1 / Term2 / Annual (for OverallRemark)
  behaviour:    { type: String, default: '' },           // Excellent / Good / Satisfactory / NeedsImprovement

  recordedBy:   { type: String, default: '' },          // teacher username
}, { timestamps: true });

function academicYear(dateStr) {
  const d = new Date(dateStr);
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  return m >= 4 ? `${y}-${String(y+1).slice(-2)}` : `${y-1}-${String(y).slice(-2)}`;
}

DisciplineSchema.pre('save', function (next) {
  if (!this.academicYear && this.date) {
    this.academicYear = academicYear(this.date);
  }
  // Auto-set points sign based on type
  if (this.type === 'positive'  && this.points < 0) this.points = Math.abs(this.points);
  if (this.type === 'negative'  && this.points > 0) this.points = -Math.abs(this.points);
  next();
});

module.exports = mongoose.model('Discipline', DisciplineSchema);
