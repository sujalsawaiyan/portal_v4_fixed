// =============================================================
//  Event.js — Mongoose Model v2.2.0
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema({
  title:         { type: String, required: true, trim: true, maxlength: 200 },
  type:          { type: String, default: 'other', trim: true, maxlength: 50 },
  date:          { type: String, required: true, maxlength: 20 },
  endDate:       { type: String, default: '', maxlength: 20 },
  end_date:      { type: String, default: '', maxlength: 20 },
  description:   { type: String, default: '', trim: true, maxlength: 2000 },
  venue:         { type: String, default: '', trim: true, maxlength: 300 },
  featured:      { type: Boolean, default: false },
  is_featured:   { type: Boolean, default: false },
  image:         { type: String, default: '', maxlength: 500 },
  imagePublicId: { type: String, default: '', maxlength: 200 },        // Cloudinary public_id
  highlighted:   { type: Boolean, default: false },
  glowColor:     { type: String, default: '', maxlength: 20 },
  createdBy:     { type: String, default: 'admin', maxlength: 100 },
  isActive:      { type: Boolean, default: true },
}, { timestamps: true });

EventSchema.pre('save', function(next) {
  if (this.is_featured !== undefined) this.featured    = this.is_featured;
  if (this.featured    !== undefined) this.is_featured = this.featured;
  if (this.end_date && !this.endDate) this.endDate     = this.end_date;
  if (this.endDate  && !this.end_date) this.end_date   = this.endDate;
  next();
});

module.exports = mongoose.model('Event', EventSchema);
