// =============================================================
//  ExamSchedule.js — Mongoose Model
//  SCHOOL PORTAL
//  Stores exam schedule entries (Term I, Term II, Board Exams)
// =============================================================
const mongoose = require('mongoose');

const ExamScheduleSchema = new mongoose.Schema({
  term: {
    type: String,
    required: true,
    enum: ['term1', 'term2', 'board'],
    trim: true,
  },
  date: {
    type: String,
    required: true,
    trim: true,
    maxlength: 30,
  },
  subject: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100,
  },
  classes: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100,
  },
  duration: {
    type: String,
    default: '3 Hours',
    trim: true,
    maxlength: 30,
  },
  maxMarks: {
    type: Number,
    default: 100,
  },
  order: {
    type: Number,
    default: 0,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  createdBy: {
    type: String,
    default: 'admin',
    maxlength: 100,
  },
}, { timestamps: true });

ExamScheduleSchema.index({ term: 1, order: 1 });

module.exports = mongoose.model('ExamSchedule', ExamScheduleSchema);
