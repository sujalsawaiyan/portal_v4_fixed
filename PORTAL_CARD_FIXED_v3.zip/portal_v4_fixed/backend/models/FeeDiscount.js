// =============================================================
//  FeeDiscount.js — Student-specific fee discounts
// =============================================================
const mongoose = require('mongoose');

const FeeDiscountSchema = new mongoose.Schema({
  studentId:       { type: String, required: true, index: true },
  studentName:     { type: String, default: '' },
  discountType:    { type: String, enum: ['Scholarship','Sibling','Staff Ward','RTE','Merit','Special'], required: true },
  discountPercent: { type: Number, default: 0 },   // use percent OR fixed amount
  discountAmount:  { type: Number, default: 0 },
  applicableHeads: [String],                        // which feeHead names this applies to; empty = all
  academicYear:    { type: String, required: true },
  approvedBy:      { type: String, default: 'Admin' },
  remarks:         { type: String, default: '' },
  isActive:        { type: Boolean, default: true },
  // Approval workflow (MISSING 6)
  status:          { type: String, enum: ['pending','approved','rejected'], default: 'approved' },
  approvalRequired:{ type: Boolean, default: false },
  requestedBy:     { type: String, default: 'Admin' },
  approvedAt:      { type: Date },
  // Frontend-friendly virtual fields stored as extra
  name:            { type: String, default: '' },   // alias for category display
  type:            { type: String, enum: ['percentage','fixed',''], default: '' },
  value:           { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('FeeDiscount', FeeDiscountSchema);
