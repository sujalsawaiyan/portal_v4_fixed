// =============================================================
//  FeePayment.js — Updated: Online/UPI, cheque bounce, edit log
// =============================================================
const mongoose = require('mongoose');

const PaymentHeadSchema = new mongoose.Schema({
  headName: { type: String },
  amount:   { type: Number },
  period:   { type: String, default: '' }
}, { _id: false });

const EditLogSchema = new mongoose.Schema({
  editedAt: { type: Date, default: Date.now },
  editedBy: { type: String, default: 'Admin' },
  changes:  { type: String, default: '' },
}, { _id: false });

const FeePaymentSchema = new mongoose.Schema({
  receiptNumber:   { type: String, unique: true, index: true },
  studentId:       { type: String, required: true, index: true },
  studentName:     { type: String, required: true },
  class:           { type: String, required: true },
  section:         { type: String, default: 'A' },
  admissionNumber: { type: String, default: '' },
  academicYear:    { type: String, required: true, index: true },
  paymentDate:     { type: String, required: true },
  feeHeads:        [PaymentHeadSchema],
  totalAmount:     { type: Number, required: true },
  paymentMode:     { type: String, enum: ['Cash','Cheque','DD','Online','UPI'], default: 'Cash' },
  chequeNumber:    { type: String, default: '' },
  chequeDate:      { type: String, default: '' },
  bankName:        { type: String, default: '' },
  chequeStatus:    { type: String, enum: ['pending','cleared','bounced',''], default: '' },
  utrNumber:       { type: String, default: '' },
  bankRef:         { type: String, default: '' },
  upiApp:          { type: String, default: '' },
  upiVerified:     { type: Boolean, default: false },
  upiPending:      { type: Boolean, default: false },
  upiRejected:     { type: Boolean, default: false },
  upiRejectReason: { type: String,  default: '' },
  remarks:         { type: String,  default: '' },
  receivedBy:      { type: String,  default: 'Admin' },
  isCancelled:     { type: Boolean, default: false },
  cancelReason:    { type: String,  default: '' },
  cancelledAt:     { type: String,  default: '' },
  cancelledBy:     { type: String,  default: '' },
  // Late fine fields (Feature 2 — non-destructive additions)
  fineAmount:      { type: Number,  default: 0 },
  fineWaived:      { type: Boolean, default: false },
  fineWaiverReason:{ type: String,  default: '' },
  editLog:         [EditLogSchema],
}, { timestamps: true });

FeePaymentSchema.index({ academicYear: 1, paymentDate: 1 });
FeePaymentSchema.index({ academicYear: 1, class: 1 });
FeePaymentSchema.index({ upiPending: 1 });

FeePaymentSchema.pre('save', async function (next) {
  if (this.receiptNumber) return next();
  const year   = this.academicYear ? this.academicYear.split('-')[0] : new Date().getFullYear();
  const prefix = `RCP-${year}-`;
  const last   = await mongoose.model('FeePayment')
    .findOne({ receiptNumber: new RegExp(`^${prefix}`) })
    .sort({ receiptNumber: -1 });
  const nextNum = last ? parseInt(last.receiptNumber.replace(prefix, ''), 10) + 1 : 1;
  this.receiptNumber = `${prefix}${String(nextNum).padStart(4, '0')}`;
  next();
});

module.exports = mongoose.model('FeePayment', FeePaymentSchema);
