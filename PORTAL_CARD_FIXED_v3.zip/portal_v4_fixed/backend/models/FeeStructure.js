// =============================================================
//  FeeStructure.js — Fee structure per class per academic year
// =============================================================
const mongoose = require('mongoose');

const FeeHeadSchema = new mongoose.Schema({
  headName:  { type: String, required: true },
  amount:    { type: Number, required: true, default: 0 },
  frequency: { type: String, enum: ['monthly','quarterly','annually','one-time'], default: 'annually' }
}, { _id: false });

const FeeStructureSchema = new mongoose.Schema({
  academicYear:   { type: String, required: true },   // e.g. "2024-25"
  class:          { type: String, required: true },   // LKG, UKG, 1 … 12
  feeHeads:       [FeeHeadSchema],
  totalAnnualFee: { type: Number, default: 0 }
}, { timestamps: true });

FeeStructureSchema.index({ academicYear: 1, class: 1 }, { unique: true });

// Auto-calculate total annual fee based on frequency
FeeStructureSchema.pre('save', function (next) {
  const mult = { monthly: 12, quarterly: 4, annually: 1, 'one-time': 1 };
  this.totalAnnualFee = this.feeHeads.reduce(
    (sum, h) => sum + h.amount * (mult[h.frequency] || 1), 0
  );
  next();
});

// Also run on findOneAndUpdate with upsert
FeeStructureSchema.pre('findOneAndUpdate', async function (next) {
  const update = this.getUpdate();
  const feeHeads = update?.feeHeads || update?.$set?.feeHeads;
  if (feeHeads) {
    const mult = { monthly: 12, quarterly: 4, annually: 1, 'one-time': 1 };
    const total = feeHeads.reduce((sum, h) => sum + h.amount * (mult[h.frequency] || 1), 0);
    if (update.$set) update.$set.totalAnnualFee = total;
    else update.totalAnnualFee = total;
  }
  next();
});

module.exports = mongoose.model('FeeStructure', FeeStructureSchema);
