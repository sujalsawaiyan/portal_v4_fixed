// FineRule.js — Late fine configuration per academic year
const mongoose = require('mongoose');
const FineRuleSchema = new mongoose.Schema({
  academicYear: { type: String, required: true, unique: true },
  graceDays:    { type: Number, default: 5 },
  fineType:     { type: String, enum: ['fixed','percentage'], default: 'fixed' },
  amount:       { type: Number, default: 50 },    // ₹ per period (if fixed)
  percentage:   { type: Number, default: 2 },     // % of due (if percentage)
  per:          { type: String, enum: ['day','week','month'], default: 'month' },
  autoApply:    { type: Boolean, default: true },
  showSeparately: { type: Boolean, default: true },
}, { timestamps: true });
module.exports = mongoose.model('FineRule', FineRuleSchema);
