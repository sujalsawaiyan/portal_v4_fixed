// =============================================================
//  Gallery.js — Mongoose Model
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const GallerySchema = new mongoose.Schema({
  title:        { type: String, required: true, trim: true },
  category:     { type: String, default: 'general' },
  // sports, academic, cultural, general, other
  url:          { type: String, default: '' },      // image URL (Cloudinary or /uploads/)
  cloudinaryId: { type: String, default: '' },      // public_id for deletion
  emoji:        { type: String, default: '🖼️' },
  order:        { type: Number, default: 0 },
  isActive:     { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Gallery', GallerySchema);
