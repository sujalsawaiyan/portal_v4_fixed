// =============================================================
//  House.js — Mongoose Model
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const ContributorSchema = new mongoose.Schema({
  name:   { type: String, default: '' },
  points: { type: Number, default: 0 },
  photo:  { type: String, default: '' },
}, { _id: false });

const HouseSchema = new mongoose.Schema({
  id:          { type: Number, default: 0 },   // legacy numeric id for frontend compat
  name:        { type: String, required: true },
  color:       { type: String, default: '#6C63FF' },
  gradient:    { type: String, default: '' },
  emoji:       { type: String, default: '' },
  captain:     { type: String, default: '' },
  viceCaptain: { type: String, default: '' },
  sports:      { type: Number, default: 0 },
  study:       { type: Number, default: 0 },
  activities:  { type: Number, default: 0 },
  discipline:  { type: Number, default: 0 },
  tagline:       { type: String, default: '' },       // Short house motto / tagline
  logo:          { type: String, default: '' },       // Cloudinary URL
  logoPublicId:  { type: String, default: '' },       // Cloudinary public_id (for deletion)
  contributors:  { type: [ContributorSchema], default: [] },
  isActive:      { type: Boolean, default: true },
}, { timestamps: true });

// Virtual: sum of all point categories
HouseSchema.virtual('points').get(function() {
  return (this.sports || 0) + (this.study || 0) +
         (this.activities || 0) + (this.discipline || 0);
});

HouseSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('House', HouseSchema);
