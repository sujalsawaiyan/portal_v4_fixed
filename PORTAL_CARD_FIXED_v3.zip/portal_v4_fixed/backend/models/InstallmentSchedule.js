// InstallmentSchedule.js — Term/installment schedule per academic year
const mongoose = require('mongoose');
const TermSchema = new mongoose.Schema({
  name:       { type: String, required: true },  // e.g. "Term 1 (Apr)"
  dueDate:    { type: String, required: true },   // YYYY-MM-DD
  percentage: { type: Number, required: true },   // 25
}, { _id: false });

const InstallmentScheduleSchema = new mongoose.Schema({
  academicYear: { type: String, required: true, unique: true },
  terms:        [TermSchema],
}, { timestamps: true });
module.exports = mongoose.model('InstallmentSchedule', InstallmentScheduleSchema);
