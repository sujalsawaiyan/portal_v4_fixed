// =============================================================
//  LedgerEntry.js — Bank-statement style ledger for fee tracking
//  Each student has a running ledger of charges & payments
// =============================================================
const mongoose = require('mongoose');

const LedgerEntrySchema = new mongoose.Schema({
  studentId:    { type: String, required: true, index: true },
  studentName:  { type: String, required: true },
  class:        { type: String, required: true },
  section:      { type: String, default: 'A' },
  academicYear: { type: String, required: true, index: true },

  // ── Entry core ────────────────────────────────────────────
  type:        { type: String, enum: ['charge', 'payment'], required: true },
  amount:      { type: Number, required: true, min: 0 },
  date:        { type: String, required: true },  // YYYY-MM-DD
  description: { type: String, required: true },  // "Monthly Fee – April 2025", "Cash Payment", etc.
  method:      { type: String, default: '' },     // Cash / Cheque / Online (for payments)
  month:       { type: String, default: '' },     // "2025-04" — for month-wise tracking

  // ── Running balance after this entry ──────────────────────
  // Recalculated whenever any entry for this student is mutated
  balance:     { type: Number, default: 0 },

  // ── Receipt / reference ────────────────────────────────────
  receiptNumber: { type: String, default: '' },
  chequeNumber:  { type: String, default: '' },
  bankName:      { type: String, default: '' },
  remarks:       { type: String, default: '' },

  // ── Soft-delete ────────────────────────────────────────────
  isDeleted:    { type: Boolean, default: false, index: true },
  deletedBy:    { type: String, default: '' },
  deletedAt:    { type: String, default: '' },
  deleteReason: { type: String, default: '' },

  // ── Audit ──────────────────────────────────────────────────
  createdBy:    { type: String, default: 'Admin' },
}, { timestamps: true });

LedgerEntrySchema.index({ studentId: 1, academicYear: 1, date: 1 });
LedgerEntrySchema.index({ studentId: 1, isDeleted: 1, date: 1 });

module.exports = mongoose.model('LedgerEntry', LedgerEntrySchema);
