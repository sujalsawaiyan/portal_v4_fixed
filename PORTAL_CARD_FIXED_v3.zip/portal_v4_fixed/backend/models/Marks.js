// =============================================================
//  Marks.js — Student Subject Marks
//  SCHOOL PORTAL
//  One record per student per subject per term per academic year
// =============================================================
const mongoose = require('mongoose');

const MarksSchema = new mongoose.Schema({
  studentId:          { type: String, required: true, index: true },
  class:              { type: String, required: true },
  section:            { type: String, default: 'A' },
  subject:            { type: String, required: true, trim: true },
  term:               { type: String, required: true },    // "Term1" | "Term2" | "Annual"
  academicYear:       { type: String, default: '' },       // "2025-26"

  // Theory
  marksObtained:      { type: Number, default: 0 },
  maxMarks:           { type: Number, default: 100 },

  // Practical (optional — 0 means no practical)
  practicalObtained:  { type: Number, default: 0 },
  maxPractical:       { type: Number, default: 0 },

  // Auto-calculated
  totalObtained:      { type: Number, default: 0 },
  totalMax:           { type: Number, default: 100 },
  percentage:         { type: Number, default: 0 },
  grade:              { type: String, default: '' },
  gradePoint:         { type: Number, default: 0 },

  remarks:            { type: String, default: '' },
  enteredBy:          { type: String, default: '' },       // teacher username
}, { timestamps: true });

// Unique: one record per student+subject+term+year
MarksSchema.index({ studentId: 1, subject: 1, term: 1, academicYear: 1 }, { unique: true });

// Auto-calculate totals, percentage, grade before save
MarksSchema.pre('save', function (next) {
  this.totalObtained = this.marksObtained + this.practicalObtained;
  this.totalMax      = this.maxMarks + this.maxPractical;
  this.percentage    = this.totalMax > 0
    ? Math.round((this.totalObtained / this.totalMax) * 100 * 10) / 10
    : 0;
  this.grade      = calcGrade(this.percentage);
  this.gradePoint = calcGradePoint(this.percentage);
  next();
});

function calcGrade(pct) {
  if (pct >= 91) return 'A+';
  if (pct >= 81) return 'A';
  if (pct >= 71) return 'B+';
  if (pct >= 61) return 'B';
  if (pct >= 51) return 'C+';
  if (pct >= 41) return 'C';
  if (pct >= 33) return 'D';
  return 'F';
}

function calcGradePoint(pct) {
  if (pct >= 91) return 10;
  if (pct >= 81) return 9;
  if (pct >= 71) return 8;
  if (pct >= 61) return 7;
  if (pct >= 51) return 6;
  if (pct >= 41) return 5;
  if (pct >= 33) return 4;
  return 0;
}

module.exports = mongoose.model('Marks', MarksSchema);
