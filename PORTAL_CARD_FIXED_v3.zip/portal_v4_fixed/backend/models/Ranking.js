// =============================================================
//  Ranking.js — Student Class Rankings
//  SCHOOL PORTAL
//  Class Teacher sets rankings for their own class students
//  One record per student per term per academic year per class
// =============================================================
const mongoose = require('mongoose');

const RankingSchema = new mongoose.Schema({
  studentId:     { type: String, required: true, index: true },
  studentName:   { type: String, default: '' },
  rollNumber:    { type: String, default: '' },
  class:         { type: String, required: true },
  section:       { type: String, default: 'A' },
  term:          { type: String, required: true },      // "Term1" | "Term2" | "Annual"
  academicYear:  { type: String, default: '' },         // "2025-26"

  // Scores entered by class teacher
  marksScore:    { type: Number, default: 0, min: 0, max: 100 },   // percentage marks
  attendance:    { type: Number, default: 0, min: 0, max: 100 },   // attendance %
  activities:    { type: Number, default: 0, min: 0, max: 10 },    // co-curricular /10
  discipline:    { type: Number, default: 0, min: 0, max: 10 },    // discipline /10

  // Auto-calculated overall score (marks*0.6 + att*0.2 + act*0.1 + disc*0.1)
  overallScore:  { type: Number, default: 0 },

  // Rank within class-section-term (set when teacher saves all rankings)
  rank:          { type: Number, default: 0 },

  // Who entered
  enteredBy:     { type: String, default: '' },    // teacher username
  remarks:       { type: String, default: '' },

}, { timestamps: true });

// Unique: one record per student+term+year
RankingSchema.index({ studentId: 1, term: 1, academicYear: 1 }, { unique: true });
RankingSchema.index({ class: 1, section: 1, term: 1, academicYear: 1 });

// Auto-calculate overall score before save
RankingSchema.pre('save', function (next) {
  this.overallScore = parseFloat(
    (this.marksScore * 0.6 + this.attendance * 0.2 + this.activities * 10 * 0.1 + this.discipline * 10 * 0.1).toFixed(1)
  );
  next();
});

module.exports = mongoose.model('Ranking', RankingSchema);
