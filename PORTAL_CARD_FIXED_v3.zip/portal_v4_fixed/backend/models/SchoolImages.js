// =============================================================
//  SchoolImages.js — MongoDB Models for All Image Sections
//  SCHOOL PORTAL
// =============================================================

const mongoose = require('mongoose');

// ── Single-image sections (logo, principal, banner, etc.) ────
const SchoolImageSchema = new mongoose.Schema({
  category:   { type: String, required: true, unique: true, index: true },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },  // Cloudinary public_id for deletion
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
  uploadedBy: { type: String, default: 'admin' },
}, { timestamps: true });

const SchoolImage = mongoose.model('SchoolImage', SchoolImageSchema);

// ── Gallery ───────────────────────────────────────────────────
const GalleryItemSchema = new mongoose.Schema({
  title:      { type: String, required: true, trim: true },
  category:   { type: String, default: 'other' },
  emoji:      { type: String, default: '🖼️' },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
  uploadedBy: { type: String, default: 'admin' },
}, { timestamps: true });

const GalleryItem = mongoose.model('GalleryItem', GalleryItemSchema);

// ── Teacher photos ────────────────────────────────────────────
const TeacherPhotoSchema = new mongoose.Schema({
  teacherId:  { type: String, required: true, unique: true, index: true },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
}, { timestamps: true });

const TeacherPhoto = mongoose.model('TeacherPhoto', TeacherPhotoSchema);

// ── Event images ─────────────────────────────────────────────
const EventImageSchema = new mongoose.Schema({
  eventId:    { type: String, required: true, unique: true, index: true },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
}, { timestamps: true });

const EventImage = mongoose.model('EventImage', EventImageSchema);

// ── Top Students ─────────────────────────────────────────────
const TopStudentImageSchema = new mongoose.Schema({
  rank:       { type: Number, required: true, unique: true, index: true },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
}, { timestamps: true });

const TopStudentImage = mongoose.model('TopStudentImage', TopStudentImageSchema);

// ── House Images ─────────────────────────────────────────────
const HouseImageSchema = new mongoose.Schema({
  houseId:    { type: String, required: true, unique: true, index: true },
  imageUrl:   { type: String, default: '' },
  publicId:   { type: String, default: '' },
  filename:   { type: String, default: '' },
  uploadedAt: { type: Date,   default: Date.now },
}, { timestamps: true });

const HouseImage = mongoose.model('HouseImage', HouseImageSchema);

module.exports = { SchoolImage, GalleryItem, TeacherPhoto, EventImage, TopStudentImage, HouseImage };
