// =============================================================
//  SchoolSettings.js — Mongoose Model
//  Stores arbitrary school configuration as key-value pairs.
//  Used for: schoolInfo, homepageContent, schoolTiming,
//            feeStructure, socialLinks, upiPayment, etc.
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const SchoolSettingsSchema = new mongoose.Schema({
  key:       { type: String, required: true, unique: true, index: true },
  value:     { type: mongoose.Schema.Types.Mixed, required: true },
  updatedBy: { type: String, default: 'admin' },
}, { timestamps: true });

module.exports = mongoose.model('SchoolSettings', SchoolSettingsSchema);
