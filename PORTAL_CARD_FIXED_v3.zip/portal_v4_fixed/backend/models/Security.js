const mongoose = require('mongoose');

const VisitorSchema = new mongoose.Schema({
  visitorName:   { type: String, required: true, trim: true },
  phone:         { type: String, default: '' },
  idType:        { type: String, enum: ['Aadhar','Voter ID','Driving Licence','Passport','Other'], default: 'Aadhar' },
  idNumber:      { type: String, default: '' },
  purpose:       { type: String, enum: ['Parent Meeting','Student Pickup','Official Work','Delivery','Interview','Other'], default: 'Parent Meeting' },
  purposeNote:   { type: String, default: '' },
  personToMeet:  { type: String, default: '' },
  studentName:   { type: String, default: '' },
  studentClass:  { type: String, default: '' },
  dateIn:        { type: String, required: true },
  timeIn:        { type: String, required: true },
  timeOut:       { type: String, default: '' },
  duration:      { type: Number, default: 0 },
  status:        { type: String, enum: ['inside','checked_out','denied'], default: 'inside' },
  passNo:        { type: String, default: '' },
  remarks:       { type: String, default: '' },
  enteredBy:     { type: String, default: 'admin' },
}, { timestamps: true });

VisitorSchema.index({ dateIn: 1 });

const Visitor = mongoose.model('Visitor', VisitorSchema);

const SecurityAlertSchema = new mongoose.Schema({
  type:        { type: String, enum: ['lockdown','fire_drill','unauthorized_entry','medical','fight','theft','other'], default: 'other' },
  title:       { type: String, required: true },
  description: { type: String, default: '' },
  severity:    { type: String, enum: ['low','medium','high','critical'], default: 'medium' },
  date:        { type: String, required: true },
  time:        { type: String, required: true },
  location:    { type: String, default: '' },
  resolvedAt:  { type: String, default: '' },
  status:      { type: String, enum: ['open','resolved'], default: 'open' },
  reportedBy:  { type: String, default: 'admin' },
}, { timestamps: true });

const SecurityAlert = mongoose.model('SecurityAlert', SecurityAlertSchema);

module.exports = { Visitor, SecurityAlert };
