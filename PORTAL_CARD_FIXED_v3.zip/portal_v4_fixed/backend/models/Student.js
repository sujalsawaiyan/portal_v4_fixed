const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

// Auto-generate Student ID: SCH + year + 4-digit number
// e.g. SCH20250001, SCH20250002, ...
async function generateStudentId() {
  const year    = new Date().getFullYear();
  const prefix  = `SCH${year}`;
  const last    = await Student.findOne({ studentId: new RegExp(`^${prefix}`) })
                               .sort({ studentId: -1 });
  if (!last) return `${prefix}0001`;
  const num = parseInt(last.studentId.slice(-4)) + 1;
  return `${prefix}${String(num).padStart(4, '0')}`;
}

const StudentSchema = new mongoose.Schema({
  studentId: {
    type:     String,
    unique:   true,
    index:    true,
  },

  // Basic Info
  fullName:      { type: String, required: true, trim: true },
  dateOfBirth:   { type: String, default: '' },  // YYYY-MM-DD (optional — not required to avoid form errors)
  gender:        { type: String, enum: ['Male', 'Female', 'Other'] },
  photo:         { type: String, default: '' },  // base64 or URL

  // Academic
  class:         { type: String, required: true },   // e.g. "10"
  section:       { type: String, default: 'A' },
  rollNumber:    { type: String, default: '' },
  house:         { type: String, default: '' },
  admissionDate: { type: String, default: '' },
  admissionNumber: { type: String, default: '', index: true },  // for fees system

  // Contact
  email:         { type: String, default: '' },
  guardianName:  { type: String, default: '' },   // fatherName
  motherName:    { type: String, default: '' },
  guardianPhone: { type: String, default: '' },
  address:       { type: String, default: '' },

  // Photo
  photoPublicId: { type: String, default: '' },  // Cloudinary public_id for deletion

  // Auth
  password:      { type: String, required: true },  // hashed
  role:          { type: String, default: 'student' },
  isActive:      { type: Boolean, default: true },

}, { timestamps: true });

// Auto-generate studentId before saving
StudentSchema.pre('save', async function(next) {
  if (!this.studentId) {
    this.studentId = await generateStudentId();
  }
  // Hash password if changed
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  next();
});

// Compare password
StudentSchema.methods.comparePassword = function(plain) {
  return bcrypt.compare(plain, this.password);
};

// Don't send password in JSON response
StudentSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

const Student = mongoose.model('Student', StudentSchema);
module.exports = Student;
