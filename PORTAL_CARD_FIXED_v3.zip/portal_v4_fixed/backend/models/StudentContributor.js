// =============================================================
//  models/StudentContributor.js
//  Top Student Contributors — per house, sorted by points
// =============================================================
const mongoose = require('mongoose');

const StudentContributorSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  house:     { type: String, required: true, enum: ['Red', 'Blue', 'Green', 'Yellow'], trim: true },
  points:    { type: Number, required: true, default: 0, min: 0 },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('StudentContributor', StudentContributorSchema);
