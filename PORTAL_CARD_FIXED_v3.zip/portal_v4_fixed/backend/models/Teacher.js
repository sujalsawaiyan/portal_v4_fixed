// =============================================================
//  Teacher.js — Mongoose Model v2.2.0
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const TeacherSchema = new mongoose.Schema({
  name:          { type: String, required: true, trim: true, maxlength: 100 },
  fullName:      { type: String, trim: true, maxlength: 100 },        // alias
  subject:       { type: String, default: '', trim: true, maxlength: 100 },
  department:    { type: String, default: 'General', trim: true, maxlength: 100 },
  dept:          { type: String, default: '', trim: true, maxlength: 100 },  // alias
  experience:    { type: Number, default: 0, min: 0, max: 60 },
  exp:           { type: Number, default: 0, min: 0, max: 60 },       // alias
  role:          { type: String, default: 'teacher', trim: true },
  // principal, vice_principal, hod, academic_coordinator,
  // activity_coordinator, teacher
  qualification: { type: String, default: '', trim: true, maxlength: 200 },
  qual:          { type: String, default: '', trim: true, maxlength: 200 }, // alias
  email: {
    type:      String,
    default:   '',
    trim:      true,
    lowercase: true,
    maxlength: 150,
    validate: {
      validator: v => !v || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v),
      message:   'Invalid email format',
    },
  },
  phone:         { type: String, default: '', trim: true, maxlength: 20 },
  photo:         { type: String, default: '', maxlength: 500 },        // Cloudinary URL
  photoPublicId: { type: String, default: '', maxlength: 200 },        // ✅ FIXED: Cloudinary public_id for cleanup
  isActive:      { type: Boolean, default: true },
  order:         { type: Number, default: 0 },
}, { timestamps: true });

// ── Keep aliases in sync on save ─────────────────────────────
TeacherSchema.pre('save', function(next) {
  if (this.fullName && !this.name)       this.name       = this.fullName;
  if (this.name     && !this.fullName)   this.fullName   = this.name;
  if (this.exp      && !this.experience) this.experience = this.exp;
  if (this.experience !== undefined && !this.exp) this.exp = this.experience;
  if (this.dept     && !this.department) this.department = this.dept;
  if (this.department && !this.dept)     this.dept       = this.department;
  next();
});

// Virtual for compatibility
TeacherSchema.virtual('full_name').get(function() { return this.name; });
TeacherSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Teacher', TeacherSchema);
