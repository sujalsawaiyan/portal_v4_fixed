// =============================================================
//  TeacherAccount.js — Teacher Login Accounts
//  SCHOOL PORTAL
//  Admin creates these from admin panel
// =============================================================
const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const TeacherAccountSchema = new mongoose.Schema({
  // Login credentials
  username:        { type: String, required: true, unique: true, trim: true, lowercase: true },
  password:        { type: String, required: true },

  // Profile
  fullName:        { type: String, required: true, trim: true },
  email:           { type: String, default: '', trim: true },
  phone:           { type: String, default: '' },
  photo:           { type: String, default: '' },         // URL

  // Class assignment (class teacher)
  assignedClass:   { type: String, default: '' },         // "10", "LKG", etc.
  assignedSection: { type: String, default: 'A' },        // "A" or "B"

  // Subjects this teacher teaches (across classes)
  subjects:        [{ type: String }],

  // Link to Teacher display record (optional)
  teacherDocId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Teacher', default: null },

  // Meta
  role:            { type: String, default: 'teacher' },
  isActive:        { type: Boolean, default: true },
  lastLogin:       { type: Date, default: null },
}, { timestamps: true });

// Hash password before save
TeacherAccountSchema.pre('save', async function (next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  next();
});

TeacherAccountSchema.methods.comparePassword = function (plain) {
  return bcrypt.compare(plain, this.password);
};

TeacherAccountSchema.methods.toJSON = function () {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('TeacherAccount', TeacherAccountSchema);
