// =============================================================
//  Timetable.js — Mongoose Model
//  SCHOOL PORTAL v2.5.0
//  Stores daily period-wise timetable per class/section/day
// =============================================================
const mongoose = require('mongoose');

const PeriodSchema = new mongoose.Schema({
  periodNum:   { type: Number, required: true },   // 1,2,3...  0 = break
  startTime:   { type: String, required: true },   // "8:00"
  endTime:     { type: String, required: true },   // "8:30"
  subject:     { type: String, default: '' },      // "Mathematics"
  subjectIcon: { type: String, default: '📖' },
  teacher:     { type: String, default: '' },      // "Ashish Sir"
  isBreak:     { type: Boolean, default: false },
  breakLabel:  { type: String, default: '' },      // "Short Break", "Lunch Break"
}, { _id: false });

const TimetableSchema = new mongoose.Schema({
  class:        { type: String, required: true },  // "LKG","UKG","1"..."12"
  section:      { type: String, required: true, enum: ['A','B'] },
  day:          { type: String, required: true,
                  enum: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'] },
  academicYear: { type: String, default: '' },     // "2025-26"
  periods:      { type: [PeriodSchema], default: [] },
  updatedBy:    { type: String, default: 'admin' },
}, { timestamps: true });

// One timetable per class+section+day
TimetableSchema.index({ class: 1, section: 1, day: 1 }, { unique: true });

module.exports = mongoose.model('Timetable', TimetableSchema);
