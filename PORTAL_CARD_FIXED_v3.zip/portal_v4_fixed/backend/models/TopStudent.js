// =============================================================
//  TopStudent.js — Mongoose Model
//  SCHOOL PORTAL
//  Year-wise Top Students System
// =============================================================

const mongoose = require('mongoose');

const TopStudentSchema = new mongoose.Schema({
  year:          { type: String, required: true },       // "2025", "2026"
  classLabel:    { type: String, required: true },       // "Class 10", "Class 12"
  rank:          { type: Number, required: true },       // 1, 2, 3
  name:          { type: String, required: true },       // Student full name
  score:         { type: Number, default: 0 },           // Percentage e.g. 98.4
  subjects:      { type: String, default: '' },          // "Science Stream", "Commerce"
  house:         { type: String, default: '' },          // "Blue House", "Green House"
  image:         { type: String, default: '' },          // Cloudinary URL
  imagePublicId: { type: String, default: '' },          // Cloudinary public_id
  achievement:   { type: String, default: '' },          // "School Topper", "District Rank 3"
  isActive:      { type: Boolean, default: true },
}, { timestamps: true });

// Compound index for fast queries
TopStudentSchema.index({ year: 1, classLabel: 1, rank: 1 });

module.exports = mongoose.model('TopStudent', TopStudentSchema);
