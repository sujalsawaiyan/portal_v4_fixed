// =============================================================
//  models/TransportRoute.js — Transport Route & Stop Model
//  School Portal v2.6.0
// =============================================================

const mongoose = require('mongoose');

const StopSchema = new mongoose.Schema({
  stopName:    { type: String, required: true },
  distance_km: { type: Number, default: 0 },
  monthlyFee:  { type: Number, required: true },
  annualFee:   { type: Number, default: 0 },
}, { _id: false });

const TransportRouteSchema = new mongoose.Schema({
  routeNumber:  { type: String, required: true, unique: true },
  routeName:    { type: String, required: true },
  vehicleNo:    { type: String, default: '' },
  driverName:   { type: String, default: '' },
  driverPhone:  { type: String, default: '' },
  capacity:     { type: Number, default: 40 },
  academicYear: { type: String, required: true },
  stops:        [StopSchema],
  isActive:     { type: Boolean, default: true },
}, { timestamps: true });

TransportRouteSchema.pre('save', function(next) {
  this.stops.forEach(s => { s.annualFee = s.monthlyFee * 12; });
  next();
});

module.exports = mongoose.model('TransportRoute', TransportRouteSchema);
