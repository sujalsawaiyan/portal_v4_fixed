// =============================================================
//  WhatsappLog.js — Message Log Model v2.5.0
//  SCHOOL PORTAL
// =============================================================
const mongoose = require('mongoose');

const WhatsappLogSchema = new mongoose.Schema({
  studentId:    { type: String, default: '' },
  studentName:  { type: String, default: '' },
  studentClass: { type: String, default: '' },
  rollNumber:   { type: String, default: '' },
  parentPhone:  { type: String, required: true },
  messageType:  {
    type: String,
    enum: ['admission_approved', 'admission_rejected', 'fee_reminder', 'test', 'custom'],
    default: 'custom',
  },
  messageBody:  { type: String, default: '' },
  status:       { type: String, enum: ['sent', 'failed'], default: 'failed' },
  errorMessage: { type: String, default: '' },
  sentAt:       { type: Date, default: Date.now },
  sentBy:       { type: String, default: 'admin' },
  provider:     { type: String, default: 'meta' },   // 'meta' | 'twilio'
}, { timestamps: true });

WhatsappLogSchema.index({ sentAt: -1 });
WhatsappLogSchema.index({ messageType: 1 });
WhatsappLogSchema.index({ status: 1 });

module.exports = mongoose.model('WhatsappLog', WhatsappLogSchema);
