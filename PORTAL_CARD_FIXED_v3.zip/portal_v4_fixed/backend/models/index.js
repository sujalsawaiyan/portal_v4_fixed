// =============================================================
//  models/index.js — Shared/Inline Models
//  SCHOOL PORTAL v2.4.0
//
//  Models exported from here:
//    - Attendance  (one record per student per day)
//    - Fees        (fee records per student)
//    - Notice      (announcements/notice board)
//
//  NOTE: Result/Marks data uses the dedicated Marks.js model.
//  The old Result model here has been removed to avoid confusion.
//  See: backend/models/Marks.js for the active marks/results model.
// =============================================================
const mongoose = require('mongoose');

// ── ATTENDANCE ────────────────────────────────────────────────
// One record per student per day
// status: P = Present, A = Absent, L = Late
const AttendanceSchema = new mongoose.Schema({
  studentId:    { type: String, required: true, index: true },
  date:         { type: String, required: true },   // YYYY-MM-DD
  status:       { type: String, enum: ['P', 'A', 'L'], required: true },
  class:        { type: String, default: '' },
  section:      { type: String, default: '' },
  markedBy:     { type: String, default: 'admin' }, // username who marked it
  academicYear: { type: String, default: '' },       // e.g. "2025-26" (April-March)
}, { timestamps: true });

// Compound unique index: one attendance record per student per day
AttendanceSchema.index({ studentId: 1, date: 1 }, { unique: true });

// Performance indexes for class-level queries (daily/monthly/yearly views)
AttendanceSchema.index({ class: 1, section: 1, date: 1 });
AttendanceSchema.index({ class: 1, section: 1, academicYear: 1 });
AttendanceSchema.index({ studentId: 1, academicYear: 1 });
const Attendance = mongoose.model('Attendance', AttendanceSchema);


// ── FEES ──────────────────────────────────────────────────────
const FeesSchema = new mongoose.Schema({
  studentId:     { type: String, required: true, index: true },
  feeType:       { type: String, default: 'tuition' },
  amount:        { type: Number, required: true },
  status:        { type: String, enum: ['paid', 'pending', 'partial'], default: 'pending' },
  dueDate:       { type: String, default: '' },
  paidDate:      { type: String, default: '' },
  paymentMethod: { type: String, default: '' },
  transactionId: { type: String, default: '' }, // Razorpay payment_id
  academicYear:  { type: String, default: '' },  // e.g. "2025-26"
  term:          { type: String, default: 'Annual' },
  receiptNo:     { type: String, default: '' },
}, { timestamps: true });

const Fees = mongoose.model('Fees', FeesSchema);


// ── NOTICE / ANNOUNCEMENTS ───────────────────────────────────
const NoticeSchema = new mongoose.Schema({
  title:       { type: String, required: true, trim: true },
  body:        { type: String, required: true },
  category:    { type: String, default: 'General' },
  isPinned:    { type: Boolean, default: false },
  highlighted: { type: Boolean, default: false },
  targetRole:  { type: String, default: 'all' }, // all / student / parent
  imageUrl:    { type: String, default: '' },
  expiresAt:   { type: Date, default: null },
  createdBy:   { type: String, default: 'admin' },
}, { timestamps: true });

const Notice = mongoose.model('Notice', NoticeSchema);


module.exports = { Attendance, Fees, Notice, LedgerEntry: require('./LedgerEntry') };
