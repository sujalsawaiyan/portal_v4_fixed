// =============================================================
//  routes/adminData.js  — Data Management API (Admin Only)
//  Delete demo data, clear all fee payments, delete records
// =============================================================
const router = require('express').Router();
const { auth, adminOnly } = require('../middleware/auth');

// ── GET /api/admin-data/stats — count of each collection ─────
router.get('/stats', auth, adminOnly, async (req, res) => {
  try {
    const FeePayment = require('../models/FeePayment');
    const Student    = require('../models/Student');
    const Teacher    = require('../models/Teacher');

    const [payments, students, teachers] = await Promise.all([
      FeePayment.countDocuments(),
      Student.countDocuments(),
      Teacher.countDocuments(),
    ]);

    res.json({ payments, students, teachers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/admin-data/fee-payments — clear ALL payments ─
router.delete('/fee-payments', auth, adminOnly, async (req, res) => {
  try {
    const FeePayment = require('../models/FeePayment');
    const result = await FeePayment.deleteMany({});

    // Also clear ledger entries if model exists
    try {
      const LedgerEntry = require('../models/LedgerEntry');
      await LedgerEntry.deleteMany({});
    } catch (_) { /* optional */ }

    res.json({
      message: `All fee payment records deleted (${result.deletedCount} records).`,
      deletedCount: result.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/admin-data/demo-data — remove demo/dummy records ─
router.delete('/demo-data', auth, adminOnly, async (req, res) => {
  try {
    const FeePayment = require('../models/FeePayment');
    const Student    = require('../models/Student');
    const Teacher    = require('../models/Teacher');

    const summary = {};

    // 1. All fee payments (receipts RCP-2845 etc are demo)
    const fp = await FeePayment.deleteMany({});
    summary.feePayments = fp.deletedCount;

    // 2. Ledger entries
    try {
      const LedgerEntry = require('../models/LedgerEntry');
      const le = await LedgerEntry.deleteMany({});
      summary.ledgerEntries = le.deletedCount;
    } catch (_) { summary.ledgerEntries = 0; }

    // 3. Known demo student names
    const demoStudentNames = ['Rahul Sharma', 'Priya Gupta', 'Aman Khan'];
    const stuRes = await Student.deleteMany({ fullName: { $in: demoStudentNames } });
    summary.demoStudents = stuRes.deletedCount;

    // 4. Known demo teacher names
    const demoTeacherNames = [
      'Dr. Sarah Johnson', 'Mr. David Williams', 'Mrs. Priya Sharma',
      'Mr. Rahul Verma', 'Mrs. Anita Mehta', 'Mr. Suresh Kumar',
      'Mr. Anil Tiwari', 'Mrs. Deepa Singh',
    ];
    const tchRes = await Teacher.deleteMany({ name: { $in: demoTeacherNames } });
    summary.demoTeachers = tchRes.deletedCount;

    // 5. Demo events
    try {
      const Event = require('../models/Event');
      const demoEvents = ['Annual Sports Day', 'Parent-Teacher Meeting', 'Science Exhibition', 'Annual Day & Prize Giving'];
      const evtRes = await Event.deleteMany({ title: { $in: demoEvents } });
      summary.demoEvents = evtRes.deletedCount;
    } catch (_) { summary.demoEvents = 0; }

    // 6. Demo houses
    try {
      const House = require('../models/House');
      const demoHouses = ['Blue House', 'Green House', 'Red House', 'Yellow House'];
      const houseRes = await House.deleteMany({ name: { $in: demoHouses } });
      summary.demoHouses = houseRes.deletedCount;
    } catch (_) { summary.demoHouses = 0; }

    res.json({
      message: 'Demo data cleared. Admin accounts and School Settings are safe.',
      summary,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/admin-data/all-students — remove ALL students ─
router.delete('/all-students', auth, adminOnly, async (req, res) => {
  try {
    const Student    = require('../models/Student');
    const FeePayment = require('../models/FeePayment');
    const [stuRes, fpRes] = await Promise.all([
      Student.deleteMany({}),
      FeePayment.deleteMany({}),
    ]);
    res.json({
      message: `All students and their fee records deleted.`,
      students: stuRes.deletedCount,
      feePayments: fpRes.deletedCount,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
