// =============================================================
//  routes/admissions.js — Admission Applications API v3.0
//  Base path: /api/admissions
//  SCHOOL PORTAL — Enhanced Phone Validation + WhatsApp Status
// =============================================================
'use strict';

const router    = require('express').Router();
const Admission = require('../models/Admission');
const { auth, adminOnly } = require('../middleware/auth');
const {
  sendAdmissionApproved,
  sendAdmissionRejected,
} = require('../utils/whatsappService');

// ── Phone validation helper ───────────────────────────────────
function isValidPhone(phone) {
  const digits = String(phone || '').replace(/\D/g, '');
  return digits.length === 10;
}

// =============================================================
// GET /api/admissions — list all (admin)
// =============================================================
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const { status, page = 1, limit = 50 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    const total = await Admission.countDocuments(filter);
    const apps  = await Admission.find(filter)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.json({ data: apps, total, page: Number(page), limit: Number(limit) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/admissions/track/:appId — public status tracking
// =============================================================
router.get('/track/:appId', async (req, res) => {
  try {
    const app = await Admission.findOne({
      applicationId: req.params.appId.toUpperCase()
    }).select('-__v');

    if (!app) return res.status(404).json({ error: 'Application not found.' });

    res.json({
      data: {
        applicationId: app.applicationId,
        studentName:   app.studentName,
        applyingClass: app.applyingClass,
        section:       app.section,
        status:        app.status,
        createdAt:     app.createdAt,
        updatedAt:     app.updatedAt,
      }
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/admissions/check-phone/:phone — duplicate phone check
// PUBLIC — called from admission form before submitting
// =============================================================
router.get('/check-phone/:phone', async (req, res) => {
  try {
    const phone  = String(req.params.phone).replace(/\D/g, '');

    // Validate format first
    if (phone.length !== 10) {
      return res.status(400).json({ error: 'Phone must be exactly 10 digits.' });
    }

    const existing = await Admission.findOne({ phone });
    if (existing) {
      return res.json({
        duplicate: true,
        message:   `This phone number already has an application on record (ID: ${existing.applicationId}, Status: ${existing.status}).`,
        applicationId: existing.applicationId,
        status: existing.status,
      });
    }

    res.json({ duplicate: false });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/admissions — submit application (PUBLIC)
// =============================================================
router.post('/', async (req, res) => {
  try {
    const { studentName, applyingClass, phone, alternatePhone } = req.body;

    // Required fields check
    if (!studentName || !applyingClass || !phone) {
      return res.status(400).json({
        error: 'studentName, applyingClass, and phone are required.'
      });
    }

    // Phone format validation
    if (!isValidPhone(phone)) {
      return res.status(400).json({
        error: 'Parent phone number must be exactly 10 digits.'
      });
    }

    // Alternate phone validation (if provided)
    if (alternatePhone && !isValidPhone(alternatePhone)) {
      return res.status(400).json({
        error: 'Alternate phone number must be exactly 10 digits.'
      });
    }

    // Duplicate phone check
    const cleanPhone = String(phone).replace(/\D/g, '');
    const duplicate  = await Admission.findOne({ phone: cleanPhone });
    if (duplicate) {
      return res.status(409).json({
        error: `A record with this phone number already exists (Application ID: ${duplicate.applicationId}).`,
        applicationId: duplicate.applicationId,
        status: duplicate.status,
      });
    }

    const app = await Admission.create({
      studentName:      req.body.studentName,
      dateOfBirth:      req.body.dateOfBirth      || '',
      gender:           req.body.gender           || '',
      applyingClass:    req.body.applyingClass,
      section:          req.body.section          || '',
      previousSchool:   req.body.previousSchool   || '',
      previousClass:    req.body.previousClass     || '',
      previousMarks:    req.body.previousMarks     || '',
      previousBoard:    req.body.previousBoard     || '',
      reasonForJoining: req.body.reasonForJoining || '',
      howDidYouHear:    req.body.howDidYouHear     || '',
      specialNeeds:     req.body.specialNeeds      || '',
      fatherName:       req.body.fatherName        || '',
      motherName:       req.body.motherName        || '',
      phone:            cleanPhone,
      alternatePhone:   alternatePhone ? String(alternatePhone).replace(/\D/g, '') : '',
      email:            req.body.email             || '',
      address:          req.body.address           || '',
      annualIncome:     req.body.annualIncome       || '',
      session:          req.body.session           || `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`,
      status:           'pending',
    });

    res.status(201).json({
      message:       'Application submitted successfully.',
      applicationId: app.applicationId,
      data:          app,
    });
  } catch (err) {
    // Mongoose validation error
    if (err.name === 'ValidationError') {
      const msg = Object.values(err.errors).map(e => e.message).join(', ');
      return res.status(400).json({ error: msg });
    }
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// PUT /api/admissions/:id — update status/notes (admin)
// AUTO-TRIGGERS WhatsApp when status → approved or rejected
// =============================================================
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { status, notes } = req.body;
    const allowed = ['pending', 'approved', 'rejected', 'waitlisted'];

    if (status && !allowed.includes(status)) {
      return res.status(400).json({
        error: `status must be one of: ${allowed.join(', ')}`
      });
    }

    const updates = { updatedAt: new Date() };
    if (status)              updates.status = status;
    if (notes !== undefined) updates.notes  = notes;

    const app = await Admission.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!app) return res.status(404).json({ error: 'Application not found.' });

    // ── WhatsApp Notification (fire-and-forget) ────────────
    // Only send WhatsApp for 'approved' — rejection is silent
    if (status === 'approved' && app.phone) {
      const sentBy = req.user?.username || req.user?.name || 'admin';
      (async () => {
        try {
          const result = await sendAdmissionApproved({ admission: app, sentBy });

          // Update WhatsApp status in admission record
          const waStatus = result?.success ? 'sent' : 'failed';
          await Admission.findByIdAndUpdate(app._id, {
            whatsappStatus: waStatus,
            whatsappSentAt: new Date(),
            whatsappError:  result?.error || '',
          });

          console.log(`[Admissions] ✅ WhatsApp approved → ${waStatus} for: ${app.phone}`);
        } catch (e) {
          await Admission.findByIdAndUpdate(app._id, {
            whatsappStatus: 'failed',
            whatsappError:  e.message,
          }).catch(() => {});
          console.error('[Admissions] WhatsApp error:', e.message);
        }
      })();
    }

    res.json({ message: 'Application updated.', data: app });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// DELETE /api/admissions/:id (admin)
// =============================================================
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    await Admission.findByIdAndDelete(req.params.id);
    res.json({ message: 'Application deleted.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/admissions/:id/resend-whatsapp (admin)
// Manually re-send WhatsApp notification for an application
// =============================================================
router.post('/:id/resend-whatsapp', auth, adminOnly, async (req, res) => {
  try {
    const app    = await Admission.findById(req.params.id);
    if (!app) return res.status(404).json({ error: 'Application not found.' });

    if (!app.phone) {
      return res.status(400).json({ error: 'No phone number on this application.' });
    }

    if (!['approved', 'rejected'].includes(app.status)) {
      return res.status(400).json({
        error: 'Can only re-send notification for approved or rejected applications.'
      });
    }

    const sentBy = req.user?.username || 'admin';
    let result;

    if (app.status === 'approved') {
      result = await sendAdmissionApproved({ admission: app, sentBy });
    } else {
      result = await sendAdmissionRejected({ admission: app, reason: app.notes || '', sentBy });
    }

    const waStatus = result?.success ? 'sent' : 'failed';
    await Admission.findByIdAndUpdate(app._id, {
      whatsappStatus: waStatus,
      whatsappSentAt: new Date(),
      whatsappError:  result?.error || '',
    });

    res.json({
      message:        `WhatsApp notification ${waStatus}.`,
      whatsappStatus: waStatus,
      error:          result?.error || null,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
