// =============================================================
//  routes/announcements.js — Announcements CRUD API
//  Base path: /api/announcements
//  Uses existing Notice model from models/index.js
//  SCHOOL PORTAL
// =============================================================
const router = require('express').Router();
const { Notice } = require('../models/index');
const { auth, adminOnly } = require('../middleware/auth');

// ── GET /api/announcements — list (public) ───────────────────
router.get('/', async (req, res) => {
  try {
    const notices = await Notice.find({
      $or: [
        { expiresAt: null },
        { expiresAt: { $gte: new Date() } },
      ],
    }).sort({ isPinned: -1, createdAt: -1 }).limit(50);

    // Normalize to dashboard-expected format
    const data = notices.map(n => ({
      _id:        n._id,
      id:         n._id,
      title:      n.title,
      content:    n.body,
      body:       n.body,
      category:   n.category,
      date:       n.createdAt?.toISOString().slice(0, 10),
      publish_date:n.createdAt?.toISOString().slice(0, 10),
      is_pinned:  n.isPinned ? 1 : 0,
      pinned:     n.isPinned,
      highlighted:n.highlighted || false,
      expiresAt:  n.expiresAt,
      createdAt:  n.createdAt,
    }));

    res.json({ data, total: data.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/announcements — create (admin) ─────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      title, body, content, category,
      is_pinned, pinned, expire_date, expiresAt, highlighted,
    } = req.body;

    if (!title)            return res.status(400).json({ error: 'title is required.' });
    if (!body && !content) return res.status(400).json({ error: 'body/content is required.' });

    const notice = await Notice.create({
      title:     title.trim(),
      body:      (body || content).trim(),
      category:  category || 'General',
      isPinned:  !!(is_pinned || pinned),
      highlighted: !!highlighted,
      expiresAt: expiresAt || expire_date || null,
      createdBy: req.user?.username || 'admin',
    });

    res.status(201).json({
      message: 'Announcement posted.',
      data: {
        _id:        notice._id,
        id:         notice._id,
        title:      notice.title,
        content:    notice.body,
        body:       notice.body,
        category:   notice.category,
        date:       notice.createdAt.toISOString().slice(0, 10),
        is_pinned:  notice.isPinned ? 1 : 0,
        highlighted:notice.highlighted,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/announcements/:id — update (admin) ──────────────
// ══════════════════════════════════════════════════
//  PUT /bulk/replace — MUST BE BEFORE /:id
//  (Express would match "bulk" as :id otherwise)
// ══════════════════════════════════════════════════
router.put('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { announcements, force } = req.body;
    if (!Array.isArray(announcements)) {
      return res.status(400).json({ error: 'announcements array required.' });
    }
    if (announcements.length === 0) {
      const existingCount = await Notice.countDocuments({});
      if (existingCount > 0 && !force) {
        return res.status(400).json({ error: `Safety guard: cannot replace ${existingCount} announcements with empty list. Pass force:true to confirm.`, existingCount });
      }
    }
    await Notice.deleteMany({});
    if (announcements.length) {
      const docs = announcements.map(a => ({
        title:      a.title || '',
        body:       a.body || a.content || '',
        category:   a.category || 'General',
        isPinned:   !!(a.is_pinned || a.pinned),
        highlighted: !!a.highlighted,
        createdBy:  'admin',
      }));
      await Notice.insertMany(docs);
    }
    const all = await Notice.find().sort({ isPinned: -1, createdAt: -1 });
    res.json({ message: 'Announcements replaced.', total: all.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const {
      title, body, content, category,
      is_pinned, pinned, expiresAt, highlighted,
    } = req.body;

    const updates = {};
    if (title !== undefined)              updates.title      = title.trim();
    if ((body || content) !== undefined)  updates.body       = (body || content).trim();
    if (category !== undefined)           updates.category   = category;
    if ((is_pinned || pinned) !== undefined) updates.isPinned = !!(is_pinned || pinned);
    if (highlighted !== undefined)        updates.highlighted = !!highlighted;
    if (expiresAt !== undefined)          updates.expiresAt  = expiresAt || null;

    const notice = await Notice.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!notice) return res.status(404).json({ error: 'Announcement not found.' });
    res.json({ message: 'Announcement updated.', data: notice });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/announcements/:id (admin) ────────────────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const notice = await Notice.findByIdAndDelete(req.params.id);
    if (!notice) return res.status(404).json({ error: 'Announcement not found.' });
    res.json({ message: 'Announcement deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/announcements/bulk/replace — replace all ────────

module.exports = router;
