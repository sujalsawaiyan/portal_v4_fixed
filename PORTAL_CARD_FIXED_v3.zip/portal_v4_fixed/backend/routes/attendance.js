// =============================================================
//  routes/attendance.js — Yearly Attendance System
//  SCHOOL PORTAL
// =============================================================
const router     = require('express').Router();
const { Attendance } = require('../models/index');
const Student    = require('../models/Student');
const { auth, adminOnly } = require('../middleware/auth');

// ── helpers ──────────────────────────────────────────────────
function calcPct(present, late, total) {
  if (!total) return 0;
  return Math.round((present + late) / total * 100);
}
function monthKey(dateStr) { return dateStr.slice(0, 7); }
function academicYear(dateStr) {
  const d = new Date(dateStr);
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  return m >= 4 ? `${y}-${String(y+1).slice(-2)}` : `${y-1}-${String(y).slice(-2)}`;
}

// Month index in academic year (Apr=0 ... Mar=11)
const MONTH_NAMES = ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'];
function academicMonthIndex(yyyymm) {
  const m = parseInt(yyyymm.slice(5,7)); // 1-12
  return m >= 4 ? m - 4 : m + 8; // Apr=0, Mar=11
}

// ── POST /api/attendance/mark ─────────────────────────────────
router.post('/mark', auth, adminOnly, async (req, res) => {
  try {
    const { studentId, date, status, records, class: cls, section } = req.body;

    if (records && Array.isArray(records)) {
      const ops = records.map(r => ({
        updateOne: {
          filter: { studentId: r.studentId.toUpperCase(), date: r.date },
          update: {
            $set: {
              status:       r.status,
              class:        r.class   || cls || '',
              section:      r.section || section || '',
              markedBy:     req.user.username || 'admin',
              academicYear: academicYear(r.date),
            }
          },
          upsert: true,
        }
      }));
      const result = await Attendance.bulkWrite(ops);
      return res.json({
        message: `${result.upsertedCount + result.modifiedCount} records saved.`,
        saved:   result.upsertedCount + result.modifiedCount,
      });
    }

    if (!studentId || !date || !status) {
      return res.status(400).json({ error: 'studentId, date, status required.' });
    }
    await Attendance.findOneAndUpdate(
      { studentId: studentId.toUpperCase(), date },
      { status, class: cls || '', section: section || '',
        markedBy: req.user.username || 'admin',
        academicYear: academicYear(date) },
      { upsert: true, new: true }
    );
    res.json({ message: 'Attendance marked.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/attendance/class/:cls/:sec/:date ─────────────────
// PUBLIC — No auth needed for frontend display
router.get('/class/:cls/:sec/:date', async (req, res) => {
  try {
    const { cls, sec, date } = req.params;
    const records = await Attendance.find({ class: cls, section: sec, date });
    const map = {};
    records.forEach(r => { map[r.studentId] = r.status; });
    res.json({ data: records, map, date, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/attendance/class/:cls/:sec/monthly ───────────────
// ?month=2025-08  — PUBLIC — No auth for frontend display
router.get('/class/:cls/:sec/monthly', async (req, res) => {
  try {
    const { cls, sec } = req.params;
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const [yr, mo] = month.split('-').map(Number);
    const start = `${month}-01`;
    // Compute actual last day of the month (handles Feb, 30-day months)
    const lastDay = new Date(yr, mo, 0).getDate();
    const end   = `${month}-${String(lastDay).padStart(2, '0')}`;

    const records = await Attendance.find({
      class: cls, section: sec,
      date: { $gte: start, $lte: end },
    }).lean();

    // Group by studentId
    const byStudent = {};
    records.forEach(r => {
      if (!byStudent[r.studentId]) byStudent[r.studentId] = { present:0, absent:0, late:0, total:0 };
      byStudent[r.studentId].total++;
      if (r.status === 'P') byStudent[r.studentId].present++;
      else if (r.status === 'A') byStudent[r.studentId].absent++;
      else if (r.status === 'L') byStudent[r.studentId].late++;
    });

    // Fetch student names + rolls from DB
    const studentIds = Object.keys(byStudent);
    let dbStudents = [];
    if (studentIds.length) {
      dbStudents = await Student.find(
        { studentId: { $in: studentIds } },
        { studentId:1, fullName:1, rollNumber:1 }
      ).lean();
    }
    const nameMap = {};
    dbStudents.forEach(s => { nameMap[s.studentId] = { name: s.fullName, roll: s.rollNumber }; });

    // Build students array
    const students = studentIds.map(sid => {
      const s   = byStudent[sid];
      const inf = nameMap[sid] || {};
      return {
        studentId:  sid,
        name:       inf.name || sid,
        roll:       inf.roll || '',
        present:    s.present,
        absent:     s.absent,
        late:       s.late,
        totalDays:  s.total,
        percentage: calcPct(s.present, s.late, s.total),
      };
    }).sort((a,b) => {
      const na = parseInt((a.roll||'').replace(/\D/g,''))||0;
      const nb = parseInt((b.roll||'').replace(/\D/g,''))||0;
      return na - nb;
    });

    // Return raw records for calendar heatmap
    res.json({ students, records, month, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/attendance/class/:cls/:sec/yearly ────────────────
// ?year=2025-26 — PUBLIC — No auth for frontend display
router.get('/class/:cls/:sec/yearly', async (req, res) => {
  try {
    const { cls, sec } = req.params;
    const year = req.query.year || academicYear(new Date().toISOString().slice(0,10));

    const records = await Attendance.find({ class: cls, section: sec, academicYear: year }).lean();

    // Per-student summary
    const byStudent = {};
    records.forEach(r => {
      if (!byStudent[r.studentId]) byStudent[r.studentId] = { present:0, absent:0, late:0, total:0 };
      byStudent[r.studentId].total++;
      if (r.status === 'P') byStudent[r.studentId].present++;
      else if (r.status === 'A') byStudent[r.studentId].absent++;
      else if (r.status === 'L') byStudent[r.studentId].late++;
    });

    // Month-wise aggregate (Apr–Mar)
    const byMonth = {}; // key: "YYYY-MM"
    records.forEach(r => {
      const mk = monthKey(r.date);
      if (!byMonth[mk]) byMonth[mk] = { present:0, absent:0, late:0, total:0, dates: new Set() };
      byMonth[mk].total++;
      byMonth[mk].dates.add(r.date);
      if (r.status === 'P') byMonth[mk].present++;
      else if (r.status === 'A') byMonth[mk].absent++;
      else if (r.status === 'L') byMonth[mk].late++;
    });

    // Build months array in academic year order (Apr to Mar)
    const months = MONTH_NAMES.map((mn, idx) => {
      // Find the YYYY-MM key for this month in this academic year
      const startYr = parseInt(year.slice(0,4));
      const calMonth = idx < 9 ? startYr : startYr + 1; // Apr-Dec = startYr, Jan-Mar = startYr+1
      const calMIdx  = idx < 9 ? idx + 4 : idx - 8;     // Apr=4,...Dec=12,Jan=1,..Mar=3
      const key = `${calMonth}-${String(calMIdx).padStart(2,'0')}`;
      const m   = byMonth[key] || null;
      return {
        month:       mn,
        monthKey:    key,
        monthIndex:  idx,
        workingDays: m ? m.dates.size : 0,
        present:     m ? m.present : 0,
        absent:      m ? m.absent : 0,
        late:        m ? m.late : 0,
        total:       m ? m.total : 0,
        percentage:  m ? calcPct(m.present, m.late, m.total) : null,
        hasData:     !!m,
      };
    });

    // Fetch student names
    const studentIds = Object.keys(byStudent);
    let dbStudents = [];
    if (studentIds.length) {
      dbStudents = await Student.find(
        { studentId: { $in: studentIds } },
        { studentId:1, fullName:1, rollNumber:1 }
      ).lean();
    }
    const nameMap = {};
    dbStudents.forEach(s => { nameMap[s.studentId] = { name: s.fullName, roll: s.rollNumber }; });

    const students = studentIds.map(sid => {
      const s   = byStudent[sid];
      const inf = nameMap[sid] || {};
      return {
        studentId:  sid,
        name:       inf.name || sid,
        roll:       inf.roll || '',
        present:    s.present,
        absent:     s.absent,
        late:       s.late,
        totalDays:  s.total,
        percentage: calcPct(s.present, s.late, s.total),
      };
    }).sort((a,b) => {
      const na = parseInt((a.roll||'').replace(/\D/g,''))||0;
      const nb = parseInt((b.roll||'').replace(/\D/g,''))||0;
      return na - nb;
    });

    res.json({ students, months, year, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/attendance/:studentId ───────────────────────────
router.get('/:studentId', auth, async (req, res) => {
  try {
    if (req.user.role === 'student' && req.user.studentId !== req.params.studentId.toUpperCase()) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    const records = await Attendance.find({ studentId: req.params.studentId.toUpperCase() })
      .sort({ date: -1 });

    const total   = records.length;
    const present = records.filter(r => r.status === 'P').length;
    const absent  = records.filter(r => r.status === 'A').length;
    const late    = records.filter(r => r.status === 'L').length;
    const pct     = calcPct(present, late, total);

    const monthly = {};
    records.forEach(r => {
      const mk = monthKey(r.date);
      if (!monthly[mk]) monthly[mk] = { month: mk, present:0, absent:0, late:0, total:0 };
      monthly[mk].total++;
      if (r.status === 'P') monthly[mk].present++;
      else if (r.status === 'A') monthly[mk].absent++;
      else if (r.status === 'L') monthly[mk].late++;
    });
    Object.values(monthly).forEach(m => { m.percentage = calcPct(m.present, m.late, m.total); });

    const yearly = {};
    records.forEach(r => {
      const ay = r.academicYear || academicYear(r.date);
      if (!yearly[ay]) yearly[ay] = { year: ay, present:0, absent:0, late:0, total:0 };
      yearly[ay].total++;
      if (r.status === 'P') yearly[ay].present++;
      else if (r.status === 'A') yearly[ay].absent++;
      else if (r.status === 'L') yearly[ay].late++;
    });
    Object.values(yearly).forEach(y => { y.percentage = calcPct(y.present, y.late, y.total); });

    res.json({
      data:    records,
      summary: { total, present, absent, late, percentage: pct },
      monthly: Object.values(monthly).sort((a,b) => b.month.localeCompare(a.month)),
      yearly:  Object.values(yearly).sort((a,b) => b.year.localeCompare(a.year)),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
