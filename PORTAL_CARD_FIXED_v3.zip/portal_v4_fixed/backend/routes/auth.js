const router  = require('express').Router();
const jwt     = require('jsonwebtoken');
const bcrypt  = require('bcryptjs');
const Student = require('../models/Student');
const User    = require('../models/User');
const { JWT_SECRET, auth, adminOnly } = require('../middleware/auth');

const JWT_EXPIRES = process.env.JWT_EXPIRES || '8h';

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { studentId, password, role } = req.body;
    if (!studentId || !password || !role)
      return res.status(400).json({ error: 'studentId, password and role are required.' });

    let user = null, tokenData = null;

    if (role === 'admin') {
      const admin = await User.findOne({ username: studentId, role: 'admin', isActive: true });
      if (!admin) return res.status(401).json({ error: 'Invalid admin credentials.' });
      const valid = await admin.comparePassword(password);
      if (!valid) return res.status(401).json({ error: 'Invalid admin credentials.' });
      tokenData = { id: admin._id, username: admin.username, role: 'admin', fullName: admin.fullName };
      user = { id: admin._id, username: admin.username, fullName: admin.fullName, role: 'admin' };

    } else if (role === 'student') {
      let student;
      const { className, section: sec, rollNumber } = req.body;

      if (className) {
        // ── New: lookup by Class + Section + Roll Number ──────────
        // password = rollNumber + section (e.g. "05A")
        const lookupSection = (sec || password.slice(-1)).toUpperCase();
        const lookupRoll    = rollNumber || password.slice(0, -1);
        student = await Student.findOne({
          class:      className,
          section:    lookupSection,
          rollNumber: lookupRoll,
          isActive:   true,
        });
        if (!student) return res.status(401).json({ error: 'Student not found. Class, Section ya Roll Number check karein.' });
      } else {
        // ── Legacy: lookup by Student ID ──────────────────────────
        student = await Student.findOne({ studentId: studentId.toUpperCase(), isActive: true });
        if (!student) return res.status(401).json({ error: 'Student ID not found.' });
      }

      const valid = await student.comparePassword(password);
      if (!valid) return res.status(401).json({ error: 'Incorrect password. Default password = Roll Number + Section (e.g. 05A).' });
      tokenData = { id: student._id, studentId: student.studentId, role: 'student', fullName: student.fullName, class: student.class, section: student.section };
      user = student.toJSON();

    } else if (role === 'parent') {
      const parent = await User.findOne({ studentId: studentId.toUpperCase(), role: 'parent', isActive: true });
      if (!parent) return res.status(401).json({ error: 'Parent account not found for this Student ID.' });
      const valid = await parent.comparePassword(password);
      if (!valid) return res.status(401).json({ error: 'Incorrect password.' });
      const student = await Student.findOne({ studentId: studentId.toUpperCase() });
      tokenData = { id: parent._id, studentId: studentId.toUpperCase(), role: 'parent', fullName: parent.fullName, class: student ? student.class : '', section: student ? student.section : '' };
      user = { ...parent.toJSON(), student: student ? student.toJSON() : null };
    } else {
      return res.status(400).json({ error: 'Invalid role.' });
    }

    const token = jwt.sign(tokenData, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    res.json({ token, user, role });
  } catch (err) {
    console.error('[Auth] login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// POST /api/auth/change-password  (auth required)
router.post('/change-password', auth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword)
      return res.status(400).json({ error: 'Both passwords required.' });
    if (newPassword.length < 6)
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });

    let account;
    if (req.user.role === 'admin' || req.user.role === 'parent')
      account = await User.findById(req.user.id);
    else
      account = await Student.findById(req.user.id);

    if (!account) return res.status(404).json({ error: 'Account not found.' });
    const valid = await account.comparePassword(currentPassword);
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect.' });
    account.password = newPassword;
    await account.save();
    res.json({ message: 'Password changed successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// POST /api/auth/change-username  (admin only)
router.post('/change-username', auth, adminOnly, async (req, res) => {
  try {
    const { newUsername, currentPassword } = req.body;
    if (!newUsername || !currentPassword)
      return res.status(400).json({ error: 'newUsername and currentPassword required.' });
    const clean = newUsername.trim().toLowerCase();
    if (clean.length < 3)
      return res.status(400).json({ error: 'Username must be at least 3 characters.' });

    const admin = await User.findById(req.user.id);
    if (!admin) return res.status(404).json({ error: 'Account not found.' });
    const valid = await admin.comparePassword(currentPassword);
    if (!valid) return res.status(400).json({ error: 'Current password is incorrect.' });

    const exists = await User.findOne({ username: clean, _id: { $ne: admin._id } });
    if (exists) return res.status(409).json({ error: 'Username already taken.' });

    admin.username = clean;
    await admin.save();

    const tokenData = { id: admin._id, username: admin.username, role: 'admin', fullName: admin.fullName };
    const token = jwt.sign(tokenData, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    res.json({ message: 'Username changed.', token, username: admin.username });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});

// GET /api/auth/me
router.get('/me', auth, async (req, res) => {
  try {
    let account;
    if (req.user.role === 'student')
      account = await Student.findById(req.user.id);
    else
      account = await User.findById(req.user.id);
    if (!account) return res.status(404).json({ error: 'Account not found.' });
    res.json({ user: account, role: req.user.role });
  } catch (err) {
    res.status(500).json({ error: 'Server error.' });
  }
});


// ═══════════════════════════════════════════════════════════════
// POST /api/auth/parent-login
// 4-field lookup: className + section + rollNumber + studentId
// No password required — studentId is the unique secret key
// ═══════════════════════════════════════════════════════════════
router.post('/parent-login', async (req, res) => {
  try {
    const { className, section, rollNumber, studentId, loginType, guardianPhone } = req.body;

    // Validate required fields
    if (!className || !section || !rollNumber || !studentId) {
      return res.status(400).json({
        error: 'Class, Section, Roll Number aur School ID — sab required hain.'
      });
    }
    if (loginType === 'parent' && !guardianPhone) {
      return res.status(400).json({
        error: 'Parent ka registered mobile number required hai.'
      });
    }

    const cleanSection   = section.trim().toUpperCase();
    const cleanClass     = className.trim();
    const cleanRoll      = rollNumber.trim();
    const cleanStudentId = studentId.trim().toUpperCase();
    const cleanPhone     = loginType === 'parent'
      ? String(guardianPhone || '').replace(/\D/g, '').slice(-10)
      : null;

    // Lookup student by all 4 fields
    const student = await Student.findOne({
      studentId:  cleanStudentId,
      class:      cleanClass,
      section:    cleanSection,
      isActive:   { $ne: false },
    });

    if (!student) {
      return res.status(401).json({
        error: 'Student nahi mila. Class, Section, Roll Number aur School ID check karein.'
      });
    }

    // Verify roll number matches (case-insensitive, strip leading zeros)
    const dbRoll    = String(student.rollNumber || '').replace(/^0+/, '');
    const inputRoll = cleanRoll.replace(/^0+/, '');
    if (dbRoll !== inputRoll) {
      return res.status(401).json({
        error: 'Roll Number galat hai. School se confirm karein.'
      });
    }

    // ── Phone verification (parent only) ─────────────────────────
    if (loginType === 'parent') {
      const dbPhone = String(student.guardianPhone || '').replace(/\D/g, '').slice(-10);
      if (!dbPhone) {
        return res.status(401).json({
          error: 'Is student ka parent phone number register nahi hai. School admin se contact karein.'
        });
      }
      if (dbPhone !== cleanPhone) {
        return res.status(401).json({
          error: 'Parent mobile number galat hai. School mein registered number use karein.'
        });
      }
    }

    // Build JWT token
    const tokenData = {
      id:        student._id,
      studentId: student.studentId,
      role:      'student',
      fullName:  student.fullName,
      class:     student.class,
      section:   student.section,
    };
    const token = jwt.sign(tokenData, JWT_SECRET, { expiresIn: JWT_EXPIRES });

    return res.json({
      success:  true,
      token,
      student:  student.toJSON(),
      loginType: loginType || 'parent',
    });

  } catch (err) {
    console.error('[Auth] parent-login error:', err);
    res.status(500).json({ error: 'Server error. Thodi der baad try karein.' });
  }
});

module.exports = router;
