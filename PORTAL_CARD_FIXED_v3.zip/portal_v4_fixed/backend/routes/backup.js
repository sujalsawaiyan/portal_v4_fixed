// =============================================================
//  routes/backup.js — Backup & Restore API  v3.0.0
//  Base path: /api/backup
//  SCHOOL PORTAL — Production Ready
//
//  Routes:
//    GET  /api/backup/export              — Download full DB backup as JSON
//    POST /api/backup/import              — Restore DB from uploaded JSON
//    GET  /api/backup/list                — List server-saved backup files
//    POST /api/backup/auto-save           — Save backup to /backups/ folder
//    POST /api/backup/restore-server/:fn  — Restore from a server-saved file
//    DELETE /api/backup/delete/:fn        — Delete a server-saved backup
//    GET  /api/backup/verify              — Quick integrity check of current DB
//
//  Restore Modes (via req.body.mode):
//    "full"  — Delete existing -> insert backup (default, exact mirror)
//    "merge" — Upsert by _id (preserves new data, adds missing)
//
//  IMPORTANT: Backup covers MongoDB data ONLY.
//  Uploaded images/files stored on disk or Cloudinary are NOT included.
// =============================================================

'use strict';

const router  = require('express').Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');

// ── Auth middleware ──────────────────────────────────────────
const { auth, adminOnly } = require('../middleware/auth');

// ── Models ───────────────────────────────────────────────────
const Student        = require('../models/Student');
const Teacher        = require('../models/Teacher');
const TeacherAccount = require('../models/TeacherAccount');
const Gallery        = require('../models/Gallery');
const House          = require('../models/House');
const Class          = require('../models/Class');
const Admission      = require('../models/Admission');
const TopStudent     = require('../models/TopStudent');
const Marks          = require('../models/Marks');
const Discipline     = require('../models/Discipline');
const SchoolSettings = require('../models/SchoolSettings');
const User           = require('../models/User');
const FeePayment     = require('../models/FeePayment');
const FeeStructure   = require('../models/FeeStructure');
const FeeDiscount    = require('../models/FeeDiscount');
const { Visitor, SecurityAlert } = require('../models/Security');
const { Attendance, Fees, Notice, LedgerEntry } = require('../models/index');

// ── Previously MISSING models — now added ─────────────────────
const ClassSubjects       = require('../models/ClassSubjects');
const FineRule            = require('../models/FineRule');
const InstallmentSchedule = require('../models/InstallmentSchedule');
const {
  SchoolImage, GalleryItem, TeacherPhoto,
  EventImage, TopStudentImage, HouseImage,
} = require('../models/SchoolImages');

// Optional models — loaded safely
let EventModel  = null;
let WhatsappLog = null;
try { EventModel  = require('../models/Event');       } catch(_) { console.warn('[Backup] Event model not found'); }
try { WhatsappLog = require('../models/WhatsappLog'); } catch(_) { console.warn('[Backup] WhatsappLog model not found'); }

// ── Backups directory ─────────────────────────────────────────
const BACKUPS_DIR = path.join(__dirname, '../../backups');
if (!fs.existsSync(BACKUPS_DIR)) {
  fs.mkdirSync(BACKUPS_DIR, { recursive: true });
}

// ── Multer (memory storage) ───────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 200 * 1024 * 1024 },
  fileFilter(_req, file, cb) {
    const ok = file.mimetype === 'application/json' ||
               file.mimetype === 'text/plain' ||
               file.originalname.toLowerCase().endsWith('.json');
    if (!ok) return cb(new Error('Only .json backup files are allowed.'), false);
    cb(null, true);
  },
});

const BACKUP_VERSION = '3.0';

// ── Helpers ──────────────────────────────────────────────────
function dateTag(d = new Date()) { return d.toISOString().slice(0, 10); }
function fullDateTag(d = new Date()) {
  return d.toISOString().slice(0, 10) + '_' + d.toTimeString().slice(0, 8).replace(/:/g, '');
}
function safeFilename(name) {
  return path.basename(name).replace(/[^a-zA-Z0-9._\-]/g, '_');
}
async function getSchoolName() {
  try {
    const s = await SchoolSettings.findOne({ key: 'schoolInfo' }).lean();
    if (s && s.value) return s.value.schoolName || s.value.name || 'School Portal';
  } catch(_) {}
  return process.env.SCHOOL_NAME || 'School Portal';
}

// ── Collection map — order matters for restore (parents first) ─
function getCollectionMap() {
  const map = [
    // ── Core auth & config ─────────────────────────────────────
    { key: 'users',               model: User,               label: 'Users'               },
    { key: 'schoolSettings',      model: SchoolSettings,     label: 'SchoolSettings'      },

    // ── Academic structure ────────────────────────────────────
    { key: 'classes',             model: Class,              label: 'Classes'             },
    { key: 'classSubjects',       model: ClassSubjects,      label: 'ClassSubjects'       },  // ✅ was missing
    { key: 'houses',              model: House,              label: 'Houses'              },

    // ── People ────────────────────────────────────────────────
    { key: 'students',            model: Student,            label: 'Students'            },
    { key: 'teachers',            model: Teacher,            label: 'Teachers'            },
    { key: 'teacherAccounts',     model: TeacherAccount,     label: 'TeacherAccounts'     },

    // ── Academic records ──────────────────────────────────────
    { key: 'marks',               model: Marks,              label: 'Marks/Results'       },
    { key: 'discipline',          model: Discipline,         label: 'Discipline'          },
    { key: 'attendance',          model: Attendance,         label: 'Attendance'          },
    { key: 'topStudents',         model: TopStudent,         label: 'TopStudents'         },

    // ── Fee system ────────────────────────────────────────────
    { key: 'fees',                model: Fees,               label: 'Fees'                },
    { key: 'feePayments',         model: FeePayment,         label: 'FeePayments'         },
    { key: 'feeStructures',       model: FeeStructure,       label: 'FeeStructures'       },
    { key: 'feeDiscounts',        model: FeeDiscount,        label: 'FeeDiscounts'        },
    { key: 'fineRules',           model: FineRule,           label: 'FineRules'           },  // ✅ was missing
    { key: 'installmentSchedules',model: InstallmentSchedule,label: 'InstallmentSchedules'}, // ✅ was missing
    { key: 'ledgerEntries',       model: LedgerEntry,        label: 'LedgerEntries'       },  // ✅ was missing

    // ── Events & communication ────────────────────────────────
    { key: 'events',              model: EventModel,         label: 'Events'              },
    { key: 'announcements',       model: Notice,             label: 'Announcements'       },

    // ── Media / Images (Cloudinary URLs stored in MongoDB) ────
    { key: 'gallery',             model: Gallery,            label: 'Gallery'             },
    { key: 'schoolImages',        model: SchoolImage,        label: 'SchoolImages'        },  // ✅ was missing
    { key: 'galleryItems',        model: GalleryItem,        label: 'GalleryItems'        },  // ✅ was missing
    { key: 'teacherPhotos',       model: TeacherPhoto,       label: 'TeacherPhotos'       },  // ✅ was missing
    { key: 'eventImages',         model: EventImage,         label: 'EventImages'         },  // ✅ was missing
    { key: 'topStudentImages',    model: TopStudentImage,    label: 'TopStudentImages'    },  // ✅ was missing
    { key: 'houseImages',         model: HouseImage,         label: 'HouseImages'         },  // ✅ was missing

    // ── Admissions ────────────────────────────────────────────
    { key: 'admissions',          model: Admission,          label: 'Admissions'          },

    // ── Security & logs ───────────────────────────────────────
    { key: 'visitors',            model: Visitor,            label: 'Visitors'            },
    { key: 'securityAlerts',      model: SecurityAlert,      label: 'SecurityAlerts'      },
  ];
  if (WhatsappLog) map.push({ key: 'whatsappLogs', model: WhatsappLog, label: 'WhatsappLogs' });
  return map.filter(e => e.model !== null && e.model !== undefined);
}

async function safeFetch(model, label) {
  if (!model) return [];
  try { return await model.find({}).lean(); }
  catch(e) { console.error('[Backup] Fetch failed:', label, e.message); return []; }
}

async function fetchAllCollections() {
  const map = getCollectionMap();
  const results = await Promise.all(map.map(({ model, label }) => safeFetch(model, label)));
  const collections = {};
  map.forEach(({ key }, i) => { collections[key] = results[i]; });
  return collections;
}

async function buildBackupPayload() {
  const [collections, school] = await Promise.all([fetchAllCollections(), getSchoolName()]);
  const stats = {};
  let totalRecords = 0;
  Object.entries(collections).forEach(([k, v]) => {
    stats[k] = Array.isArray(v) ? v.length : 0;
    totalRecords += stats[k];
  });
  return { version: BACKUP_VERSION, exportedAt: new Date().toISOString(), school, totalRecords, stats, collections };
}

// ── Core restore logic (shared by /import and /restore-server) ─
async function runRestore(collections, mode) {
  const map      = getCollectionMap();
  const restored = {};
  const errors   = [];

  for (const { key, model, label } of map) {
    const docs = collections[key];
    if (!Array.isArray(docs) || docs.length === 0) { restored[key] = 0; continue; }

    const clean = docs.map(doc => { const d = { ...doc }; delete d.__v; return d; });

    try {
      if (mode === 'merge') {
        // Upsert by _id in batches of 200
        let count = 0;
        for (let i = 0; i < clean.length; i += 200) {
          const ops = clean.slice(i, i + 200).map(doc => ({
            replaceOne: { filter: { _id: doc._id }, replacement: doc, upsert: true },
          }));
          const r = await model.bulkWrite(ops, { ordered: false });
          count += (r.upsertedCount || 0) + (r.modifiedCount || 0);
        }
        restored[key] = count;
      } else {
        // Full restore: wipe then insert
        await model.deleteMany({});
        const result = await model.insertMany(clean, { ordered: false });
        restored[key] = result.length;
      }
    } catch (err) {
      const partial = err.result ? (err.result.nInserted || err.insertedCount || 0) : 0;
      console.error(`[Backup] Restore error for ${label}:`, err.message);
      errors.push(`${label}: ${err.message.slice(0, 150)}`);
      restored[key] = partial;
    }
  }

  return { restored, errors };
}


// =============================================================
//  GET /api/backup/export  —  Download full DB as JSON
// =============================================================
router.get('/export', auth, adminOnly, async (req, res) => {
  try {
    console.log('[Backup] Export started by:', req.user.username);
    const payload  = await buildBackupPayload();
    const filename = `school-backup-${dateTag()}.json`;
    const jsonStr  = JSON.stringify(payload, null, 2);
    const byteLen  = Buffer.byteLength(jsonStr, 'utf8');
    console.log(`[Backup] Export: ${payload.totalRecords} records, ${Math.round(byteLen/1024)} KB`);
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', byteLen);
    res.send(jsonStr);
  } catch (err) {
    console.error('[Backup] Export error:', err);
    res.status(500).json({ error: 'Backup export failed: ' + err.message });
  }
});


// =============================================================
//  POST /api/backup/import  —  Restore from uploaded JSON file
//  Form fields: backup (file), mode (text: "full"|"merge")
// =============================================================
router.post('/import', auth, adminOnly, upload.single('backup'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No backup file uploaded. Expected multipart field name: backup' });

  let data;
  try { data = JSON.parse(req.file.buffer.toString('utf8')); }
  catch(_) { return res.status(400).json({ error: 'Invalid JSON — backup file is corrupt or not a valid JSON file.' }); }

  if (!data.version || !data.collections || typeof data.collections !== 'object') {
    return res.status(400).json({ error: 'Invalid backup format. File must contain "version" and "collections". This may not be a School Portal backup.' });
  }

  const mode = (req.body && req.body.mode === 'merge') ? 'merge' : 'full';
  console.log(`[Backup] Import — version: ${data.version}, mode: ${mode}, by: ${req.user.username}`);

  const { restored, errors } = await runRestore(data.collections, mode);
  const totalRestored = Object.values(restored).reduce((a, b) => a + b, 0);
  console.log(`[Backup] Import complete — ${totalRestored} records, ${errors.length} errors`);

  const response = {
    success: errors.length === 0,
    message: errors.length === 0
      ? `Database ${mode === 'merge' ? 'merged' : 'restored'} successfully. ${totalRestored} records.`
      : `Restore completed with ${errors.length} error(s). Most data was restored.`,
    mode, restoredAt: new Date().toISOString(),
    backupVersion: data.version, backupDate: data.exportedAt || null,
    school: data.school || null, totalRestored, restored,
  };
  if (errors.length > 0) response.errors = errors;
  res.status(errors.length > 0 ? 207 : 200).json(response);
});


// =============================================================
//  GET /api/backup/list  —  List server-saved backup files
// =============================================================
router.get('/list', auth, adminOnly, (req, res) => {
  try {
    if (!fs.existsSync(BACKUPS_DIR)) return res.json({ backups: [], count: 0 });

    const files = fs.readdirSync(BACKUPS_DIR)
      .filter(f => f.endsWith('.json'))
      .map(filename => {
        const filepath = path.join(BACKUPS_DIR, filename);
        let stat;
        try { stat = fs.statSync(filepath); } catch(_) { return null; }
        let meta = { version: '?', exportedAt: null, school: null, totalRecords: null };
        try {
          const fd  = fs.openSync(filepath, 'r');
          const buf = Buffer.alloc(2048);
          const n   = fs.readSync(fd, buf, 0, 2048, 0);
          fs.closeSync(fd);
          const h = buf.slice(0, n).toString('utf8');
          const vm = h.match(/"version"\s*:\s*"([^"]+)"/);
          const em = h.match(/"exportedAt"\s*:\s*"([^"]+)"/);
          const sm = h.match(/"school"\s*:\s*"([^"]+)"/);
          const tm = h.match(/"totalRecords"\s*:\s*(\d+)/);
          if (vm) meta.version      = vm[1];
          if (em) meta.exportedAt   = em[1];
          if (sm) meta.school       = sm[1];
          if (tm) meta.totalRecords = parseInt(tm[1]);
        } catch(_) {}
        return {
          filename,
          size: stat.size, sizeKB: Math.round(stat.size/1024),
          sizeMB: (stat.size / (1024*1024)).toFixed(2),
          createdAt: stat.birthtime.toISOString(), modifiedAt: stat.mtime.toISOString(),
          ...meta,
        };
      })
      .filter(Boolean)
      .sort((a, b) => new Date(b.modifiedAt) - new Date(a.modifiedAt));

    res.json({ backups: files, count: files.length });
  } catch (err) {
    console.error('[Backup] List error:', err.message);
    res.status(500).json({ error: 'Could not list backups: ' + err.message });
  }
});


// =============================================================
//  POST /api/backup/auto-save  —  Save fresh backup to server
// =============================================================
router.post('/auto-save', auth, adminOnly, async (req, res) => {
  const MAX_BACKUPS = 7;
  try {
    console.log('[Backup] Auto-save by:', req.user.username);
    const payload  = await buildBackupPayload();
    const filename = `school-backup-${fullDateTag()}.json`;
    const filepath = path.join(BACKUPS_DIR, filename);
    fs.writeFileSync(filepath, JSON.stringify(payload, null, 2), 'utf8');

    // Prune old files
    const allFiles = fs.readdirSync(BACKUPS_DIR)
      .filter(f => f.endsWith('.json'))
      .map(f => ({ name: f, mtime: fs.statSync(path.join(BACKUPS_DIR, f)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime);

    let deleted = 0;
    allFiles.slice(MAX_BACKUPS).forEach(f => {
      try { fs.unlinkSync(path.join(BACKUPS_DIR, f.name)); deleted++; } catch(_) {}
    });

    const stat = fs.statSync(filepath);
    res.json({
      success: true, message: 'Backup saved to server.',
      filename, sizeKB: Math.round(stat.size/1024),
      totalRecords: payload.totalRecords, stats: payload.stats,
      savedAt: payload.exportedAt,
      kept: Math.min(allFiles.length, MAX_BACKUPS), deleted,
    });
  } catch (err) {
    console.error('[Backup] Auto-save error:', err);
    res.status(500).json({ error: 'Auto-save failed: ' + err.message });
  }
});


// =============================================================
//  POST /api/backup/restore-server/:filename
//  Restore database directly from a server-saved backup file.
//  Body: { mode: "full" | "merge" }
// =============================================================
router.post('/restore-server/:filename', auth, adminOnly, async (req, res) => {
  const filename = safeFilename(req.params.filename);
  if (!filename.endsWith('.json')) return res.status(400).json({ error: 'Only .json backup files can be restored.' });

  const filepath = path.join(BACKUPS_DIR, filename);
  if (!fs.existsSync(filepath)) return res.status(404).json({ error: `Backup file not found: ${filename}` });

  let data;
  try { data = JSON.parse(fs.readFileSync(filepath, 'utf8')); }
  catch(err) { return res.status(400).json({ error: 'Could not read/parse backup file: ' + err.message }); }

  if (!data.version || !data.collections) return res.status(400).json({ error: 'Invalid backup format in server file.' });

  const mode = (req.body && req.body.mode === 'merge') ? 'merge' : 'full';
  console.log(`[Backup] Server-restore — file: ${filename}, mode: ${mode}, by: ${req.user.username}`);

  const { restored, errors } = await runRestore(data.collections, mode);
  const totalRestored = Object.values(restored).reduce((a, b) => a + b, 0);

  const response = {
    success: errors.length === 0,
    message: errors.length === 0
      ? `Restored from "${filename}" successfully. ${totalRestored} records.`
      : `Restore completed with ${errors.length} error(s).`,
    mode, filename, restoredAt: new Date().toISOString(),
    backupVersion: data.version, backupDate: data.exportedAt || null,
    totalRestored, restored,
  };
  if (errors.length > 0) response.errors = errors;
  res.status(errors.length > 0 ? 207 : 200).json(response);
});


// =============================================================
//  DELETE /api/backup/delete/:filename  —  Delete server backup
// =============================================================
router.delete('/delete/:filename', auth, adminOnly, (req, res) => {
  const filename = safeFilename(req.params.filename);
  if (!filename.endsWith('.json')) return res.status(400).json({ error: 'Only .json backup files can be deleted.' });

  const filepath = path.join(BACKUPS_DIR, filename);
  if (!fs.existsSync(filepath)) return res.status(404).json({ error: `File not found: ${filename}` });

  try {
    fs.unlinkSync(filepath);
    console.log(`[Backup] Deleted: ${filename} by ${req.user.username}`);
    res.json({ success: true, message: `Backup "${filename}" deleted.` });
  } catch (err) {
    res.status(500).json({ error: 'Could not delete file: ' + err.message });
  }
});


// =============================================================
//  GET /api/backup/verify  —  DB integrity check
//  Counts records and checks for orphaned attendance/fee records.
// =============================================================
router.get('/verify', auth, adminOnly, async (req, res) => {
  try {
    const map = getCollectionMap();
    const counts = {};
    const results = await Promise.all(
      map.map(({ model }) => model ? model.countDocuments().catch(() => 0) : Promise.resolve(0))
    );
    map.forEach(({ key }, i) => { counts[key] = results[i]; });

    const studentIds       = await Student.distinct('studentId');
    const orphanAttendance = await Attendance.countDocuments({ studentId: { $nin: studentIds } });
    const orphanFees       = await FeePayment.countDocuments({ studentId: { $nin: studentIds } });
    const orphanMarks      = await Marks.countDocuments({ studentId: { $nin: studentIds } });
    const orphanLedger     = await LedgerEntry.countDocuments({ studentId: { $nin: studentIds } }).catch(() => 0);
    const ok = orphanAttendance === 0 && orphanFees === 0 && orphanMarks === 0 && orphanLedger === 0;
    const totalRecords = Object.values(counts).reduce((a, b) => a + b, 0);

    res.json({
      counts,
      totalRecords,
      integrity: {
        ok,
        orphanAttendanceRecords: orphanAttendance,
        orphanFeeRecords:        orphanFees,
        orphanMarkRecords:       orphanMarks,
        orphanLedgerRecords:     orphanLedger,
        message: ok
          ? `✅ All ${map.length} collections valid. ${totalRecords} total records. No orphans found.`
          : `⚠️ Found ${orphanAttendance} orphan attendance, ${orphanFees} fee, ${orphanMarks} marks, ${orphanLedger} ledger records.`,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Integrity check failed: ' + err.message });
  }
});


module.exports = router;
