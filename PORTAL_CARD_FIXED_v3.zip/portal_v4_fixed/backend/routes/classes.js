// =============================================================
//  routes/classes.js — Classes CRUD API
//  Base path: /api/classes
//  SCHOOL PORTAL
//
//  ⚠️  ROUTE ORDER MATTERS in Express:
//      /bulk/replace  MUST come BEFORE  /:id
//      Otherwise Express treats the literal string "bulk" as
//      an :id parameter and the bulk endpoint is never reached.
// =============================================================
const router  = require('express').Router();
const Class   = require('../models/Class');
const Student = require('../models/Student');
const { auth, adminOnly } = require('../middleware/auth');

// ── GET /api/classes — list all (public) ─────────────────────
// Returns real student count from Student collection for each class
router.get('/', async (req, res) => {
  try {
    const classes = await Class.find({ isActive: true })
      .sort({ className: 1, section: 1 });

    // Aggregate real student counts per class+section in one query
    const studentCounts = await Student.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: { class: '$class', section: '$section' }, count: { $sum: 1 } } },
    ]);

    // Build lookup map: "className_section" → count
    const countMap = {};
    studentCounts.forEach(({ _id, count }) => {
      countMap[`${_id.class}_${_id.section}`] = count;
    });

    const data = classes.map(cls => ({
      ...cls.toJSON(),
      totalStudents: countMap[`${cls.className}_${cls.section}`] || 0,
    }));

    res.json({ data, total: data.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/classes/:className/:section ─────────────────────
router.get('/:className/:section', async (req, res) => {
  try {
    const cls = await Class.findOne({
      className: req.params.className,
      section:   req.params.section,
    });
    if (!cls) return res.status(404).json({ error: 'Class not found.' });

    const count = await Student.countDocuments({
      class:   req.params.className,
      section: req.params.section,
      isActive: true,
    });
    res.json({ data: { ...cls.toJSON(), totalStudents: count } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/classes — create / upsert (admin) ──────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { className, section } = req.body;
    if (!className) return res.status(400).json({ error: 'className is required.' });

    const cls = await Class.findOneAndUpdate(
      { className, section: section || 'A' },
      {
        $set: {
          teacherName:    req.body.teacherName    || '',
          teacherPhoto:   req.body.teacherPhoto   || '',
          teacherExp:     Number(req.body.teacherExp || 0),
          teacherSubject: req.body.teacherSubject || '',
          teacherQual:    req.body.teacherQual    || '',
          room:           req.body.room           || '',
        },
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({ message: 'Class saved.', data: cls });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ error: 'This class-section already exists.' });
    }
    res.status(500).json({ error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════
//  PUT /api/classes/bulk/replace — MUST BE BEFORE /:id
//
//  If /:id is defined first, Express matches the literal path
//  segment "bulk" as an :id value and this handler is skipped.
//  FIX: specific named paths must come before wildcard routes.
// ══════════════════════════════════════════════════════════════
router.put('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { classTeachers } = req.body;
    if (!classTeachers || typeof classTeachers !== 'object') {
      return res.status(400).json({ error: 'classTeachers object required.' });
    }

    const ops = [];
    Object.keys(classTeachers).forEach(key => {
      // key format: cls_LKG_A  →  parts = ['cls', 'LKG', 'A']
      const parts = key.split('_');
      if (parts.length < 3) return;
      const className = parts[1];
      const section   = parts[2];
      const ct        = classTeachers[key] || {};

      ops.push({
        updateOne: {
          filter: { className, section },
          update: {
            $set: {
              teacherName:    ct.teacherName    || '',
              teacherPhoto:   ct.teacherPhoto   || '',
              teacherExp:     Number(ct.teacherExp || 0),
              teacherSubject: ct.teacherSubject || '',
              teacherQual:    ct.teacherQual    || '',
              totalStudents:  Number(ct.totalStudents || 0),
              isActive:       true,
            },
          },
          upsert: true,
        },
      });
    });

    if (ops.length) await Class.bulkWrite(ops);
    const all = await Class.find({ isActive: true }).sort({ className: 1, section: 1 });
    res.json({ message: 'Classes updated.', total: all.length, data: all });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/classes/:id — update single class (admin) ───────
//  ⚠️  Intentionally placed AFTER /bulk/replace
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = [
      'teacherName', 'teacherPhoto', 'teacherExp',
      'teacherSubject', 'teacherQual', 'room', 'totalStudents',
    ];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    const cls = await Class.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!cls) return res.status(404).json({ error: 'Class not found.' });
    res.json({ message: 'Class updated.', data: cls });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/classes/:id — delete a class (admin) ─────────
// ✅ NEW v2.4.0 — Missing endpoint added
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const cls = await Class.findById(req.params.id);
    if (!cls) return res.status(404).json({ error: 'Class not found.' });

    // Check if any active students are enrolled in this class
    const studentCount = await Student.countDocuments({
      class:    cls.className,
      section:  cls.section,
      isActive: true,
    });
    if (studentCount > 0) {
      return res.status(409).json({
        error: `Cannot delete class. ${studentCount} active student(s) are enrolled. Please transfer or deactivate them first.`,
      });
    }

    await cls.deleteOne();
    res.json({ message: 'Class deleted successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
