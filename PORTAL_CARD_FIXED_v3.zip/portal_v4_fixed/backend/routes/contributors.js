// =============================================================
//  routes/contributors.js — Top Student Contributors API
//  Base path : /api/contributors
//  Auth      : GET is public; POST/PUT/DELETE require admin JWT
// =============================================================
const router     = require('express').Router();
const SC         = require('../models/StudentContributor');
const { auth, adminOnly } = require('../middleware/auth');

// ── GET /api/contributors — all students, desc points ─────────
router.get('/', async (req, res) => {
  try {
    const students = await SC.find().sort({ points: -1 });
    res.json({ data: students, total: students.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/contributors — add student (admin) ──────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { name, house, points } = req.body;
    if (!name || !name.trim())  return res.status(400).json({ error: 'name is required.' });
    if (!house)                  return res.status(400).json({ error: 'house is required.' });
    if (points === undefined || points === '') return res.status(400).json({ error: 'points is required.' });

    const student = await SC.create({
      name:   name.trim(),
      house:  house.trim(),
      points: Number(points),
    });
    res.status(201).json({ message: 'Student contributor added.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/contributors/:id — update student (admin) ────────
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { name, house, points } = req.body;
    const updates = {};
    if (name  !== undefined) updates.name   = name.trim();
    if (house !== undefined) updates.house  = house.trim();
    if (points !== undefined) updates.points = Number(points);

    const student = await SC.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Student updated.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/contributors/:id — delete student (admin) ─────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const student = await SC.findByIdAndDelete(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Student deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
