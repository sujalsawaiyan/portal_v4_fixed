// =============================================================
//  routes/dashboard.js — Dashboard Stats API
//  Base path: /api/dashboard
//  SCHOOL PORTAL
// =============================================================
const router         = require('express').Router();
const Student        = require('../models/Student');
const Teacher        = require('../models/Teacher');
const Event          = require('../models/Event');
const House          = require('../models/House');
const { Notice }     = require('../models/index');
const Admission      = require('../models/Admission');
const SchoolSettings = require('../models/SchoolSettings');
const { auth, adminOnly } = require('../middleware/auth');

// ✅ FIX: Shared utility — duplicate function hataya
const { currentAcademicYear } = require('../utils/academicYear');

// ── GET /api/dashboard — stats (admin only) ───────────────────
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    let FeePayment;
    try { FeePayment = require('../models/FeePayment'); } catch(_){}

    const today      = new Date().toISOString().slice(0, 10);
    const monthStart = today.slice(0, 7) + '-01';
    const academicYear = currentAcademicYear();

    const [
      totalStudents,
      totalTeachers,
      totalEvents,
      totalAnnouncements,
      pendingAdmissions,
      houses,
    ] = await Promise.all([
      Student.countDocuments({ isActive: true }),
      Teacher.countDocuments({ isActive: true }),
      Event.countDocuments({ isActive: true }),
      Notice.countDocuments(),
      Admission.countDocuments({ status: 'pending' }),
      House.find({ isActive: true }).sort({ points: -1 }),
    ]);

    // Fee stats
    let todayCollection = 0, monthCollection = 0, yearCollection = 0;
    if (FeePayment) {
      const [todayAgg, monthAgg, yearAgg] = await Promise.all([
        FeePayment.aggregate([
          { $match: { paymentDate: today, isCancelled: { $ne: true } } },
          { $group: { _id: null, total: { $sum: '$totalAmount' } } }
        ]),
        FeePayment.aggregate([
          { $match: { paymentDate: { $gte: monthStart, $lte: today }, isCancelled: { $ne: true } } },
          { $group: { _id: null, total: { $sum: '$totalAmount' } } }
        ]),
        FeePayment.aggregate([
          { $match: { academicYear, isCancelled: { $ne: true } } },
          { $group: { _id: null, total: { $sum: '$totalAmount' } } }
        ]),
      ]);
      todayCollection = todayAgg[0]?.total || 0;
      monthCollection = monthAgg[0]?.total || 0;
      yearCollection  = yearAgg[0]?.total  || 0;
    }

    // Fetch custom stats from SchoolSettings (if admin has set them)
    const statsSetting = await SchoolSettings.findOne({ key: 'stats' });
    const customStats  = statsSetting?.value || {};

    res.json({
      total_students:      customStats.students || totalStudents,
      total_teachers:      customStats.teachers || totalTeachers,
      total_events:        totalEvents,
      total_announcements: totalAnnouncements,
      pending_admissions:  pendingAdmissions,
      houses:              houses,
      fee_today:           todayCollection,
      fee_month:           monthCollection,
      fee_year:            yearCollection,
      academicYear,
      db_counts: {
        students:     totalStudents,
        teachers:     totalTeachers,
        events:       totalEvents,
        announcements:totalAnnouncements,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/dashboard/public — public stats (no auth) ───────
// Used by main website to show counters
router.get('/public', async (req, res) => {
  try {
    const statsSetting = await SchoolSettings.findOne({ key: 'stats' });
    const stats = statsSetting?.value || {
      students: 0, teachers: 0, years: 0,
      alumni: 0, awards: 0, passRate: 0,
    };

    const schoolInfoSetting = await SchoolSettings.findOne({ key: 'schoolInfo' });
    const schoolInfo = schoolInfoSetting?.value || {};

    res.json({ stats, schoolInfo });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
