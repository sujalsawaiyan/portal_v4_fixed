// =============================================================
//  routes/discounts.js — Fee Discount Management (CRUD + Assignment)
//  FIX: Duplicate currentAcademicYear() → shared utils/academicYear.js
// =============================================================
const router      = require('express').Router();
const FeeDiscount = require('../models/FeeDiscount');
const Student     = require('../models/Student');
const { auth, adminOnly } = require('../middleware/auth');

// ✅ FIX: Shared utility — duplicate function hataya
const { currentAcademicYear } = require('../utils/academicYear');

// =============================================================
// GET /api/discounts — list all discount categories
// =============================================================
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, active } = req.query;
    const filter = {};
    if (academicYear) filter.academicYear = academicYear;
    if (active === 'true') filter.isActive = true;
    const discounts = await FeeDiscount.find(filter).sort({ createdAt: -1 });
    res.json(discounts);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/discounts/pending — list pending approvals
// =============================================================
router.get('/pending', auth, adminOnly, async (req, res) => {
  try {
    const discounts = await FeeDiscount.find({ status: 'pending' }).sort({ createdAt: -1 });
    res.json({ data: discounts, count: discounts.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/discounts/student/:studentId — discounts for a student
// =============================================================
router.get('/student/:studentId', auth, adminOnly, async (req, res) => {
  try {
    const { studentId } = req.params;
    const { academicYear } = req.query;
    const filter = { studentId: studentId.toUpperCase(), isActive: true };
    if (academicYear) filter.academicYear = academicYear;
    const discounts = await FeeDiscount.find(filter).sort({ createdAt: -1 });
    res.json({ data: discounts });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/discounts — create discount category
// =============================================================
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      name, type, value,
      discountType, discountPercent, discountAmount,
      applicableHeads, academicYear,
      approvedBy, remarks,
    } = req.body;

    if (!name && !discountType) return res.status(400).json({ error: 'Discount name/type required.' });

    // Resolve fields — support both the frontend simplified format (name/type/value)
    // and the full model format (discountType/discountPercent/discountAmount)
    const resolvedType    = discountType || name || 'Special';
    const resolvedPercent = discountPercent || (type === 'percentage' ? Number(value) : 0);
    const resolvedAmount  = discountAmount  || (type === 'fixed'      ? Number(value) : 0);
    const yr              = academicYear || currentAcademicYear();

    const discount = new FeeDiscount({
      studentId:       'CATEGORY',       // category-level (no student)
      studentName:     name || discountType,
      discountType:    resolvedType,
      discountPercent: resolvedPercent,
      discountAmount:  resolvedAmount,
      applicableHeads: applicableHeads || [],
      academicYear:    yr,
      approvedBy:      approvedBy || req.user?.username || 'Admin',
      remarks:         remarks || '',
      isActive:        true,
      // Keep frontend-friendly fields in virtual by piggy-backing remarks
    });
    // Store extra frontend fields
    discount._doc = discount._doc || {};
    await discount.save();
    // Return in frontend-friendly format too
    const plain = discount.toObject();
    res.status(201).json({ ...plain, name: plain.studentName, type: plain.discountPercent > 0 ? 'percentage' : 'fixed', value: plain.discountPercent || plain.discountAmount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/discounts/assign — assign discount to student
// =============================================================
router.post('/assign', auth, adminOnly, async (req, res) => {
  try {
    const {
      studentId, discountId, studentName,
      discountType, discountPercent, discountAmount,
      applicableHeads, academicYear, remarks,
    } = req.body;

    if (!studentId) return res.status(400).json({ error: 'studentId is required.' });

    const yr = academicYear || currentAcademicYear();

    // If discountId provided, copy from existing category
    let typeVal = discountType, pct = discountPercent || 0, amt = discountAmount || 0;
    if (discountId && discountId !== 'CATEGORY') {
      const cat = await FeeDiscount.findById(discountId).catch(() => null);
      if (cat) {
        typeVal = cat.discountType;
        pct     = cat.discountPercent;
        amt     = cat.discountAmount;
      }
    }

    const student = await Student.findOne({
      $or: [{ studentId: studentId.toUpperCase() }, { _id: studentId }],
    }).catch(() => null);

    const discount = new FeeDiscount({
      studentId:       student?.studentId || studentId.toUpperCase(),
      studentName:     student?.fullName || studentName || '',
      discountType:    typeVal || 'Special',
      discountPercent: pct,
      discountAmount:  amt,
      applicableHeads: applicableHeads || [],
      academicYear:    yr,
      approvedBy:      req.user?.username || 'Admin',
      remarks:         remarks || '',
      isActive:        true,
    });

    await discount.save();
    res.status(201).json({ message: 'Discount assigned.', data: discount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// PUT /api/discounts/:id — update discount
// =============================================================
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const discount = await FeeDiscount.findById(req.params.id);
    if (!discount) return res.status(404).json({ error: 'Discount not found.' });
    const fields = ['discountType','discountPercent','discountAmount','applicableHeads','remarks','isActive','approvedBy'];
    fields.forEach(f => { if (req.body[f] !== undefined) discount[f] = req.body[f]; });
    // Frontend-friendly mapping
    if (req.body.type === 'percentage') discount.discountPercent = Number(req.body.value || req.body.discountPercent);
    if (req.body.type === 'fixed')      discount.discountAmount  = Number(req.body.value || req.body.discountAmount);
    if (req.body.name)                  discount.studentName     = req.body.name;
    await discount.save();
    res.json({ message: 'Discount updated.', data: discount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/discounts/:id/approve
// =============================================================
router.post('/:id/approve', auth, adminOnly, async (req, res) => {
  try {
    const discount = await FeeDiscount.findById(req.params.id);
    if (!discount) return res.status(404).json({ error: 'Discount not found.' });
    discount.status     = 'approved';
    discount.approvedBy = req.user?.username || 'Principal';
    discount.approvedAt = new Date();
    discount.isActive   = true;
    await discount.save();
    res.json({ message: 'Discount approved.', data: discount });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/discounts/:id/reject
// =============================================================
router.post('/:id/reject', auth, adminOnly, async (req, res) => {
  try {
    const discount = await FeeDiscount.findById(req.params.id);
    if (!discount) return res.status(404).json({ error: 'Discount not found.' });
    discount.status   = 'rejected';
    discount.remarks  = req.body.reason || discount.remarks;
    discount.isActive = false;
    await discount.save();
    res.json({ message: 'Discount rejected.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// DELETE /api/discounts/assign/:id — remove student's discount
// =============================================================
router.delete('/assign/:id', auth, adminOnly, async (req, res) => {
  try {
    const discount = await FeeDiscount.findById(req.params.id);
    if (!discount) return res.status(404).json({ error: 'Discount not found.' });
    discount.isActive = false;
    await discount.save();
    res.json({ message: 'Discount removed.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// DELETE /api/discounts/:id — delete discount category
// =============================================================
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    await FeeDiscount.findByIdAndDelete(req.params.id);
    res.json({ message: 'Discount deleted.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// currentAcademicYear() ab upar shared import se aa raha hai

module.exports = router;
