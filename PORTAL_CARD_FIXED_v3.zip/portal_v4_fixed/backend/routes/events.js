// =============================================================
//  routes/events.js — Events CRUD API
//  Base path: /api/events
//  SCHOOL PORTAL
// =============================================================
const router  = require('express').Router();
const path    = require('path');
const fs      = require('fs');
const multer  = require('multer');
const Event   = require('../models/Event');
const { auth, adminOnly }                        = require('../middleware/auth');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');

// ── Multer temp storage ───────────────────────────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, tmpDir),
  filename:    (_req,  file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, 'event_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    cb(null, ['image/jpeg','image/jpg','image/png','image/webp'].includes(file.mimetype));
  },
});

// ── GET /api/events — list (public) ──────────────────────────
router.get('/', async (req, res) => {
  try {
    const { type, featured } = req.query;
    const filter = { isActive: true };
    if (type)     filter.type = type;
    if (featured === 'true') filter.featured = true;

    const events = await Event.find(filter).sort({ date: 1 });
    res.json({ data: events, total: events.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/events/:id ───────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    res.json({ data: event });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/events — create (admin) ────────────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      title, type, date, endDate, end_date,
      description, venue, featured, is_featured,
      image, highlighted, glowColor,
    } = req.body;

    if (!title) return res.status(400).json({ error: 'title is required.' });
    if (!date)  return res.status(400).json({ error: 'date is required.' });

    const isFeat = !!(featured || is_featured);
    const event = await Event.create({
      title: title.trim(),
      type:        type || 'other',
      date,
      endDate:     endDate || end_date || '',
      end_date:    endDate || end_date || '',
      description: description || '',
      venue:       venue || '',
      featured:    isFeat,
      is_featured: isFeat,
      image:       image || '',
      highlighted: !!highlighted,
      glowColor:   glowColor || '',
      createdBy:   req.user?.username || 'admin',
    });

    res.status(201).json({ message: 'Event created.', data: event });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/events/:id — update (admin) ─────────────────────
// ══════════════════════════════════════════════════
//  PUT /bulk/replace — MUST BE BEFORE /:id
//  (Express would match "bulk" as :id otherwise)
// ══════════════════════════════════════════════════
router.put('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { events, force } = req.body;
    if (!Array.isArray(events)) {
      return res.status(400).json({ error: 'events array required.' });
    }
    if (events.length === 0) {
      const existingCount = await Event.countDocuments({});
      if (existingCount > 0 && !force) {
        return res.status(400).json({ error: `Safety guard: cannot replace ${existingCount} events with empty list. Pass force:true to confirm.`, existingCount });
      }
    }
    await Event.deleteMany({});
    if (events.length) {
      const docs = events.map(e => {
        const isFeat = !!(e.featured || e.is_featured);
        return {
          title:       e.title || '',
          type:        e.type || 'other',
          date:        e.date || new Date().toISOString().slice(0, 10),
          endDate:     e.endDate || e.end_date || '',
          end_date:    e.endDate || e.end_date || '',
          description: e.description || '',
          venue:       e.venue || '',
          featured:    isFeat,
          is_featured: isFeat,
          image:       e.image || '',
          highlighted: !!e.highlighted,
          glowColor:   e.glowColor || '',
          isActive:    true,
        };
      });
      await Event.insertMany(docs);
    }
    const all = await Event.find({ isActive: true }).sort({ date: 1 });
    res.json({ message: 'Events replaced.', total: all.length, data: all });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = [
      'title', 'type', 'date', 'endDate', 'end_date',
      'description', 'venue', 'featured', 'is_featured',
      'image', 'highlighted', 'glowColor', 'isActive',
    ];
    const updates = {};
    allowed.forEach(k => {
      if (req.body[k] !== undefined) updates[k] = req.body[k];
    });

    // Keep featured aliases in sync
    if (updates.featured !== undefined)    updates.is_featured = updates.featured;
    if (updates.is_featured !== undefined) updates.featured    = updates.is_featured;
    if (updates.endDate)   updates.end_date = updates.endDate;
    if (updates.end_date)  updates.endDate  = updates.end_date;

    const event = await Event.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    res.json({ message: 'Event updated.', data: event });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/events/:id/image — Cloudinary upload (admin) ───
router.post('/:id/image', auth, adminOnly, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image file provided.' });
    const event = await Event.findById(req.params.id);
    if (!event) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(404).json({ error: 'Event not found.' });
    }
    if (event.imagePublicId) await deleteFromCloudinary(event.imagePublicId);
    const result = await uploadToCloudinary(req.file.path, 'events');
    event.image         = result.url;
    event.imagePublicId = result.publicId;
    await event.save();
    res.json({ message: 'Image uploaded.', imageUrl: result.url, publicId: result.publicId, data: event });
  } catch (err) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/events/:id/image — remove image (admin) ──────
router.delete('/:id/image', auth, adminOnly, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    if (event.imagePublicId) await deleteFromCloudinary(event.imagePublicId);
    event.image = ''; event.imagePublicId = '';
    await event.save();
    res.json({ message: 'Image removed.', data: event });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── DELETE /api/events/:id — delete + Cloudinary cleanup ─────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    if (event.imagePublicId) await deleteFromCloudinary(event.imagePublicId);
    await event.deleteOne();
    res.json({ message: 'Event deleted.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── PUT /api/events/bulk/replace — replace all (admin) ───────

module.exports = router;
