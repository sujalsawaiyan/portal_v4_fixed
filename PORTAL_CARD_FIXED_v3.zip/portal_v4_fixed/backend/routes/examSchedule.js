// =============================================================
//  routes/examSchedule.js — Exam Schedule CRUD API
//  Base path: /api/exam-schedule
//  SCHOOL PORTAL
// =============================================================
const router = require('express').Router();
const ExamSchedule = require('../models/ExamSchedule');
const { auth, adminOnly } = require('../middleware/auth');

// ── GET /api/exam-schedule — list all (public) ──────────────
router.get('/', async (req, res) => {
  try {
    const { term } = req.query;
    const filter = { isActive: true };
    if (term) filter.term = term;

    const schedules = await ExamSchedule.find(filter).sort({ term: 1, order: 1, _id: 1 });

    // Group by term
    const grouped = { term1: [], term2: [], board: [] };
    schedules.forEach(s => {
      if (grouped[s.term]) grouped[s.term].push(s);
    });

    res.json({ data: grouped, list: schedules, total: schedules.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/exam-schedule/:id ───────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const item = await ExamSchedule.findById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Exam schedule entry not found.' });
    res.json({ data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/exam-schedule — create (admin) ─────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { term, date, subject, classes, duration, maxMarks, order } = req.body;

    if (!term)    return res.status(400).json({ error: 'term is required (term1/term2/board).' });
    if (!date)    return res.status(400).json({ error: 'date is required.' });
    if (!subject) return res.status(400).json({ error: 'subject is required.' });
    if (!classes) return res.status(400).json({ error: 'classes is required.' });

    const item = await ExamSchedule.create({
      term,
      date:      date.trim(),
      subject:   subject.trim(),
      classes:   classes.trim(),
      duration:  duration || '3 Hours',
      maxMarks:  maxMarks !== undefined ? Number(maxMarks) : 100,
      order:     order !== undefined ? Number(order) : 0,
      createdBy: req.user?.username || 'admin',
    });

    res.status(201).json({ message: 'Exam schedule entry created.', data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/exam-schedule/:id — update (admin) ──────────────
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = ['term', 'date', 'subject', 'classes', 'duration', 'maxMarks', 'order', 'isActive'];
    const updates = {};
    allowed.forEach(k => {
      if (req.body[k] !== undefined) updates[k] = req.body[k];
    });

    if (updates.maxMarks !== undefined) updates.maxMarks = Number(updates.maxMarks);
    if (updates.order    !== undefined) updates.order    = Number(updates.order);

    const item = await ExamSchedule.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!item) return res.status(404).json({ error: 'Exam schedule entry not found.' });
    res.json({ message: 'Exam schedule entry updated.', data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/exam-schedule/:id — delete (admin) ──────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const item = await ExamSchedule.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ error: 'Exam schedule entry not found.' });
    res.json({ message: 'Exam schedule entry deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/exam-schedule/bulk/seed — seed default data (admin) ─
router.post('/bulk/seed', auth, adminOnly, async (req, res) => {
  try {
    const existing = await ExamSchedule.countDocuments({});
    if (existing > 0) {
      return res.status(400).json({ error: 'Exam schedule already has data. Use bulk/replace to overwrite.' });
    }

    const defaults = [
      // Term 1
      { term: 'term1', date: 'Feb 10, 2025', subject: 'English',                  classes: 'All Classes', duration: '3 Hours', maxMarks: 100, order: 1 },
      { term: 'term1', date: 'Feb 12, 2025', subject: 'Mathematics',              classes: 'I – XII',     duration: '3 Hours', maxMarks: 100, order: 2 },
      { term: 'term1', date: 'Feb 14, 2025', subject: 'Science / Physics',        classes: 'IV – XII',    duration: '3 Hours', maxMarks: 100, order: 3 },
      { term: 'term1', date: 'Feb 17, 2025', subject: 'Hindi',                    classes: 'All Classes', duration: '3 Hours', maxMarks: 100, order: 4 },
      { term: 'term1', date: 'Feb 19, 2025', subject: 'Social Studies / History', classes: 'V – X',       duration: '3 Hours', maxMarks: 100, order: 5 },
      { term: 'term1', date: 'Feb 21, 2025', subject: 'Computer Science',         classes: 'VI – XII',    duration: '2 Hours', maxMarks:  50, order: 6 },
      // Term 2
      { term: 'term2', date: 'Sep 08, 2025', subject: 'English',                     classes: 'All Classes', duration: '3 Hours', maxMarks: 100, order: 1 },
      { term: 'term2', date: 'Sep 10, 2025', subject: 'Mathematics',                 classes: 'I – XII',     duration: '3 Hours', maxMarks: 100, order: 2 },
      { term: 'term2', date: 'Sep 12, 2025', subject: 'Science / Chemistry',         classes: 'IV – XII',    duration: '3 Hours', maxMarks: 100, order: 3 },
      { term: 'term2', date: 'Sep 15, 2025', subject: 'Hindi',                       classes: 'All Classes', duration: '3 Hours', maxMarks: 100, order: 4 },
      { term: 'term2', date: 'Sep 17, 2025', subject: 'Social Studies / Geography',  classes: 'V – X',       duration: '3 Hours', maxMarks: 100, order: 5 },
      // Board Exams
      { term: 'board', date: 'Feb 15, 2026', subject: 'English (Core)', classes: 'X & XII',  duration: '3 Hours', maxMarks: 80, order: 1 },
      { term: 'board', date: 'Feb 18, 2026', subject: 'Mathematics',    classes: 'X & XII',  duration: '3 Hours', maxMarks: 80, order: 2 },
      { term: 'board', date: 'Feb 20, 2026', subject: 'Science',        classes: 'Class X',  duration: '3 Hours', maxMarks: 80, order: 3 },
      { term: 'board', date: 'Feb 22, 2026', subject: 'Physics',        classes: 'Class XII', duration: '3 Hours', maxMarks: 70, order: 4 },
      { term: 'board', date: 'Feb 24, 2026', subject: 'Chemistry',      classes: 'Class XII', duration: '3 Hours', maxMarks: 70, order: 5 },
      { term: 'board', date: 'Feb 26, 2026', subject: 'Biology / CS',   classes: 'Class XII', duration: '3 Hours', maxMarks: 70, order: 6 },
      { term: 'board', date: 'Feb 28, 2026', subject: 'Social Science', classes: 'Class X',  duration: '3 Hours', maxMarks: 80, order: 7 },
    ];

    await ExamSchedule.insertMany(defaults);
    res.json({ message: 'Default exam schedule seeded.', total: defaults.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/exam-schedule/bulk/replace — replace all (admin) ─
router.post('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { items } = req.body;
    if (!Array.isArray(items)) return res.status(400).json({ error: 'items array required.' });

    await ExamSchedule.deleteMany({});
    if (items.length) {
      await ExamSchedule.insertMany(items.map((item, i) => ({
        term:      item.term     || 'term1',
        date:      item.date     || '',
        subject:   item.subject  || '',
        classes:   item.classes  || '',
        duration:  item.duration || '3 Hours',
        maxMarks:  Number(item.maxMarks || 100),
        order:     Number(item.order    || i),
        isActive:  true,
      })));
    }

    const all = await ExamSchedule.find({ isActive: true }).sort({ term: 1, order: 1 });
    res.json({ message: 'Exam schedule replaced.', total: all.length, data: all });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
