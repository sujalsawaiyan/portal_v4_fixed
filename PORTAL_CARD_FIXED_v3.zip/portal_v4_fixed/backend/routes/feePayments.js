// =============================================================
//  routes/feePayments.js  — Full fee management API
//  Routes: collect, edit, cancel, ledger, reports, defaulters,
//          UPI pending, student history, annual summary
//
//  FIXES APPLIED:
//    1. Duplicate currentAcademicYear() → shared utils/academicYear.js
//    2. SMS balance hardcoded 0 → real balance from balanceCalculator
//    3. getDefaulters ab balanceCalculator use karta hai (consistent)
// =============================================================
const router       = require('express').Router();
const FeePayment   = require('../models/FeePayment');
const FeeStructure = require('../models/FeeStructure');
const FeeDiscount  = require('../models/FeeDiscount');
const Student      = require('../models/Student');
const { auth, adminOnly } = require('../middleware/auth');

// ✅ FIX 1: Shared utility — duplicate function hataya
const { currentAcademicYear } = require('../utils/academicYear');
// ✅ FIX 2: Central balance calculator — SMS mein ab sahi balance jayega
const { getStudentBalance }   = require('../utils/balanceCalculator');

// =============================================================
// POST /api/fee-payments — Collect fee, generate receipt
// =============================================================
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      studentId, academicYear, date, paymentDate,
      feeHeads, mode, paymentMode,
      chequeNo, chequeNumber, chequeDate, bankName, chequeStatus,
      utrNo, utrNumber, bankRef, upiApp,
      remarks, amount,
      fineAmount, fineWaived, fineWaiverReason,
    } = req.body;

    if (!studentId) return res.status(400).json({ error: 'studentId is required.' });

    // Accept studentId as either admissionNo or _id
    const student = await Student.findOne({
      $or: [
        { studentId: studentId.toString().toUpperCase() },
        { admissionNumber: studentId.toString().toUpperCase() },
      ]
    });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    // feeHeads may come as array or be inferred from amount
    let heads = feeHeads;
    if (!heads || !heads.length) {
      if (amount) heads = [{ headName: 'Fee Payment', amount: Number(amount) }];
      else return res.status(400).json({ error: 'feeHeads or amount is required.' });
    }

    const totalAmount = heads.reduce((s, h) => s + Number(h.amount || h.headAmount || 0), 0);
    if (totalAmount <= 0) return res.status(400).json({ error: 'Total amount must be > 0.' });

    const yr   = academicYear || currentAcademicYear();
    // Normalize paymentMode — frontend select may send lowercase ('cash', 'cheque')
    const _modeRaw = paymentMode || mode || 'Cash';
    const _modeMap = { cash:'Cash', cheque:'Cheque', dd:'DD', online:'Online', upi:'UPI' };
    const pMode = _modeMap[_modeRaw.toLowerCase()] || _modeRaw;

    const payment = new FeePayment({
      studentId:       student.studentId || student.admissionNumber,
      studentName:     student.fullName,
      class:           student.class,
      section:         student.section || 'A',
      admissionNumber: student.admissionNumber || '',
      academicYear:    yr,
      paymentDate:     paymentDate || date || new Date().toISOString().slice(0, 10),
      feeHeads:        heads.map(h => ({ headName: h.name || h.headName || 'Fee', amount: Number(h.amount || 0), period: h.period || '' })),
      totalAmount,
      paymentMode:     pMode,
      chequeNumber:    chequeNo    || chequeNumber || '',
      chequeDate:      chequeDate  || '',
      bankName:        bankName    || '',
      chequeStatus:    (['Cash','Online','UPI'].includes(pMode)) ? '' : (chequeStatus || 'pending'),
      utrNumber:       utrNo || utrNumber || '',
      bankRef:         bankRef || '',
      upiApp:          upiApp || '',
      upiVerified:     ['Online','UPI'].includes(pMode),
      remarks:         remarks || '',
      receivedBy:      req.user?.username || req.user?.name || 'Admin',
      fineAmount:      Number(fineAmount || 0),
      fineWaived:      fineWaived === true || fineWaived === 'true',
      fineWaiverReason: fineWaiverReason || '',
    });

    await payment.save();

    // ✅ FIX: Real balance calculate karo payment save hone ke baad
    // Pehle SMS mein hardcoded zero jaata tha — ab actual remaining due jayega
    let remainingBalance = 0;
    try {
      const bal = await getStudentBalance(student.studentId || student.admissionNumber, yr);
      remainingBalance = bal.remainingDue;
    } catch (balErr) {
      console.warn('[FeePayments] Balance calculation failed (non-fatal):', balErr.message);
    }

    // ── WhatsApp Receipt (non-blocking — never fail collection if WA fails) ──
    setImmediate(async () => {
      try {
        const { sendFeeReceiptWhatsApp } = require('../utils/whatsappService');
        await sendFeeReceiptWhatsApp(payment, student, remainingBalance);
      } catch (e) {
        console.warn('[WhatsApp Receipt] Send failed (non-fatal):', e.message);
      }
    });

    // ── SMS Receipt (non-blocking) ──
    setImmediate(async () => {
      try {
        const { sendReceiptSMS } = require('../utils/smsService');
        const phone = student.guardianPhone || student.phone || '';
        if (phone) {
          await sendReceiptSMS({
            studentName:   student.fullName || student.name,
            guardianPhone: phone,
            amount:        payment.totalAmount,
            receiptNo:     payment.receiptNumber,
            balance:       remainingBalance, // ✅ Ab sahi balance jayega SMS mein
            schoolName:    process.env.SCHOOL_NAME || 'School',
          });
          console.log(`[SMS Receipt] Sent to ${phone} for receipt #${payment.receiptNumber} | Balance: ₹${remainingBalance}`);
        }
      } catch (e) {
        console.warn('[SMS Receipt] Send failed (non-fatal):', e.message);
      }
    });

    res.status(201).json({
      message: 'Fee collected.',
      receiptNo: payment.receiptNumber,
      data: payment,
    });
  } catch (err) {
    console.error('[FeePayments] POST error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/fee-payments — list with filters
// =============================================================
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, class: cls, studentId, startDate, endDate, page = 1, limit = 50 } = req.query;
    const filter = { isCancelled: { $ne: true } };
    if (academicYear) filter.academicYear = academicYear;
    if (cls)          filter.class        = cls;
    if (studentId)    filter.studentId    = studentId.toUpperCase();
    if (startDate || endDate) {
      filter.paymentDate = {};
      if (startDate) filter.paymentDate.$gte = startDate;
      if (endDate)   filter.paymentDate.$lte = endDate;
    }
    const total    = await FeePayment.countDocuments(filter);
    const payments = await FeePayment.find(filter)
      .sort({ paymentDate: -1, createdAt: -1 })
      .skip((page - 1) * limit).limit(Number(limit));
    res.json({ data: payments, total, page: Number(page), limit: Number(limit) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/dashboard
// =============================================================
router.get('/reports/dashboard', auth, adminOnly, async (req, res) => {
  try {
    const academicYear = req.query.academicYear || currentAcademicYear();
    const today      = new Date().toISOString().slice(0, 10);
    const monthStart = today.slice(0, 7) + '-01';

    const [totalStudents, todayAgg, monthAgg, yearAgg, pendingUPI] = await Promise.all([
      Student.countDocuments({ isActive: true }),
      FeePayment.aggregate([
        { $match: { paymentDate: today, isCancelled: { $ne: true } } },
        { $group: { _id: null, total: { $sum: '$totalAmount' }, count: { $sum: 1 } } },
      ]),
      FeePayment.aggregate([
        { $match: { paymentDate: { $gte: monthStart, $lte: today }, academicYear, isCancelled: { $ne: true } } },
        { $group: { _id: null, total: { $sum: '$totalAmount' }, count: { $sum: 1 } } },
      ]),
      FeePayment.aggregate([
        { $match: { academicYear, isCancelled: { $ne: true } } },
        { $group: { _id: null, total: { $sum: '$totalAmount' } } },
      ]),
      FeePayment.countDocuments({ upiPending: true }),
    ]);

    res.json({
      totalStudents,
      todayCollection: todayAgg[0]?.total  || 0,
      todayReceipts:   todayAgg[0]?.count   || 0,
      monthCollection: monthAgg[0]?.total   || 0,
      monthReceipts:   monthAgg[0]?.count    || 0,
      yearCollection:  yearAgg[0]?.total    || 0,
      pendingUPI,
      academicYear,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/daily
// =============================================================
router.get('/reports/daily', auth, adminOnly, async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10);
    const payments = await FeePayment.find({ paymentDate: date, isCancelled: { $ne: true } })
      .sort({ createdAt: -1 });
    const total = payments.reduce((s, p) => s + p.totalAmount, 0);

    const byMode = { Cash: 0, Cheque: 0, DD: 0, Online: 0, UPI: 0 };
    for (const p of payments) byMode[p.paymentMode] = (byMode[p.paymentMode] || 0) + p.totalAmount;

    res.json({ data: payments, total, byMode, date });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/monthly
// =============================================================
router.get('/reports/monthly', auth, adminOnly, async (req, res) => {
  try {
    const { month, year } = req.query;
    if (!month || !year) return res.status(400).json({ error: 'month and year required.' });
    const startDate = `${year}-${String(month).padStart(2,'0')}-01`;
    const endDate   = new Date(year, month, 0).toISOString().slice(0, 10);
    const payments  = await FeePayment.find({ paymentDate: { $gte: startDate, $lte: endDate }, isCancelled: { $ne: true } })
      .sort({ paymentDate: 1 });

    const byDay = {};
    for (const p of payments) byDay[p.paymentDate] = (byDay[p.paymentDate] || 0) + p.totalAmount;

    const total = payments.reduce((s, p) => s + p.totalAmount, 0);

    // Build days[] array — frontend expects this format (BUG 4 fix)
    const daysInMonth = new Date(year, month, 0).getDate();
    const days = Array.from({ length: daysInMonth }, (_, i) => {
      const day     = i + 1;
      const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
      const dayPmts = payments.filter(p => p.paymentDate === dateStr);
      return {
        day,
        amount:   dayPmts.reduce((s, p) => s + p.totalAmount, 0),
        receipts: dayPmts.length,
      };
    });

    res.json({ days, data: payments, total, byDay, startDate, endDate });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/annual
// =============================================================
router.get('/reports/annual', auth, adminOnly, async (req, res) => {
  try {
    const academicYear = req.query.academicYear || currentAcademicYear();
    const [payments, structures, activeStudents] = await Promise.all([
      FeePayment.find({ academicYear, isCancelled: { $ne: true } }),
      FeeStructure.find({ academicYear }),
      Student.find({ isActive: true }, { class: 1 }),
    ]);

    const totalCollected = payments.reduce((s, p) => s + p.totalAmount, 0);

    // FIX 2 — Correct totalTarget: per-class fee × actual student count in that class
    const freqMult = { monthly: 12, quarterly: 4, annually: 1, 'one-time': 1 };
    // Count students per class
    const studentCountByClass = {};
    for (const stu of activeStudents) {
      studentCountByClass[stu.class] = (studentCountByClass[stu.class] || 0) + 1;
    }
    // For each fee structure, compute annual fee (using feeHeads if available, else totalAnnualFee)
    // then multiply by the number of students in that class
    let totalTarget = 0;
    for (const st of structures) {
      const annualFee = st.feeHeads && st.feeHeads.length
        ? st.feeHeads.reduce((s, h) => s + (h.amount || 0) * (freqMult[h.frequency] || 1), 0)
        : (st.totalAnnualFee || 0);
      const classStudents = studentCountByClass[st.class] || 0;
      totalTarget += annualFee * classStudents;
    }

    // FIX 1 — Month-wise breakdown returned as sorted array for chart
    const byMonthMap = {};
    for (const p of payments) {
      const dateStr = p.paymentDate ? (typeof p.paymentDate === 'string' ? p.paymentDate : p.paymentDate.toISOString().slice(0,10)) : '';
      const mo = dateStr.slice(0, 7); // YYYY-MM
      byMonthMap[mo] = (byMonthMap[mo] || 0) + p.totalAmount;
    }
    // Build sorted months array with readable labels
    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const months = Object.keys(byMonthMap)
      .sort()
      .map(key => {
        const [yr, mo] = key.split('-');
        return { key, month: `${monthNames[parseInt(mo, 10) - 1]} ${yr}`, amount: byMonthMap[key] };
      });

    // Mode-wise breakdown (kept for backward compat)
    const byMode = { Cash: 0, Cheque: 0, DD: 0, Online: 0, UPI: 0 };
    for (const p of payments) byMode[p.paymentMode] = (byMode[p.paymentMode] || 0) + p.totalAmount;

    res.json({
      academicYear, totalCollected, totalTarget,
      totalPending: Math.max(0, totalTarget - totalCollected),
      collectionPct: totalTarget > 0 ? Math.round(totalCollected / totalTarget * 100) : 0,
      months,        // FIX 1 — array for chart bars
      byMode,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/classwise-summary — all classes (BUG 3 fix)
// =============================================================
router.get('/reports/classwise-summary', auth, adminOnly, async (req, res) => {
  try {
    const academicYear = req.query.academicYear || currentAcademicYear();

    const CLASSES = ['Nursery','LKG','UKG','I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

    const [structures, allStudents, payAgg] = await Promise.all([
      FeeStructure.find({ academicYear }),
      Student.find({ isActive: true }),
      FeePayment.aggregate([
        { $match: { academicYear, isCancelled: { $ne: true } } },
        { $group: { _id: '$studentId', totalPaid: { $sum: '$totalAmount' }, class: { $first: '$class' } } },
      ]),
    ]);

    const structMap = {};
    for (const s of structures) structMap[s.class] = s.totalAnnualFee || 0;

    const paidMap = {};
    for (const p of payAgg) paidMap[p._id] = p.totalPaid;

    // Group students by class
    const classBuckets = {};
    for (const stu of allStudents) {
      if (!classBuckets[stu.class]) classBuckets[stu.class] = [];
      classBuckets[stu.class].push(stu);
    }

    const summary = Object.entries(classBuckets).map(([cls, students]) => {
      const expectedFee = structMap[cls] || 0;
      const target      = expectedFee * students.length;
      let collected = 0, paid = 0, partial = 0, due = 0;
      for (const stu of students) {
        const p = paidMap[stu.studentId] || 0;
        collected += p;
        if (p >= expectedFee && expectedFee > 0) paid++;
        else if (p > 0) partial++;
        else due++;
      }
      const outstanding = Math.max(0, target - collected);
      const collectionPct = target > 0 ? Math.round(collected / target * 100) : 0;
      return { class: cls, totalStudents: students.length, target, collected, pending: outstanding, outstanding, paid, partial, due, collectionPct };
    });

    // Sort by class order
    summary.sort((a, b) => {
      const ia = CLASSES.indexOf(a.class), ib = CLASSES.indexOf(b.class);
      return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
    });

    res.json(summary);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/class/:cls  (BUG 2 fix — also accepts ?class= query)
// =============================================================
router.get(['/reports/class/:cls', '/reports/class'], auth, adminOnly, async (req, res) => {
  try {
    const cls = req.params.cls || req.query.class;
    if (!cls) return res.status(400).json({ error: 'class is required.' });
    const academicYear = req.query.academicYear || currentAcademicYear();

    const [payments, students, structure] = await Promise.all([
      FeePayment.aggregate([
        { $match: { class: cls, academicYear, isCancelled: { $ne: true } } },
        { $group: { _id: '$studentId', studentName: { $first: '$studentName' }, totalPaid: { $sum: '$totalAmount' }, lastPayment: { $max: '$paymentDate' } } },
      ]),
      Student.find({ class: cls, isActive: true }),
      FeeStructure.findOne({ class: cls, academicYear }),
    ]);

    const paidMap = {};
    for (const p of payments) paidMap[p._id] = p;
    const expectedFee = structure?.totalAnnualFee || 0;
    const target      = expectedFee * students.length;
    const collected   = payments.reduce((s, p) => s + p.totalPaid, 0);

    const rows = students.map(s => {
      const paid = paidMap[s.studentId]?.totalPaid || 0;
      const balance = Math.max(0, expectedFee - paid);
      return {
        studentId: s.studentId, studentName: s.fullName,
        rollNo: s.rollNumber || '', section: s.section,
        annualFee: expectedFee, totalPaid: paid, balance,
        lastPaymentDate: paidMap[s.studentId]?.lastPayment || null,
        status: paid >= expectedFee ? 'paid' : paid > 0 ? 'partial' : 'due',
      };
    });

    res.json({ data: rows, target, collected, pending: Math.max(0, target - collected), expectedFee, academicYear, class: cls });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/defaulters  (also /defaulters)
// ✅ FIX 3: Ab balanceCalculator use karta hai — discount bhi consider hoga
//           Pehle discount ignore ho raha tha, student wrongly defaulter dikhta tha
// =============================================================
async function getDefaulters(req, res) {
  try {
    const academicYear = req.query.academicYear || currentAcademicYear();
    const { class: cls, section, minDays } = req.query;
    const stuFilter = { isActive: true };
    if (cls)     stuFilter.class   = cls;
    if (section) stuFilter.section = section;
    const students = await Student.find(stuFilter).lean();

    // Batch mein saare structures aur payments ek saath lao (fast)
    const [structures, payAgg, discounts] = await Promise.all([
      FeeStructure.find({ academicYear }).lean(),
      FeePayment.aggregate([
        { $match: { academicYear, isCancelled: { $ne: true } } },
        { $group: { _id: '$studentId', totalPaid: { $sum: '$totalAmount' }, lastPayment: { $max: '$paymentDate' } } },
      ]),
      FeeDiscount.find({ academicYear, isActive: true }).lean(),
    ]);

    const structMap   = {};
    for (const s of structures) structMap[s.class] = s.totalAnnualFee || 0;
    const paidMap = {};
    for (const p of payAgg) paidMap[p._id] = p;
    const discountMap = {};
    for (const d of discounts) {
      if (d.studentId === 'CATEGORY') continue;
      (discountMap[d.studentId] = discountMap[d.studentId] || []).push(d);
    }

    const today      = new Date();
    const defaulters = [];

    for (const s of students) {
      const totalFee = structMap[s.class] || 0;
      if (!totalFee) continue;

      // ✅ Discount calculate karo per student
      let totalDiscount = 0;
      for (const d of (discountMap[s.studentId] || [])) {
        if (d.discountPercent > 0) totalDiscount += Math.round((totalFee * d.discountPercent) / 100);
        else                        totalDiscount += d.discountAmount || 0;
      }
      const netFee  = Math.max(0, totalFee - totalDiscount);
      const paid    = paidMap[s.studentId]?.totalPaid || 0;
      const pending = Math.max(0, netFee - paid);

      if (pending <= 0) continue;

      const dueDate = `${academicYear.split('-')[0]}-04-10`;
      const daysDue = Math.floor((today - new Date(dueDate)) / 86400000);
      if (minDays && daysDue < Number(minDays)) continue;

      defaulters.push({
        studentId:       s.studentId,
        studentName:     s.fullName,
        class:           s.class,
        section:         s.section,
        phone:           s.guardianPhone || s.phone || '',
        totalFee,
        totalDiscount,
        netFee,
        totalPaid:       paid,
        pending,
        dueDate,
        daysDue:         Math.max(0, daysDue),
        lastPaymentDate: paidMap[s.studentId]?.lastPayment || null,
      });
    }

    defaulters.sort((a, b) => b.pending - a.pending);
    const totalPending = defaulters.reduce((s, d) => s + d.pending, 0);
    res.json({ data: defaulters, totalPending, count: defaulters.length, academicYear });
  } catch (err) { res.status(500).json({ error: err.message }); }
}
router.get('/reports/defaulters', auth, adminOnly, getDefaulters);
router.get('/defaulters',         auth, adminOnly, getDefaulters);

// =============================================================
// GET /api/fee-payments/upi-pending — UPI payments to verify
// =============================================================
router.get('/upi-pending', auth, adminOnly, async (req, res) => {
  try {
    const payments = await FeePayment.find({ upiPending: true, upiRejected: { $ne: true } })
      .sort({ createdAt: -1 });
    res.json({ data: payments, count: payments.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/fee-payments/upi-verify/:id — Approve UPI payment
// =============================================================
router.post('/upi-verify/:id', auth, adminOnly, async (req, res) => {
  try {
    const payment = await FeePayment.findById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found.' });
    payment.upiPending  = false;
    payment.upiVerified = true;
    payment.receivedBy  = req.user?.username || 'Admin';
    await payment.save();
    res.json({ message: 'UPI payment approved.', receiptNo: payment.receiptNumber, data: payment });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/fee-payments/upi-reject/:id — Reject UPI payment
// =============================================================
router.post('/upi-reject/:id', auth, adminOnly, async (req, res) => {
  try {
    const { reason } = req.body;
    const payment = await FeePayment.findById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found.' });
    payment.upiPending      = false;
    payment.upiRejected     = true;
    payment.upiRejectReason = reason || 'Rejected by admin';
    await payment.save();
    res.json({ message: 'UPI payment rejected.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/student/:studentId — payment history
// =============================================================
router.get('/student/:studentId', auth, adminOnly, async (req, res) => {
  try {
    const { studentId } = req.params;
    const academicYear  = req.query.academicYear || currentAcademicYear();
    const payments = await FeePayment.find({
      studentId: studentId.toUpperCase(),
      academicYear,
      isCancelled: { $ne: true },
    }).sort({ paymentDate: -1 });
    res.json({ data: payments });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/student/:studentId/ledger
// =============================================================
router.get('/student/:studentId/ledger', auth, adminOnly, async (req, res) => {
  try {
    const { studentId } = req.params;
    const academicYear  = req.query.academicYear || currentAcademicYear();
    // Only include _id in $or if it is a valid ObjectId — otherwise Mongoose throws CastError
    const mongoose = require('mongoose');
    const conditions = [
      { studentId: studentId.toUpperCase() },
      { admissionNumber: studentId.toUpperCase() },
    ];
    if (mongoose.isValidObjectId(studentId)) conditions.push({ _id: studentId });
    const student   = await Student.findOne({ $or: conditions });
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    const payments   = await FeePayment.find({ studentId: student.studentId, academicYear }).sort({ paymentDate: 1 });
    const structure  = await FeeStructure.findOne({ class: student.class, academicYear });
    const discounts  = await FeeDiscount.find({ studentId: student.studentId, academicYear, isActive: true }).catch(() => []);
    const totalPaid     = payments.filter(p => !p.isCancelled).reduce((s, p) => s + p.totalAmount, 0);
    const totalDiscount = discounts.reduce((s, d) => s + (d.discountAmount || 0), 0);
    const expected      = structure?.totalAnnualFee || 0;
    const pending       = Math.max(0, expected - totalPaid - totalDiscount);
    const lastPayment   = payments.filter(p => !p.isCancelled)[0]?.paymentDate || null;
    res.json({ student, payments, structure, discounts, summary: { expected, totalPaid, totalDiscount, pending, lastPayment }, academicYear });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/student/:studentId/installment-status
// Returns per-term payment status for a student
// =============================================================
router.get('/student/:studentId/installment-status', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear } = req.query;
    const yr = academicYear || currentAcademicYear();

    const student = await Student.findOne({
      $or: [
        { studentId:       req.params.studentId.toUpperCase() },
        { admissionNumber: req.params.studentId.toUpperCase() },
      ]
    });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const InstallmentSchedule = require('../models/InstallmentSchedule');
    const schedule = await InstallmentSchedule.findOne({ academicYear: yr });
    const terms = schedule?.terms || [];

    const structure = await FeeStructure.findOne({ class: student.class, academicYear: yr });
    const totalAnnualFee = structure?.totalAnnualFee || 0;

    const payments = await FeePayment.find({
      studentId:   { $in: [student.studentId, student.admissionNumber] },
      academicYear: yr,
      isCancelled:  { $ne: true },
    }).sort({ paymentDate: 1 });

    const termStatus = terms.map((term, idx) => {
      const termPayments = payments.filter(p =>
        p.feeHeads.some(h => h.period === term.name)
      );

      const termDueDate  = new Date(term.dueDate);
      const nextTermDate = terms[idx + 1] ? new Date(terms[idx + 1].dueDate) : new Date('2099-01-01');

      const orphanPayments = payments.filter(p =>
        !p.feeHeads.some(h => h.period) &&
        new Date(p.paymentDate) >= termDueDate &&
        new Date(p.paymentDate) <  nextTermDate
      );

      const allTermPayments = [...termPayments, ...orphanPayments];
      const paidAmount      = allTermPayments.reduce((s, p) => s + (p.totalAmount || 0), 0);

      const expectedAmount = totalAnnualFee > 0
        ? Math.round(totalAnnualFee * (term.percentage / 100))
        : 0;

      const isOverdue = new Date() > new Date(term.dueDate) && paidAmount < expectedAmount;

      return {
        termName:       term.name,
        dueDate:        term.dueDate,
        percentage:     term.percentage,
        expectedAmount,
        paidAmount,
        balance:        Math.max(0, expectedAmount - paidAmount),
        status:         paidAmount >= expectedAmount ? 'paid' : (isOverdue ? 'overdue' : 'pending'),
        receipts:       allTermPayments.map(p => ({
          receiptNumber: p.receiptNumber,
          date:          p.paymentDate,
          amount:        p.totalAmount,
          mode:          p.paymentMode,
          id:            p._id,
        })),
      };
    });

    res.json({
      student: {
        name:            student.fullName,
        class:           student.class,
        section:         student.section,
        admissionNumber: student.admissionNumber,
      },
      academicYear: yr,
      totalAnnualFee,
      totalPaid:    payments.reduce((s, p) => s + p.totalAmount, 0),
      terms:        termStatus,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/fee-payments/reports/term-collection
// ?academicYear=2024-25&term=Term+1+(April)&class=8
// Class-wise term collection status
// =============================================================
router.get('/reports/term-collection', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, term, class: cls } = req.query;
    const yr = academicYear || currentAcademicYear();

    const stuFilter = { isActive: true };
    if (cls) stuFilter.class = cls;
    const students = await Student.find(stuFilter)
      .select('studentId admissionNumber fullName class section');

    const payments = await FeePayment.find({
      academicYear: yr,
      isCancelled:  { $ne: true },
      ...(term ? { 'feeHeads.period': term } : {}),
    });

    const paidStudentIds = new Set(payments.map(p => p.studentId));

    const result = students.map(s => ({
      studentId:   s.studentId || s.admissionNumber,
      name:        s.fullName,
      class:       s.class,
      section:     s.section,
      paid:        paidStudentIds.has(s.studentId) || paidStudentIds.has(s.admissionNumber),
      amount:      payments
        .filter(p => p.studentId === s.studentId || p.studentId === s.admissionNumber)
        .reduce((sum, p) => sum + p.totalAmount, 0),
    }));

    const summary = {
      totalStudents:  result.length,
      paidCount:      result.filter(r =>  r.paid).length,
      pendingCount:   result.filter(r => !r.paid).length,
      totalCollected: result.reduce((s, r) => s + r.amount, 0),
    };

    res.json({ summary, students: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/fee-payments/:id — single receipt
// FIX: ObjectId validation added — prevents crash for invalid IDs like "demo1"
// =============================================================
router.get('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { id } = req.params;
    // Validate ObjectId before querying — prevents CastError 500 crash
    if (!id.match(/^[a-f\d]{24}$/i)) {
      return res.status(400).json({ error: `Invalid receipt ID: "${id}". Please provide a valid ID.` });
    }
    const payment = await FeePayment.findById(id);
    if (!payment) return res.status(404).json({ error: 'Receipt not found.' });
    res.json({ data: payment });
  } catch (err) {
    if (err.name === 'CastError') return res.status(400).json({ error: `Invalid ID format: "${req.params.id}"` });
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// PUT /api/fee-payments/:id — Edit offline payment
// =============================================================
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { id } = req.params;
    if (!id.match(/^[a-f\d]{24}$/i)) return res.status(400).json({ error: `Invalid ID: "${id}"` });
    const payment = await FeePayment.findById(id);
    if (!payment) return res.status(404).json({ error: 'Receipt not found.' });
    if (payment.isCancelled) return res.status(400).json({ error: 'Cannot edit a cancelled receipt.' });
    if (['Online','UPI'].includes(payment.paymentMode) && payment.upiVerified) {
      return res.status(400).json({ error: 'Verified online payments cannot be edited. Use UPI tab.' });
    }

    const allowed = ['paymentDate','paymentMode','totalAmount','chequeNumber','chequeDate','bankName','chequeStatus','remarks','feeHeads'];
    const changes = [];
    for (const field of allowed) {
      if (req.body[field] !== undefined && String(req.body[field]) !== String(payment[field])) {
        changes.push(`${field}: ${payment[field]} → ${req.body[field]}`);
        payment[field] = req.body[field];
      }
    }
    if (req.body.amount) { payment.totalAmount = Number(req.body.amount); changes.push(`amount updated`); }
    if (req.body.feeHead) {
      if (payment.feeHeads && payment.feeHeads.length > 0) {
        payment.feeHeads[0].headName = req.body.feeHead;
        changes.push(`feeHead: ${req.body.feeHead}`);
      }
    }

    payment.editLog = payment.editLog || [];
    payment.editLog.push({ editedBy: req.user?.username || 'Admin', changes: changes.join(', ') || 'Updated' });

    await payment.save();
    res.json({ message: 'Payment updated.', data: payment });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// DELETE /api/fee-payments/:id — Cancel receipt
// =============================================================
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { id } = req.params;
    if (!id.match(/^[a-f\d]{24}$/i)) return res.status(400).json({ error: `Invalid ID: "${id}"` });
    const reason = req.body?.reason || 'Cancelled by admin';
    const payment = await FeePayment.findById(id);
    if (!payment) return res.status(404).json({ error: 'Receipt not found.' });
    if (payment.isCancelled) return res.status(400).json({ error: 'Already cancelled.' });
    payment.isCancelled  = true;
    payment.cancelReason = reason;
    payment.cancelledAt  = new Date().toISOString().slice(0, 10);
    payment.cancelledBy  = req.user?.username || 'Admin';
    await payment.save();
    res.json({ message: 'Receipt cancelled.', data: payment });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/fee-payments/:id/bounce — Mark cheque as bounced (MISSING 1)
// =============================================================
router.post('/:id/bounce', auth, adminOnly, async (req, res) => {
  try {
    const payment = await FeePayment.findById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Payment not found.' });
    if (!['Cheque','DD'].includes(payment.paymentMode))
      return res.status(400).json({ error: 'Only Cheque/DD payments can be marked bounced.' });

    payment.chequeStatus = 'bounced';
    payment.isCancelled  = true;
    payment.cancelReason = req.body.reason || 'Cheque bounced';
    payment.cancelledBy  = req.user?.username || 'Admin';
    payment.cancelledAt  = new Date().toISOString().slice(0, 10);
    await payment.save();

    // Add bounce penalty to ledger if requested
    const penaltyAmt = Number(req.body.penaltyAmount || 0);
    if (penaltyAmt > 0) {
      try {
        const LedgerEntry = require('../models/LedgerEntry');
        await LedgerEntry.create({
          studentId:   payment.studentId,
          type:        'charge',
          description: `Cheque Bounce Penalty (Cheque #${payment.chequeNumber || 'N/A'})`,
          amount:      penaltyAmt,
          academicYear: payment.academicYear,
          addedBy:     req.user?.username || 'Admin',
        });
      } catch (_) { /* LedgerEntry optional */ }
    }

    res.json({ message: `Cheque marked as bounced. Fee of ₹${payment.totalAmount} re-added as due.`, data: payment });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/fee-payments/carry-forward — Previous year dues (MISSING 3)
// =============================================================
router.post('/carry-forward', auth, adminOnly, async (req, res) => {
  try {
    const { fromYear, toYear } = req.body;
    if (!fromYear || !toYear) return res.status(400).json({ error: 'fromYear and toYear required.' });

    const students  = await Student.find({ isActive: true });
    const structures = await FeeStructure.find({ academicYear: fromYear });
    const structMap  = {};
    for (const s of structures) structMap[s.class] = s.totalAnnualFee || 0;

    const payAgg = await FeePayment.aggregate([
      { $match: { academicYear: fromYear, isCancelled: { $ne: true } } },
      { $group: { _id: '$studentId', totalPaid: { $sum: '$totalAmount' } } },
    ]);
    const paidMap = {};
    for (const p of payAgg) paidMap[p._id] = p.totalPaid;

    let count = 0;
    const LedgerEntry = require('../models/LedgerEntry').catch ? null : require('../models/LedgerEntry');

    for (const stu of students) {
      const expected = structMap[stu.class] || 0;
      const paid     = paidMap[stu.studentId] || 0;
      const pending  = expected - paid;
      if (pending > 0 && LedgerEntry) {
        const existing = await LedgerEntry.findOne({ studentId: stu.studentId, academicYear: toYear, type: 'carry-forward' });
        if (!existing) {
          await LedgerEntry.create({
            studentId:   stu.studentId,
            type:        'carry-forward',
            description: `Previous Year Dues (${fromYear})`,
            amount:      pending,
            academicYear: toYear,
            addedBy:     req.user?.username || 'Admin',
          });
          count++;
        }
      }
    }

    res.json({ message: `Carry-forward complete. ${count} students had pending dues from ${fromYear}.`, count });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/fee-payments/reports/daybook — Day Book (MISSING 8)
// =============================================================
router.get('/reports/daybook', auth, adminOnly, async (req, res) => {
  try {
    const date = req.query.date || new Date().toISOString().slice(0, 10);

    const transactions = await FeePayment.find({ paymentDate: date, isCancelled: { $ne: true } })
      .sort({ createdAt: 1 });

    // Previous day's closing = sum of all payments before this date
    const prevAgg = await FeePayment.aggregate([
      { $match: { paymentDate: { $lt: date }, isCancelled: { $ne: true } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } },
    ]);
    const openingBalance = prevAgg[0]?.total || 0;

    const cashTotal    = transactions.filter(p => p.paymentMode === 'Cash').reduce((s, p) => s + p.totalAmount, 0);
    const nonCashTotal = transactions.filter(p => p.paymentMode !== 'Cash').reduce((s, p) => s + p.totalAmount, 0);
    const dayTotal     = transactions.reduce((s, p) => s + p.totalAmount, 0);
    const closingBalance = openingBalance + dayTotal;

    const byMode = { Cash: 0, Cheque: 0, DD: 0, Online: 0, UPI: 0 };
    for (const p of transactions) byMode[p.paymentMode] = (byMode[p.paymentMode] || 0) + p.totalAmount;

    res.json({ date, openingBalance, transactions, cashTotal, nonCashTotal, dayTotal, closingBalance, byMode, count: transactions.length });
  } catch (err) { res.status(500).json({ error: err.message }); }
});


// =============================================================
// POST /api/payment/upi-submission — Student submits UPI UTR for verification
// Called from frontend payment.html when student pays via UPI manually
// =============================================================
router.post('/upi-submission', async (req, res) => {
  try {
    const { studentId, amount, utrNumber, paymentApp, paymentDate, academicYear } = req.body;
    if (!studentId || !amount || !utrNumber) {
      return res.status(400).json({ error: 'studentId, amount and utrNumber are required.' });
    }

    // Bug 3 fix: prevent duplicate UTR submissions (security)
    const duplicate = await FeePayment.findOne({ utrNumber: utrNumber.trim() });
    if (duplicate) {
      return res.status(409).json({ error: 'This UTR / Transaction ID has already been submitted. If this is an error, contact the school office.' });
    }

    const _conds1 = [
      { studentId: studentId.toString().toUpperCase() },
      { admissionNumber: studentId.toString().toUpperCase() },
    ];
    if (require('mongoose').isValidObjectId(studentId)) _conds1.push({ _id: studentId });
    const student = await Student.findOne({ $or: _conds1 });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const yr  = academicYear || currentAcademicYear();
    const pDate = (paymentDate || new Date().toISOString()).slice(0, 10);

    const payment = new FeePayment({
      studentId:       student.studentId,
      studentName:     student.fullName,
      class:           student.class,
      section:         student.section || 'A',
      admissionNumber: student.admissionNumber || '',
      academicYear:    yr,
      paymentDate:     pDate,
      feeHeads:        [{ headName: 'Fee Payment (UPI)', amount: Number(amount) }],
      totalAmount:     Number(amount),
      paymentMode:     'UPI',
      utrNumber:       utrNumber,
      upiApp:          paymentApp || '',
      upiPending:      true,   // needs admin verification
      upiVerified:     false,
      remarks:         `Online UPI submission — pending admin verification`,
    });
    await payment.save();
    res.status(201).json({
      message: 'UPI payment submitted. Pending admin verification.',
      data: { receiptNumber: payment.receiptNumber, _id: payment._id, status: 'pending_verification' }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/payment/create-order — Razorpay order creation
// Bug 2 fix: this route was missing, causing 404
// =============================================================
router.post('/create-order', async (req, res) => {
  try {
    const key    = process.env.RAZORPAY_KEY_ID;
    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (!key || !secret || key === 'your_razorpay_key_id') {
      return res.status(503).json({ notConfigured: true, message: 'Razorpay is not configured. Please use UPI payment.' });
    }
    const { amount, studentId, academicYear } = req.body;
    if (!amount || amount < 1) return res.status(400).json({ error: 'Valid amount is required.' });

    const Razorpay = require('razorpay');
    const rzp = new Razorpay({ key_id: key, key_secret: secret });
    const order = await rzp.orders.create({
      amount:   Math.round(Number(amount) * 100), // paise
      currency: 'INR',
      receipt:  `rcpt_${studentId || 'stu'}_${Date.now()}`,
      notes:    { studentId: studentId || '', academicYear: academicYear || '' }
    });
    res.json({ data: { ...order, key_id: key } });
  } catch (err) {
    console.error('Razorpay create-order error:', err.message);
    if (err.statusCode === 401) return res.status(503).json({ notConfigured: true, message: 'Razorpay credentials invalid.' });
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/payment/verify-payment — Razorpay payment verification
// =============================================================
router.post('/verify-payment', async (req, res) => {
  try {
    const key    = process.env.RAZORPAY_KEY_ID;
    const secret = process.env.RAZORPAY_KEY_SECRET;
    if (!key || !secret) return res.status(503).json({ notConfigured: true });

    const crypto = require('crypto');
    const { razorpay_payment_id, razorpay_order_id, razorpay_signature, studentId, amount, academicYear } = req.body;

    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSig !== razorpay_signature) {
      return res.status(400).json({ error: 'Payment signature verification failed.' });
    }

    // Find student and record payment
    const _conds2 = [
      { studentId: studentId?.toString().toUpperCase() },
      { admissionNumber: studentId?.toString().toUpperCase() },
    ];
    if (require('mongoose').isValidObjectId(studentId)) _conds2.push({ _id: studentId });
    const student = await Student.findOne({ $or: _conds2 });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const yr = academicYear || currentAcademicYear();
    const payment = new FeePayment({
      studentId:       student.studentId,
      studentName:     student.fullName,
      class:           student.class,
      section:         student.section || 'A',
      admissionNumber: student.admissionNumber || '',
      academicYear:    yr,
      paymentDate:     new Date().toISOString().slice(0, 10),
      feeHeads:        [{ headName: 'Fee Payment (Online)', amount: Number(amount) }],
      totalAmount:     Number(amount),
      paymentMode:     'Online',
      razorpayPaymentId: razorpay_payment_id,
      razorpayOrderId:   razorpay_order_id,
      upiPending:      false,
      upiVerified:     true,
      remarks:         `Razorpay online payment — verified`,
    });
    await payment.save();

    res.json({ data: { receiptNumber: payment.receiptNumber, _id: payment._id, status: 'verified' } });
  } catch (err) {
    console.error('Razorpay verify error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/fee-payments/:id/pdf  — PDF Receipt (pdfkit)
// Accept token from query param for direct browser opens
// =============================================================
router.get('/:id/pdf', (req, res, next) => {
  if (req.query.token && !req.headers.authorization) {
    req.headers.authorization = `Bearer ${req.query.token}`;
  }
  next();
}, auth, adminOnly, async (req, res) => {
  try {
    const payment = await FeePayment.findById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'Receipt not found.' });

    const SchoolSettings = require('../models/SchoolSettings');
    const settingDoc = await SchoolSettings.findOne({ key: 'schoolInfo' }).catch(() => null);
    const school = settingDoc?.value || {};

    let PDFDocument;
    try { PDFDocument = require('pdfkit'); }
    catch(e) {
      return res.status(503).json({ error: 'PDFKit not installed. Run: npm install pdfkit' });
    }

    const doc = new PDFDocument({ size: 'A5', margin: 30 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="Receipt-${payment.receiptNumber}.pdf"`);
    doc.pipe(res);

    const schoolName = school.schoolName || school.name || 'School Portal';
    doc.fontSize(16).font('Helvetica-Bold').text(schoolName, { align: 'center' });
    doc.fontSize(9).font('Helvetica').text(school.schoolAddress || school.address || '', { align: 'center' });
    doc.fontSize(9).text(`Phone: ${school.schoolPhone || school.phone || ''} | Email: ${school.schoolEmail || school.email || ''}`, { align: 'center' });

    doc.moveDown(0.5);
    doc.moveTo(30, doc.y).lineTo(390, doc.y).stroke();
    doc.moveDown(0.5);

    doc.fontSize(13).font('Helvetica-Bold').text('FEE RECEIPT', { align: 'center' });
    doc.moveDown(0.5);

    doc.fontSize(9).font('Helvetica');
    doc.text(`Receipt No: ${payment.receiptNumber}`, 30);
    doc.text(`Date: ${payment.paymentDate}`, 30);
    doc.moveDown(0.5);
    doc.moveTo(30, doc.y).lineTo(390, doc.y).stroke();
    doc.moveDown(0.5);

    doc.font('Helvetica-Bold').text('Student Details', 30);
    doc.font('Helvetica');
    doc.text(`Name: ${payment.studentName}`);
    doc.text(`Class: ${payment.class}${payment.section ? '-' + payment.section : ''}  |  Adm No: ${payment.admissionNumber || '-'}`);
    doc.text(`Academic Year: ${payment.academicYear}`);
    doc.moveDown(0.5);
    doc.moveTo(30, doc.y).lineTo(390, doc.y).stroke();
    doc.moveDown(0.5);

    doc.font('Helvetica-Bold').text('Fee Details', 30);
    doc.moveDown(0.3);
    (payment.feeHeads || []).forEach(h => {
      doc.font('Helvetica').text(h.headName, 30, doc.y, { continued: true });
      doc.text(`Rs. ${Number(h.amount).toLocaleString('en-IN')}`, { align: 'right' });
    });
    if (payment.fineAmount > 0) {
      doc.font('Helvetica').text('Late Fine', 30, doc.y, { continued: true });
      doc.text(`Rs. ${Number(payment.fineAmount).toLocaleString('en-IN')}`, { align: 'right' });
    }
    doc.moveDown(0.3);
    doc.moveTo(30, doc.y).lineTo(390, doc.y).stroke();
    doc.moveDown(0.3);
    doc.font('Helvetica-Bold').fontSize(11);
    doc.text('TOTAL PAID', 30, doc.y, { continued: true });
    doc.text(`Rs. ${Number(payment.totalAmount).toLocaleString('en-IN')}`, { align: 'right' });
    doc.fontSize(9);
    doc.moveDown(0.5);
    doc.moveTo(30, doc.y).lineTo(390, doc.y).stroke();
    doc.moveDown(0.5);

    doc.font('Helvetica');
    doc.text(`Payment Mode: ${payment.paymentMode}`);
    if (payment.chequeNumber) doc.text(`Cheque No: ${payment.chequeNumber} | Bank: ${payment.bankName}`);
    if (payment.utrNumber)    doc.text(`UTR No: ${payment.utrNumber}`);
    if (payment.remarks)      doc.text(`Remarks: ${payment.remarks}`);

    doc.moveDown(1.5);
    doc.text(`Received By: ${payment.receivedBy || 'Admin'}`, 30);
    doc.moveDown(1);
    doc.text('______________________', 250);
    doc.text('Authorised Signature', 255);
    doc.moveDown(0.8);
    doc.fontSize(7).fillColor('gray')
       .text('** This is a computer-generated receipt. No signature required. **', { align: 'center' });

    doc.end();
  } catch (err) {
    console.error('[PDF Receipt]', err.message);
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

module.exports = router;
