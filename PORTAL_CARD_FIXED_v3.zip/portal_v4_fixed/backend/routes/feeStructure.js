// =============================================================
//  routes/feeStructure.js — Fee structure management
//  FIXES APPLIED:
//  1. module.exports moved to END of file (was cutting off fine-rules & installments)
//  2. Specific routes (fine-rules, installments, copy) placed BEFORE wildcard /:cls/:year
//  3. Duplicate currentAcademicYear() → shared utils/academicYear.js
// =============================================================
const router       = require('express').Router();
const FeeStructure = require('../models/FeeStructure');
const FineRule     = require('../models/FineRule');
const InstallmentSchedule = require('../models/InstallmentSchedule');
const { auth, adminOnly } = require('../middleware/auth');

// ✅ FIX: Shared utility
const { currentAcademicYear } = require('../utils/academicYear');

// ── GET /api/fee-structure/public — PUBLIC (no auth needed) ──
// Admission page pe show karne ke liye — sirf current year ka data
// Auth nahi chahiye, parents directly dekh sakte hain
router.get('/public', async (req, res) => {
  try {
    const yr = req.query.year || currentAcademicYear();
    const structures = await FeeStructure.find({ academicYear: yr })
      .sort({ class: 1 })
      .lean();

    // Class order: LKG, UKG, 1-12
    const classOrder = ['LKG','UKG','Nursery','1','2','3','4','5','6','7','8','9','10','11','12'];
    structures.sort((a, b) => {
      const ai = classOrder.indexOf(a.class);
      const bi = classOrder.indexOf(b.class);
      return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
    });

    res.json({ academicYear: yr, structures });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/fee-structure — list all (optionally filter) ────
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const filter = {};
    if (req.query.academicYear) filter.academicYear = req.query.academicYear;
    if (req.query.class)        filter.class        = req.query.class;
    const data = await FeeStructure.find(filter).sort({ academicYear: -1, class: 1 });
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/fee-structure — create or update ────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, class: cls, feeHeads } = req.body;
    if (!academicYear || !cls || !Array.isArray(feeHeads)) {
      return res.status(400).json({ error: 'academicYear, class, and feeHeads[] are required.' });
    }
    const mult  = { monthly: 12, quarterly: 4, annually: 1, 'one-time': 1 };
    const total = feeHeads.reduce((s, h) => s + Number(h.amount || 0) * (mult[h.frequency] || 1), 0);
    const data = await FeeStructure.findOneAndUpdate(
      { academicYear, class: cls },
      { feeHeads, totalAnnualFee: total },
      { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
    );
    res.json({ message: 'Fee structure saved.', data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// SPECIFIC ROUTES — MUST come BEFORE wildcard /:cls/:year
// =============================================================

// ── POST /api/fee-structure/copy ─────────────────────────────
router.post('/copy', auth, adminOnly, async (req, res) => {
  try {
    const { fromYear, toYear } = req.body;
    if (!fromYear || !toYear) return res.status(400).json({ error: 'fromYear and toYear required.' });
    const structures = await FeeStructure.find({ academicYear: fromYear });
    if (!structures.length) return res.status(404).json({ error: `No fee structures found for ${fromYear}.` });
    const mult = { monthly: 12, quarterly: 4, annually: 1, 'one-time': 1 };
    let copied = 0;
    for (const s of structures) {
      const total = s.feeHeads.reduce((sum, h) => sum + h.amount * (mult[h.frequency] || 1), 0);
      await FeeStructure.findOneAndUpdate(
        { academicYear: toYear, class: s.class },
        { feeHeads: s.feeHeads.toObject ? s.feeHeads.toObject() : s.feeHeads, totalAnnualFee: total },
        { upsert: true, new: true }
      );
      copied++;
    }
    res.json({ message: `Copied ${copied} class structures from ${fromYear} to ${toYear}.`, copied });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET/POST /api/fee-structure/fine-rules/:year ─────────────
router.get('/fine-rules/:year', auth, adminOnly, async (req, res) => {
  try {
    const rule = await FineRule.findOne({ academicYear: req.params.year });
    if (!rule) return res.json({ data: null });
    res.json({ data: rule });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/fine-rules/:year', auth, adminOnly, async (req, res) => {
  try {
    const { graceDays, fineType, amount, percentage, per, autoApply, showSeparately } = req.body;
    const rule = await FineRule.findOneAndUpdate(
      { academicYear: req.params.year },
      { graceDays, fineType, amount, percentage, per, autoApply, showSeparately },
      { upsert: true, new: true }
    );
    res.json({ message: 'Fine rules saved.', data: rule });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ── GET/POST /api/fee-structure/installments/:year ───────────
router.get('/installments/:year', auth, adminOnly, async (req, res) => {
  try {
    const year = req.params.year;
    let sched = await InstallmentSchedule.findOne({ academicYear: year });
    if (!sched) {
      const startYr = parseInt(year.split('-')[0]) || new Date().getFullYear();
      const defaultTerms = [
        { name: 'Term 1 (April)',   dueDate: `${startYr}-04-10`,     percentage: 25 },
        { name: 'Term 2 (July)',    dueDate: `${startYr}-07-10`,     percentage: 25 },
        { name: 'Term 3 (October)', dueDate: `${startYr}-10-10`,    percentage: 25 },
        { name: 'Term 4 (January)', dueDate: `${startYr + 1}-01-10`, percentage: 25 },
      ];
      sched = await InstallmentSchedule.create({ academicYear: year, terms: defaultTerms });
    }
    res.json({ data: sched.terms });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/installments/:year', auth, adminOnly, async (req, res) => {
  try {
    const terms = Array.isArray(req.body) ? req.body : req.body.terms;
    if (!terms) return res.status(400).json({ error: 'terms array required.' });
    const sched = await InstallmentSchedule.findOneAndUpdate(
      { academicYear: req.params.year },
      { terms },
      { upsert: true, new: true }
    );
    res.json({ message: 'Installment schedule saved.', data: sched.terms });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// WILDCARD ROUTES — AFTER specific routes
// =============================================================

// ── GET /api/fee-structure/:cls/:year ─────────────────────────
router.get('/:cls/:year', auth, adminOnly, async (req, res) => {
  try {
    const data = await FeeStructure.findOne({
      class:        req.params.cls,
      academicYear: req.params.year,
    });
    if (!data) return res.status(404).json({ error: 'Fee structure not found.' });
    res.json({ data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/fee-structure/:cls/:year ─────────────────────
router.delete('/:cls/:year', auth, adminOnly, async (req, res) => {
  try {
    await FeeStructure.findOneAndDelete({ class: req.params.cls, academicYear: req.params.year });
    res.json({ message: 'Fee structure deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
