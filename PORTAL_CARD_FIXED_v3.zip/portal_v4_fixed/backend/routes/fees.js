// =============================================================
//  routes/fees.js — DEPRECATED / LEGACY FILE
//
//  ⚠️  YEH FILE PURANI HAI — USE MAT KARO
//
//  PROBLEM: Do alag fee systems chal rahe the:
//    - fees.js       → Fees model (purana, simple)
//    - feePayments.js → FeePayment model (naya, complete)
//  Dono alag MongoDB collections the, data split ho raha tha.
//
//  FIX: Ab saare calls feePayments.js pe redirect ho rahe hain.
//
//  server.js/app.js mein:
//    ✅ RAKHO:  app.use('/api/fee-payments', require('./routes/feePayments'));
//    ❌ HATAO:  app.use('/api/fees', require('./routes/fees'));   ← yeh line
//
//  Frontend mein migrate karo:
//    /api/fees/add        → POST /api/fee-payments
//    /api/fees/:studentId → GET  /api/fee-payments/student/:studentId
// =============================================================

const router   = require('express').Router();
const { auth } = require('../middleware/auth');

const DEPRECATED = (newRoute) => (req, res) =>
  res.status(410).json({
    error:   'This endpoint is deprecated.',
    message: `Use ${newRoute} instead.`,
    migrate: true,
  });

router.get('/:studentId',   auth, DEPRECATED('GET /api/fee-payments/student/:studentId'));
router.post('/add',         auth, DEPRECATED('POST /api/fee-payments'));
router.put('/:id/status',   auth, DEPRECATED('PUT /api/fee-payments/:id'));
router.post('/create-order',   auth, DEPRECATED('POST /api/fee-payments/create-order'));
router.post('/verify-payment', auth, DEPRECATED('POST /api/fee-payments/verify-payment'));

module.exports = router;
