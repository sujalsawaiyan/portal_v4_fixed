// =============================================================
//  routes/gallery.js — Gallery CRUD + Cloudinary
//  Base path: /api/gallery
//  SCHOOL PORTAL
// =============================================================
const router  = require('express').Router();
const multer  = require('multer');
const Gallery = require('../models/Gallery');
const { auth, adminOnly } = require('../middleware/auth');
const { uploadToCloudinary: _uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');

// ── Multer: disk storage (we pipe to Cloudinary via util) ────
const path = require('path');
const fs   = require('fs');
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, tmpDir),
    filename:    (_req,  file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg';
      cb(null, 'gallery_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files are allowed'), false);
    }
    cb(null, true);
  },
});

// ── GET /api/gallery — list (public) ─────────────────────────
router.get('/', async (req, res) => {
  try {
    const { category } = req.query;
    const filter = { isActive: true };
    if (category && category !== 'all') filter.category = category;

    const items = await Gallery.find(filter).sort({ order: 1, createdAt: -1 });
    res.json({ data: items, total: items.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gallery/upload — upload image (admin) ───────────
// Accepts multipart OR JSON (url already uploaded)
router.post('/upload', auth, adminOnly, upload.single('image'), async (req, res) => {
  try {
    const { title, category, emoji, order } = req.body;
    if (!title) return res.status(400).json({ error: 'title is required.' });

    let imageUrl = '';
    let cloudinaryId = '';

    if (req.file) {
      // Real image upload → Cloudinary via shared util
      try {
        const result = await _uploadToCloudinary(req.file.path, 'gallery');
        imageUrl     = result.url;
        cloudinaryId = result.publicId;
      } catch (cErr) {
        console.warn('[Gallery] Cloudinary upload failed:', cErr.message);
        return res.status(503).json({
          error: 'Image upload failed. Check Cloudinary config in .env',
        });
      }
    } else if (req.body.url) {
      imageUrl = req.body.url;
    }

    const item = await Gallery.create({
      title:        title.trim(),
      category:     category || 'general',
      url:          imageUrl,
      cloudinaryId: cloudinaryId,
      emoji:        emoji || '🖼️',
      order:        Number(order || 0),
    });

    res.status(201).json({ message: 'Gallery item added.', data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/gallery — create with URL (admin) ───────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { title, category, url, emoji, order } = req.body;
    if (!title) return res.status(400).json({ error: 'title is required.' });

    const item = await Gallery.create({
      title:    title.trim(),
      category: category || 'general',
      url:      url || '',
      emoji:    emoji || '🖼️',
      order:    Number(order || 0),
    });
    res.status(201).json({ message: 'Gallery item added.', data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/gallery/:id — update (admin) ────────────────────
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = ['title', 'category', 'url', 'emoji', 'order', 'isActive'];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    const item = await Gallery.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!item) return res.status(404).json({ error: 'Gallery item not found.' });
    res.json({ message: 'Gallery item updated.', data: item });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/gallery/:id — delete + Cloudinary cleanup (admin)
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const item = await Gallery.findById(req.params.id);
    if (!item) return res.status(404).json({ error: 'Gallery item not found.' });

    // Delete from Cloudinary if we have the public_id
    if (item.cloudinaryId) {
      try {
        await deleteFromCloudinary(item.cloudinaryId);
      } catch (cErr) {
        console.warn('[Gallery] Cloudinary delete failed:', cErr.message);
      }
    }

    await Gallery.findByIdAndDelete(req.params.id);
    res.json({ message: 'Gallery item deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
