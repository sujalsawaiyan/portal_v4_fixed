// =============================================================
//  routes/houses.js — Houses CRUD API v2.2.0
//  Base path: /api/houses
//  SCHOOL PORTAL
//
//  ✅ FIXED v2.2.0:
//    - DELETE now cleans up Cloudinary logo (logoPublicId)
//    - HouseImage collection also cleaned on DELETE
// =============================================================
const router = require('express').Router();
const path   = require('path');
const fs     = require('fs');
const multer = require('multer');
const House  = require('../models/House');
const { auth, adminOnly } = require('../middleware/auth');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');

// ── Multer temp storage ───────────────────────────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const _upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, tmpDir),
    filename:    (_req,  file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg';
      cb(null, 'house_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
    },
  }),
  limits:     { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ['image/jpeg','image/jpg','image/png','image/webp','image/svg+xml'];
    cb(ok.includes(file.mimetype) ? null : new Error('Only image files allowed.'), ok.includes(file.mimetype));
  },
});



// ── Also import HouseImage model for cleanup ──────────────────
let HouseImage;
try {
  const models = require('../models/SchoolImages');
  HouseImage = models.HouseImage;
} catch (_) {}

// ── GET /api/houses — list all (public) ──────────────────────
router.get('/', async (req, res) => {
  try {
    const houses = await House.find({ isActive: true });
    const sorted = houses.slice().sort((a, b) => b.points - a.points);
    res.json({ data: sorted, total: sorted.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/houses/:id ───────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const house = await House.findById(req.params.id);
    if (!house) return res.status(404).json({ error: 'House not found.' });
    res.json({ data: house });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/houses — create (admin) ────────────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required.' });

    const house = await House.create({
      id:           req.body.id || 0,
      name,
      color:        req.body.color       || '#6C63FF',
      gradient:     req.body.gradient    || '',
      emoji:        req.body.emoji       || '',
      captain:      req.body.captain     || '',
      viceCaptain:  req.body.viceCaptain || '',
      sports:       Number(req.body.sports      || 0),
      study:        Number(req.body.study       || 0),
      activities:   Number(req.body.activities  || 0),
      discipline:   Number(req.body.discipline  || 0),
      contributors: req.body.contributors || [],
    });
    res.status(201).json({ message: 'House created.', data: house });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════
//  PUT /api/houses/bulk/replace — MUST BE BEFORE /:id
// ══════════════════════════════════════════════════════════════
router.put('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { houses } = req.body;
    if (!Array.isArray(houses)) {
      return res.status(400).json({ error: 'houses array required.' });
    }
    if (!houses.length) {
      return res.status(400).json({ error: 'houses array cannot be empty.' });
    }

    const incomingNames = houses.map(h => (h.name || '').trim()).filter(Boolean);

    const bulkOps = houses.map((h, i) => ({
      updateOne: {
        filter: { name: (h.name || '').trim() },
        update: {
          $set: {
            id:           h.id || i + 1,
            name:         (h.name || '').trim(),
            color:        h.color        || '#6C63FF',
            gradient:     h.gradient     || '',
            emoji:        h.emoji        || '',
            tagline:      h.tagline      || '',
            captain:      h.captain      || '',
            viceCaptain:  h.viceCaptain  || '',
            sports:       Number(h.sports      || 0),
            study:        Number(h.study       || 0),
            activities:   Number(h.activities  || 0),
            discipline:   Number(h.discipline  || 0),
            logo:         h.logo         || '',
            logoPublicId: h.logoPublicId || '',
            contributors: h.contributors || [],
            isActive:     true,
          },
        },
        upsert: true,
      },
    }));

    await House.bulkWrite(bulkOps, { ordered: false });

    // Soft-delete houses NOT in this save
    await House.updateMany(
      { name: { $nin: incomingNames } },
      { $set: { isActive: false } }
    );

    const all    = await House.find({ isActive: true });
    const sorted = all.slice().sort((a, b) => b.points - a.points);
    res.json({ message: 'Houses saved safely.', total: sorted.length, data: sorted });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/houses/:id — update (admin) ─────────────────────
//  ⚠️ Intentionally placed AFTER /bulk/replace
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = [
      'name', 'color', 'gradient', 'emoji', 'tagline',
      'captain', 'viceCaptain',
      'sports', 'study', 'activities', 'discipline',
      'logo', 'logoPublicId', 'contributors',
    ];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    // ✅ FIXED: If logo is being replaced, delete old Cloudinary image
    if (updates.logo !== undefined) {
      const existing = await House.findById(req.params.id);
      if (existing && existing.logoPublicId && existing.logo !== updates.logo) {
        await deleteFromCloudinary(existing.logoPublicId).catch(() => {});
        if (!updates.logoPublicId) updates.logoPublicId = '';
      }
    }

    const house = await House.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!house) return res.status(404).json({ error: 'House not found.' });
    res.json({ message: 'House updated.', data: house });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/houses/:id (admin) ───────────────────────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const house = await House.findById(req.params.id);
    if (!house) return res.status(404).json({ error: 'House not found.' });

    // ✅ FIXED: Delete Cloudinary logo before removing house record
    if (house.logoPublicId) {
      await deleteFromCloudinary(house.logoPublicId).catch(err =>
        console.warn('[Cloudinary] Failed to delete house logo:', err.message)
      );
    }

    // ✅ Also clean up HouseImage collection if it exists
    if (HouseImage) {
      const hi = await HouseImage.findOne({ houseId: req.params.id });
      if (hi && hi.publicId && hi.publicId !== house.logoPublicId) {
        await deleteFromCloudinary(hi.publicId).catch(() => {});
      }
      await HouseImage.deleteOne({ houseId: req.params.id }).catch(() => {});
    }

    await house.deleteOne();
    res.json({ message: 'House deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/houses/:id/logo — upload/replace house logo ──────
router.post('/:id/logo', auth, adminOnly, _upload.single('logo'), async (req, res) => {
  try {
    const house = await House.findById(req.params.id);
    if (!house) return res.status(404).json({ error: 'House not found.' });

    if (!req.file) return res.status(400).json({ error: 'No image file. Field name must be "logo".' });

    // Delete old Cloudinary logo if exists
    if (house.logoPublicId) {
      await deleteFromCloudinary(house.logoPublicId).catch(() => {});
    }

    const { url: logoUrl, publicId } = await uploadToCloudinary(req.file.path, 'houses');

    await House.findByIdAndUpdate(req.params.id, {
      logo:        logoUrl,
      logoPublicId: publicId,
    });

    // Sync HouseImage collection if exists
    if (HouseImage) {
      const existing = await HouseImage.findOne({ houseId: req.params.id });
      if (existing && existing.publicId && existing.publicId !== publicId) {
        await deleteFromCloudinary(existing.publicId).catch(() => {});
      }
      await HouseImage.findOneAndUpdate(
        { houseId: req.params.id },
        { imageUrl: logoUrl, publicId, filename: publicId, uploadedAt: new Date() },
        { upsert: true }
      );
    }

    res.json({ message: 'Logo uploaded.', logoUrl, publicId });
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) { try { fs.unlinkSync(req.file.path); } catch (_) {} }
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/houses/:id/logo — remove house logo ────────────
router.delete('/:id/logo', auth, adminOnly, async (req, res) => {
  try {
    const house = await House.findById(req.params.id);
    if (!house) return res.status(404).json({ error: 'House not found.' });

    if (house.logoPublicId) {
      await deleteFromCloudinary(house.logoPublicId).catch(() => {});
    }
    await House.findByIdAndUpdate(req.params.id, { logo: '', logoPublicId: '' });

    if (HouseImage) {
      await HouseImage.deleteOne({ houseId: req.params.id }).catch(() => {});
    }

    res.json({ message: 'Logo removed.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
