// =============================================================
//  imageRoutes.js — Image Upload / Update / Delete API Routes v2.2.0
//  SCHOOL PORTAL
//
//  ✅ FIXED v2.2.0: Removed duplicate auth function (wrong JWT secret)
//  ✅ FIXED v2.2.0: Added adminOnly to DELETE/PUT (students/parents blocked)
//
//  POST   /api/images/upload/:category     — upload new image
//  GET    /api/images/:category            — get image(s) for a category
//  DELETE /api/images/:category/:id        — delete image from Cloudinary + DB
// =============================================================

const router  = require('express').Router();
const multer  = require('multer');
const path    = require('path');
const fs      = require('fs');

const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');
const {
  SchoolImage, GalleryItem, TeacherPhoto,
  EventImage, TopStudentImage, HouseImage
} = require('../models/SchoolImages');

// Import models to sync photo fields
const Teacher = require('../models/Teacher');
const Event   = require('../models/Event');
const House   = require('../models/House');


const ALLOWED_CATEGORIES = [
  'logo', 'principal', 'banners', 'teachers',
  'class-teachers', 'leadership', 'events',
  'gallery', 'students', 'houses', 'house-logo'
];

// ── Auth middleware (shared — fixes JWT secret mismatch) ─────
const { auth, adminOnly } = require('../middleware/auth');

// ── Multer: store in uploads/tmp temporarily ──────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, tmpDir),
  filename:    (req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB — matches gallery UI
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|svg/i;
    if (allowed.test(path.extname(file.originalname)) && allowed.test(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed (JPG, PNG, GIF, WebP, SVG)'));
    }
  },
});

// =============================================================
// DELETE /api/images/delete-by-public-id/:publicId
// Deletes an image from Cloudinary by publicId (URL-encoded).
// Called by imageUploadManager.deleteFromCloudinary().
// =============================================================
router.delete('/delete-by-public-id/:publicId', auth, adminOnly, async (req, res) => {
  try {
    const publicId = decodeURIComponent(req.params.publicId);
    if (!publicId) return res.status(400).json({ error: 'publicId required' });
    await deleteFromCloudinary(publicId);
    res.json({ success: true, message: 'Image deleted from Cloudinary' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// DELETE /api/images/:category — remove a single-image category
// (logo, principal, banners)
// =============================================================
router.delete('/:category', auth, adminOnly, async (req, res) => {
  const { category } = req.params;
  const singleCategories = ['logo', 'principal', 'banners'];
  if (!singleCategories.includes(category)) {
    return res.status(400).json({ error: 'Use /:category/:id for multi-item categories' });
  }
  try {
    const doc = await SchoolImage.findOne({ category });
    if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
    await SchoolImage.findOneAndUpdate({ category }, { imageUrl: '', publicId: '', filename: '' });
    res.json({ success: true, message: category + ' image removed' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Upload to Cloudinary misc folder — NO DB save, just returns URL + publicId.
// Used by admin panel when entity ID is not yet known (e.g. before teacher is saved).
// =============================================================
router.post('/upload/temp', auth, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file received. Field name must be "image".' });
    }

    const category = req.body.category || 'misc';
    const { url: imageUrl, publicId } = await uploadToCloudinary(req.file.path, category);

    res.status(201).json({ success: true, imageUrl, publicId, secure_url: imageUrl, public_id: publicId });
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
    }
    console.error('[uploadTemp] Error:', err.message);
    res.status(500).json({ error: err.message || 'Upload failed' });
  }
});

// =============================================================
// POST /api/images/upload/:category
// =============================================================
router.post('/upload/:category', auth, (req, res, next) => {
  const { category } = req.params;
  if (!ALLOWED_CATEGORIES.includes(category)) {
    return res.status(400).json({ error: `Invalid category. Allowed: ${ALLOWED_CATEGORIES.join(', ')}` });
  }
  next();
}, upload.single('image'), async (req, res) => {
  try {
    const { category } = req.params;

    if (!req.file) {
      return res.status(400).json({ error: 'No image file received. Field name must be "image".' });
    }

    // Upload to Cloudinary (also deletes local tmp file)
    const { url: imageUrl, publicId } = await uploadToCloudinary(req.file.path, category);

    // ── Gallery ───────────────────────────────────────────────
    if (category === 'gallery') {
      const title = req.body.title || 'Gallery Photo';
      const doc = await GalleryItem.create({
        title,
        category:   req.body.subCategory || 'other',
        emoji:      req.body.emoji || '🖼️',
        imageUrl,
        publicId,
        filename:   publicId,
        uploadedBy: req.user?.username || 'admin',
      });
      return res.status(201).json({ success: true, imageUrl, publicId, id: doc._id, doc });
    }

    // ── Teachers / Class-Teachers / Leadership ────────────────
    if (['teachers', 'class-teachers', 'leadership'].includes(category)) {
      const teacherId = req.body.teacherId;
      if (!teacherId) {
        return res.status(400).json({ error: 'teacherId is required for teacher uploads' });
      }

      // Delete old Cloudinary image
      const existing = await TeacherPhoto.findOne({ teacherId });
      if (existing && existing.publicId) await deleteFromCloudinary(existing.publicId);

      await TeacherPhoto.findOneAndUpdate(
        { teacherId },
        { imageUrl, publicId, filename: publicId, uploadedAt: new Date() },
        { upsert: true, new: true }
      );

      // ✅ Sync Teacher.photo field so /api/teachers returns Cloudinary URL
      await Teacher.findByIdAndUpdate(teacherId, { photo: imageUrl }).catch(() => {});

      return res.status(201).json({ success: true, imageUrl, publicId, teacherId });
    }

    // ── Events ────────────────────────────────────────────────
    if (category === 'events') {
      const eventId = req.body.eventId;
      if (!eventId) {
        return res.status(400).json({ error: 'eventId is required for event uploads' });
      }

      const existing = await EventImage.findOne({ eventId });
      if (existing && existing.publicId) await deleteFromCloudinary(existing.publicId);

      await EventImage.findOneAndUpdate(
        { eventId },
        { imageUrl, publicId, filename: publicId, uploadedAt: new Date() },
        { upsert: true, new: true }
      );

      // ✅ Sync Event.image field
      await Event.findByIdAndUpdate(eventId, { image: imageUrl }).catch(() => {});

      return res.status(201).json({ success: true, imageUrl, publicId, eventId });
    }

    // ── Students (top students by rank) ───────────────────────
    if (category === 'students') {
      const rank = parseInt(req.body.rank);
      if (!rank) {
        return res.status(400).json({ error: 'rank (number) is required for student uploads' });
      }

      const existing = await TopStudentImage.findOne({ rank });
      if (existing && existing.publicId) await deleteFromCloudinary(existing.publicId);

      await TopStudentImage.findOneAndUpdate(
        { rank },
        { imageUrl, publicId, filename: publicId, uploadedAt: new Date() },
        { upsert: true, new: true }
      );

      return res.status(201).json({ success: true, imageUrl, publicId, rank });
    }

    // ── Houses ────────────────────────────────────────────────
    if (category === 'houses' || category === 'house-logo') {
      const houseId = req.body.houseId;

      if (houseId) {
        // Full save: update HouseImage + House model
        const existing = await HouseImage.findOne({ houseId });
        if (existing && existing.publicId) await deleteFromCloudinary(existing.publicId);

        await HouseImage.findOneAndUpdate(
          { houseId },
          { imageUrl, publicId, filename: publicId, uploadedAt: new Date() },
          { upsert: true, new: true }
        );

        // ✅ Sync House.logo field
        await House.findByIdAndUpdate(houseId, { logo: imageUrl, logoPublicId: publicId }).catch(() => {});

        return res.status(201).json({ success: true, imageUrl, publicId, houseId });
      } else {
        // Temp upload (no houseId yet) — just return URL, frontend saves on house update
        return res.status(201).json({ success: true, imageUrl, publicId, category: 'house-logo' });
      }
    }

    // ── Single-image categories: logo, principal, banners ─────
    const existing = await SchoolImage.findOne({ category });
    if (existing && existing.publicId) await deleteFromCloudinary(existing.publicId);

    await SchoolImage.findOneAndUpdate(
      { category },
      { imageUrl, publicId, filename: publicId, uploadedAt: new Date(), uploadedBy: req.user?.username || 'admin' },
      { upsert: true, new: true }
    );

    res.status(201).json({ success: true, imageUrl, publicId, category });

  } catch (err) {
    // Clean up uploaded tmp file on error
    if (req.file && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
    }
    console.error('[uploadImage] Error:', err.message);
    res.status(500).json({ error: err.message || 'Upload failed' });
  }
});

// =============================================================
// GET /api/images/:category
// =============================================================
router.get('/:category', async (req, res) => {
  const { category } = req.params;

  try {
    if (category === 'gallery') {
      // v2.3.0: merge GalleryItem (SchoolImages) + Gallery model so both sources show
      const Gallery = require('../models/Gallery');
      const [itemsA, itemsB] = await Promise.all([
        GalleryItem.find({}).sort({ createdAt: -1 }).lean(),
        Gallery.find({ isActive: true }).sort({ createdAt: -1 }).lean(),
      ]);
      // Normalize Gallery model docs to match GalleryItem shape (url → imageUrl)
      const normalized = itemsB.map(d => ({
        ...d,
        imageUrl: d.imageUrl || d.url || '',
        publicId: d.publicId || d.cloudinaryId || '',
      }));
      // Combine, deduplicate by imageUrl
      const seen = new Set();
      const combined = [...itemsA, ...normalized].filter(d => {
        const key = d.imageUrl || d._id.toString();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      return res.json({ success: true, data: combined });
    }

    if (['teachers', 'class-teachers', 'leadership'].includes(category)) {
      const items = await TeacherPhoto.find({});
      return res.json({ success: true, data: items });
    }

    if (category === 'events') {
      const items = await EventImage.find({});
      return res.json({ success: true, data: items });
    }

    if (category === 'students') {
      const items = await TopStudentImage.find({}).sort({ rank: 1 });
      return res.json({ success: true, data: items });
    }

    if (category === 'houses') {
      const items = await HouseImage.find({});
      return res.json({ success: true, data: items });
    }

    // Single-image categories
    const doc = await SchoolImage.findOne({ category });
    res.json({ success: true, imageUrl: doc?.imageUrl || '', publicId: doc?.publicId || '' });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// DELETE /api/images/:category/:id
// =============================================================
router.delete('/:category/:id', auth, adminOnly, async (req, res) => {
  const { category, id } = req.params;

  try {
    if (category === 'gallery') {
      const doc = await GalleryItem.findById(id);
      if (!doc) return res.status(404).json({ error: 'Gallery item not found' });
      if (doc.publicId) await deleteFromCloudinary(doc.publicId);
      await GalleryItem.findByIdAndDelete(id);
      return res.json({ success: true, message: 'Gallery photo deleted' });
    }

    if (['teachers', 'class-teachers', 'leadership'].includes(category)) {
      const doc = await TeacherPhoto.findOne({ teacherId: id });
      if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
      await TeacherPhoto.deleteOne({ teacherId: id });
      // Clear Teacher.photo field
      await Teacher.findByIdAndUpdate(id, { photo: '' }).catch(() => {});
      return res.json({ success: true, message: 'Teacher photo deleted' });
    }

    if (category === 'events') {
      const doc = await EventImage.findOne({ eventId: id });
      if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
      await EventImage.deleteOne({ eventId: id });
      await Event.findByIdAndUpdate(id, { image: '' }).catch(() => {});
      return res.json({ success: true, message: 'Event image deleted' });
    }

    if (category === 'students') {
      const doc = await TopStudentImage.findOne({ rank: parseInt(id) });
      if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
      await TopStudentImage.deleteOne({ rank: parseInt(id) });
      return res.json({ success: true, message: 'Student photo deleted' });
    }

    if (category === 'houses') {
      const doc = await HouseImage.findOne({ houseId: id });
      if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
      await HouseImage.deleteOne({ houseId: id });
      await House.findByIdAndUpdate(id, { logo: '' }).catch(() => {});
      return res.json({ success: true, message: 'House logo deleted' });
    }

    // Single-image categories
    const doc = await SchoolImage.findOne({ category });
    if (doc && doc.publicId) await deleteFromCloudinary(doc.publicId);
    await SchoolImage.findOneAndUpdate({ category }, { imageUrl: '', publicId: '', filename: '' });
    res.json({ success: true, message: `${category} image deleted` });

  } catch (err) {
    console.error('[deleteImage] Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// PUT /api/images/gallery/:id — update gallery item metadata
// =============================================================
router.put('/gallery/:id', auth, adminOnly, upload.single('image'), async (req, res) => {
  try {
    const doc = await GalleryItem.findById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Gallery item not found' });

    const updates = {};
    if (req.body.title)       updates.title    = req.body.title;
    if (req.body.subCategory) updates.category = req.body.subCategory;
    if (req.body.emoji)       updates.emoji    = req.body.emoji;

    if (req.file) {
      // Delete old Cloudinary image
      if (doc.publicId) await deleteFromCloudinary(doc.publicId);
      // Upload new image
      const { url: imageUrl, publicId } = await uploadToCloudinary(req.file.path, 'gallery');
      updates.imageUrl   = imageUrl;
      updates.publicId   = publicId;
      updates.filename   = publicId;
      updates.uploadedAt = new Date();
    }

    const updated = await GalleryItem.findByIdAndUpdate(req.params.id, updates, { new: true });
    res.json({ success: true, doc: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Multer error handler
router.use((err, _req, res, _next) => {
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Maximum size is 5MB.' });
  }
  res.status(500).json({ error: err.message || 'Upload error' });
});

module.exports = router;
