// =============================================================
//  routes/ledger.js — Bank-Statement Style Fee Ledger
//  Charges (debit) + Payments (credit) with running balance
//  FIX: Duplicate currentAcademicYear() → shared utils/academicYear.js
// =============================================================
const router      = require('express').Router();
const LedgerEntry = require('../models/LedgerEntry');
const Student     = require('../models/Student');
const { auth, adminOnly } = require('../middleware/auth');

// ✅ FIX: Shared utility — duplicate function hataya
const { currentAcademicYear } = require('../utils/academicYear');

// ── Helper: recalculate running balances for a student ───────
// Called after every insert / update / delete.
// Processes entries in ascending date order; balance increases on
// "charge" and decreases on "payment".
async function recalcBalances(studentId, academicYear) {
  const entries = await LedgerEntry.find({
    studentId,
    academicYear,
    isDeleted: false,
  }).sort({ date: 1, createdAt: 1 });

  let running = 0;
  const bulkOps = entries.map(e => {
    running = e.type === 'charge'
      ? running + e.amount
      : running - e.amount;
    return {
      updateOne: {
        filter: { _id: e._id },
        update: { $set: { balance: running } },
      },
    };
  });

  if (bulkOps.length) await LedgerEntry.bulkWrite(bulkOps);
  return running; // final balance = outstanding due
}

// ── Helper: auto receipt number for payments ─────────────────
async function nextReceiptNo(academicYear) {
  const year   = (academicYear || currentAcademicYear()).split('-')[0];
  const prefix = `LED-${year}-`;
  const last   = await LedgerEntry.findOne({
    receiptNumber: new RegExp(`^${prefix}`),
  }).sort({ receiptNumber: -1 });
  const n = last ? parseInt(last.receiptNumber.replace(prefix, ''), 10) + 1 : 1;
  return `${prefix}${String(n).padStart(4, '0')}`;
}

// =============================================================
// ── GET /api/ledger/student/:studentId
//    Full ledger for a student (admin or the student themselves)
// =============================================================
router.get('/student/:studentId', auth, async (req, res) => {
  try {
    const sid = req.params.studentId.toUpperCase();

    // Students and parents can only see their own ledger
    if (req.user.role === 'student' && req.user.studentId !== sid) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    if (req.user.role === 'parent' && req.user.studentId !== sid) {
      return res.status(403).json({ error: 'Access denied. You can only view your own child\'s records.' });
    }

    const academicYear = req.query.academicYear || currentAcademicYear();

    const student = await Student.findOne({ studentId: sid });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const entries = await LedgerEntry.find({
      studentId: sid,
      academicYear,
      isDeleted: false,
    }).sort({ date: 1, createdAt: 1 });

    // Compute summary
    const totalCharged = entries
      .filter(e => e.type === 'charge')
      .reduce((s, e) => s + e.amount, 0);
    const totalPaid = entries
      .filter(e => e.type === 'payment')
      .reduce((s, e) => s + e.amount, 0);
    const currentBalance = entries.length
      ? entries[entries.length - 1].balance
      : 0;

    // Month-wise breakdown: previous due + current month fees
    const monthMap = {};
    for (const e of entries) {
      const mon = e.month || e.date.slice(0, 7);
      if (!monthMap[mon]) monthMap[mon] = { charged: 0, paid: 0 };
      if (e.type === 'charge')  monthMap[mon].charged += e.amount;
      if (e.type === 'payment') monthMap[mon].paid    += e.amount;
    }

    // Current month info
    const currentMonth = new Date().toISOString().slice(0, 7);
    const prevDue      = entries.length
      ? entries.filter(e => e.date < currentMonth + '-01' && e.type === 'charge')
               .reduce((s, e) => s + e.amount, 0) -
        entries.filter(e => e.date < currentMonth + '-01' && e.type === 'payment')
               .reduce((s, e) => s + e.amount, 0)
      : 0;
    const currentMonthFees = entries
      .filter(e => (e.month || e.date.slice(0, 7)) === currentMonth && e.type === 'charge')
      .reduce((s, e) => s + e.amount, 0);
    const currentMonthPaid = entries
      .filter(e => (e.month || e.date.slice(0, 7)) === currentMonth && e.type === 'payment')
      .reduce((s, e) => s + e.amount, 0);

    res.json({
      student,
      entries,
      summary: {
        totalCharged,
        totalPaid,
        currentBalance,   // outstanding due (positive = owe money)
        prevDue:          Math.max(0, prevDue),
        currentMonthFees,
        currentMonthPaid,
        totalPayable:     Math.max(0, prevDue) + currentMonthFees,
        remainingDue:     currentBalance,
      },
      monthMap,
      academicYear,
    });
  } catch (err) {
    console.error('[Ledger] GET student error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── POST /api/ledger/charge — Add a fee charge (admin only)
// =============================================================
router.post('/charge', auth, adminOnly, async (req, res) => {
  try {
    const {
      studentId, amount, date, description,
      month, academicYear, remarks,
    } = req.body;

    if (!studentId || !amount || !description) {
      return res.status(400).json({ error: 'studentId, amount, description required.' });
    }

    const sid     = studentId.toUpperCase();
    const student = await Student.findOne({ studentId: sid });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const year = academicYear || currentAcademicYear();

    const entry = await LedgerEntry.create({
      studentId:   sid,
      studentName: student.fullName,
      class:       student.class,
      section:     student.section || 'A',
      academicYear: year,
      type:        'charge',
      amount:      Number(amount),
      date:        date || new Date().toISOString().slice(0, 10),
      description,
      month:       month || (date || new Date().toISOString().slice(0, 7)).slice(0, 7),
      remarks:     remarks || '',
      createdBy:   req.user?.username || req.user?.name || 'Admin',
    });

    await recalcBalances(sid, year);

    // Return updated entry with correct balance
    const updated = await LedgerEntry.findById(entry._id);
    res.status(201).json({ message: 'Charge added.', data: updated });
  } catch (err) {
    console.error('[Ledger] POST charge error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── POST /api/ledger/payment — Record a payment (admin only)
// Auto-sends WhatsApp payment confirmation to parent
// =============================================================
const { sendFeesPaymentReceived, getLedgerSummary } = require('../utils/whatsappService');

router.post('/payment', auth, adminOnly, async (req, res) => {
  try {
    const {
      studentId, amount, date, description, method,
      chequeNumber, bankName, month, academicYear, remarks,
    } = req.body;

    if (!studentId || !amount) {
      return res.status(400).json({ error: 'studentId and amount required.' });
    }

    const sid     = studentId.toUpperCase();
    const student = await Student.findOne({ studentId: sid });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const year    = academicYear || currentAcademicYear();
    const rcptNo  = await nextReceiptNo(year);

    const entry = await LedgerEntry.create({
      studentId:     sid,
      studentName:   student.fullName,
      class:         student.class,
      section:       student.section || 'A',
      academicYear:  year,
      type:          'payment',
      amount:        Number(amount),
      date:          date || new Date().toISOString().slice(0, 10),
      description:   description || `Payment via ${method || 'Cash'}`,
      method:        method || 'Cash',
      month:         month || (date || new Date().toISOString().slice(0, 7)).slice(0, 7),
      receiptNumber: rcptNo,
      chequeNumber:  chequeNumber || '',
      bankName:      bankName || '',
      remarks:       remarks || '',
      createdBy:     req.user?.username || req.user?.name || 'Admin',
    });

    await recalcBalances(sid, year);

    const updated = await LedgerEntry.findById(entry._id);

    // ── WhatsApp: Payment confirmation (fire-and-forget) ──────
    if (student.guardianPhone) {
      (async () => {
        try {
          const summary = await getLedgerSummary(sid, year);
          const sentBy  = req.user?.username || req.user?.name || 'admin';
          await sendFeesPaymentReceived({
            student:       student.toObject ? student.toObject() : student,
            payment: {
              amount:        Number(amount),
              method:        method || 'Cash',
              receiptNumber: rcptNo,
              date:          date || new Date().toISOString().slice(0, 10),
              academicYear:  year,
            },
            ledgerSummary: summary,
            sentBy,
          });
          console.log(`[Ledger] ✅ WhatsApp payment receipt sent to: ${student.guardianPhone}`);
        } catch (e) {
          console.error('[Ledger] WhatsApp notification error (non-fatal):', e.message);
        }
      })();
    }

    res.status(201).json({ message: 'Payment recorded.', data: updated, receiptNumber: rcptNo });
  } catch (err) {
    console.error('[Ledger] POST payment error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── POST /api/ledger/monthly-charges — Bulk monthly fees
//    Adds "charge" entries for all students in a class/section
// =============================================================
router.post('/monthly-charges', auth, adminOnly, async (req, res) => {
  try {
    const {
      class: cls, section, amount, description,
      month, date, academicYear,
    } = req.body;

    if (!cls || !amount || !description || !month) {
      return res.status(400).json({ error: 'class, amount, description, month required.' });
    }

    const year  = academicYear || currentAcademicYear();
    const today = date || new Date().toISOString().slice(0, 10);

    const filter = { class: cls, isActive: true };
    if (section) filter.section = section;
    const students = await Student.find(filter);

    if (!students.length) {
      return res.status(404).json({ error: 'No active students found for given class/section.' });
    }

    // Check duplicates: skip students who already have a charge for this month+description
    const existing = await LedgerEntry.find({
      class: cls,
      academicYear: year,
      month,
      description,
      isDeleted: false,
      type: 'charge',
    }).distinct('studentId');
    const existingSet = new Set(existing);

    const toCreate = students.filter(s => !existingSet.has(s.studentId));
    if (!toCreate.length) {
      return res.status(409).json({ error: 'Monthly charge already added for these students.' });
    }

    const docs = toCreate.map(s => ({
      studentId:   s.studentId,
      studentName: s.fullName,
      class:       s.class,
      section:     s.section || 'A',
      academicYear: year,
      type:        'charge',
      amount:      Number(amount),
      date:        today,
      description,
      month,
      createdBy:   req.user?.username || 'Admin',
    }));

    await LedgerEntry.insertMany(docs);

    // Recalculate balances for all affected students
    for (const s of toCreate) {
      await recalcBalances(s.studentId, year);
    }

    res.status(201).json({
      message: `Monthly charges added for ${toCreate.length} students.`,
      count:   toCreate.length,
      skipped: students.length - toCreate.length,
    });
  } catch (err) {
    console.error('[Ledger] monthly-charges error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── PUT /api/ledger/:id — Edit an entry (admin only)
// =============================================================
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const entry = await LedgerEntry.findById(req.params.id);
    if (!entry)            return res.status(404).json({ error: 'Entry not found.' });
    if (entry.isDeleted)   return res.status(400).json({ error: 'Cannot edit a deleted entry.' });

    const { amount, date, description, method, month, remarks } = req.body;

    if (amount    !== undefined) entry.amount      = Number(amount);
    if (date      !== undefined) entry.date        = date;
    if (description !== undefined) entry.description = description;
    if (method    !== undefined) entry.method      = method;
    if (month     !== undefined) entry.month       = month;
    if (remarks   !== undefined) entry.remarks     = remarks;

    await entry.save();
    await recalcBalances(entry.studentId, entry.academicYear);

    const updated = await LedgerEntry.findById(entry._id);
    res.json({ message: 'Entry updated.', data: updated });
  } catch (err) {
    console.error('[Ledger] PUT error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── DELETE /api/ledger/:id — Soft-delete an entry (admin only)
// =============================================================
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const { reason } = req.body;
    if (!reason || reason.trim().length < 3) {
      return res.status(400).json({ error: 'A deletion reason (min 3 chars) is required.' });
    }

    const entry = await LedgerEntry.findById(req.params.id);
    if (!entry)          return res.status(404).json({ error: 'Entry not found.' });
    if (entry.isDeleted) return res.status(400).json({ error: 'Entry already deleted.' });

    entry.isDeleted    = true;
    entry.deleteReason = reason;
    entry.deletedAt    = new Date().toISOString().slice(0, 10);
    entry.deletedBy    = req.user?.username || 'Admin';
    await entry.save();

    await recalcBalances(entry.studentId, entry.academicYear);

    res.json({ message: 'Entry deleted.', data: entry });
  } catch (err) {
    console.error('[Ledger] DELETE error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── GET /api/ledger/summary/class — class-wise outstanding
// =============================================================
router.get('/summary/class', auth, adminOnly, async (req, res) => {
  try {
    const { class: cls, academicYear } = req.query;
    const year = academicYear || currentAcademicYear();

    const match = { academicYear: year, isDeleted: false };
    if (cls) match.class = cls;

    const agg = await LedgerEntry.aggregate([
      { $match: match },
      { $sort: { studentId: 1, date: 1, createdAt: 1 } },
      {
        $group: {
          _id:         '$studentId',
          studentName: { $last: '$studentName' },
          class:       { $last: '$class' },
          section:     { $last: '$section' },
          balance:     { $last: '$balance' },
          lastEntry:   { $last: '$date' },
          totalCharged: {
            $sum: { $cond: [{ $eq: ['$type', 'charge'] }, '$amount', 0] }
          },
          totalPaid: {
            $sum: { $cond: [{ $eq: ['$type', 'payment'] }, '$amount', 0] }
          },
        },
      },
      { $sort: { class: 1, section: 1, studentName: 1 } },
    ]);

    res.json({ data: agg, academicYear: year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── GET /api/ledger/defaulters — students with balance > 0
// =============================================================
router.get('/defaulters', auth, adminOnly, async (req, res) => {
  try {
    const { class: cls, section, academicYear } = req.query;
    const year = academicYear || currentAcademicYear();

    const match = { academicYear: year, isDeleted: false };
    if (cls)     match.class   = cls;
    if (section) match.section = section;

    const agg = await LedgerEntry.aggregate([
      { $match: match },
      { $sort: { studentId: 1, date: 1, createdAt: 1 } },
      {
        $group: {
          _id:         '$studentId',
          studentName: { $last: '$studentName' },
          class:       { $last: '$class' },
          section:     { $last: '$section' },
          balance:     { $last: '$balance' },
          totalCharged:{ $sum: { $cond: [{ $eq: ['$type','charge']  }, '$amount', 0] } },
          totalPaid:   { $sum: { $cond: [{ $eq: ['$type','payment'] }, '$amount', 0] } },
          lastEntry:   { $max: '$date' },
        },
      },
      { $match: { balance: { $gt: 0 } } },
      { $sort: { balance: -1 } },
    ]);

    // Attach phone numbers from Student collection
    const ids      = agg.map(a => a._id);
    const students = await Student.find({ studentId: { $in: ids } }, 'studentId guardianPhone');
    const phoneMap = {};
    for (const s of students) phoneMap[s.studentId] = s.guardianPhone || '';

    const result = agg.map(a => ({ ...a, phone: phoneMap[a._id] || '' }));
    const totalDue = result.reduce((s, a) => s + a.balance, 0);

    res.json({ data: result, totalDue, count: result.length, academicYear: year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// ── GET /api/ledger/dashboard — top-level stats
// =============================================================
router.get('/dashboard', auth, adminOnly, async (req, res) => {
  try {
    const academicYear = req.query.academicYear || currentAcademicYear();
    const today        = new Date().toISOString().slice(0, 10);
    const monthPrefix  = today.slice(0, 7);

    const [
      totalStudents,
      yearAgg,
      monthAgg,
      todayAgg,
      defaulterCount,
    ] = await Promise.all([
      Student.countDocuments({ isActive: true }),
      LedgerEntry.aggregate([
        { $match: { academicYear, isDeleted: false, type: 'payment' } },
        { $group: { _id: null, total: { $sum: '$amount' } } },
      ]),
      LedgerEntry.aggregate([
        { $match: { academicYear, isDeleted: false, type: 'payment', date: { $regex: `^${monthPrefix}` } } },
        { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } },
      ]),
      LedgerEntry.aggregate([
        { $match: { isDeleted: false, type: 'payment', date: today } },
        { $group: { _id: null, total: { $sum: '$amount' }, count: { $sum: 1 } } },
      ]),
      // Count students with positive balance
      LedgerEntry.aggregate([
        { $match: { academicYear, isDeleted: false } },
        { $sort: { studentId: 1, date: 1, createdAt: 1 } },
        { $group: { _id: '$studentId', balance: { $last: '$balance' } } },
        { $match: { balance: { $gt: 0 } } },
        { $count: 'total' },
      ]),
    ]);

    res.json({
      totalStudents,
      yearCollection:  yearAgg[0]?.total   || 0,
      monthCollection: monthAgg[0]?.total  || 0,
      monthPayments:   monthAgg[0]?.count  || 0,
      todayCollection: todayAgg[0]?.total  || 0,
      todayPayments:   todayAgg[0]?.count  || 0,
      defaulterCount:  defaulterCount[0]?.total || 0,
      academicYear,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
