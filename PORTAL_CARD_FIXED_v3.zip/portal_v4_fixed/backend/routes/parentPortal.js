// =============================================================
//  routes/parentPortal.js — Parent Portal Data API
//  Base path: /api/parent
//  SCHOOL PORTAL
//
//  All routes require parentAuth middleware (role: parent/student)
//  Parents can only see their OWN child's data.
//  READ-ONLY — no create/update/delete operations.
//  Fee data is intentionally excluded for privacy/security.
// =============================================================

const router     = require('express').Router();
const Student    = require('../models/Student');
const Marks      = require('../models/Marks');
const { Attendance } = require('../models/index');
const { Notice }     = require('../models/index');
const parentAuth = require('../middleware/parentAuth');

// Apply parentAuth to ALL routes in this file
router.use(parentAuth);

// ── Helper: get studentId from JWT ───────────────────────────
// For 'student' role: req.parent.studentId (the SCH... ID)
// For 'parent' role: req.parent.studentId
function getStudentId(req) {
  return (req.parent.studentId || '').toUpperCase();
}

// =============================================================
// GET /api/parent/me — Student basic info
// =============================================================
router.get('/me', async (req, res) => {
  try {
    const sid     = getStudentId(req);
    const student = await Student.findOne({ studentId: sid });

    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }

    res.json({
      studentId:    student.studentId,
      fullName:     student.fullName,
      className:    student.class,
      section:      student.section,
      rollNumber:   student.rollNumber,
      guardianName: student.guardianName,
      guardianPhone:student.guardianPhone,
      photo:        student.photo || '',
      admissionDate:student.admissionDate || '',
      house:        student.house || '',
    });
  } catch (err) {
    console.error('[Parent] /me error:', err.message);
    res.status(500).json({ error: 'Server error.' });
  }
});

// =============================================================
// GET /api/parent/marks — Exam results grouped by term
// =============================================================
router.get('/marks', async (req, res) => {
  try {
    const sid    = getStudentId(req);
    const { term, academicYear } = req.query;

    const filter = { studentId: sid };
    if (term)         filter.term         = term;
    if (academicYear) filter.academicYear = academicYear;

    const marksRaw = await Marks.find(filter).sort({ term: 1, subject: 1 });

    if (!marksRaw.length) {
      return res.json({ data: [], grouped: {}, terms: [] });
    }

    // Group by term
    const grouped = {};
    marksRaw.forEach(m => {
      const t = m.term || 'General';
      if (!grouped[t]) grouped[t] = [];
      grouped[t].push({
        subject:        m.subject,
        marksObtained:  m.marksObtained,
        maxMarks:       m.maxMarks,
        practicalObtained: m.practicalObtained || 0,
        maxPractical:   m.maxPractical || 0,
        totalObtained:  m.totalObtained,
        totalMax:       m.totalMax,
        percentage:     m.percentage,
        grade:          m.grade,
        gradePoint:     m.gradePoint,
        academicYear:   m.academicYear,
        term:           m.term,
      });
    });

    // Calculate overall per term
    const termSummary = {};
    Object.entries(grouped).forEach(([t, subjects]) => {
      const totalObt = subjects.reduce((s, x) => s + (x.totalObtained || 0), 0);
      const totalMax = subjects.reduce((s, x) => s + (x.totalMax || 0), 0);
      const pct = totalMax > 0 ? Math.round((totalObt / totalMax) * 1000) / 10 : 0;
      termSummary[t] = {
        totalObtained: totalObt,
        totalMax:      totalMax,
        percentage:    pct,
        grade:         calcGrade(pct),
        subjectCount:  subjects.length,
      };
    });

    res.json({
      data:        marksRaw,
      grouped,
      termSummary,
      terms:       Object.keys(grouped).sort(),
    });
  } catch (err) {
    console.error('[Parent] /marks error:', err.message);
    res.status(500).json({ error: 'Server error.' });
  }
});

// =============================================================
// GET /api/parent/attendance — Attendance summary + recent records
// =============================================================
router.get('/attendance', async (req, res) => {
  try {
    const sid     = getStudentId(req);
    const records = await Attendance.find({ studentId: sid }).sort({ date: -1 });

    const total   = records.length;
    const present = records.filter(r => r.status === 'P').length;
    const absent  = records.filter(r => r.status === 'A').length;
    const late    = records.filter(r => r.status === 'L').length;
    const pct     = total > 0 ? Math.round(((present + late) / total) * 100) : 0;

    // Attendance status label
    let statusLabel = 'Good';
    let statusColor = 'green';
    if (pct < 75) { statusLabel = 'Critical'; statusColor = 'red'; }
    else if (pct < 90) { statusLabel = 'Average'; statusColor = 'amber'; }

    // Recent 10 absences/late
    const recentAbsences = records
      .filter(r => r.status === 'A' || r.status === 'L')
      .slice(0, 10)
      .map(r => ({ date: r.date, status: r.status === 'A' ? 'Absent' : 'Late' }));

    // Monthly summary
    const monthly = {};
    records.forEach(r => {
      const mk = r.date ? r.date.slice(0, 7) : 'unknown';
      if (!monthly[mk]) monthly[mk] = { month: mk, present: 0, absent: 0, late: 0, total: 0 };
      monthly[mk].total++;
      if (r.status === 'P') monthly[mk].present++;
      else if (r.status === 'A') monthly[mk].absent++;
      else if (r.status === 'L') monthly[mk].late++;
    });

    res.json({
      summary: {
        totalDays:         total,
        presentDays:       present,
        absentDays:        absent,
        lateDays:          late,
        attendancePercent: pct,
        statusLabel,
        statusColor,
      },
      recentAbsences,
      monthly: Object.values(monthly).sort((a, b) => b.month.localeCompare(a.month)),
    });
  } catch (err) {
    console.error('[Parent] /attendance error:', err.message);
    res.status(500).json({ error: 'Server error.' });
  }
});

// =============================================================
// GET /api/parent/notices — Latest 5 school announcements
// Fee data is intentionally NOT included.
// =============================================================
router.get('/notices', async (req, res) => {
  try {
    const notices = await Notice.find({
      $or: [
        { expiresAt: null },
        { expiresAt: { $exists: false } },
        { expiresAt: { $gte: new Date() } },
      ],
    })
    .sort({ isPinned: -1, createdAt: -1 })
    .limit(5);

    const data = notices.map(n => ({
      id:       n._id,
      title:    n.title,
      body:     n.body || n.content || '',
      category: n.category || 'General',
      date:     n.createdAt ? n.createdAt.toISOString().slice(0, 10) : '',
      pinned:   n.isPinned || false,
    }));

    res.json({ data, total: data.length });
  } catch (err) {
    console.error('[Parent] /notices error:', err.message);
    res.status(500).json({ error: 'Server error.' });
  }
});

// ── Grade helper ─────────────────────────────────────────────
function calcGrade(pct) {
  if (pct >= 91) return 'A+';
  if (pct >= 81) return 'A';
  if (pct >= 71) return 'B+';
  if (pct >= 61) return 'B';
  if (pct >= 51) return 'C+';
  if (pct >= 41) return 'C';
  if (pct >= 33) return 'D';
  return 'F';
}

module.exports = router;
