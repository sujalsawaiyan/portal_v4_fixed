// =============================================================
//  routes/result.js — Student Result API v2.5.0
//  Base path: /api/result
//  Used by: frontend/pages/result.html
//
//  Auth: Student or Parent JWT token
//
//  ✅ FIXED v2.5.0:
//    - Added /api/result/admin/student/:id  — admin can preview any student's result
//    - Added /api/result/check              — lookup by rollNumber+class+section (no login)
//    - Replaced all Hindi error messages with English
//    - Consistent error response format
// =============================================================
const router     = require('express').Router();
const jwt        = require('jsonwebtoken');
const Student    = require('../models/Student');
const Marks      = require('../models/Marks');
const Discipline = require('../models/Discipline');
const { Attendance } = require('../models/index');
const { JWT_SECRET } = require('../middleware/auth');

const JWT_EXPIRES = '8h';

// ── Helper: academic year from date ──────────────────────────
function academicYear(d) {
  const dt = new Date(d || Date.now());
  const y  = dt.getFullYear();
  const m  = dt.getMonth() + 1;
  return m >= 4 ? `${y}-${String(y + 1).slice(-2)}` : `${y - 1}-${String(y).slice(-2)}`;
}
function currentAY() { return academicYear(new Date()); }

// ── Grade calculator ─────────────────────────────────────────
function calcGrade(pct) {
  if (pct >= 91) return 'A+';
  if (pct >= 81) return 'A';
  if (pct >= 71) return 'B+';
  if (pct >= 61) return 'B';
  if (pct >= 51) return 'C+';
  if (pct >= 41) return 'C';
  if (pct >= 33) return 'D';
  return 'F';
}

// ── Auth middleware (student / parent / admin JWT) ────────────
function resultAuth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'Authentication required. Please login first.' });
  }
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (!['student', 'parent', 'admin'].includes(decoded.role)) {
      return res.status(403).json({ error: 'Access denied. Invalid role.' });
    }
    req.user = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Session expired. Please login again.' });
  }
}

// ── POST /api/result/login — student login for result page ────
// Auth: studentId + class + rollNumber + section (no password required)
router.post('/login', async (req, res) => {
  try {
    const { studentId, class: cls, rollNumber, section } = req.body;

    if (!studentId)   return res.status(400).json({ error: 'Student ID is required.' });
    if (!cls)         return res.status(400).json({ error: 'Class is required.' });
    if (!rollNumber)  return res.status(400).json({ error: 'Roll Number is required.' });
    if (!section)     return res.status(400).json({ error: 'Section is required.' });

    const student = await Student.findOne({
      studentId:  studentId.toUpperCase(),
      class:      cls,
      rollNumber: rollNumber.trim(),
      section:    section.trim().toUpperCase(),
      isActive:   true,
    });

    if (!student) {
      return res.status(401).json({ error: 'No student found matching the provided details. Please check Student ID, Class, Roll Number and Section.' });
    }

    const token = jwt.sign(
      {
        id:        student._id,
        studentId: student.studentId,
        role:      'student',
        fullName:  student.fullName,
        class:     student.class,
        section:   student.section,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES }
    );

    res.json({
      token,
      studentId: student.studentId,
      fullName:  student.fullName,
      class:     student.class,
      section:   student.section,
    });
  } catch (err) {
    console.error('[Result Login]', err);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── Helper: build full result payload for a student ──────────
async function buildResultPayload(student, ay) {
  // Fetch marks (all terms, current academic year)
  const marksAll = await Marks.find({ studentId: student.studentId, academicYear: ay })
    .sort({ subject: 1 })
    .lean();

  // Group marks by term
  const marksByTerm = { Term1: [], Term2: [], Annual: [] };
  marksAll.forEach(m => {
    if (marksByTerm[m.term]) marksByTerm[m.term].push(m);
  });

  function termSummary(marks) {
    if (!marks.length) return null;
    const totalObt = marks.reduce((s, m) => s + m.totalObtained, 0);
    const totalMax = marks.reduce((s, m) => s + m.totalMax, 0);
    const pct      = totalMax > 0 ? Math.round(totalObt / totalMax * 1000) / 10 : 0;
    return {
      totalObtained: totalObt,
      totalMax,
      percentage:    pct,
      grade:         calcGrade(pct),
      subjectCount:  marks.length,
    };
  }

  // Fetch attendance
  const attRecords = await Attendance.find({ studentId: student.studentId }).lean();
  const attTotal   = attRecords.length;
  const attPresent = attRecords.filter(r => r.status === 'P').length;
  const attLate    = attRecords.filter(r => r.status === 'L').length;
  const attAbsent  = attRecords.filter(r => r.status === 'A').length;
  const attPct     = attTotal > 0 ? Math.round((attPresent + attLate) / attTotal * 100) : 0;

  const monthlyMap = {};
  attRecords.forEach(r => {
    const mk = r.date.slice(0, 7);
    if (!monthlyMap[mk]) monthlyMap[mk] = { month: mk, P: 0, A: 0, L: 0, total: 0 };
    monthlyMap[mk].total++;
    monthlyMap[mk][r.status]++;
  });
  const monthly = Object.values(monthlyMap).sort((a, b) => a.month.localeCompare(b.month));

  // Fetch discipline records
  const disciplineAll = await Discipline.find({ studentId: student.studentId })
    .sort({ date: -1 }).limit(50).lean();
  const discPositive = disciplineAll.filter(d => d.points > 0).length;
  const discNegative = disciplineAll.filter(d => d.points < 0).length;
  const netPoints    = disciplineAll.reduce((s, d) => s + d.points, 0);

  // Overall remarks (per term) - from OverallRemark category
  const overallRemarks = {};
  disciplineAll.filter(d => d.category === 'OverallRemark').forEach(d => {
    const key = d.term || 'Annual';
    overallRemarks[key] = {
      remark:    d.description,
      behaviour: d.behaviour || '',
      date:      d.date,
    };
  });

  return {
    student: {
      studentId:     student.studentId,
      fullName:      student.fullName,
      class:         student.class,
      section:       student.section,
      rollNumber:    student.rollNumber,
      gender:        student.gender,
      house:         student.house,
      dateOfBirth:   student.dateOfBirth,
      guardianName:  student.guardianName,
      guardianPhone: student.guardianPhone,
      photo:         student.photo,
    },
    academicYear: ay,
    marks: {
      Term1:   marksByTerm.Term1,
      Term2:   marksByTerm.Term2,
      Annual:  marksByTerm.Annual,
      summary: {
        Term1:  termSummary(marksByTerm.Term1),
        Term2:  termSummary(marksByTerm.Term2),
        Annual: termSummary(marksByTerm.Annual),
      },
    },
    attendance: {
      total:      attTotal,
      present:    attPresent,
      absent:     attAbsent,
      late:       attLate,
      percentage: attPct,
      monthly,
    },
    discipline: {
      records:        disciplineAll.filter(d => d.category !== 'OverallRemark'),
      positive:       discPositive,
      negative:       discNegative,
      netPoints,
      overallRemarks,
    },
  };
}

// ── GET /api/result/me — get own result (auth required) ───────
router.get('/me', resultAuth, async (req, res) => {
  try {
    let studentId = req.user.studentId;

    if (!studentId) {
      return res.status(400).json({ error: 'Student ID not found in session.' });
    }

    const sid = studentId.toUpperCase();
    const ay  = currentAY();

    const student = await Student.findOne({ studentId: sid, isActive: true }).lean();
    if (!student) {
      return res.status(404).json({ error: 'Student not found.' });
    }
    delete student.password;

    const payload = await buildResultPayload(student, ay);
    res.json(payload);
  } catch (err) {
    console.error('[Result]', err);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── GET /api/result/check — lookup by rollNumber+class+section (no login needed) ───
// Students can check result using: schoolId + class + section + rollNumber
router.get('/check', async (req, res) => {
  try {
    const { rollNumber, class: cls, section, studentId } = req.query;

    // Build query — support lookup by studentId OR by class+section+rollNumber
    let student;
    if (studentId) {
      student = await Student.findOne({ studentId: studentId.toUpperCase(), isActive: true }).lean();
    } else if (rollNumber && cls) {
      const query = { rollNumber, class: cls, isActive: true };
      if (section) query.section = section;
      student = await Student.findOne(query).lean();
    }

    if (!student) {
      return res.status(404).json({ error: 'Student not found. Please check the details and try again.' });
    }
    delete student.password;

    const ay      = currentAY();
    const payload = await buildResultPayload(student, ay);
    res.json(payload);
  } catch (err) {
    console.error('[Result Check]', err);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// ── GET /api/result/admin/student/:studentId — admin preview of any student's result ─
router.get('/admin/student/:studentId', async (req, res) => {
  try {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Admin token required.' });

    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });

    const sid     = req.params.studentId.toUpperCase();
    const ay      = req.query.year || currentAY();
    const student = await Student.findOne({ studentId: sid }).lean();
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    delete student.password;

    const payload = await buildResultPayload(student, ay);
    res.json(payload);
  } catch (err) {
    console.error('[Result Admin]', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
