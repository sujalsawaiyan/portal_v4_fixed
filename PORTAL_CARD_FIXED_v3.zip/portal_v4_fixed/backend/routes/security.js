const router = require('express').Router();
const { Visitor, SecurityAlert } = require('../models/Security');
const { auth, adminOnly } = require('../middleware/auth');

async function generatePassNo() {
  const today = new Date().toISOString().slice(0,10).replace(/-/g,'');
  const count = await Visitor.countDocuments({ dateIn: new Date().toISOString().slice(0,10) });
  return 'GP' + today + String(count+1).padStart(3,'0');
}

// GET /api/security/visitors
router.get('/visitors', auth, adminOnly, async (req, res) => {
  try {
    const filter = {};
    if (req.query.date)   filter.dateIn = req.query.date;
    if (req.query.status) filter.status = req.query.status;
    const visitors = await Visitor.find(filter).sort({ createdAt: -1 }).limit(parseInt(req.query.limit)||200).lean();
    const today = new Date().toISOString().slice(0,10);
    const agg = await Visitor.aggregate([
      { $match: { dateIn: today } },
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    const stats = { inside:0, checked_out:0, denied:0, total:0 };
    agg.forEach(s => { stats[s._id]=s.count; stats.total+=s.count; });
    res.json({ visitors, stats });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// POST /api/security/visitors
router.post('/visitors', auth, adminOnly, async (req, res) => {
  try {
    const today = new Date().toISOString().slice(0,10);
    const now   = new Date().toTimeString().slice(0,5);
    const passNo = await generatePassNo();
    const v = new Visitor({
      visitorName:  req.body.visitorName,
      phone:        req.body.phone        || '',
      idType:       req.body.idType       || 'Aadhar',
      idNumber:     req.body.idNumber     || '',
      purpose:      req.body.purpose      || 'Parent Meeting',
      purposeNote:  req.body.purposeNote  || '',
      personToMeet: req.body.personToMeet || '',
      studentName:  req.body.studentName  || '',
      studentClass: req.body.studentClass || '',
      dateIn:       req.body.dateIn       || today,
      timeIn:       req.body.timeIn       || now,
      passNo, status: 'inside',
      remarks:      req.body.remarks   || '',
      enteredBy:    req.user.username  || 'admin',
    });
    await v.save();
    res.status(201).json({ message: 'Visitor registered. Pass: ' + passNo, visitor: v });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/security/visitors/:id/checkout
router.put('/visitors/:id/checkout', auth, adminOnly, async (req, res) => {
  try {
    const v = await Visitor.findById(req.params.id);
    if (!v) return res.status(404).json({ error: 'Not found.' });
    const now = new Date().toTimeString().slice(0,5);
    v.timeOut = req.body.timeOut || now;
    v.status  = 'checked_out';
    if (v.timeIn && v.timeOut) {
      const [ih,im] = v.timeIn.split(':').map(Number);
      const [oh,om] = v.timeOut.split(':').map(Number);
      v.duration = (oh*60+om)-(ih*60+im);
    }
    await v.save();
    res.json({ message: 'Checked out.', visitor: v });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// DELETE /api/security/visitors/:id
router.delete('/visitors/:id', auth, adminOnly, async (req, res) => {
  try {
    await Visitor.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted.' });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// GET /api/security/alerts
router.get('/alerts', auth, adminOnly, async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    const alerts = await SecurityAlert.find(filter).sort({ createdAt: -1 }).limit(50).lean();
    res.json({ alerts });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// POST /api/security/alerts
router.post('/alerts', auth, adminOnly, async (req, res) => {
  try {
    const today = new Date().toISOString().slice(0,10);
    const now   = new Date().toTimeString().slice(0,5);
    const a = new SecurityAlert({
      type: req.body.type||'other', title: req.body.title,
      description: req.body.description||'', severity: req.body.severity||'medium',
      date: req.body.date||today, time: req.body.time||now,
      location: req.body.location||'', reportedBy: req.user.username||'admin',
    });
    await a.save();
    res.status(201).json({ message: 'Alert logged.', alert: a });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/security/alerts/:id/resolve
router.put('/alerts/:id/resolve', auth, adminOnly, async (req, res) => {
  try {
    const now = new Date().toTimeString().slice(0,5);
    const a = await SecurityAlert.findByIdAndUpdate(
      req.params.id, { status:'resolved', resolvedAt: req.body.resolvedAt||now }, { new:true }
    );
    if (!a) return res.status(404).json({ error: 'Not found.' });
    res.json({ message: 'Resolved.', alert: a });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// DELETE /api/security/alerts/:id
router.delete('/alerts/:id', auth, adminOnly, async (req, res) => {
  try {
    await SecurityAlert.findByIdAndDelete(req.params.id);
    res.json({ message: 'Deleted.' });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

// GET /api/security/dashboard
router.get('/dashboard', auth, adminOnly, async (req, res) => {
  try {
    const today = new Date().toISOString().slice(0,10);
    const monthStart = today.slice(0,7)+'-01';
    const [todayV, insideNow, openAlerts, monthV] = await Promise.all([
      Visitor.countDocuments({ dateIn: today }),
      Visitor.countDocuments({ status:'inside' }),
      SecurityAlert.countDocuments({ status:'open' }),
      Visitor.countDocuments({ dateIn: { $gte: monthStart } }),
    ]);
    const recentAlerts   = await SecurityAlert.find({ status:'open' }).sort({ createdAt:-1 }).limit(5).lean();
    const insideVisitors = await Visitor.find({ status:'inside' }).sort({ createdAt:-1 }).limit(20).lean();
    res.json({ todayVisitors:todayV, insideNow, openAlerts, totalVisitorsMonth:monthV, recentAlerts, insideVisitors });
  } catch(err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
