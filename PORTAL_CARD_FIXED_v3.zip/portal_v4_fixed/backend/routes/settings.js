// =============================================================
//  routes/settings.js — School Settings Key-Value API
//  Base path: /api/settings
//  Stores: schoolInfo, homepageContent, schoolTiming, stats,
//          topStudents, feeStructure, socialLinks, upiPayment,
//          admissions, lockdown, onlineLinks, calendar, scores
//  SCHOOL PORTAL
// =============================================================
const router         = require('express').Router();
const SchoolSettings = require('../models/SchoolSettings');
const { auth, adminOnly } = require('../middleware/auth');
const { bustPaymentCache } = require('../middleware/paymentGuard');

// ── GET /api/settings/:key — read a setting (public) ─────────
router.get('/:key', async (req, res) => {
  try {
    const doc = await SchoolSettings.findOne({ key: req.params.key });
    res.json({ key: req.params.key, value: doc ? doc.value : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/settings/:key — write a setting (admin) ────────
router.post('/:key', auth, adminOnly, async (req, res) => {
  try {
    const { value } = req.body;
    if (value === undefined) return res.status(400).json({ error: 'value is required.' });

    const doc = await SchoolSettings.findOneAndUpdate(
      { key: req.params.key },
      { value, updatedBy: req.user?.username || 'admin' },
      { upsert: true, new: true }
    );
    // Instantly bust payment guard cache so toggle takes effect immediately
    if (req.params.key === 'paymentVisible') bustPaymentCache();
    res.json({ message: 'Setting saved.', key: doc.key, value: doc.value });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/settings — get all settings (admin) ─────────────
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const docs = await SchoolSettings.find();
    const map  = {};
    docs.forEach(d => { map[d.key] = d.value; });
    res.json({ data: map });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/settings — bulk write (admin) ───────────────────
// Body: { settings: { key1: val1, key2: val2, ... } }
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { settings } = req.body;
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ error: 'settings object required.' });
    }

    const ops = Object.keys(settings).map(key => ({
      updateOne: {
        filter: { key },
        update: { $set: { value: settings[key], updatedBy: req.user?.username || 'admin' } },
        upsert: true,
      },
    }));

    if (ops.length) await SchoolSettings.bulkWrite(ops);
    res.json({ message: `${ops.length} settings saved.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// ── PUT /api/settings/:key — update a setting (admin, alias for POST) ────
router.put('/:key', auth, adminOnly, async (req, res) => {
  try {
    const { value } = req.body;
    if (value === undefined) return res.status(400).json({ error: 'value is required.' });
    const doc = await SchoolSettings.findOneAndUpdate(
      { key: req.params.key },
      { value, updatedBy: req.user?.username || 'admin' },
      { upsert: true, new: true }
    );
    if (req.params.key === 'paymentVisible') bustPaymentCache();
    res.json({ message: 'Setting saved.', key: doc.key, value: doc.value });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
