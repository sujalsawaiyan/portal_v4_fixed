// =============================================================
//  routes/sms.js — SMS Notification API
//  Base: /api/sms
//
//  GET  /config              → get current SMS config
//  POST /config              → save SMS config
//  POST /test                → send test SMS
//  POST /send-receipt        → receipt confirmation SMS
//  POST /send-reminder       → single fee reminder
//  POST /send-bulk-reminders → bulk reminders to all defaulters
//  POST /send-bounce-alert   → cheque bounce alert
//  GET  /logs                → SMS send history
// =============================================================

'use strict';

const router  = require('express').Router();
const { auth, adminOnly } = require('../middleware/auth');
const SchoolSettings = require('../models/SchoolSettings');
const Student  = require('../models/Student');
const FeePayment = require('../models/FeePayment');
const FeeStructure = require('../models/FeeStructure');

const {
  sendSMS,
  getSmsConfig,
  sendReceiptSMS,
  sendFeeReminderSMS,
  sendBulkReminderSMS,
  sendChequeBounceAlertSMS,
} = require('../utils/smsService');

function currentAcademicYear() {
  const now = new Date(), y = now.getFullYear();
  return now.getMonth() + 1 >= 4 ? `${y}-${String(y+1).slice(2)}` : `${y-1}-${String(y).slice(2)}`;
}

// =============================================================
// GET /api/sms/config
// =============================================================
router.get('/config', auth, adminOnly, async (_req, res) => {
  try {
    const config = await getSmsConfig();
    // Mask sensitive keys
    const masked = {
      provider:        config.provider,
      msg91ApiKey:     config.msg91ApiKey     ? config.msg91ApiKey.slice(0,6)     + '••••••' : '',
      msg91SenderId:   config.msg91SenderId,
      msg91TemplateId: config.msg91TemplateId,
      twilioSid:       config.twilioSid       ? config.twilioSid.slice(0,8)       + '••••' : '',
      twilioFrom:      config.twilioFrom,
      fast2smsKey:     config.fast2smsKey     ? config.fast2smsKey.slice(0,6)     + '••••••' : '',
      configured: !!(
        (config.provider === 'msg91'     && config.msg91ApiKey)   ||
        (config.provider === 'twilio'    && config.twilioSid)     ||
        (config.provider === 'fast2sms'  && config.fast2smsKey)
      ),
    };
    res.json({ data: masked });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/config
// =============================================================
router.post('/config', auth, adminOnly, async (req, res) => {
  try {
    const {
      provider, msg91ApiKey, msg91SenderId, msg91TemplateId,
      twilioSid, twilioToken, twilioFrom, fast2smsKey,
    } = req.body;

    const existing = await SchoolSettings.findOne({ key: 'smsConfig' });
    const existingCfg = existing?.value || {};

    const newCfg = {
      provider:        provider        || existingCfg.provider        || 'msg91',
      msg91SenderId:   msg91SenderId   || existingCfg.msg91SenderId   || 'SCHOOL',
      msg91TemplateId: msg91TemplateId || existingCfg.msg91TemplateId || '',
      twilioFrom:      twilioFrom      || existingCfg.twilioFrom      || '',
    };

    // Only update secrets if new values provided (not masked)
    if (msg91ApiKey    && !msg91ApiKey.includes('•'))    newCfg.msg91ApiKey    = msg91ApiKey;
    if (twilioSid      && !twilioSid.includes('•'))      newCfg.twilioSid      = twilioSid;
    if (twilioToken    && !twilioToken.includes('•'))    newCfg.twilioToken    = twilioToken;
    if (fast2smsKey    && !fast2smsKey.includes('•'))    newCfg.fast2smsKey    = fast2smsKey;

    await SchoolSettings.findOneAndUpdate(
      { key: 'smsConfig' },
      { value: { ...existingCfg, ...newCfg } },
      { upsert: true, new: true }
    );
    res.json({ message: 'SMS config saved.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/test
// =============================================================
router.post('/test', auth, adminOnly, async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'phone required.' });
    const config = await getSmsConfig();
    const result = await sendSMS(phone, `Test SMS from ${config.schoolName || 'School Portal'}. System is working correctly.`);
    if (!result.success) return res.status(400).json({ error: result.error });
    res.json({ message: 'Test SMS sent.', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/send-receipt
// =============================================================
router.post('/send-receipt', auth, adminOnly, async (req, res) => {
  try {
    const { studentId, paymentId, phone } = req.body;

    // Get payment details
    const payment = paymentId ? await FeePayment.findById(paymentId) : null;
    const student = studentId ? await Student.findOne({
      $or: [{ studentId: studentId.toUpperCase() }, { _id: studentId }]
    }) : null;

    if (!student && !payment) return res.status(404).json({ error: 'Student or payment not found.' });

    const guardianPhone = phone || student?.guardianPhone || student?.phone;
    if (!guardianPhone) return res.status(400).json({ error: 'No phone number found for this student.' });

    const config   = await getSmsConfig();
    const amount   = payment?.totalAmount || req.body.amount || 0;
    const balance  = req.body.balance || 0;
    const rcpNo    = payment?.receiptNumber || req.body.receiptNo || '—';
    const stuName  = student?.fullName || payment?.studentName || 'Student';

    const result = await sendReceiptSMS({
      studentName:   stuName,
      guardianPhone,
      amount,
      receiptNo:     rcpNo,
      balance,
      schoolName:    config.schoolName,
    });

    if (!result.success) return res.status(400).json({ error: result.error });
    res.json({ message: 'Receipt SMS sent.', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/send-reminder  (single student)
// =============================================================
router.post('/send-reminder', auth, adminOnly, async (req, res) => {
  try {
    const { studentId, phone, amountDue, dueDate } = req.body;
    if (!studentId && !phone) return res.status(400).json({ error: 'studentId or phone required.' });

    const student = studentId ? await Student.findOne({
      $or: [{ studentId: studentId.toUpperCase() }, { _id: studentId }]
    }) : null;

    const guardianPhone = phone || student?.guardianPhone || student?.phone;
    if (!guardianPhone) return res.status(400).json({ error: 'No phone number found.' });

    const config = await getSmsConfig();
    const result = await sendFeeReminderSMS({
      studentName:   student?.fullName || 'Student',
      guardianPhone,
      amountDue:     amountDue || 0,
      dueDate:       dueDate || '',
      schoolName:    config.schoolName,
    });

    if (!result.success) return res.status(400).json({ error: result.error });
    res.json({ message: 'Reminder SMS sent.', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/send-bulk-reminders  (all defaulters)
// =============================================================
router.post('/send-bulk-reminders', auth, adminOnly, async (req, res) => {
  try {
    const academicYear = req.body.academicYear || currentAcademicYear();
    const { class: cls } = req.body;

    // Get all defaulters
    const stuFilter = { isActive: true };
    if (cls) stuFilter.class = cls;
    const students = await Student.find(stuFilter);

    const payAgg = await FeePayment.aggregate([
      { $match: { academicYear, isCancelled: { $ne: true } } },
      { $group: { _id: '$studentId', totalPaid: { $sum: '$totalAmount' } } },
    ]);
    const paidMap = {};
    for (const p of payAgg) paidMap[p._id] = p.totalPaid;

    const structures = await FeeStructure.find({ academicYear });
    const structMap  = {};
    for (const s of structures) structMap[s.class] = s.totalAnnualFee;

    const defaulters = [];
    for (const s of students) {
      const expected = structMap[s.class] || 0;
      const paid     = paidMap[s.studentId] || 0;
      const pending  = expected - paid;
      if (pending > 0 && (s.guardianPhone || s.phone)) {
        defaulters.push({
          studentName:   s.fullName,
          phone:         s.guardianPhone || s.phone,
          pending,
          dueDate:       `${academicYear.split('-')[0]}-04-10`,
        });
      }
    }

    if (!defaulters.length) return res.json({ message: 'No defaulters with phone numbers found.', sent: 0, results: [] });

    const config  = await getSmsConfig();
    const results = await sendBulkReminderSMS(defaulters, config.schoolName);

    const sent   = results.filter(r => r.success).length;
    const failed = results.filter(r => !r.success).length;

    res.json({
      message: `Bulk SMS complete. Sent: ${sent}, Failed: ${failed}, Skipped: ${results.filter(r=>r.status==='skipped').length}`,
      sent, failed, total: defaulters.length, results,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// POST /api/sms/send-bounce-alert  (cheque bounce)
// =============================================================
router.post('/send-bounce-alert', auth, adminOnly, async (req, res) => {
  try {
    const { paymentId, phone } = req.body;
    if (!paymentId) return res.status(400).json({ error: 'paymentId required.' });

    const payment = await FeePayment.findById(paymentId);
    if (!payment) return res.status(404).json({ error: 'Payment not found.' });

    const student = await Student.findOne({ studentId: payment.studentId });
    const guardianPhone = phone || student?.guardianPhone || student?.phone;
    if (!guardianPhone) return res.status(400).json({ error: 'No phone number.' });

    // Mark cheque as bounced
    payment.chequeStatus = 'bounced';
    payment.editLog = payment.editLog || [];
    payment.editLog.push({ editedBy: req.user?.username || 'Admin', changes: 'Cheque marked as bounced' });
    await payment.save();

    const config = await getSmsConfig();
    const result = await sendChequeBounceAlertSMS({
      studentName:   payment.studentName,
      guardianPhone,
      chequeNo:      payment.chequeNumber,
      amount:        payment.totalAmount,
      schoolName:    config.schoolName,
    });

    if (!result.success) return res.status(400).json({ error: result.error });
    res.json({ message: 'Bounce alert SMS sent & cheque marked bounced.', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// =============================================================
// GET /api/sms/logs  (basic - from WhatsappLog reuse pattern)
// =============================================================
router.get('/logs', auth, adminOnly, async (req, res) => {
  try {
    // We don't have a separate SmsLog model — return last sent info from settings
    res.json({ data: [], message: 'SMS log feature — add SmsLog model for full history.' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
