// =============================================================
//  routes/students.js — Student CRUD API v2.4.0
//  Base path: /api/students
//  SCHOOL PORTAL
//
//  ✅ FIXED v2.4.0:
//    - DELETE now cleans up Cloudinary photo (photoPublicId)
//    - Added parent account cleanup on student delete
//    - Proper error messages in English throughout
// =============================================================
const router  = require('express').Router();
const path    = require('path');
const fs      = require('fs');
const multer  = require('multer');
const Student = require('../models/Student');
const User    = require('../models/User');
const { auth, adminOnly } = require('../middleware/auth');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');

// ── Multer temp storage for student photos ────────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, tmpDir),
  filename:    (_req,  file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, 'student_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    cb(new Error('Only JPG, PNG and WEBP images are allowed.'));
  },
});

// ── GET /api/students — list
// PUBLIC when filtering by class+section (for frontend attendance/result pages)
// Admin-only when no filter (full dump)
router.get('/', async (req, res) => {
  try {
    const { class: cls, section, search, page = 1, limit = 50 } = req.query;

    // If no class filter AND no token — block full dump
    if (!cls) {
      const header = req.headers['authorization'] || '';
      const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
      if (!token) return res.status(401).json({ error: 'Auth required for full student list.' });
      try {
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, process.env.JWT_SECRET || require('../middleware/auth').JWT_SECRET);
        if (!['admin','teacher'].includes(decoded.role)) return res.status(403).json({ error: 'Forbidden.' });
      } catch(e) { return res.status(401).json({ error: 'Invalid token.' }); }
    }

    const filter = { isActive: true };
    if (cls)     filter.class   = cls;
    if (section) filter.section = section;
    if (search) {
      filter.$or = [
        { fullName:   new RegExp(search, 'i') },
        { studentId:  new RegExp(search, 'i') },
        { rollNumber: new RegExp(search, 'i') },
      ];
    }

    // For public requests, only return safe fields (no auth/password info)
    const selectFields = 'studentId fullName rollNumber gender class section house guardianName guardianPhone dateOfBirth';
    const total    = await Student.countDocuments(filter);
    const students = await Student.find(filter)
      .select(selectFields)
      .sort({ class: 1, section: 1, rollNumber: 1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.json({ data: students, total, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/students/:studentId — single student ────────────
router.get('/:studentId', auth, async (req, res) => {
  try {
    if (req.user.role === 'student' && req.user.studentId !== req.params.studentId.toUpperCase()) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    const student = await Student.findOne({ studentId: req.params.studentId.toUpperCase() });
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/students — add new student (admin) ─────────────
const { sendNewStudentWelcome } = require('../utils/whatsappService');

// Phone validation helper
function isValidPhone(p) {
  return /^\d{10}$/.test(String(p || '').replace(/\D/g, ''));
}

router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      fullName, dateOfBirth, gender, class: cls, section,
      rollNumber, house, email, guardianName, guardianPhone,
      address, admissionDate, password,
    } = req.body;

    if (!fullName || !cls) {
      return res.status(400).json({ error: 'fullName and class are required.' });
    }

    const cleanPhone = guardianPhone ? String(guardianPhone).replace(/\D/g, '') : '';

    // Phone validation — warn but don't block (WhatsApp won't work without it)
    if (guardianPhone && !isValidPhone(guardianPhone)) {
      return res.status(400).json({
        error: 'Parent phone number must be exactly 10 digits (e.g. 9876543210).'
      });
    }
    const cleanSection = (section || 'A').trim().toUpperCase();

    // Default password = Roll No. + Section  e.g. "01A"
    // Falls back to provided password if explicitly set by admin
    const studentPass = password || ((rollNumber || '') + cleanSection);

    const student = new Student({
      fullName, dateOfBirth, gender,
      class: cls, section: cleanSection,
      rollNumber, house, email,
      guardianName, guardianPhone: cleanPhone,
      address, admissionDate,
      password: studentPass,
    });

    await student.save();

    // Auto-create parent account with same default password
    const parentPass = password || ((rollNumber || '') + cleanSection);
    const parent = new User({
      username:  student.studentId + '_parent',
      password:  parentPass,
      fullName:  guardianName || (fullName + "'s Parent"),
      role:      'parent',
      studentId: student.studentId,
    });
    await parent.save();

    // ── WhatsApp: Welcome notification to parent (fire-and-forget) ──
    if (guardianPhone) {
      (async () => {
        try {
          const sentBy = req.user?.username || 'admin';
          await sendNewStudentWelcome({ student: student.toObject(), sentBy });
          console.log(`[Students] ✅ WhatsApp welcome sent to: ${guardianPhone}`);
        } catch (e) {
          console.error('[Students] WhatsApp welcome error (non-fatal):', e.message);
        }
      })();
    }

    res.status(201).json({
      message:    'Student added successfully.',
      studentId:  student.studentId,
      student,
      parentNote: `Parent login: ID = ${student.studentId}, Password = ${parentPass}`,
    });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ error: 'Duplicate entry. Check roll number or studentId.' });
    }
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/students/:studentId — update student (admin) ────
router.put('/:studentId', auth, adminOnly, async (req, res) => {
  try {
    const allowed = [
      'fullName', 'dateOfBirth', 'gender', 'class', 'section',
      'rollNumber', 'house', 'email', 'guardianName', 'motherName', 'guardianPhone',
      'address', 'admissionDate', 'admissionNumber', 'photo', 'isActive',
    ];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    const student = await Student.findOneAndUpdate(
      { studentId: req.params.studentId.toUpperCase() },
      updates,
      { new: true }
    );
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Student updated successfully.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/students/:studentId/reset-password ──────────────
router.put('/:studentId/reset-password', auth, adminOnly, async (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword)           return res.status(400).json({ error: 'newPassword is required.' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });

    const student = await Student.findOne({ studentId: req.params.studentId.toUpperCase() });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    student.password = newPassword;
    await student.save();
    res.json({ message: 'Password reset successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/students/:studentId — soft delete + Cloudinary cleanup (admin) ──
// ✅ FIXED v2.4.0: Now cleans up Cloudinary photo + parent account
router.delete('/:studentId', auth, adminOnly, async (req, res) => {
  try {
    const student = await Student.findOne({ studentId: req.params.studentId.toUpperCase() });
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    // ✅ Delete Cloudinary photo if exists
    if (student.photoPublicId) {
      await deleteFromCloudinary(student.photoPublicId).catch(err =>
        console.warn('[Cloudinary] Failed to delete student photo:', err.message)
      );
    }

    // ✅ Deactivate (soft delete)
    student.isActive = false;
    await student.save();

    // ✅ Also deactivate linked parent account
    await User.findOneAndUpdate(
      { studentId: req.params.studentId.toUpperCase(), role: 'parent' },
      { isActive: false }
    ).catch(() => {}); // non-fatal if parent doesn't exist

    res.json({ message: 'Student deactivated successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/students/:studentId/photo — Cloudinary upload (admin) ──
router.post('/:studentId/photo', auth, adminOnly, upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No photo file provided.' });

    const student = await Student.findOne({ studentId: req.params.studentId.toUpperCase() });
    if (!student) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(404).json({ error: 'Student not found.' });
    }

    // Delete old Cloudinary photo if exists
    if (student.photoPublicId) {
      await deleteFromCloudinary(student.photoPublicId).catch(() => {});
    }

    const result = await uploadToCloudinary(req.file.path, 'students');
    student.photo         = result.url;
    student.photoPublicId = result.publicId;
    await student.save();

    res.json({ message: 'Photo uploaded successfully.', photoUrl: result.url, data: student });
  } catch (err) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
