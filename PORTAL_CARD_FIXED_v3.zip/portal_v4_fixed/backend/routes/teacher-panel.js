// =============================================================
//  teacher-panel.js — All Teacher Panel API Routes
//  SCHOOL PORTAL
//
//  All routes: /api/teacher/*
//  Auth: Bearer token with role = 'teacher'
// =============================================================
const router          = require('express').Router();
const jwt             = require('jsonwebtoken');
const TeacherAccount  = require('../models/TeacherAccount');
const Student         = require('../models/Student');
const { Attendance }  = require('../models/index');
const Marks           = require('../models/Marks');
const Discipline      = require('../models/Discipline');
const { JWT_SECRET }  = require('../middleware/auth');
const Class           = require('../models/Class');
const Teacher         = require('../models/Teacher');
const ClassSubjects   = require('../models/ClassSubjects');
const Ranking         = require('../models/Ranking');

const JWT_EXPIRES = process.env.JWT_EXPIRES || '8h';

// ── Helpers ──────────────────────────────────────────────────
function academicYear(dateStr) {
  const d = new Date(dateStr || Date.now());
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  return m >= 4 ? `${y}-${String(y+1).slice(-2)}` : `${y-1}-${String(y).slice(-2)}`;
}

function currentAcademicYear() {
  return academicYear(new Date().toISOString().slice(0, 10));
}

function calcGrade(pct) {
  if (pct >= 91) return 'A+';
  if (pct >= 81) return 'A';
  if (pct >= 71) return 'B+';
  if (pct >= 61) return 'B';
  if (pct >= 51) return 'C+';
  if (pct >= 41) return 'C';
  if (pct >= 33) return 'D';
  return 'F';
}

// ── Teacher Auth Middleware ───────────────────────────────────
function teacherAuth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token provided.' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'teacher') return res.status(403).json({ error: 'Teacher access only.' });
    req.teacher = decoded;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

// ── Dual Auth Middleware (Teacher OR Admin) ───────────────────
// Used for marks routes so admin panel can also read/write marks.
// For admin tokens: class/section come from query params or request body.
function dualAuth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token provided.' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role === 'teacher') {
      req.teacher = decoded;
    } else if (decoded.role === 'admin') {
      // Admin gets class/section from query params or request body
      const cls = req.query.class   || req.body.class   || '';
      const sec = req.query.section || req.body.section || 'A';
      req.teacher = {
        id:              decoded.id || 'admin',
        username:        decoded.username || 'admin',
        role:            'admin',
        assignedClass:   cls,
        assignedSection: sec,
      };
    } else {
      return res.status(403).json({ error: 'Teacher or Admin access required.' });
    }
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
}

// =============================================================
// POST /api/teacher/login
// Body: { username, password }
// =============================================================
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required.' });

    const teacher = await TeacherAccount.findOne({ username: username.toLowerCase().trim(), isActive: true });
    if (!teacher) return res.status(401).json({ error: 'Invalid credentials.' });

    const valid = await teacher.comparePassword(password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials.' });

    // Update lastLogin
    teacher.lastLogin = new Date();
    await teacher.save();

    const tokenData = {
      id:              teacher._id,
      username:        teacher.username,
      role:            'teacher',
      fullName:        teacher.fullName,
      assignedClass:   teacher.assignedClass,
      assignedSection: teacher.assignedSection,
    };
    const token = jwt.sign(tokenData, JWT_SECRET, { expiresIn: JWT_EXPIRES });
    res.json({ token, teacher: teacher.toJSON() });
  } catch (err) {
    console.error('[Teacher Login]', err);
    res.status(500).json({ error: 'Server error.' });
  }
});

// =============================================================
// GET /api/teacher/me — Profile + class info
// =============================================================
router.get('/me', teacherAuth, async (req, res) => {
  try {
    const teacher = await TeacherAccount.findById(req.teacher.id).lean();
    if (!teacher) return res.status(404).json({ error: 'Account not found.' });
    delete teacher.password;
    res.json({ teacher });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/class/students
// Returns all students in teacher's assigned class+section
// =============================================================
router.get('/class/students', teacherAuth, async (req, res) => {
  try {
    const cls = req.teacher.assignedClass;
    const sec = req.teacher.assignedSection;
    if (!cls) return res.json({ students: [] });

    const students = await Student.find({ class: cls, section: sec, isActive: true })
      .select('studentId fullName rollNumber gender dateOfBirth house photo guardianName guardianPhone')
      .lean();

    students.sort((a, b) => {
      const na = parseInt((a.rollNumber || '').replace(/\D/g, '')) || 999;
      const nb = parseInt((b.rollNumber || '').replace(/\D/g, '')) || 999;
      return na - nb;
    });

    res.json({ students, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/attendance?date=YYYY-MM-DD
// Get attendance for teacher's class on a specific date
// =============================================================
router.get('/attendance', teacherAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass;
    const sec  = req.teacher.assignedSection;
    const date = req.query.date || new Date().toISOString().slice(0, 10);

    const records = await Attendance.find({ class: cls, section: sec, date }).lean();
    const map = {};
    records.forEach(r => { map[r.studentId] = r.status; });
    res.json({ map, date, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/attendance/mark
// Body: { date, records: [{studentId, status}] }
// =============================================================
router.post('/attendance/mark', teacherAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass;
    const sec  = req.teacher.assignedSection;
    const { date, records } = req.body;

    if (!date || !records || !records.length) {
      return res.status(400).json({ error: 'date and records required.' });
    }

    const ops = records.map(r => ({
      updateOne: {
        filter: { studentId: r.studentId.toUpperCase(), date },
        update: {
          $set: {
            status:       r.status,
            class:        cls,
            section:      sec,
            markedBy:     req.teacher.username,
            academicYear: academicYear(date),
          }
        },
        upsert: true,
      }
    }));

    const result = await Attendance.bulkWrite(ops);
    res.json({
      message: `Attendance saved for ${result.upsertedCount + result.modifiedCount} students.`,
      saved:   result.upsertedCount + result.modifiedCount,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/marks/subjects?term=Term1&class=10&section=A
// Get all subjects used for this class (for autocomplete)
// Accepts both teacher and admin tokens (dualAuth)
// =============================================================
router.get('/marks/subjects', dualAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass   || req.query.class   || '';
    const sec  = req.teacher.assignedSection || req.query.section || '';
    const filter = {};
    if (cls) filter.class = cls;
    if (sec) filter.section = sec;
    const subjects = await Marks.distinct('subject', filter);
    res.json({ subjects: subjects.sort() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/marks?subject=Math&term=Term1&year=2025-26&class=10&section=A
// Get marks for all students in class for a subject (or all subjects if no subject given)
// Accepts both teacher and admin tokens (dualAuth)
// =============================================================
router.get('/marks', dualAuth, async (req, res) => {
  try {
    // class/section: teacher gets from JWT, admin gets from query params (set by dualAuth)
    const cls     = req.teacher.assignedClass   || req.query.class   || '';
    const sec     = req.teacher.assignedSection || req.query.section || 'A';
    const subject = req.query.subject || '';
    const term    = req.query.term    || 'Term1';
    const year    = req.query.year    || currentAcademicYear();

    if (!cls) return res.json({ marks: [], map: {} });

    const filter = { class: cls, section: sec, term, academicYear: year };
    // If subject specified, filter by it; otherwise return all subjects for this class
    if (subject) filter.subject = subject;

    const marks = await Marks.find(filter).lean();
    const map   = {};
    marks.forEach(m => {
      if (!map[m.studentId]) map[m.studentId] = {};
      map[m.studentId][m.subject] = m;
    });
    res.json({ marks, map, subject, term, year, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/marks/save
// Body (batch format — preferred):
//   { subject, term, year, maxMarks, maxPractical, class, section,
//     records:[{studentId, marksObtained, practicalObtained, remarks}] }
// Body (single-record format — legacy admin panel):
//   { studentId, subject, term, academicYear, marksObtained, maxMarks,
//     practicalObtained, maxPractical, class, section }
// Accepts both teacher and admin tokens (dualAuth)
// =============================================================
router.post('/marks/save', dualAuth, async (req, res) => {
  try {
    // class/section: teacher JWT takes precedence; admin uses body or query (set by dualAuth)
    const cls = req.teacher.role === 'teacher'
      ? req.teacher.assignedClass
      : (req.body.class || req.teacher.assignedClass || '');
    const sec = req.teacher.role === 'teacher'
      ? req.teacher.assignedSection
      : (req.body.section || req.teacher.assignedSection || 'A');

    const {
      subject, term,
      maxMarks, maxPractical,
    } = req.body;

    const year       = req.body.year || req.body.academicYear || currentAcademicYear();
    const mMax       = parseInt(maxMarks)     || 100;
    const pMax       = parseInt(maxPractical) || 0;

    // ── Normalise to records array (support both formats) ──────
    let records = req.body.records;
    if (!records || !Array.isArray(records)) {
      // Single-record format (legacy): { studentId, marksObtained, practicalObtained, ... }
      if (!req.body.studentId) {
        return res.status(400).json({ error: 'subject, term, and records (or studentId) required.' });
      }
      records = [{
        studentId:         req.body.studentId,
        marksObtained:     req.body.marksObtained,
        practicalObtained: req.body.practicalObtained || 0,
        remarks:           req.body.remarks || '',
      }];
    }

    if (!subject || !term || !records.length) {
      return res.status(400).json({ error: 'subject, term, and records required.' });
    }

    const ops = records.map(r => {
      // Sanitise studentId — must be SCH-prefixed string, NOT MongoDB _id
      const rawId = String(r.studentId || '').trim().toUpperCase();
      // If it looks like a MongoDB ObjectId (24 hex chars), skip it safely
      if (!rawId || /^[0-9A-F]{24}$/.test(rawId)) return null;

      const mo   = Math.max(0, Math.min(parseFloat(r.marksObtained)     || 0, mMax));
      const po   = Math.max(0, Math.min(parseFloat(r.practicalObtained) || 0, pMax));
      const tot  = mo + po;
      const tMax = mMax + pMax;
      const pct  = tMax > 0 ? Math.round(tot / tMax * 1000) / 10 : 0;

      return {
        updateOne: {
          filter: { studentId: rawId, subject, term, academicYear: year },
          update: {
            $set: {
              class:             cls,
              section:           sec,
              marksObtained:     mo,
              maxMarks:          mMax,
              practicalObtained: po,
              maxPractical:      pMax,
              totalObtained:     tot,
              totalMax:          tMax,
              percentage:        pct,
              grade:             calcGrade(pct),
              remarks:           r.remarks || '',
              enteredBy:         req.teacher.username || 'admin',
            }
          },
          upsert: true,
        }
      };
    }).filter(Boolean);  // remove nulls (bad studentIds)

    if (!ops.length) {
      return res.status(400).json({ error: 'No valid records to save. Ensure studentId is correct (e.g. SCH20250001).' });
    }

    const result = await Marks.bulkWrite(ops);
    res.json({
      message: `Marks saved for ${result.upsertedCount + result.modifiedCount} students.`,
      saved:   result.upsertedCount + result.modifiedCount,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/marks/report?studentId=&term=&year=
// Full marks report for one student (all subjects)
// =============================================================
router.get('/marks/report', teacherAuth, async (req, res) => {
  try {
    const { studentId, term, year } = req.query;
    if (!studentId) return res.status(400).json({ error: 'studentId required.' });

    const filter = { studentId: studentId.toUpperCase() };
    if (term) filter.term = term;
    if (year) filter.academicYear = year;

    const marks = await Marks.find(filter).sort({ subject: 1 }).lean();
    res.json({ marks });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/discipline?studentId=&limit=50
// =============================================================
router.get('/discipline', teacherAuth, async (req, res) => {
  try {
    const cls   = req.teacher.assignedClass;
    const sec   = req.teacher.assignedSection;
    const query = { class: cls, section: sec };
    if (req.query.studentId) query.studentId = req.query.studentId.toUpperCase();

    const records = await Discipline.find(query)
      .sort({ date: -1 })
      .limit(parseInt(req.query.limit) || 100)
      .lean();

    // Per-student summary (net points)
    const summary = {};
    records.forEach(r => {
      if (!summary[r.studentId]) summary[r.studentId] = { positive: 0, negative: 0, net: 0 };
      summary[r.studentId].net += r.points;
      if (r.points > 0) summary[r.studentId].positive += r.points;
      else               summary[r.studentId].negative += Math.abs(r.points);
    });

    res.json({ records, summary });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/discipline/add
// Body: { studentId, studentName, date, type, category, description, points }
// =============================================================
router.post('/discipline/add', teacherAuth, async (req, res) => {
  try {
    const cls = req.teacher.assignedClass;
    const sec = req.teacher.assignedSection;
    const { studentId, studentName, date, type, category, description, points } = req.body;

    if (!studentId || !description || !date) {
      return res.status(400).json({ error: 'studentId, date, and description required.' });
    }

    const record = new Discipline({
      studentId:   studentId.toUpperCase(),
      studentName: studentName || '',
      class:       cls,
      section:     sec,
      date,
      type:        type     || 'neutral',
      category:    category || 'General',
      description,
      points:      parseInt(points) || 0,
      recordedBy:  req.teacher.username,
    });

    await record.save();
    res.json({ message: 'Discipline record added.', record });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// DELETE /api/teacher/discipline/:id
// =============================================================
router.delete('/discipline/:id', teacherAuth, async (req, res) => {
  try {
    const record = await Discipline.findById(req.params.id);
    if (!record) return res.status(404).json({ error: 'Record not found.' });
    if (record.recordedBy !== req.teacher.username) {
      return res.status(403).json({ error: 'You can only delete your own records.' });
    }
    await record.deleteOne();
    res.json({ message: 'Record deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/reports/attendance/monthly?month=YYYY-MM
// Monthly attendance summary for teacher's class
// =============================================================
router.get('/reports/attendance/monthly', teacherAuth, async (req, res) => {
  try {
    const cls   = req.teacher.assignedClass;
    const sec   = req.teacher.assignedSection;
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const [tyr, tmo] = month.split('-').map(Number);
    const start = `${month}-01`;
    const lastDay = new Date(tyr, tmo, 0).getDate();
    const end   = `${month}-${String(lastDay).padStart(2, '0')}`;

    const records = await Attendance.find({
      class: cls, section: sec,
      date: { $gte: start, $lte: end }
    }).lean();

    const byStudent = {};
    records.forEach(r => {
      if (!byStudent[r.studentId]) byStudent[r.studentId] = { P: 0, A: 0, L: 0, total: 0 };
      byStudent[r.studentId].total++;
      byStudent[r.studentId][r.status]++;
    });

    // Get student names
    const ids = Object.keys(byStudent);
    const students = ids.length
      ? await Student.find({ studentId: { $in: ids } }, { studentId: 1, fullName: 1, rollNumber: 1 }).lean()
      : [];
    const nameMap = {};
    students.forEach(s => { nameMap[s.studentId] = { name: s.fullName, roll: s.rollNumber }; });

    const summary = ids.map(sid => {
      const s   = byStudent[sid];
      const inf = nameMap[sid] || {};
      const pct = s.total ? Math.round((s.P + s.L) / s.total * 100) : 0;
      return { studentId: sid, name: inf.name || sid, roll: inf.roll || '', ...s, percentage: pct };
    }).sort((a, b) => (parseInt(a.roll)||999) - (parseInt(b.roll)||999));

    res.json({ summary, records, month });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/overview — Dashboard overview stats
// =============================================================
router.get('/overview', teacherAuth, async (req, res) => {
  try {
    const cls   = req.teacher.assignedClass;
    const sec   = req.teacher.assignedSection;
    const today = new Date().toISOString().slice(0, 10);
    const year  = currentAcademicYear();

    // Total students
    const totalStudents = await Student.countDocuments({ class: cls, section: sec, isActive: true });

    // Today's attendance
    const todayAtt = await Attendance.find({ class: cls, section: sec, date: today }).lean();
    const present  = todayAtt.filter(r => r.status === 'P').length;
    const absent   = todayAtt.filter(r => r.status === 'A').length;
    const late     = todayAtt.filter(r => r.status === 'L').length;
    const marked   = todayAtt.length;
    const attPct   = marked ? Math.round((present + late) / marked * 100) : null;

    // Subjects with marks entered this year
    const subjectsEntered = await Marks.distinct('subject', { class: cls, section: sec, academicYear: year });

    // Recent discipline records (last 7 days)
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekAgoStr = weekAgo.toISOString().slice(0, 10);
    const disciplineCount = await Discipline.countDocuments({
      class: cls, section: sec,
      date: { $gte: weekAgoStr }
    });

    res.json({
      totalStudents,
      today,
      attendance: { present, absent, late, marked, total: totalStudents, percentage: attPct },
      subjectsEntered: subjectsEntered.length,
      recentDiscipline: disciplineCount,
      class: cls,
      section: sec,
      academicYear: year,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// Admin: Create/manage teacher accounts
// POST /api/teacher/admin/create  (admin token required)
// =============================================================
router.post('/admin/create', async (req, res) => {
  try {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Admin token required.' });

    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });

    const { username, password, fullName, assignedClass, assignedSection, subjects, email, phone, photo } = req.body;
    if (!username || !password || !fullName) {
      return res.status(400).json({ error: 'username, password, fullName required.' });
    }

    const exists = await TeacherAccount.findOne({ username: username.toLowerCase() });
    if (exists) return res.status(409).json({ error: 'Username already exists.' });

    const teacher = new TeacherAccount({
      username:        username.toLowerCase().trim(),
      password,
      fullName,
      assignedClass:   assignedClass   || '',
      assignedSection: assignedSection || 'A',
      subjects:        subjects        || [],
      email:           email           || '',
      phone:           phone           || '',
      photo:           photo           || '',
    });

    await teacher.save();

    // ── AUTO-SYNC: Update Class document with this teacher's info ──
    if (assignedClass && assignedSection) {
      const classUpdate = { teacherName: fullName };
      if (photo)           classUpdate.teacherPhoto   = photo;
      if (subjects && subjects.length) classUpdate.teacherSubject = subjects[0];

      await Class.findOneAndUpdate(
        { className: assignedClass, section: assignedSection },
        { $set: classUpdate },
        { upsert: false }
      );
    }

    res.json({ message: 'Teacher account created.', teacher: teacher.toJSON(), synced: !!(assignedClass && assignedSection) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/teacher/admin/list — List all teacher accounts (admin)
router.get('/admin/list', async (req, res) => {
  try {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Admin token required.' });
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });

    const teachers = await TeacherAccount.find({}).select('-password').lean();
    res.json({ teachers });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/teacher/admin/update/:id — Update teacher account (admin)
// =============================================================
// PUT /api/teacher/admin/update/:id  (admin only)
// ✅ AUTO-SYNC: Updates TeacherAccount → Class model → Teacher model
// So Classes page + Admin Teachers page both reflect the change
// =============================================================
router.put('/admin/update/:id', async (req, res) => {
  try {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Admin token required.' });
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });

    const allowed = ['fullName','assignedClass','assignedSection','subjects','email','phone','photo','isActive'];
    const update  = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) update[k] = req.body[k]; });

    // Handle username update with duplicate check
    if (req.body.username) {
      const newUsername = req.body.username.toLowerCase().trim();
      const existing = await TeacherAccount.findOne({ username: newUsername, _id: { $ne: req.params.id } });
      if (existing) return res.status(400).json({ error: 'Username already taken by another teacher.' });
      update.username = newUsername;
    }

    let teacher;

    // ✅ FIX: Fetch old data BEFORE saving so rename-sync comparison works correctly
    const oldTeacherData = await TeacherAccount.findById(req.params.id).lean();

    if (req.body.password) {
      teacher = await TeacherAccount.findById(req.params.id);
      if (!teacher) return res.status(404).json({ error: 'Not found.' });
      teacher.password = req.body.password;
      Object.assign(teacher, update);
      await teacher.save();
    } else {
      teacher = await TeacherAccount.findByIdAndUpdate(req.params.id, update, { new: true }).select('-password');
      if (!teacher) return res.status(404).json({ error: 'Not found.' });
    }

    // ── AUTO-SYNC to Class model (Classes page teacher display) ──────
    // Only sync if name, photo, or class assignment changed
    const syncFields = ['fullName','assignedClass','assignedSection','photo'];
    const shouldSync = syncFields.some(k => req.body[k] !== undefined);

    if (shouldSync) {
      const cls = teacher.assignedClass;
      const sec = teacher.assignedSection;

      if (cls && sec) {
        // Build class teacher update payload
        const classUpdate = {};
        if (teacher.fullName) classUpdate.teacherName  = teacher.fullName;
        if (teacher.photo)    classUpdate.teacherPhoto = teacher.photo;
        // subjects[0] as teacherSubject if available
        if (teacher.subjects && teacher.subjects.length)
          classUpdate.teacherSubject = teacher.subjects[0];

        // Update the Class document for this class+section
        await Class.findOneAndUpdate(
          { className: cls, section: sec },
          { $set: classUpdate },
          { upsert: false }  // don't create, only update existing
        );

        // Also sync all Class documents where teacherName matches old name
        // (handles rename case — uses pre-save snapshot)
        if (oldTeacherData && oldTeacherData.fullName && req.body.fullName &&
            oldTeacherData.fullName !== req.body.fullName) {
          await Class.updateMany(
            { teacherName: oldTeacherData.fullName },
            { $set: { teacherName: req.body.fullName,
                      ...(teacher.photo ? { teacherPhoto: teacher.photo } : {}) } }
          );
        }
      }

      // ── AUTO-SYNC to Teacher display model (Admin Teachers page) ─────
      // Find matching Teacher by name and update, or create if linked
      if (teacher.fullName) {
        const teacherDocUpdate = {};
        if (teacher.fullName) teacherDocUpdate.name     = teacher.fullName;
        if (teacher.fullName) teacherDocUpdate.fullName = teacher.fullName;
        if (teacher.photo)    teacherDocUpdate.photo    = teacher.photo;
        if (teacher.email)    teacherDocUpdate.email    = teacher.email;
        if (teacher.phone)    teacherDocUpdate.phone    = teacher.phone;

        // If account has a linked Teacher doc — update it
        if (teacher.teacherDocId) {
          await Teacher.findByIdAndUpdate(teacher.teacherDocId, teacherDocUpdate);
        } else {
          // Try to find by name match (best-effort sync)
          await Teacher.findOneAndUpdate(
            { $or: [{ name: teacher.fullName }, { fullName: teacher.fullName }] },
            { $set: teacherDocUpdate }
          );
        }
      }
    }

    res.json({
      message: 'Teacher account updated and synced to Class + Teacher pages.',
      teacher: teacher.toJSON ? teacher.toJSON() : teacher,
      synced: shouldSync,
    });
  } catch (err) {
    console.error('[Teacher Admin Update]', err);
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/teacher/admin/delete/:id (admin)
router.delete('/admin/delete/:id', async (req, res) => {
  try {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'Admin token required.' });
    const decoded = jwt.verify(token, JWT_SECRET);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Admin only.' });

    await TeacherAccount.findByIdAndDelete(req.params.id);
    res.json({ message: 'Teacher account deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/change-password  ✅ NEW — v2.4.0
// Body: { currentPassword, newPassword }
// Allows teacher to change their own password after login
// =============================================================
router.post('/change-password', teacherAuth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'currentPassword and newPassword are required.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }
    if (currentPassword === newPassword) {
      return res.status(400).json({ error: 'New password must be different from current password.' });
    }

    const teacher = await TeacherAccount.findById(req.teacher.id);
    if (!teacher) return res.status(404).json({ error: 'Teacher account not found.' });

    const valid = await teacher.comparePassword(currentPassword);
    if (!valid) {
      return res.status(400).json({ error: 'Current password is incorrect.' });
    }

    teacher.password = newPassword;
    await teacher.save();

    res.json({ message: 'Password changed successfully. Please login again with your new password.' });
  } catch (err) {
    console.error('[Teacher Change Password]', err);
    res.status(500).json({ error: 'Server error. Please try again.' });
  }
});

// =============================================================
// GET /api/teacher/profile — Get teacher's own profile  ✅ NEW
// =============================================================
router.get('/profile', teacherAuth, async (req, res) => {
  try {
    const teacher = await TeacherAccount.findById(req.teacher.id).select('-password').lean();
    if (!teacher) return res.status(404).json({ error: 'Teacher account not found.' });
    res.json({ teacher });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// PUT /api/teacher/student/:id — Teacher updates student details
// Only allowed fields: basic profile (NOT class/section/studentId)
// Teacher can only edit students in their own class+section
// =============================================================
router.put('/student/:id', teacherAuth, async (req, res) => {
  try {
    const cls = req.teacher.assignedClass;
    const sec = req.teacher.assignedSection;

    // Find the student and verify they belong to teacher's class
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    if (student.class !== cls || student.section !== sec) {
      return res.status(403).json({ error: 'You can only edit students in your assigned class.' });
    }

    // Only allow safe fields — NOT class, section, studentId, role, password
    const allowed = ['fullName', 'rollNumber', 'dateOfBirth', 'gender', 'house',
                     'email', 'guardianName', 'motherName', 'guardianPhone', 'address'];
    const update = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) update[k] = req.body[k]; });

    if (!update.fullName || update.fullName.trim() === '') {
      return res.status(400).json({ error: 'Student name is required.' });
    }

    Object.assign(student, update);
    await student.save();

    res.json({ message: 'Student updated successfully.', student: student.toJSON ? student.toJSON() : student });
  } catch (err) {
    console.error('[Teacher Student Update]', err);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/any-class/students?class=10&section=A
// Get students for ANY class (teacher selects class in UI)
// Teacher token required — no class restriction (allows flexible access)
// =============================================================
router.get('/any-class/students', teacherAuth, async (req, res) => {
  try {
    const cls = req.query.class   || req.teacher.assignedClass;
    const sec = req.query.section || req.teacher.assignedSection || 'A';
    if (!cls) return res.json({ students: [], class: cls, section: sec });

    const students = await Student.find({ class: cls, section: sec, isActive: true })
      .select('studentId fullName rollNumber gender dateOfBirth house photo guardianName guardianPhone')
      .lean();

    students.sort((a, b) => {
      const na = parseInt((a.rollNumber || '').replace(/\D/g, '')) || 999;
      const nb = parseInt((b.rollNumber || '').replace(/\D/g, '')) || 999;
      return na - nb;
    });

    res.json({ students, class: cls, section: sec });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/class-subjects?class=10&section=A&year=2025-26
// Get subject list for a class (from ClassSubjects model)
// =============================================================
router.get('/class-subjects', teacherAuth, async (req, res) => {
  try {
    const cls  = req.query.class   || req.teacher.assignedClass;
    const sec  = req.query.section || req.teacher.assignedSection || 'A';
    const year = req.query.year    || currentAcademicYear();

    if (!cls) return res.json({ subjects: [], class: cls, section: sec, year });

    let doc = await ClassSubjects.findOne({ class: cls, section: sec, academicYear: year }).lean();

    // If no ClassSubjects doc, fall back to subjects derived from Marks
    if (!doc || !doc.subjects || doc.subjects.length === 0) {
      const marksSubjects = await Marks.distinct('subject', { class: cls, section: sec, academicYear: year });
      const fallback = marksSubjects.sort().map((s, i) => ({
        name: s, code: '', maxMarks: 100, maxPractical: 0, isOptional: false, order: i
      }));
      return res.json({ subjects: fallback, class: cls, section: sec, year, fromMarks: true });
    }

    const sorted = [...doc.subjects].sort((a, b) => a.order - b.order);
    res.json({ subjects: sorted, class: cls, section: sec, year, fromMarks: false });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/class-subjects
// Save/update subject list for a class
// Body: { class, section, year, subjects: [{name, maxMarks, maxPractical, isOptional, order}] }
// =============================================================
router.post('/class-subjects', teacherAuth, async (req, res) => {
  try {
    const { class: cls, section, year, subjects } = req.body;
    const sec = section || req.teacher.assignedSection || 'A';
    const ay  = year   || currentAcademicYear();

    if (!cls || !subjects || !Array.isArray(subjects)) {
      return res.status(400).json({ error: 'class and subjects array required.' });
    }

    // Validate & normalise
    const cleaned = subjects
      .filter(s => s.name && s.name.trim())
      .map((s, i) => ({
        name:         s.name.trim(),
        code:         s.code         || '',
        maxMarks:     Number(s.maxMarks)     || 100,
        maxPractical: Number(s.maxPractical) || 0,
        isOptional:   !!s.isOptional,
        order:        s.order !== undefined ? s.order : i,
      }));

    const doc = await ClassSubjects.findOneAndUpdate(
      { class: cls, section: sec, academicYear: ay },
      { $set: { subjects: cleaned, updatedBy: req.teacher.username } },
      { upsert: true, new: true }
    );

    res.json({ message: 'Subjects saved.', subjects: doc.subjects, class: cls, section: sec, year: ay });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/marks/grid?class=10&section=A&term=Term1&year=2025-26
// Returns marks for ALL students × ALL subjects in one call
// Response: { students, subjects, marksMap: {studentId: {subjectName: markRecord}} }
// =============================================================
router.get('/marks/grid', teacherAuth, async (req, res) => {
  try {
    const cls  = req.query.class   || req.teacher.assignedClass;
    const sec  = req.query.section || req.teacher.assignedSection || 'A';
    const term = req.query.term    || 'Term1';
    const year = req.query.year    || currentAcademicYear();

    if (!cls) return res.json({ students: [], subjects: [], marksMap: {}, class: cls, section: sec });

    // Get students
    const students = await Student.find({ class: cls, section: sec, isActive: true })
      .select('studentId fullName rollNumber gender house')
      .lean();
    students.sort((a, b) => {
      const na = parseInt((a.rollNumber || '').replace(/\D/g, '')) || 999;
      const nb = parseInt((b.rollNumber || '').replace(/\D/g, '')) || 999;
      return na - nb;
    });

    // Get subjects from ClassSubjects (or marks fallback)
    let subjectsDef = [];
    const csDOc = await ClassSubjects.findOne({ class: cls, section: sec, academicYear: year }).lean();
    if (csDOc && csDOc.subjects && csDOc.subjects.length) {
      subjectsDef = [...csDOc.subjects].sort((a, b) => a.order - b.order);
    } else {
      const marksSubjects = await Marks.distinct('subject', { class: cls, section: sec, academicYear: year });
      subjectsDef = marksSubjects.sort().map((s, i) => ({
        name: s, code: '', maxMarks: 100, maxPractical: 0, isOptional: false, order: i
      }));
    }

    // Get all marks for this class/term/year
    const allMarks = await Marks.find({ class: cls, section: sec, term, academicYear: year }).lean();

    // Build marksMap: { studentId: { subjectName: markRecord } }
    const marksMap = {};
    allMarks.forEach(m => {
      if (!marksMap[m.studentId]) marksMap[m.studentId] = {};
      marksMap[m.studentId][m.subject] = {
        marksObtained:    m.marksObtained,
        maxMarks:         m.maxMarks,
        practicalObtained: m.practicalObtained,
        maxPractical:     m.maxPractical,
        totalObtained:    m.totalObtained,
        totalMax:         m.totalMax,
        percentage:       m.percentage,
        grade:            m.grade,
        remarks:          m.remarks,
      };
    });

    res.json({ students, subjects: subjectsDef, marksMap, class: cls, section: sec, term, year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/marks/grid-save
// Save marks for multiple students × multiple subjects in one shot
// Body: { class, section, term, year, records: [{studentId, subject, marksObtained, maxMarks, practicalObtained, maxPractical, remarks}] }
// =============================================================
router.post('/marks/grid-save', teacherAuth, async (req, res) => {
  try {
    const { class: cls, section, term, year, records } = req.body;
    const sec = section || req.teacher.assignedSection || 'A';
    const ay  = year   || currentAcademicYear();

    if (!cls || !records || !Array.isArray(records) || !records.length) {
      return res.status(400).json({ error: 'class, term, and records array required.' });
    }

    const ops = records.map(r => {
      const mMax = Math.max(0, Number(r.maxMarks)    || 100);
      const pMax = Math.max(0, Number(r.maxPractical)|| 0);
      const mo   = Math.max(0, Math.min(Number(r.marksObtained)    || 0, mMax));
      const po   = Math.max(0, Math.min(Number(r.practicalObtained)|| 0, pMax));
      const total = mo + po;
      const totalMax = mMax + pMax;
      const pct = totalMax > 0 ? Math.round(total / totalMax * 100 * 10) / 10 : 0;
      const grade = calcGrade(pct);

      return {
        updateOne: {
          filter: {
            studentId:    r.studentId.toUpperCase(),
            subject:      r.subject,
            term,
            academicYear: ay,
          },
          update: {
            $set: {
              class:             cls,
              section:           sec,
              marksObtained:     mo,
              maxMarks:          mMax,
              practicalObtained: po,
              maxPractical:      pMax,
              totalObtained:     total,
              totalMax,
              percentage:        pct,
              grade,
              gradePoint:        calcGradePoint(pct),
              remarks:           r.remarks || '',
              enteredBy:         req.teacher.username,
            }
          },
          upsert: true,
        }
      };
    });

    const result = await Marks.bulkWrite(ops);
    res.json({
      message: `Marks saved for ${result.upsertedCount + result.modifiedCount} entries.`,
      saved:   result.upsertedCount + result.modifiedCount,
    });
  } catch (err) {
    console.error('[Grid Save]', err);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/discipline/class?class=10&section=A&year=2025-26&limit=200
// Get all discipline records for a class
// =============================================================
router.get('/discipline/class', teacherAuth, async (req, res) => {
  try {
    const cls   = req.query.class   || req.teacher.assignedClass;
    const sec   = req.query.section || req.teacher.assignedSection || 'A';
    const year  = req.query.year    || currentAcademicYear();
    const limit = parseInt(req.query.limit) || 200;

    const records = await Discipline.find({ class: cls, section: sec, academicYear: year })
      .sort({ date: -1 })
      .limit(limit)
      .lean();

    // Build per-student summary
    const summary = {};
    records.forEach(r => {
      if (!summary[r.studentId]) {
        summary[r.studentId] = { positive: 0, negative: 0, neutral: 0, latestRemark: '' };
      }
      summary[r.studentId][r.type]++;
      if (!summary[r.studentId].latestRemark) summary[r.studentId].latestRemark = r.description;
    });

    res.json({ records, summary, class: cls, section: sec, year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Helper: grade point
function calcGradePoint(pct) {
  if (pct >= 91) return 10;
  if (pct >= 81) return 9;
  if (pct >= 71) return 8;
  if (pct >= 61) return 7;
  if (pct >= 51) return 6;
  if (pct >= 41) return 5;
  if (pct >= 33) return 4;
  return 0;
}

// =============================================================
// POST /api/teacher/student-remarks/save
// Save overall behavior remark for multiple students at once
// Body: { class, section, term, year, remarks: [{studentId, studentName, remark, behaviour}] }
// remark: text, behaviour: 'Excellent'|'Good'|'Satisfactory'|'NeedsImprovement'
// =============================================================
router.post('/student-remarks/save', teacherAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass  || req.body.class   || '';
    const sec  = req.teacher.assignedSection|| req.body.section || 'A';
    const selectedClass   = req.body.class   || cls;
    const selectedSection = req.body.section || sec;
    const term = req.body.term || 'Term1';
    const year = req.body.year || currentAcademicYear();
    const { remarks } = req.body;

    if (!remarks || !Array.isArray(remarks) || !remarks.length) {
      return res.status(400).json({ error: 'remarks array required.' });
    }

    const today = new Date().toISOString().slice(0, 10);
    const behaviourPoints = { Excellent: 5, Good: 3, Satisfactory: 1, NeedsImprovement: -2 };

    const ops = remarks
      .filter(r => r.studentId && r.remark)
      .map(r => ({
        updateOne: {
          filter: {
            studentId: r.studentId.toUpperCase(),
            category: 'OverallRemark',
            term,
            academicYear: year,
          },
          update: {
            $set: {
              studentName:  r.studentName || '',
              class:        selectedClass,
              section:      selectedSection,
              date:         today,
              academicYear: year,
              type:         r.behaviour === 'Excellent' || r.behaviour === 'Good' ? 'positive'
                          : r.behaviour === 'NeedsImprovement' ? 'negative' : 'neutral',
              category:     'OverallRemark',
              term,
              description:  r.remark,
              behaviour:    r.behaviour || 'Satisfactory',
              points:       behaviourPoints[r.behaviour] || 0,
              recordedBy:   req.teacher.username,
            }
          },
          upsert: true,
        }
      }));

    const result = await Discipline.bulkWrite(ops);
    res.json({
      message: `Remarks saved for ${result.upsertedCount + result.modifiedCount} students.`,
      saved:   result.upsertedCount + result.modifiedCount,
    });
  } catch (err) {
    console.error('[Student Remarks Save]', err);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/student-remarks?class=X&section=Y&term=T&year=Y
// Get overall remarks for all students in a class
// =============================================================
router.get('/student-remarks', teacherAuth, async (req, res) => {
  try {
    const cls  = req.query.class   || req.teacher.assignedClass   || '';
    const sec  = req.query.section || req.teacher.assignedSection || 'A';
    const term = req.query.term    || 'Term1';
    const year = req.query.year    || currentAcademicYear();

    const records = await Discipline.find({
      class: cls, section: sec,
      category: 'OverallRemark',
      term, academicYear: year,
    }).lean();

    // Map studentId → remark record
    const map = {};
    records.forEach(r => { map[r.studentId] = r; });

    res.json({ map, records, class: cls, section: sec, term, year });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/any-class/overview?class=X&section=Y
// Overview stats for any selected class (not just assigned)
// =============================================================
router.get('/any-class/overview', teacherAuth, async (req, res) => {
  try {
    const cls   = req.query.class   || req.teacher.assignedClass   || '';
    const sec   = req.query.section || req.teacher.assignedSection || 'A';
    const today = new Date().toISOString().slice(0, 10);
    const year  = currentAcademicYear();

    if (!cls) return res.json({ totalStudents: 0 });

    const totalStudents = await Student.countDocuments({ class: cls, section: sec, isActive: true });
    const todayAtt = await Attendance.find({ class: cls, section: sec, date: today }).lean();
    const present  = todayAtt.filter(r => r.status === 'P').length;
    const absent   = todayAtt.filter(r => r.status === 'A').length;
    const late     = todayAtt.filter(r => r.status === 'L').length;
    const marked   = todayAtt.length;

    const subjectsEntered = await ClassSubjects.findOne({ class: cls, section: sec, academicYear: year }).lean();
    const subjectCount = (subjectsEntered && subjectsEntered.subjects) ? subjectsEntered.subjects.length : 0;

    res.json({
      totalStudents, today,
      attendance: { present, absent, late, marked, total: totalStudents },
      subjectCount, class: cls, section: sec, academicYear: year,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// =============================================================
// GET /api/teacher/rankings?term=T&year=Y
// Get rankings for teacher's assigned class
// =============================================================
router.get('/rankings', teacherAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass   || '';
    const sec  = req.teacher.assignedSection || 'A';
    const term = req.query.term || 'Term1';
    const year = req.query.year || currentAcademicYear();

    if (!cls) return res.status(400).json({ error: 'No class assigned to this teacher.' });

    const students = await Student.find({ class: cls, section: sec, isActive: true })
      .select('studentId fullName rollNumber house photo')
      .sort({ rollNumber: 1, fullName: 1 })
      .lean();

    const records = await Ranking.find({ class: cls, section: sec, term, academicYear: year }).lean();
    const rankMap = {};
    records.forEach(r => { rankMap[r.studentId] = r; });

    const merged = students.map(s => ({
      studentId:    s.studentId,
      studentName:  s.fullName,
      rollNumber:   s.rollNumber || '',
      house:        s.house      || '',
      photo:        s.photo      || '',
      marksScore:   (rankMap[s.studentId] || {}).marksScore  || 0,
      attendance:   (rankMap[s.studentId] || {}).attendance  || 0,
      activities:   (rankMap[s.studentId] || {}).activities  || 0,
      discipline:   (rankMap[s.studentId] || {}).discipline  || 0,
      overallScore: (rankMap[s.studentId] || {}).overallScore || 0,
      rank:         (rankMap[s.studentId] || {}).rank         || 0,
      remarks:      (rankMap[s.studentId] || {}).remarks      || '',
      hasData:      !!rankMap[s.studentId],
    }));

    res.json({ class: cls, section: sec, term, academicYear: year, students: merged, total: merged.length });
  } catch (err) {
    console.error('[GET Rankings]', err);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/teacher/rankings — Save rankings for entire class
// =============================================================
router.post('/rankings', teacherAuth, async (req, res) => {
  try {
    const cls  = req.teacher.assignedClass   || '';
    const sec  = req.teacher.assignedSection || 'A';
    if (!cls) return res.status(400).json({ error: 'No class assigned to this teacher.' });

    const { term, academicYear, rankings } = req.body;
    if (!term) return res.status(400).json({ error: 'term is required.' });
    if (!rankings || !Array.isArray(rankings) || rankings.length === 0)
      return res.status(400).json({ error: 'rankings array is required.' });

    const year = academicYear || currentAcademicYear();

    const withScores = rankings.map(r => {
      const m  = Math.min(100, Math.max(0, parseFloat(r.marksScore)  || 0));
      const a  = Math.min(100, Math.max(0, parseFloat(r.attendance)  || 0));
      const ac = Math.min(10,  Math.max(0, parseFloat(r.activities)  || 0));
      const d  = Math.min(10,  Math.max(0, parseFloat(r.discipline)  || 0));
      const overall = parseFloat((m * 0.6 + a * 0.2 + ac * 10 * 0.1 + d * 10 * 0.1).toFixed(1));
      return { ...r, marksScore: m, attendance: a, activities: ac, discipline: d, overallScore: overall };
    });

    // Sort descending to assign ranks
    const sorted = [...withScores].sort((a, b) => b.overallScore - a.overallScore);
    const rankOf = {};
    sorted.forEach((s, i) => { rankOf[s.studentId] = i + 1; });

    const ops = withScores.map(r => ({
      updateOne: {
        filter: { studentId: r.studentId, term, academicYear: year },
        update: {
          $set: {
            studentId:    r.studentId,
            studentName:  r.studentName  || '',
            rollNumber:   r.rollNumber   || '',
            class:        cls,
            section:      sec,
            term,
            academicYear: year,
            marksScore:   r.marksScore,
            attendance:   r.attendance,
            activities:   r.activities,
            discipline:   r.discipline,
            overallScore: r.overallScore,
            rank:         rankOf[r.studentId] || 0,
            remarks:      r.remarks || '',
            enteredBy:    req.teacher.username,
          }
        },
        upsert: true,
      }
    }));

    const result = await Ranking.bulkWrite(ops);
    res.json({
      message: `Rankings saved for ${result.upsertedCount + result.modifiedCount} students.`,
      saved:   result.upsertedCount + result.modifiedCount,
      class: cls, section: sec, term, academicYear: year,
    });
  } catch (err) {
    console.error('[POST Rankings]', err);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/teacher/rankings/public?class=X&section=Y&term=T
// Public — used by frontend classes.html to show rankings
// =============================================================
router.get('/rankings/public', async (req, res) => {
  try {
    const cls  = req.query.class   || '';
    const sec  = req.query.section || 'A';
    const term = req.query.term    || 'Term1';
    const year = req.query.year    || '';
    if (!cls) return res.status(400).json({ error: 'class is required.' });
    const query = { class: cls, section: sec, term };
    if (year) query.academicYear = year;
    const rankings = await Ranking.find(query).sort({ rank: 1 }).lean();
    res.json({ data: rankings, total: rankings.length, class: cls, section: sec, term });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
