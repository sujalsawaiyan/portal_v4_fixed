// =============================================================
//  routes/teachers.js — Teacher CRUD API v2.2.0
//  Base path: /api/teachers
//  SCHOOL PORTAL
//
//  ✅ FIXED v2.2.0:
//    - DELETE now cleans up Cloudinary image (photoPublicId)
//    - PUT now cleans up old Cloudinary image when photo replaced
//    - TeacherPhoto collection also cleaned on DELETE
//
//  ⚠️  ROUTE ORDER: /bulk/replace MUST be BEFORE /:id
// =============================================================
const router  = require('express').Router();
const Teacher = require('../models/Teacher');
const { auth, adminOnly } = require('../middleware/auth');
const { deleteFromCloudinary } = require('../utils/cloudinary');

const multer = require('multer');
const path   = require('path');
const fs     = require('fs');
const { uploadToCloudinary } = require('../utils/cloudinary');

// ── Multer temp storage ───────────────────────────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const _upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, tmpDir),
    filename:    (_req,  file, cb) => {
      const ext = path.extname(file.originalname) || '.jpg';
      cb(null, 'teacher_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
    },
  }),
  limits:     { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = ['image/jpeg','image/jpg','image/png','image/webp'];
    cb(ok.includes(file.mimetype) ? null : new Error('Only JPG/PNG/WEBP allowed.'), ok.includes(file.mimetype));
  },
});


let TeacherPhoto;
try {
  const { TeacherPhoto: TP } = require('../models/SchoolImages');
  TeacherPhoto = TP;
} catch (_) {}

// ── GET /api/teachers — list all (public) ──────────────────────
router.get('/', async (req, res) => {
  try {
    const { role, active } = req.query;
    const filter = {};
    if (active !== 'false') filter.isActive = true;
    if (role) filter.role = role;

    const teachers = await Teacher.find(filter).sort({ order: 1, createdAt: 1 });
    res.json({ data: teachers, total: teachers.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/teachers/:id ────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ error: 'Teacher not found.' });
    res.json({ data: teacher });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/teachers — create (admin) ─────────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const {
      name, fullName, subject, department, dept,
      experience, exp, role, qualification, qual,
      email, phone, photo, order,
    } = req.body;

    const teacherName = name || fullName;
    if (!teacherName) return res.status(400).json({ error: 'name is required.' });

    const teacher = await Teacher.create({
      name: teacherName, fullName: teacherName,
      subject:       subject || '',
      department:    department || dept || 'General',
      dept:          department || dept || 'General',
      experience:    Number(experience || exp || 0),
      exp:           Number(experience || exp || 0),
      role:          role || 'teacher',
      qualification: qualification || qual || '',
      qual:          qualification || qual || '',
      email:         email || '',
      phone:         phone || '',
      photo:         photo || '',
      order:         Number(order || 0),
    });

    res.status(201).json({ message: 'Teacher added.', data: teacher });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════
//  PUT /api/teachers/bulk/replace — MUST BE BEFORE /:id
// ══════════════════════════════════════════════════════════════
router.put('/bulk/replace', auth, adminOnly, async (req, res) => {
  try {
    const { teachers, force } = req.body;
    if (!Array.isArray(teachers)) {
      return res.status(400).json({ error: 'teachers array required.' });
    }

    // ── SAFETY GUARD ──────────────────────────────────────────
    // If teachers array is empty, check how many records exist.
    // Refuse to wipe existing teachers unless force:true is passed.
    // This prevents accidental bulk-wipe from stale frontend snapshots.
    if (teachers.length === 0) {
      const existingCount = await Teacher.countDocuments({});
      if (existingCount > 0 && !force) {
        console.warn(`[Teachers] bulk/replace blocked — would delete ${existingCount} teachers (pass force:true to confirm)`);
        return res.status(400).json({
          error: `Safety guard: cannot replace ${existingCount} teachers with an empty list. Pass force:true to confirm.`,
          existingCount,
        });
      }
    }

    // ✅ Cleanup all Cloudinary images before bulk replace
    const existingTeachers = await Teacher.find({ photoPublicId: { $ne: '' } });
    await Promise.allSettled(
      existingTeachers.map(t => t.photoPublicId ? deleteFromCloudinary(t.photoPublicId) : Promise.resolve())
    );

    await Teacher.deleteMany({});

    if (teachers.length > 0) {
      const docs = teachers.map((t, i) => ({
        name:          t.name || t.full_name || '',
        fullName:      t.name || t.full_name || '',
        subject:       t.subject || '',
        department:    t.department || t.dept || 'General',
        dept:          t.department || t.dept || 'General',
        experience:    Number(t.experience || t.exp || 0),
        exp:           Number(t.experience || t.exp || 0),
        role:          t.role || 'teacher',
        qualification: t.qualification || t.qual || '',
        qual:          t.qualification || t.qual || '',
        email:         t.email || '',
        phone:         t.phone || '',
        photo:         t.photo || '',
        photoPublicId: t.photoPublicId || t.publicId || '',  // accept both key names
        order:         i,
        isActive:      true,
      }));
      await Teacher.insertMany(docs);
    }

    const all = await Teacher.find({ isActive: true }).sort({ order: 1 });
    res.json({ message: 'Teachers replaced.', total: all.length, data: all });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/teachers/:id — update (admin) ────────────────────
//  ⚠️ Intentionally placed AFTER /bulk/replace
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = [
      'name', 'fullName', 'subject', 'department', 'dept',
      'experience', 'exp', 'role', 'qualification', 'qual',
      'email', 'phone', 'photo', 'photoPublicId', 'order', 'isActive',
    ];
    const updates = {};
    allowed.forEach(k => {
      if (req.body[k] !== undefined) updates[k] = req.body[k];
    });

    // Keep aliases in sync
    if (updates.name)          updates.fullName      = updates.name;
    if (updates.fullName)      updates.name          = updates.fullName;
    if (updates.department)    updates.dept          = updates.department;
    if (updates.dept)          updates.department    = updates.dept;
    if (updates.experience !== undefined) updates.exp = updates.experience;
    if (updates.exp !== undefined)        updates.experience = updates.exp;
    if (updates.qualification) updates.qual          = updates.qualification;
    if (updates.qual)          updates.qualification = updates.qual;

    // ✅ FIXED: If photo is being replaced, delete old Cloudinary image
    if (updates.photo !== undefined) {
      const existing = await Teacher.findById(req.params.id);
      if (existing && existing.photoPublicId) {
        // Only delete if new photo URL is different
        if (existing.photo !== updates.photo) {
          await deleteFromCloudinary(existing.photoPublicId).catch(() => {});
          // Clear the old publicId unless a new one is provided
          if (!updates.photoPublicId) updates.photoPublicId = '';
        }
      }
    }

    const teacher = await Teacher.findByIdAndUpdate(
      req.params.id, updates, { new: true }
    );
    if (!teacher) return res.status(404).json({ error: 'Teacher not found.' });
    res.json({ message: 'Teacher updated.', data: teacher });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/teachers/:id (admin) ─────────────────────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ error: 'Teacher not found.' });

    // ✅ FIXED: Delete Cloudinary image before removing teacher record
    if (teacher.photoPublicId) {
      await deleteFromCloudinary(teacher.photoPublicId).catch(err =>
        console.warn('[Cloudinary] Failed to delete teacher photo:', err.message)
      );
    }

    // ✅ Also clean up TeacherPhoto collection if it exists
    if (TeacherPhoto) {
      const tp = await TeacherPhoto.findOne({ teacherId: req.params.id });
      if (tp && tp.publicId && tp.publicId !== teacher.photoPublicId) {
        await deleteFromCloudinary(tp.publicId).catch(() => {});
      }
      await TeacherPhoto.deleteOne({ teacherId: req.params.id }).catch(() => {});
    }

    await teacher.deleteOne();
    res.json({ message: 'Teacher deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/teachers/:id/photo — upload/replace teacher photo ─
router.post('/:id/photo', auth, adminOnly, _upload.single('photo'), async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ error: 'Teacher not found.' });

    if (!req.file) return res.status(400).json({ error: 'No image file. Field name must be "photo".' });

    // Delete old Cloudinary image if exists
    if (teacher.photoPublicId) {
      await deleteFromCloudinary(teacher.photoPublicId).catch(() => {});
    }

    const { url: photoUrl, publicId } = await uploadToCloudinary(req.file.path, 'teachers');

    await Teacher.findByIdAndUpdate(req.params.id, {
      photo:         photoUrl,
      photoPublicId: publicId,
    });

    // Also sync TeacherPhoto collection
    if (TeacherPhoto) {
      const existing = await TeacherPhoto.findOne({ teacherId: req.params.id });
      if (existing && existing.publicId && existing.publicId !== publicId) {
        await deleteFromCloudinary(existing.publicId).catch(() => {});
      }
      await TeacherPhoto.findOneAndUpdate(
        { teacherId: req.params.id },
        { imageUrl: photoUrl, publicId, filename: publicId, uploadedAt: new Date() },
        { upsert: true }
      );
    }

    res.json({ message: 'Photo uploaded.', photoUrl, publicId });
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) { try { fs.unlinkSync(req.file.path); } catch (_) {} }
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/teachers/:id/photo — remove teacher photo ──────
router.delete('/:id/photo', auth, adminOnly, async (req, res) => {
  try {
    const teacher = await Teacher.findById(req.params.id);
    if (!teacher) return res.status(404).json({ error: 'Teacher not found.' });

    if (teacher.photoPublicId) {
      await deleteFromCloudinary(teacher.photoPublicId).catch(() => {});
    }
    await Teacher.findByIdAndUpdate(req.params.id, { photo: '', photoPublicId: '' });

    if (TeacherPhoto) {
      await TeacherPhoto.deleteOne({ teacherId: req.params.id }).catch(() => {});
    }

    res.json({ message: 'Photo removed.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
