// =============================================================
//  routes/timetable.js — Timetable CRUD API
//  Base path: /api/timetable
//  SCHOOL PORTAL v2.5.0
// =============================================================
const router    = require('express').Router();
const Timetable = require('../models/Timetable');
const { auth, adminOnly } = require('../middleware/auth');

const VALID_CLASSES = ['LKG','UKG','1','2','3','4','5','6','7','8','9','10','11','12'];
const VALID_SECTIONS = ['A','B'];
const VALID_DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

// ── GET /api/timetable — list all (public, for frontend) ─────
router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.class)   filter.class   = req.query.class;
    if (req.query.section) filter.section = req.query.section;
    if (req.query.day)     filter.day     = req.query.day;
    const list = await Timetable.find(filter).sort({ class: 1, section: 1, day: 1 });
    res.json({ data: list, total: list.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/timetable/:class/:section/:day — single day timetable ──
router.get('/:cls/:section/:day', async (req, res) => {
  try {
    const { cls, section, day } = req.params;
    const tt = await Timetable.findOne({ class: cls, section, day });
    if (!tt) return res.status(404).json({ error: 'Timetable not found.', data: null });
    res.json({ data: tt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/timetable — create/upsert full day timetable (admin) ──
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { class: cls, section, day, periods, academicYear } = req.body;

    if (!cls || !VALID_CLASSES.includes(cls))
      return res.status(400).json({ error: 'Valid class required (LKG,UKG,1-12).' });
    if (!section || !VALID_SECTIONS.includes(section))
      return res.status(400).json({ error: 'Valid section required (A or B).' });
    if (!day || !VALID_DAYS.includes(day))
      return res.status(400).json({ error: 'Valid day required.' });
    if (!Array.isArray(periods) || periods.length === 0)
      return res.status(400).json({ error: 'periods array required.' });

    const tt = await Timetable.findOneAndUpdate(
      { class: cls, section, day },
      { $set: {
          periods,
          academicYear: academicYear || '',
          updatedBy: req.user?.username || 'admin',
        }
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({ message: 'Timetable saved.', data: tt });
  } catch (err) {
    if (err.code === 11000)
      return res.status(409).json({ error: 'Timetable already exists for this class/section/day.' });
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/timetable/:id — update timetable by ID (admin) ──
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const allowed = ['periods', 'academicYear'];
    const updates = {};
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
    updates.updatedBy = req.user?.username || 'admin';

    const tt = await Timetable.findByIdAndUpdate(req.params.id, updates, { new: true });
    if (!tt) return res.status(404).json({ error: 'Timetable not found.' });
    res.json({ message: 'Timetable updated.', data: tt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/timetable/class/:cls/:section — delete entire class timetable (admin) ──
// NOTE: This MUST come before /:id route — otherwise Express matches /:id first
router.delete('/class/:cls/:section', auth, adminOnly, async (req, res) => {
  try {
    const result = await Timetable.deleteMany({
      class: req.params.cls,
      section: req.params.section,
    });
    res.json({ message: `Deleted ${result.deletedCount} timetable entries.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/timetable/:id — delete by ID (admin) ─────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const tt = await Timetable.findByIdAndDelete(req.params.id);
    if (!tt) return res.status(404).json({ error: 'Timetable not found.' });
    res.json({ message: 'Timetable deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
