// =============================================================
//  routes/topStudents.js — Year-wise Top Students API
//  Base path: /api/topstudents
//  SCHOOL PORTAL
// =============================================================

const router     = require('express').Router();
const path       = require('path');
const fs         = require('fs');
const multer     = require('multer');
const TopStudent = require('../models/TopStudent');
const { auth, adminOnly } = require('../middleware/auth');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');

// ── Multer: temp storage before Cloudinary ────────────────────
const tmpDir = path.join(__dirname, '../../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, tmpDir),
  filename:    (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.jpg';
    cb(null, 'topstu_' + Date.now() + '_' + Math.random().toString(36).slice(2) + ext);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    cb(null, allowed.includes(file.mimetype));
  },
});

// ── GET /api/topstudents — all (public) ──────────────────────
// Optional: ?year=2025&classLabel=Class+10
router.get('/', async (req, res) => {
  try {
    const filter = { isActive: true };
    if (req.query.year)       filter.year       = req.query.year;
    if (req.query.classLabel) filter.classLabel = req.query.classLabel;

    // Sort: latest year first, then by classLabel, then by rank
    const students = await TopStudent.find(filter)
      .sort({ year: -1, classLabel: 1, rank: 1 });

    res.json({ data: students, total: students.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/topstudents/years — distinct years (public) ─────
router.get('/years', async (req, res) => {
  try {
    const years = await TopStudent.distinct('year', { isActive: true });
    // Sort descending (latest first)
    years.sort((a, b) => Number(b) - Number(a));
    res.json({ years });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/topstudents/:id — single (public) ───────────────
router.get('/:id', async (req, res) => {
  try {
    const student = await TopStudent.findById(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/topstudents — create (admin) ────────────────────
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { year, classLabel, rank, name } = req.body;
    if (!year || !classLabel || !rank || !name) {
      return res.status(400).json({ error: 'year, classLabel, rank and name are required.' });
    }
    const student = await TopStudent.create({
      year:        String(req.body.year),
      classLabel:  req.body.classLabel,
      rank:        Number(req.body.rank),
      name:        req.body.name,
      score:       Number(req.body.score   || 0),
      subjects:    req.body.subjects       || '',
      house:       req.body.house          || '',
      achievement: req.body.achievement    || '',
      isActive:    req.body.isActive !== undefined ? Boolean(req.body.isActive) : true,
    });
    res.status(201).json({ message: 'Top student created.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PUT /api/topstudents/:id — update (admin) ─────────────────
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const update = {};
    const fields = ['year','classLabel','rank','name','score','subjects','house','achievement','isActive'];
    fields.forEach(f => { if (req.body[f] !== undefined) update[f] = req.body[f]; });

    const student = await TopStudent.findByIdAndUpdate(
      req.params.id, { $set: update }, { new: true, runValidators: true }
    );
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Updated.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/topstudents/:id — delete (admin) ──────────────
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const student = await TopStudent.findById(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    // Remove Cloudinary image if exists
    if (student.imagePublicId) {
      await deleteFromCloudinary(student.imagePublicId);
    }

    await student.deleteOne();
    res.json({ message: 'Deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/topstudents/:id/image — upload photo (admin) ───
router.post('/:id/image', auth, adminOnly, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No image file provided.' });

    const student = await TopStudent.findById(req.params.id);
    if (!student) {
      // Clean up temp file
      try { fs.unlinkSync(req.file.path); } catch (_) {}
      return res.status(404).json({ error: 'Student not found.' });
    }

    // Delete old Cloudinary image if exists
    if (student.imagePublicId) {
      await deleteFromCloudinary(student.imagePublicId);
    }

    // Upload to Cloudinary
    const result = await uploadToCloudinary(req.file.path, 'students');

    student.image         = result.url;
    student.imagePublicId = result.publicId;
    await student.save();

    res.json({ message: 'Image uploaded.', imageUrl: result.url, publicId: result.publicId, data: student });
  } catch (err) {
    if (req.file) try { fs.unlinkSync(req.file.path); } catch (_) {}
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE /api/topstudents/:id/image — remove photo (admin) ─
router.delete('/:id/image', auth, adminOnly, async (req, res) => {
  try {
    const student = await TopStudent.findById(req.params.id);
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    if (student.imagePublicId) {
      await deleteFromCloudinary(student.imagePublicId);
    }

    student.image         = '';
    student.imagePublicId = '';
    await student.save();

    res.json({ message: 'Image removed.', data: student });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
