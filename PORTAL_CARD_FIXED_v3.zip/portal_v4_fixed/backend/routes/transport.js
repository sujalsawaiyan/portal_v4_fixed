// =============================================================
//  routes/transport.js — Transport Fee Module
//  School Portal v2.6.0
//  Routes: CRUD routes, assign student, defaulters, collection report
// =============================================================

const router         = require('express').Router();
const TransportRoute = require('../models/TransportRoute');
const Student        = require('../models/Student');
const FeePayment     = require('../models/FeePayment');
const { auth, adminOnly } = require('../middleware/auth');

function currentAcademicYear() {
  const now = new Date(), yr = now.getFullYear(), mo = now.getMonth() + 1;
  return mo >= 4 ? `${yr}-${String(yr+1).slice(2)}` : `${yr-1}-${String(yr).slice(2)}`;
}

// =============================================================
// GET /api/transport — list all routes
// =============================================================
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear } = req.query;
    const yr = academicYear || currentAcademicYear();
    const routes = await TransportRoute.find({ academicYear: yr }).sort({ routeNumber: 1 });
    res.json({ data: routes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/transport — create route
// =============================================================
router.post('/', auth, adminOnly, async (req, res) => {
  try {
    const { routeNumber, routeName, vehicleNo, driverName, driverPhone, capacity, academicYear, stops, isActive } = req.body;
    if (!routeNumber || !routeName) return res.status(400).json({ error: 'routeNumber and routeName are required.' });
    const yr = academicYear || currentAcademicYear();
    const existing = await TransportRoute.findOne({ routeNumber: routeNumber.toUpperCase(), academicYear: yr });
    if (existing) return res.status(409).json({ error: `Route ${routeNumber} already exists for ${yr}.` });
    const route = new TransportRoute({
      routeNumber: routeNumber.toUpperCase(),
      routeName, vehicleNo: vehicleNo || '', driverName: driverName || '',
      driverPhone: driverPhone || '', capacity: capacity || 40,
      academicYear: yr, stops: stops || [], isActive: isActive !== false,
    });
    await route.save();
    res.status(201).json({ message: 'Route created.', data: route });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// PUT /api/transport/:id — update route
// =============================================================
router.put('/:id', auth, adminOnly, async (req, res) => {
  try {
    const route = await TransportRoute.findById(req.params.id);
    if (!route) return res.status(404).json({ error: 'Route not found.' });
    const fields = ['routeName', 'vehicleNo', 'driverName', 'driverPhone', 'capacity', 'stops', 'isActive'];
    fields.forEach(f => { if (req.body[f] !== undefined) route[f] = req.body[f]; });
    await route.save();
    res.json({ message: 'Route updated.', data: route });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// DELETE /api/transport/:id — delete route
// =============================================================
router.delete('/:id', auth, adminOnly, async (req, res) => {
  try {
    const route = await TransportRoute.findByIdAndDelete(req.params.id);
    if (!route) return res.status(404).json({ error: 'Route not found.' });
    res.json({ message: 'Route deleted.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/transport/assign — assign student to route/stop
// Body: { studentId, routeNumber, stopName, feeMode }
// =============================================================
router.post('/assign', auth, adminOnly, async (req, res) => {
  try {
    const { studentId, routeNumber, stopName, feeMode } = req.body;
    if (!studentId) return res.status(400).json({ error: 'studentId is required.' });
    const student = await Student.findOneAndUpdate(
      { $or: [{ studentId: studentId.toString().toUpperCase() }, { admissionNumber: studentId.toString().toUpperCase() }] },
      { $set: { transportRoute: routeNumber || '', transportStop: stopName || '', transportFeeMode: feeMode || 'monthly' } },
      { new: true }
    );
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Transport assigned.', data: { studentId: student.studentId, transportRoute: student.transportRoute, transportStop: student.transportStop, transportFeeMode: student.transportFeeMode } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/transport/unassign — remove transport from student
// =============================================================
router.post('/unassign', auth, adminOnly, async (req, res) => {
  try {
    const { studentId } = req.body;
    if (!studentId) return res.status(400).json({ error: 'studentId is required.' });
    const student = await Student.findOneAndUpdate(
      { $or: [{ studentId: studentId.toString().toUpperCase() }, { admissionNumber: studentId.toString().toUpperCase() }] },
      { $set: { transportRoute: '', transportStop: '', transportFeeMode: 'none' } },
      { new: true }
    );
    if (!student) return res.status(404).json({ error: 'Student not found.' });
    res.json({ message: 'Transport unassigned.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/transport/students — students with transport assigned
// =============================================================
router.get('/students', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, routeNumber } = req.query;
    const filter = { transportRoute: { $exists: true, $ne: '' } };
    if (routeNumber) filter.transportRoute = routeNumber.toUpperCase();
    const students = await Student.find(filter)
      .select('studentId fullName class section admissionNumber guardianPhone transportRoute transportStop transportFeeMode')
      .sort({ class: 1, fullName: 1 });
    res.json({ data: students, count: students.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/transport/defaulters?academicYear=2024-25&month=2024-07
// Students with transport assigned who haven't paid transport fee
// =============================================================
router.get('/defaulters', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, month } = req.query;
    const yr = academicYear || currentAcademicYear();

    // Current month as period label e.g. "July 2024"
    const now = new Date();
    const monthDate = month ? new Date(month + '-01') : now;
    const periodLabel = monthDate.toLocaleString('en-IN', { month: 'long', year: 'numeric' });

    // Get all students with transport assigned
    const students = await Student.find({ transportRoute: { $exists: true, $ne: '' } })
      .select('studentId fullName class section admissionNumber guardianPhone transportRoute transportStop transportFeeMode');

    // Get transport payments for this period
    const payments = await FeePayment.find({
      academicYear: yr,
      isCancelled: { $ne: true },
      'feeHeads.headName': 'Transport Fee',
      'feeHeads.period': periodLabel,
    });

    const paidIds = new Set(payments.map(p => p.studentId));

    // Get route details for fee amounts
    const routes = await TransportRoute.find({ academicYear: yr });
    const routeMap = {};
    routes.forEach(r => { routeMap[r.routeNumber] = r; });

    const defaulters = [];
    for (const s of students) {
      if (!paidIds.has(s.studentId) && !paidIds.has(s.admissionNumber)) {
        const route = routeMap[s.transportRoute];
        const stop = route?.stops?.find(st => st.stopName === s.transportStop);
        defaulters.push({
          studentId:      s.studentId,
          name:           s.fullName,
          class:          s.class,
          section:        s.section,
          phone:          s.guardianPhone || '',
          transportRoute: s.transportRoute,
          transportStop:  s.transportStop,
          feeMode:        s.transportFeeMode,
          monthlyFee:     stop?.monthlyFee || 0,
          period:         periodLabel,
        });
      }
    }

    res.json({ data: defaulters, count: defaulters.length, period: periodLabel, academicYear: yr });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/transport/collection-report?academicYear=2024-25&month=2024-07
// =============================================================
router.get('/collection-report', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, month } = req.query;
    const yr = academicYear || currentAcademicYear();

    const now = new Date();
    const monthDate = month ? new Date(month + '-01') : now;
    const periodLabel = monthDate.toLocaleString('en-IN', { month: 'long', year: 'numeric' });

    const students = await Student.find({ transportRoute: { $exists: true, $ne: '' } })
      .select('studentId fullName class section admissionNumber guardianPhone transportRoute transportStop transportFeeMode');

    const payments = await FeePayment.find({
      academicYear: yr,
      isCancelled: { $ne: true },
      'feeHeads.headName': 'Transport Fee',
    });

    const routes = await TransportRoute.find({ academicYear: yr });
    const routeMap = {};
    routes.forEach(r => { routeMap[r.routeNumber] = r; });

    // Map studentId → payments for this period
    const paidMap = {};
    for (const p of payments) {
      const hasThisPeriod = p.feeHeads.some(h => h.headName === 'Transport Fee' && h.period === periodLabel);
      if (hasThisPeriod) {
        const transportHead = p.feeHeads.find(h => h.headName === 'Transport Fee' && h.period === periodLabel);
        paidMap[p.studentId] = { amount: transportHead?.amount || p.totalAmount, receiptNumber: p.receiptNumber, paymentDate: p.paymentDate };
      }
    }

    const result = students.map(s => {
      const route = routeMap[s.transportRoute];
      const stop  = route?.stops?.find(st => st.stopName === s.transportStop);
      const paid  = paidMap[s.studentId] || paidMap[s.admissionNumber];
      return {
        studentId:      s.studentId,
        name:           s.fullName,
        class:          s.class,
        section:        s.section,
        phone:          s.guardianPhone || '',
        routeNumber:    s.transportRoute,
        routeName:      route?.routeName || '',
        stopName:       s.transportStop,
        monthlyFee:     stop?.monthlyFee || 0,
        paid:           !!paid,
        paidAmount:     paid?.amount || 0,
        receiptNumber:  paid?.receiptNumber || '',
        paymentDate:    paid?.paymentDate || '',
      };
    });

    const totalStudents = result.length;
    const paidCount     = result.filter(r => r.paid).length;
    const totalCollected = result.reduce((s, r) => s + r.paidAmount, 0);

    res.json({
      data: result,
      summary: { totalStudents, paidCount, pendingCount: totalStudents - paidCount, totalCollected },
      period: periodLabel,
      academicYear: yr,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
