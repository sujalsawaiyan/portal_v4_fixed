// =============================================================
//  routes/whatsapp.js — WhatsApp Notification API v3.0.0
//  Base path: /api/whatsapp
//  SCHOOL PORTAL — Production Grade
//
//  Endpoints:
//    GET  /config                → get current config (masked)
//    POST /config                → save config (Meta / Twilio)
//    POST /test                  → send test message
//    POST /send-admission-message → send admission notification
//    POST /send-fees-message      → send fees payment notification
//    POST /send-fee-reminder      → send due reminder
//    POST /send-bulk-reminders    → bulk due reminders
//    GET  /due-students          → list students with pending fees
//    GET  /logs                  → message history
//    GET  /stats                 → summary stats
// =============================================================

'use strict';

const router         = require('express').Router();
const SchoolSettings = require('../models/SchoolSettings');
const Student        = require('../models/Student');
const WhatsappLog    = require('../models/WhatsappLog');
const { auth, adminOnly } = require('../middleware/auth');

const {
  sendWhatsApp,
  getWhatsappConfig,
  getLedgerSummary,
  sendAdmissionApproved,
  sendAdmissionRejected,
  sendNewStudentWelcome,
  sendFeesPaymentReceived,
  sendFeeReminder,
} = require('../utils/whatsappService');

// ── Academic year helper ──────────────────────────────────────
function currentAcademicYear() {
  const now = new Date(); const y = now.getFullYear();
  return now.getMonth() + 1 >= 4
    ? `${y}-${String(y + 1).slice(2)}`
    : `${y - 1}-${String(y).slice(2)}`;
}

// =============================================================
// GET /api/whatsapp/config
// =============================================================
router.get('/config', auth, adminOnly, async (_req, res) => {
  try {
    const config = await getWhatsappConfig();
    // Mask secrets
    if (config.metaAccessToken) config.metaAccessToken = config.metaAccessToken.slice(0, 8) + '•••••••••••••••••••••';
    if (config.authToken)       config.authToken       = config.authToken.slice(0, 6)       + '•••••••••••••••••••••••••';
    res.json({ data: config });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/whatsapp/config — save config
// =============================================================
router.post('/config', auth, adminOnly, async (req, res) => {
  try {
    const {
      provider,
      metaPhoneNumberId, metaAccessToken, metaApiVersion,
      twilioAccountSid, twilioAuthToken, twilioWhatsappNumber,
      schoolName, schoolPhone, schoolAddress, principalName, paymentLink,
      feeReminderMode, feeReminderTime,
    } = req.body;

    const existing    = await SchoolSettings.findOne({ key: 'whatsappConfig' });
    const existingCfg = existing?.value || {};

    const newCfg = {
      ...existingCfg,
      provider:             provider             || existingCfg.provider             || 'meta',
      metaPhoneNumberId:    metaPhoneNumberId    || existingCfg.metaPhoneNumberId    || '',
      metaApiVersion:       metaApiVersion       || existingCfg.metaApiVersion       || 'v19.0',
      twilioAccountSid:     twilioAccountSid     || existingCfg.twilioAccountSid     || '',
      twilioWhatsappNumber: twilioWhatsappNumber || existingCfg.twilioWhatsappNumber || '',
      schoolName:           schoolName           || existingCfg.schoolName           || '',
      schoolPhone:          schoolPhone          || existingCfg.schoolPhone          || '',
      schoolAddress:        schoolAddress        || existingCfg.schoolAddress        || '',
      principalName:        principalName        || existingCfg.principalName        || '',
      paymentLink:          paymentLink          || existingCfg.paymentLink          || '',
      feeReminderMode:      feeReminderMode      || existingCfg.feeReminderMode      || 'manual',
      feeReminderTime:      feeReminderTime      || existingCfg.feeReminderTime      || '08:00',
    };

    // Only update secrets if a real (non-masked) value is provided
    if (metaAccessToken   && !metaAccessToken.includes('•'))   newCfg.metaAccessToken   = metaAccessToken;
    if (twilioAuthToken   && !twilioAuthToken.includes('•'))   newCfg.twilioAuthToken   = twilioAuthToken;

    await SchoolSettings.findOneAndUpdate(
      { key: 'whatsappConfig' },
      { value: newCfg, updatedBy: req.user?.username || 'admin' },
      { upsert: true, new: true }
    );

    // Keep schoolInfo in sync
    if (schoolName || schoolPhone || schoolAddress || principalName || paymentLink) {
      const existingInfo = (await SchoolSettings.findOne({ key: 'schoolInfo' }))?.value || {};
      await SchoolSettings.findOneAndUpdate(
        { key: 'schoolInfo' },
        {
          value: {
            ...existingInfo,
            ...(schoolName    && { schoolName }),
            ...(schoolPhone   && { schoolPhone }),
            ...(schoolAddress && { schoolAddress }),
            ...(principalName && { principalName }),
            ...(paymentLink   && { paymentLink }),
          },
          updatedBy: req.user?.username || 'admin',
        },
        { upsert: true, new: true }
      );
    }

    // Restart cron if needed
    try {
      const cronModule = require('../jobs/feeReminderCron');
      if (typeof cronModule.restartCron === 'function') await cronModule.restartCron();
    } catch (_) {}

    res.json({ message: 'WhatsApp configuration saved successfully.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/whatsapp/test — send test message
// =============================================================
router.post('/test', auth, adminOnly, async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'phone is required.' });

    const config = await getWhatsappConfig();
    if (!config.metaConfigured && !config.twilioConfigured) {
      return res.status(400).json({
        error: 'WhatsApp not configured. Please save Meta or Twilio credentials first.',
      });
    }

    const result = await sendFeeReminder({
      student: {
        fullName:      'Test Student',
        class:         '10',
        section:       'A',
        rollNumber:    '01',
        guardianName:  'Test Parent',
        guardianPhone: phone,
        studentId:     'TEST001',
      },
      amountDue: 5000,
      dueDate:   new Date().toISOString().slice(0, 10),
      sentBy:    req.user?.username || 'admin',
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/whatsapp/send-admission-message
//
// Body (admission approved):
//   { studentName, applyingClass, applicationId, phone,
//     fatherName, motherName, session, type: 'approved' }
//
// Body (admission rejected):
//   { ...same, type: 'rejected', reason: '...' }
//
// Body (student enrolled / new student added):
//   { studentId, fullName, class, section, rollNumber,
//     guardianName, guardianPhone, admissionDate, type: 'enrolled' }
// =============================================================
router.post('/send-admission-message', auth, adminOnly, async (req, res) => {
  try {
    const { type = 'approved', studentId } = req.body;
    const sentBy = req.user?.username || 'admin';

    let result;

    // ── If studentId provided, fetch from MongoDB ──────────
    if (studentId && (type === 'enrolled' || type === 'welcome')) {
      const student = await Student.findOne({ studentId: studentId.toUpperCase() }).lean();
      if (!student) return res.status(404).json({ error: 'Student not found: ' + studentId });

      result = await sendNewStudentWelcome({ student, sentBy });

    } else if (type === 'rejected') {
      const admission = {
        studentName:   req.body.studentName,
        applyingClass: req.body.applyingClass,
        applicationId: req.body.applicationId || 'N/A',
        phone:         req.body.phone,
        fatherName:    req.body.fatherName || '',
        motherName:    req.body.motherName || '',
        notes:         req.body.reason || '',
        session:       req.body.session || '',
      };

      if (!admission.studentName || !admission.phone) {
        return res.status(400).json({ error: 'studentName and phone are required.' });
      }

      result = await sendAdmissionRejected({ admission, reason: req.body.reason || '', sentBy });

    } else {
      // Default: approved
      const admission = {
        studentName:   req.body.studentName,
        applyingClass: req.body.applyingClass,
        applicationId: req.body.applicationId || 'N/A',
        phone:         req.body.phone,
        fatherName:    req.body.fatherName || '',
        motherName:    req.body.motherName || '',
        session:       req.body.session || '',
      };

      if (!admission.studentName || !admission.phone) {
        return res.status(400).json({ error: 'studentName and phone are required.' });
      }

      result = await sendAdmissionApproved({ admission, sentBy });
    }

    if (result.success) {
      res.json({ message: 'Admission notification sent successfully.', ...result });
    } else {
      res.status(500).json({ error: result.error || 'Failed to send message.' });
    }

  } catch (err) {
    console.error('[WhatsApp] /send-admission-message error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/whatsapp/send-fees-message
//
// Body:
//   { studentId, paymentAmount, paymentMethod, receiptNumber,
//     paymentDate, academicYear }
//
// Fetches student from MongoDB, fetches ledger data, calculates:
//   - Previous Due
//   - Current Month Fees
//   - Total Paid
//   - Remaining Due
// Then sends WhatsApp payment confirmation.
// =============================================================
router.post('/send-fees-message', auth, adminOnly, async (req, res) => {
  try {
    const {
      studentId,
      paymentAmount,
      paymentMethod = 'Cash',
      receiptNumber = '',
      paymentDate,
      academicYear,
    } = req.body;

    if (!studentId || !paymentAmount) {
      return res.status(400).json({ error: 'studentId and paymentAmount are required.' });
    }

    // ── Fetch student from MongoDB ─────────────────────────
    const student = await Student.findOne({ studentId: studentId.toUpperCase() }).lean();
    if (!student) return res.status(404).json({ error: 'Student not found: ' + studentId });

    const year = academicYear || currentAcademicYear();

    // ── Fetch ledger summary from MongoDB ─────────────────
    const ledgerSummary = await getLedgerSummary(student.studentId, year);

    const payment = {
      amount:        Number(paymentAmount),
      method:        paymentMethod,
      receiptNumber: receiptNumber,
      date:          paymentDate || new Date().toISOString().slice(0, 10),
      academicYear:  year,
    };

    const sentBy = req.user?.username || 'admin';

    const result = await sendFeesPaymentReceived({ student, payment, ledgerSummary, sentBy });

    if (result.success) {
      res.json({
        message: 'Fees payment notification sent successfully.',
        studentName:   student.fullName,
        studentClass:  student.class,
        ledgerSummary: ledgerSummary,
        ...result,
      });
    } else {
      res.status(500).json({ error: result.error || 'Failed to send message.' });
    }

  } catch (err) {
    console.error('[WhatsApp] /send-fees-message error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// POST /api/whatsapp/send-fee-reminder
//
// Send due reminder for one or many students.
// Body option 1 — single student:
//   { studentId, dueDate, academicYear }
// Body option 2 — multiple students:
//   { studentIds: ['SCH001', ...], dueDate, academicYear }
// Body option 3 — all students with dues:
//   { sendAll: true, dueDate, academicYear }
// =============================================================
router.post('/send-fee-reminder', auth, adminOnly, async (req, res) => {
  try {
    const { studentId, studentIds, sendAll, dueDate, academicYear } = req.body;
    const year   = academicYear || currentAcademicYear();
    const sentBy = req.user?.username || 'admin';

    let LedgerEntry;
    try { LedgerEntry = require('../models/LedgerEntry'); } catch (_) { LedgerEntry = null; }

    // Build student list
    let targetStudents = [];

    if (sendAll) {
      targetStudents = await Student.find({ isActive: true }).lean();

    } else if (studentIds?.length) {
      targetStudents = await Student.find({
        studentId: { $in: studentIds.map(id => id.toUpperCase()) },
        isActive:  true,
      }).lean();

    } else if (studentId) {
      const s = await Student.findOne({ studentId: studentId.toUpperCase(), isActive: true }).lean();
      if (!s) return res.status(404).json({ error: 'Student not found: ' + studentId });
      targetStudents = [s];

    } else {
      return res.status(400).json({ error: 'Provide studentId, studentIds[], or sendAll: true' });
    }

    const results = { sent: 0, failed: 0, skipped: 0, details: [] };

    for (const student of targetStudents) {

      // Get ledger-based balance (most accurate)
      let pending = 0;
      let ledgerSummary = null;

      if (LedgerEntry) {
        try {
          const summary = await getLedgerSummary(student.studentId, year);
          if (summary) {
            pending      = summary.remainingDue;
            ledgerSummary = summary;
          }
        } catch (_) {}
      }

      // Fallback to FeeStructure/FeePayment if no ledger
      if (!LedgerEntry || pending === 0 && !ledgerSummary) {
        try {
          const FeeStructure = require('../models/FeeStructure');
          const FeePayment   = require('../models/FeePayment');
          const structure    = await FeeStructure.findOne({ academicYear: year, class: student.class });
          const payments     = await FeePayment.find({ studentId: student.studentId, academicYear: year, isCancelled: false });
          const totalFee     = structure?.totalAnnualFee || 0;
          const totalPaid    = payments.reduce((s, p) => s + p.totalAmount, 0);
          pending = Math.max(0, totalFee - totalPaid);
        } catch (_) {}
      }

      if (pending <= 0) {
        results.skipped++;
        results.details.push({
          studentId: student.studentId,
          name:      student.fullName,
          status:    'skipped',
          reason:    'No pending fees',
        });
        continue;
      }

      const result = await sendFeeReminder({ student, amountDue: pending, dueDate, sentBy, ledgerSummary });

      if (result.success) {
        results.sent++;
        results.details.push({ studentId: student.studentId, name: student.fullName, status: 'sent', pending });
      } else {
        results.failed++;
        results.details.push({ studentId: student.studentId, name: student.fullName, status: 'failed', error: result.error });
      }

      // Small delay to avoid rate limits
      if (targetStudents.length > 1) await new Promise(r => setTimeout(r, 300));
    }

    res.json({
      message: `Done: ${results.sent} sent, ${results.failed} failed, ${results.skipped} skipped`,
      ...results,
    });

  } catch (err) {
    console.error('[WhatsApp] /send-fee-reminder error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/whatsapp/due-students
// Students with pending fees (ledger-based if available)
// =============================================================
router.get('/due-students', auth, adminOnly, async (req, res) => {
  try {
    const { academicYear, class: cls, minDue = 0 } = req.query;
    const year = academicYear || currentAcademicYear();

    let LedgerEntry;
    try { LedgerEntry = require('../models/LedgerEntry'); } catch (_) { LedgerEntry = null; }

    const filter = { isActive: true };
    if (cls) filter.class = cls;
    const students = await Student.find(filter).lean();

    const dueStudents = [];

    for (const student of students) {
      let pending = 0;
      let summary = null;

      if (LedgerEntry) {
        try {
          summary = await getLedgerSummary(student.studentId, year);
          if (summary) pending = summary.remainingDue;
        } catch (_) {}
      }

      // Fallback
      if (!summary) {
        try {
          const FeeStructure = require('../models/FeeStructure');
          const FeePayment   = require('../models/FeePayment');
          const structure    = await FeeStructure.findOne({ academicYear: year, class: student.class });
          const payments     = await FeePayment.find({ studentId: student.studentId, academicYear: year, isCancelled: false });
          const totalFee     = structure?.totalAnnualFee || 0;
          const totalPaid    = payments.reduce((s, p) => s + p.totalAmount, 0);
          pending = Math.max(0, totalFee - totalPaid);
        } catch (_) {}
      }

      if (pending > Number(minDue)) {
        dueStudents.push({
          studentId:     student.studentId,
          fullName:      student.fullName,
          class:         student.class,
          section:       student.section || 'A',
          rollNumber:    student.rollNumber || '',
          guardianName:  student.guardianName || '',
          guardianPhone: student.guardianPhone || '',
          pending,
          prevDue:            summary?.prevDue            || 0,
          currentMonthFees:   summary?.currentMonthFees   || 0,
          totalCharged:       summary?.totalCharged        || 0,
          totalPaid:          summary?.totalPaid           || 0,
          hasPhone:           !!(student.guardianPhone),
        });
      }
    }

    dueStudents.sort((a, b) =>
      a.class.localeCompare(b.class, undefined, { numeric: true }) ||
      a.fullName.localeCompare(b.fullName)
    );

    res.json({ data: dueStudents, total: dueStudents.length, academicYear: year });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/whatsapp/student-ledger/:studentId
// Returns complete ledger summary for a student
// =============================================================
router.get('/student-ledger/:studentId', auth, adminOnly, async (req, res) => {
  try {
    const { studentId } = req.params;
    const { academicYear } = req.query;

    const student = await Student.findOne({ studentId: studentId.toUpperCase() }).lean();
    if (!student) return res.status(404).json({ error: 'Student not found.' });

    const summary = await getLedgerSummary(student.studentId, academicYear);

    res.json({
      student: {
        studentId:     student.studentId,
        fullName:      student.fullName,
        class:         student.class,
        section:       student.section,
        rollNumber:    student.rollNumber,
        guardianName:  student.guardianName,
        guardianPhone: student.guardianPhone,
      },
      ledgerSummary: summary,
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/whatsapp/logs — message history
// =============================================================
router.get('/logs', auth, adminOnly, async (req, res) => {
  try {
    const { type, status, limit = 50, page = 1 } = req.query;
    const filter = {};
    if (type)   filter.messageType = type;
    if (status) filter.status      = status;

    const total = await WhatsappLog.countDocuments(filter);
    const logs  = await WhatsappLog.find(filter)
      .sort({ sentAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({ data: logs, total, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// =============================================================
// GET /api/whatsapp/stats — summary statistics
// =============================================================
router.get('/stats', auth, adminOnly, async (req, res) => {
  try {
    const [total, sent, failed, admissions, reminders] = await Promise.all([
      WhatsappLog.countDocuments({}),
      WhatsappLog.countDocuments({ status: 'sent' }),
      WhatsappLog.countDocuments({ status: 'failed' }),
      WhatsappLog.countDocuments({ messageType: { $in: ['admission_approved', 'admission_rejected'] } }),
      WhatsappLog.countDocuments({ messageType: 'fee_reminder' }),
    ]);

    res.json({
      data: {
        total, sent, failed,
        successRate: total > 0 ? ((sent / total) * 100).toFixed(1) + '%' : '0%',
        byType: { admissions, reminders, other: total - admissions - reminders },
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
