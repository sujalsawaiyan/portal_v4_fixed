// =============================================================
//  seed.js — Bootstrap Database with Admin + Default Data
//  Run: npm run seed
//  SCHOOL MANAGEMENT PORTAL
// =============================================================

require('dotenv').config();
const mongoose       = require('mongoose');
const User           = require('./models/User');
const Teacher        = require('./models/Teacher');
const Event          = require('./models/Event');
const House          = require('./models/House');
const SchoolSettings   = require('./models/SchoolSettings');
const TeacherAccount   = require('./models/TeacherAccount');
const Class          = require('./models/Class');
const TopStudent     = require('./models/TopStudent');

const MONGO_URI    = process.env.MONGO_URI    || 'mongodb://127.0.0.1:27017/school_portal';
const SCHOOL_NAME  = process.env.SCHOOL_NAME  || "Your School Name";

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('✅  MongoDB connected');

  // ── 1. Admin User ────────────────────────────────────────────
  const existing = await User.findOne({ username: 'admin' });
  if (!existing) {
    await User.create({
      username: 'admin',
      password: 'Admin@1234',
      fullName: 'School Administrator',
      role:     'admin',
      isActive: true,
    });
    console.log('✅  Admin user created  →  username: admin  |  password: Admin@1234');
  } else {
    console.log('ℹ️   Admin user already exists — skipping');
  }

  // ── 2. Default Teachers ──────────────────────────────────────
  const tCount = await Teacher.countDocuments();
  if (tCount === 0) {
    await Teacher.insertMany([
      { name:"Dr. Sarah Johnson", fullName:"Dr. Sarah Johnson", subject:'Administration', department:'Management', dept:'Management', experience:22, exp:22, role:'principal',            qualification:'Ph.D. Education', qual:'Ph.D. Education', order:1 },
      { name:'Mr. David Williams', fullName:'Mr. David Williams', subject:'Administration', department:'Management', dept:'Management', experience:18, exp:18, role:'vice_principal',       qualification:'M.Ed.',            qual:'M.Ed.',           order:2 },
      { name:'Mrs. Priya Sharma',    fullName:'Mrs. Priya Sharma',    subject:'Mathematics',    department:'Maths',      dept:'Maths',      experience:15, exp:15, role:'academic_coordinator', qualification:'M.Sc. Mathematics',qual:'M.Sc. Mathematics',order:3 },
      { name:'Mr. Rahul Verma',      fullName:'Mr. Rahul Verma',      subject:'Science',        department:'Science',    dept:'Science',    experience:12, exp:12, role:'activity_coordinator', qualification:'M.Sc. Science',    qual:'M.Sc. Science',   order:4 },
      { name:'Mrs. Anita Mehta',     fullName:'Mrs. Anita Mehta',     subject:'Physics',        department:'Science',    dept:'Science',    experience:12, exp:12, role:'teacher',              qualification:'M.Sc. Physics',    qual:'M.Sc. Physics',   order:5 },
      { name:'Mr. Suresh Kumar',     fullName:'Mr. Suresh Kumar',     subject:'Chemistry',      department:'Science',    dept:'Science',    experience:10, exp:10, role:'teacher',              qualification:'M.Sc. Chemistry',  qual:'M.Sc. Chemistry', order:6 },
      { name:'Mr. Anil Tiwari',      fullName:'Mr. Anil Tiwari',      subject:'English',        department:'Languages',  dept:'Languages',  experience:14, exp:14, role:'teacher',              qualification:'M.A. English',     qual:'M.A. English',    order:7 },
      { name:'Mrs. Deepa Singh',     fullName:'Mrs. Deepa Singh',     subject:'Hindi',        department:'Languages',  dept:'Languages',  experience:11, exp:11, role:'teacher',              qualification:'M.A. Hindi',       qual:'M.A. Hindi',      order:8 },
    ]);
    console.log('✅  Default teachers seeded (8)');
  } else {
    console.log(`ℹ️   Teachers already exist (${tCount}) — skipping`);
  }

  // ── 3. Default Houses ────────────────────────────────────────
  const hCount = await House.countDocuments();
  if (hCount === 0) {
    await House.insertMany([
      { id:1, name:'Blue House',   color:'#00A8E8', gradient:'linear-gradient(135deg,#00A8E8,#6C63FF)', emoji:'🔵', sports:1200, study:1350, activities:1070, discipline:1200, captain:'Arjun Patel',  viceCaptain:'Meera Singh' },
      { id:2, name:'Green House',  color:'#00D4AA', gradient:'linear-gradient(135deg,#00D4AA,#00C851)', emoji:'🟢', sports:1150, study:1200, activities:1060, discipline:1200, captain:'Priya Nair',   viceCaptain:'Karan Mehta' },
      { id:3, name:'Red House',    color:'#FF6B6B', gradient:'linear-gradient(135deg,#FF6B6B,#FF4757)', emoji:'🔴', sports:1300, study:1000, activities:890,  discipline:1200, captain:'Kavya Roy',    viceCaptain:'Nisha Roy' },
      { id:4, name:'Yellow House', color:'#FFD700', gradient:'linear-gradient(135deg,#FFD700,#FFA502)', emoji:'🟡', sports:1000, study:1100, activities:980,  discipline:1100, captain:'Rohan Gupta',  viceCaptain:'Ananya Das' },
    ]);
    console.log('✅  Default houses seeded (4)');
  } else {
    console.log(`ℹ️   Houses already exist (${hCount}) — skipping`);
  }

  // ── 4. Default Events ────────────────────────────────────────
  const eCount = await Event.countDocuments();
  if (eCount === 0) {
    await Event.insertMany([
      { title:'Annual Sports Day',        type:'sports',   date:'2025-11-15', description:'Inter-house athletics and field events.', venue:'School Ground',  featured:true,  is_featured:true  },
      { title:'Parent-Teacher Meeting',   type:'meeting',  date:'2025-10-20', description:'Discuss Term-I progress with parents.',    venue:'Classrooms',     featured:true,  is_featured:true  },
      { title:'Science Exhibition',       type:'academic', date:'2025-12-05', description:'Student project exhibition open to all.',   venue:'School Hall',    featured:true,  is_featured:true  },
      { title:'Annual Day & Prize Giving',type:'cultural', date:'2026-01-18', description:'Cultural performances and prize distribution.', venue:'Auditorium', featured:true,  is_featured:true  },
    ]);
    console.log('✅  Default events seeded (4)');
  } else {
    console.log(`ℹ️   Events already exist (${eCount}) — skipping`);
  }

  // ── 5. Default School Settings ───────────────────────────────
  const settingsCount = await SchoolSettings.countDocuments();
  if (settingsCount === 0) {
    await SchoolSettings.insertMany([
      { key: 'schoolInfo', value: {
          name:        SCHOOL_NAME,
          tagline:     'Excellence in Education',
          established: '1980',
          cbseCode:    '1234567',
          website:     'www.yourschool.edu.in',
          phone:       '+91 98765 43210',
          email:       'info@yourschool.edu.in',
          address:     '12, School Road, City - 400001',
          logoData:    '',
        }
      },
      { key: 'schoolTiming', value: {
          workingDays: 'Monday – Saturday',
          schoolHours: '7:45 AM – 2:30 PM',
          lkgUkgHours: '8:00 AM – 11:15 AM',
          lunchBreak:  '12:30 PM – 1:00 PM',
          officeHours: '9:00 AM – 4:00 PM',
        }
      },
      { key: 'stats', value: {
          students: 1240, teachers: 68, classes: 28,
          years: 45, alumni: 12400, awards: 320, passRate: 95,
        }
      },
      { key: 'homepageContent', value: {
          heroTitle:      'Shaping Minds, Building Futures',
          heroSubtitle:   `${SCHOOL_NAME} is committed to holistic education.`,
          aboutUs:        `Founded in 1980, ${SCHOOL_NAME} has been a beacon of quality education.`,
          principalName:  "Dr. Sarah Johnson",
          principalTitle: `Principal, ${SCHOOL_NAME}`,
          principalQual:  'M.Ed., Ph.D. | 28 Years Experience',
          principalMsg:   `At ${SCHOOL_NAME}, we believe that education is not merely the transfer of knowledge, but the transformation of character.`,
          principalMsg2:  'We provide an environment where every child is encouraged to ask questions and explore ideas.',
          principalPhoto: '',
        }
      },
      { key: 'topStudents', value: [
          { rank:1, name:'Aanya Sharma', class:'XII-A', score:98.4, house:'Blue',   avatar:'👩‍🎓', image:'' },
          { rank:2, name:'Arjun Patel',  class:'XII-B', score:97.8, house:'Red',    avatar:'👨‍🎓', image:'' },
          { rank:3, name:'Priya Nair',   class:'XI-A',  score:97.1, house:'Green',  avatar:'👩‍🎓', image:'' },
          { rank:4, name:'Rohan Gupta',  class:'XII-A', score:96.5, house:'Yellow', avatar:'👨‍🎓', image:'' },
          { rank:5, name:'Sneha Iyer',   class:'X-B',   score:96.0, house:'Blue',   avatar:'👩‍🎓', image:'' },
        ]
      },
      { key: 'admissions', value: {
          visible: false, heading: 'Admissions Open 2025-26',
          session: '2025–2026', subtext: '', deadline: '',
          phone: '', classes: 'LKG, UKG, Class I to XII',
          glowEnabled: false, imageData: '',
        }
      },
      { key: 'socialLinks',   value: { facebook:'', instagram:'', youtube:'', twitter:'', telegram:'', linkedin:'' } },
      { key: 'upiPayment',    value: { upiId:'', accountName:'', bankName:'', qrData:'' } },
      { key: 'feeStructure',  value: {
          heading: 'Annual Fee Structure 2026–27',
          categories: [
            { label:'LKG / UKG',    tuition:12000, activity:2500, transport:6000, total:20500 },
            { label:'Class I–V',    tuition:15000, activity:3000, transport:6000, total:24000 },
            { label:'Class VI–VIII',tuition:18000, activity:3500, transport:6000, total:27500 },
            { label:'Class IX–X',   tuition:22000, activity:4000, transport:6000, total:32000 },
            { label:'Class XI–XII', tuition:26000, activity:4500, transport:6000, total:36500 },
          ],
        }
      },
      { key: 'lockdown', value: { active:false, title:'School Closed — Online Classes Active', message:'' } },
    ]);
    console.log('✅  Default school settings seeded');
  } else {
    console.log(`ℹ️   Settings already exist (${settingsCount}) — skipping`);
  }

  console.log('\n🎉  Seed complete!');

  // ── SEED ALL 28 CLASSES (LKG/UKG + 1-12, Sections A & B) ──
  const CLASS_NAMES = ['LKG','UKG','1','2','3','4','5','6','7','8','9','10','11','12'];
  const SECTIONS    = ['A','B'];
  const classCount  = await Class.countDocuments();
  if (classCount === 0) {
    const classDocs = [];
    CLASS_NAMES.forEach(function(cn) {
      SECTIONS.forEach(function(sec) {
        classDocs.push({
          className:      cn,
          section:        sec,
          teacherName:    '',
          teacherPhoto:   '',
          teacherExp:     0,
          teacherSubject: '',
          teacherQual:    '',
          totalStudents:  0,
          room:           '',
          isActive:       true,
        });
      });
    });
    await Class.insertMany(classDocs);
    console.log('✅  28 classes seeded (LKG-A/B through 12-A/B)');
  } else {
    // Ensure all classes exist (add any missing ones)
    let added = 0;
    for (const cn of CLASS_NAMES) {
      for (const sec of SECTIONS) {
        const exists = await Class.findOne({ className: cn, section: sec });
        if (!exists) {
          await Class.create({ className: cn, section: sec, isActive: true });
          added++;
        }
      }
    }
    if (added > 0) console.log(`✅  ${added} missing classes added`);
    else console.log(`ℹ️   Classes already exist (${classCount}) — ensuring all 28 present`);
  }
  console.log('   Admin login:  admin / Admin@1234');
  console.log('   Change password after first login!\n');

  // ── SEED TOP STUDENTS ──────────────────────────────────────
  const tsCount = await TopStudent.countDocuments();
  if (!tsCount) {
    await TopStudent.insertMany([
      // Class 10 — 2025
      { year:'2025', classLabel:'Class 10', rank:1, name:'Aanya Sharma',  score:98.4, house:'Blue House',   achievement:'School Topper',   subjects:'Science' },
      { year:'2025', classLabel:'Class 10', rank:2, name:'Arjun Patel',   score:97.8, house:'Red House',    achievement:'',                subjects:'Science' },
      { year:'2025', classLabel:'Class 10', rank:3, name:'Priya Nair',    score:97.1, house:'Green House',  achievement:'',                subjects:'Commerce' },
      // Class 12 — 2025
      { year:'2025', classLabel:'Class 12', rank:1, name:'Rohan Gupta',   score:96.5, house:'Yellow House', achievement:'District Rank 2', subjects:'Science' },
      { year:'2025', classLabel:'Class 12', rank:2, name:'Sneha Iyer',    score:96.0, house:'Blue House',   achievement:'',                subjects:'Science' },
      { year:'2025', classLabel:'Class 12', rank:3, name:'Kabir Khan',    score:95.5, house:'Green House',  achievement:'',                subjects:'Arts' },
    ]);
    console.log('✅  Default top students seeded (6)');
  } else {
    console.log(`ℹ️   Top students already exist (${tsCount}) — skipping seed`);
  }

  // ── 28 Teacher Accounts (LKG-A/B to 12-A/B) ─────────────
  const tAccCount = await TeacherAccount.countDocuments();
  if (tAccCount === 0) {
    const teacherAccounts = [];
    const classes  = ['LKG','UKG','1','2','3','4','5','6','7','8','9','10','11','12'];
    const sections = ['A','B'];
    const teacherNames = {
      'LKG': { A:'Mrs. Sunita Verma',     B:'Mrs. Kavita Yadav'    },
      'UKG': { A:'Mrs. Rekha Sharma',     B:'Mrs. Pooja Gupta'     },
      '1':   { A:'Mrs. Anita Singh',      B:'Mrs. Meena Patel'     },
      '2':   { A:'Mrs. Priya Joshi',      B:'Mrs. Deepa Mishra'    },
      '3':   { A:'Mrs. Nisha Tiwari',     B:'Mrs. Sonal Dubey'     },
      '4':   { A:'Mrs. Ritu Agarwal',     B:'Mrs. Neha Srivastava' },
      '5':   { A:'Mrs. Anjali Rao',       B:'Mr. Suresh Kumar'     },
      '6':   { A:'Mr. Ramesh Pandey',     B:'Mrs. Sunita Chauhan'  },
      '7':   { A:'Mr. Anil Tiwari',       B:'Mrs. Vandana Singh'   },
      '8':   { A:'Mr. Vijay Sharma',      B:'Mrs. Kiran Gupta'     },
      '9':   { A:'Mr. Manoj Kumar',       B:'Mrs. Savita Mishra'   },
      '10':  { A:'Mrs. Priya Sharma',     B:'Mr. Deepak Verma'     },
      '11':  { A:'Mrs. Anita Mehta',      B:'Mr. Rajesh Saxena'    },
      '12':  { A:'Mr. Sunil Chaurasia',   B:'Mrs. Geeta Pandey'    },
    };
    for (const cls of classes) {
      for (const sec of sections) {
        const clsLabel = (cls === 'LKG' || cls === 'UKG') ? cls.toLowerCase() : cls;
        const username = `teacher_${clsLabel}${sec.toLowerCase()}`;
        teacherAccounts.push({
          username,
          password:        'Teacher@123',
          fullName:        teacherNames[cls][sec],
          email:           `${username}@school.com`,
          phone:           '',
          assignedClass:   cls,
          assignedSection: sec,
          subjects:        [],
          isActive:        true,
        });
      }
    }
    await TeacherAccount.insertMany(teacherAccounts);
    console.log('✅  28 Teacher accounts seeded (LKG to Class 12, Sections A & B)');
    console.log('   Username format: teacher_lkga ... teacher_12b');
    console.log('   Password for ALL: Teacher@123');
  } else {
    console.log(`ℹ️   Teacher accounts already exist (${tAccCount}) — skipping`);
  }

  console.log('\n══════════════════════════════════════════════');
  console.log('  🔑  DEFAULT LOGIN CREDENTIALS');
  console.log('  Admin   → username: admin         | password: Admin@1234');
  console.log('  Teachers → password for all:       Teacher@123');
  console.log('  Format: teacher_lkga/b, teacher_ukga/b, teacher_1a/b … teacher_12a/b');
  console.log('  ⚠️  Please change passwords after first login!');
  console.log('══════════════════════════════════════════════\n');

  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => {
  console.error('❌  Seed failed:', err.message);
  process.exit(1);
});
