// =============================================================
//  server.js — SCHOOL PORTAL v2.4.0 (Production)
//  Pure MongoDB · Secured · All Modules Connected
//  Run: npm start  |  Dev: npm run dev
// =============================================================

require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const morgan   = require('morgan');
const path     = require('path');
const fs       = require('fs');
const mongoose = require('mongoose');
const { sanitizeMiddleware } = require('./utils/sanitize');

// ── Optional security packages (graceful fallback if not yet installed) ──
let helmet, rateLimit, mongoSanitize;
try { helmet        = require('helmet');                  } catch (_) { console.warn('[Security] helmet not installed — run npm install'); }
try { rateLimit     = require('express-rate-limit');      } catch (_) { console.warn('[Security] express-rate-limit not installed — run npm install'); }
try { mongoSanitize = require('express-mongo-sanitize'); } catch (_) { console.warn('[Security] express-mongo-sanitize not installed — run npm install'); }

const app  = express();
const PORT = process.env.PORT || 3000;

// =============================================================
// ENSURE TEMP UPLOAD DIR EXISTS
// =============================================================
const tmpDir = path.join(__dirname, '../uploads/tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

// =============================================================
// MONGODB CONNECTION
// =============================================================
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/school_portal';

mongoose.connect(MONGO_URI)
  .then(async () => {
    console.log('✅  MongoDB connected');
    // Start WhatsApp fee reminder cron (only if mode = automatic in settings)
    try {
      const { startCron } = require('./jobs/feeReminderCron');
      await startCron();
    } catch (e) {
      console.warn('[Server] FeeReminderCron start failed (non-fatal):', e.message);
    }
  })
  .catch(err => {
    console.error('❌  MongoDB connection failed:', err.message);
    process.exit(1);
  });

// =============================================================
// SECURITY HEADERS — helmet
// =============================================================
if (helmet) {
  app.use(helmet({
    contentSecurityPolicy:      false,
    crossOriginEmbedderPolicy:  false,
  }));
}

// =============================================================
// CORS — allow localhost (any port) + production domain
// =============================================================
const ALLOWED_ORIGINS = [
  'http://localhost:3000',
  'http://127.0.0.1:3000',
  'http://localhost:5000',
  'http://127.0.0.1:5000',
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:8080',
  'http://127.0.0.1:8080',
  process.env.FRONTEND_URL,
  process.env.FRONTEND_URL_2,
].filter(Boolean);

app.use(cors({
  origin(origin, cb) {
    if (!origin) return cb(null, true); // same-origin or server-to-server
    // Allow any localhost / 127.0.0.1 port in development
    if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) return cb(null, true);
    if (ALLOWED_ORIGINS.some(o => origin.startsWith(o))) return cb(null, true);
    cb(new Error('CORS: origin not allowed'));
  },
  methods:        ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials:    true,
}));

// =============================================================
// BODY PARSER (50mb to support backup/restore imports)
// =============================================================
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// =============================================================
// REFERRER POLICY — Fix Cloudinary image tracking prevention
// (Browsers like Edge/Firefox block Cloudinary storage access
//  when Referrer-Policy is strict. This relaxes it safely.)
// =============================================================
app.use(function(req, res, next) {
  res.setHeader('Referrer-Policy', 'no-referrer-when-downgrade');
  next();
});

// =============================================================
// MONGODB QUERY INJECTION SANITIZATION
// =============================================================
if (mongoSanitize) {
  app.use(mongoSanitize());
}

// =============================================================
// XSS / HTML INJECTION SANITIZATION (built-in, no extra deps)
// Strips <script>, onerror=, javascript: from all req.body strings
// =============================================================
app.use(sanitizeMiddleware);

// =============================================================
// REQUEST LOGGING
// =============================================================
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

// =============================================================
// RATE LIMITING
// =============================================================
if (rateLimit) {
  const authLimiter = rateLimit({
    windowMs:        15 * 60 * 1000,
    max:             20,
    standardHeaders: true,
    legacyHeaders:   false,
    message: { error: 'Too many login attempts. Please try again after 15 minutes.' },
  });
  app.use('/api/auth/login', authLimiter);

  const admissionLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max:      10,
    // Only block public POST submissions — skip GET/PUT/DELETE and skip requests with admin token
    skip: (req) => {
      if (req.method !== 'POST') return true;                          // allow GET/PUT/DELETE always
      const auth = req.headers['authorization'] || '';
      if (auth.startsWith('Bearer ') && auth.length > 20) return true; // allow admin actions
      return false;
    },
    message:  { error: 'Too many admission submissions. Please try again later.' },
  });
  app.use('/api/admissions', admissionLimiter);

  const generalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max:      300,
    skip:     (req) => req.method === 'GET',
    message:  { error: 'Too many requests. Please slow down.' },
  });
  app.use('/api/', generalLimiter);
}

// =============================================================
// STATIC FILES
// =============================================================
// ── Payment Guard — must come BEFORE express.static so the
//    middleware can intercept direct URL access to payment.html
//    when admin has toggled it OFF in the admin panel.
const { paymentGuard } = require('./middleware/paymentGuard');
app.get('/frontend/pages/payment.html', paymentGuard);

app.use(express.static(path.join(__dirname, '..')));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// =============================================================
// API ROUTES
// =============================================================
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/students',      require('./routes/students'));
app.use('/api/teachers',      require('./routes/teachers'));
app.use('/api/attendance',    require('./routes/attendance'));
// ⚠️  /api/fees is DEPRECATED — routes now return 410 with migration message
// ✅  Use /api/fee-payments for all fee operations
app.use('/api/fees',          require('./routes/fees'));
app.use('/api/fee-structure', require('./routes/feeStructure'));
app.use('/api/fee-payments',  require('./routes/feePayments'));
app.use('/api/payment',       require('./routes/feePayments'));
app.use('/api/sms',           require('./routes/sms'));
app.use('/api/events',        require('./routes/events'));
app.use('/api/announcements', require('./routes/announcements'));
app.use('/api/gallery',       require('./routes/gallery'));
app.use('/api/houses',        require('./routes/houses'));
app.use('/api/contributors',  require('./routes/contributors'));
app.use('/api/classes',       require('./routes/classes'));
app.use('/api/settings',      require('./routes/settings'));
app.use('/api/dashboard',     require('./routes/dashboard'));
app.use('/api/admissions',    require('./routes/admissions'));
app.use('/api/images',        require('./routes/imageRoutes'));
app.use('/api/topstudents',   require('./routes/topStudents'));
app.use('/api/teacher',       require('./routes/teacher-panel'));
app.use('/api/security',      require('./routes/security'));
app.use('/api/result',        require('./routes/result'));
app.use('/api/backup',        require('./routes/backup'));
app.use('/api/admin-data',    require('./routes/adminData'));   // ← Data management (clear demo data)
app.use('/api/ledger',        require('./routes/ledger'));
app.use('/api/discounts',     require('./routes/discounts'));   // ← Discount management
app.use('/api/timetable',      require('./routes/timetable'));      // ← Timetable management
app.use('/api/exam-schedule',  require('./routes/examSchedule'));   // ← Exam Schedule management
app.use('/api/transport',      require('./routes/transport'));      // ← Transport Fee Module v2.6.0

// =============================================================
// PARENT PORTAL — Read-only data for parents/students
// =============================================================
app.use('/api/parent',        require('./routes/parentPortal'));

// =============================================================
// HEALTH CHECK
// =============================================================
app.get('/health', (_req, res) => {
  const state  = mongoose.connection.readyState;
  const states = { 0:'disconnected', 1:'connected', 2:'connecting', 3:'disconnecting' };
  res.json({ status: state === 1 ? 'ok' : 'degraded', mongodb: states[state], uptime: process.uptime(), version:'2.4.0' });
});

// =============================================================
// WHATSAPP MODULE — Routes + Cron (Twilio optional)
// =============================================================
app.use('/api/whatsapp', require('./routes/whatsapp'));

// =============================================================
// SPA FALLBACK
// =============================================================
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API route not found: ' + req.path });
  }
  res.sendFile(path.join(__dirname, '..', 'index.html'));
});

// =============================================================
// GLOBAL ERROR HANDLER
// =============================================================
app.use((err, _req, res, _next) => {
  const isDev = process.env.NODE_ENV !== 'production';
  console.error('[Server Error]', err.message);
  res.status(err.status || 500).json({ error: isDev ? err.message : 'Internal server error' });
});

// =============================================================
// START
// =============================================================
app.listen(PORT, () => {
  console.log(`
  ╔══════════════════════════════════════════════════╗
  ║   SCHOOL PORTAL — v2.4.0 Secured      ║
  ║   Running on  http://localhost:${PORT}               ║
  ║   Admin Panel: /admin_panel/login.html           ║
  ╚══════════════════════════════════════════════════╝
  `);
});

module.exports = app;
