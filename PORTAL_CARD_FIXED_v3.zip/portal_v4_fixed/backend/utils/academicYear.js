// =============================================================
//  utils/academicYear.js — Single source of truth
//  Pehle yeh function har file mein duplicate tha (fees, ledger,
//  discounts, dashboard, cron) — ab sirf yahan hai.
//
//  Usage:
//    const { currentAcademicYear, parseAcademicYear } = require('../utils/academicYear');
// =============================================================

/**
 * Returns current academic year string like "2026-27"
 * Logic: April se nayi academic year shuru hoti hai (Indian schools)
 */
function currentAcademicYear() {
  const now = new Date();
  const yr  = now.getFullYear();
  const mo  = now.getMonth() + 1; // 1-indexed
  return mo >= 4
    ? `${yr}-${String(yr + 1).slice(2)}`
    : `${yr - 1}-${String(yr).slice(2)}`;
}

/**
 * Validates if a string looks like a valid academic year "YYYY-YY"
 * e.g. "2026-27" → true, "2025" → false
 */
function isValidAcademicYear(str) {
  return typeof str === 'string' && /^\d{4}-\d{2}$/.test(str);
}

/**
 * Parses academic year string and returns start/end year numbers
 * "2026-27" → { startYear: 2026, endYear: 2027 }
 */
function parseAcademicYear(yearStr) {
  const yr = yearStr || currentAcademicYear();
  const [startStr, endStr] = yr.split('-');
  const startYear = parseInt(startStr, 10);
  const endYear   = startYear - Math.floor(startYear / 100) * 100 < parseInt(endStr, 10)
    ? startYear + 1
    : startYear - 99; // fallback
  return { startYear, endYear: startYear + 1 };
}

/**
 * Returns next academic year string
 * "2026-27" → "2027-28"
 */
function nextAcademicYear(yearStr) {
  const { startYear } = parseAcademicYear(yearStr || currentAcademicYear());
  const next = startYear + 1;
  return `${next}-${String(next + 1).slice(2)}`;
}

module.exports = {
  currentAcademicYear,
  isValidAcademicYear,
  parseAcademicYear,
  nextAcademicYear,
};
