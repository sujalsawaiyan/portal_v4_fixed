// =============================================================
//  utils/balanceCalculator.js — Central fee balance calculation
//
//  PROBLEM (pehle):
//    Balance calculate ho raha tha 4 alag jagah:
//      1. feePayments.js (SMS mein hardcoded 0)
//      2. feeReminderCron.js (alag logic)
//      3. dashboard.js (alag logic)
//      4. defaulters list (alag logic)
//
//  SOLUTION (ab):
//    Ek hi function — getStudentBalance() — sab jagah se call hoga.
//    Logic: Total Fee − Discount − Payments = Remaining
//
//  Usage:
//    const { getStudentBalance } = require('../utils/balanceCalculator');
//    const bal = await getStudentBalance(studentId, academicYear);
// =============================================================

const { currentAcademicYear } = require('./academicYear');

/**
 * Ek student ka complete fee balance calculate karta hai.
 *
 * @param {string} studentId   - Student's studentId / admissionNumber
 * @param {string} academicYear - e.g. "2026-27"
 * @returns {Promise<BalanceResult>}
 *
 * BalanceResult shape:
 * {
 *   totalFee:      number,  // Structure se annual fee
 *   totalDiscount: number,  // Approved discounts ka sum
 *   netFee:        number,  // totalFee - totalDiscount
 *   totalPaid:     number,  // Actual payments (non-cancelled)
 *   fineCharged:   number,  // Fine amounts charged
 *   fineWaived:    number,  // Fine amounts waived
 *   netFine:       number,  // fineCharged - fineWaived
 *   remainingDue:  number,  // netFee + netFine - totalPaid  (yeh main number hai)
 *   isDefaulter:   boolean, // remainingDue > 0
 *   source:        string,  // 'ledger' | 'calculated' (debug ke liye)
 * }
 */
async function getStudentBalance(studentId, academicYear) {
  const yr  = academicYear || currentAcademicYear();
  const sid = (studentId || '').toString().toUpperCase();

  // ── Strategy 1: Ledger-based (most accurate agar ledger entries hain) ──
  try {
    const LedgerEntry = require('../models/LedgerEntry');
    const entries = await LedgerEntry.find({
      studentId:    sid,
      academicYear: yr,
      isDeleted:    { $ne: true },
    }).sort({ date: 1, createdAt: 1 });

    if (entries.length > 0) {
      let totalCharged = 0, totalPaid = 0, fineCharged = 0, fineWaived = 0;
      for (const e of entries) {
        if (e.type === 'charge') {
          if (e.isFine) fineCharged += e.amount;
          else          totalCharged += e.amount;
        } else if (e.type === 'payment') {
          totalPaid += e.amount;
        } else if (e.type === 'waiver' || e.type === 'discount') {
          fineWaived += e.amount; // credit entries
        }
      }
      const netFine      = Math.max(0, fineCharged - fineWaived);
      const remainingDue = Math.max(0, totalCharged + netFine - totalPaid);
      return {
        totalFee:      totalCharged,
        totalDiscount: fineWaived,
        netFee:        totalCharged,
        totalPaid,
        fineCharged,
        fineWaived,
        netFine,
        remainingDue,
        isDefaulter:   remainingDue > 0,
        source:        'ledger',
      };
    }
  } catch (_) {
    // Ledger model nahi mila — fallback to calculated
  }

  // ── Strategy 2: FeeStructure + Discount + FeePayment se calculate ──
  try {
    const FeeStructure = require('../models/FeeStructure');
    const FeeDiscount  = require('../models/FeeDiscount');
    const FeePayment   = require('../models/FeePayment');
    const Student      = require('../models/Student');

    // Student ki class dhundho
    const student = await Student.findOne({
      $or: [
        { studentId: sid },
        { admissionNumber: sid },
      ],
    }).lean();

    const studentClass = student?.class || null;

    // Fee Structure se annual fee
    let totalFee = 0;
    if (studentClass) {
      const structure = await FeeStructure.findOne({
        class:        studentClass,
        academicYear: yr,
      }).lean();
      totalFee = structure?.totalAnnualFee || 0;
    }

    // Approved discounts
    const discounts = await FeeDiscount.find({
      studentId:    sid,
      academicYear: yr,
      isActive:     true,
      $or: [{ status: 'approved' }, { status: { $exists: false } }],
    }).lean();

    let totalDiscount = 0;
    for (const d of discounts) {
      if (d.discountPercent > 0) {
        totalDiscount += Math.round((totalFee * d.discountPercent) / 100);
      } else if (d.discountAmount > 0) {
        totalDiscount += d.discountAmount;
      }
    }
    totalDiscount = Math.min(totalDiscount, totalFee); // discount fee se zyada nahi ho sakta

    const netFee = Math.max(0, totalFee - totalDiscount);

    // Actual payments (cancelled nahi hone chahiye)
    const payments = await FeePayment.find({
      $or: [{ studentId: sid }, { admissionNumber: sid }],
      academicYear: yr,
      isCancelled:  { $ne: true },
    }).lean();

    const totalPaid   = payments.reduce((s, p) => s + (p.totalAmount || 0), 0);
    const fineCharged = payments.reduce((s, p) => s + (p.fineAmount  || 0), 0);
    const fineWaived  = payments.reduce((s, p) => p.fineWaived ? s + (p.fineAmount || 0) : s, 0);
    const netFine     = Math.max(0, fineCharged - fineWaived);

    const remainingDue = Math.max(0, netFee + netFine - totalPaid);

    return {
      totalFee,
      totalDiscount,
      netFee,
      totalPaid,
      fineCharged,
      fineWaived,
      netFine,
      remainingDue,
      isDefaulter:   remainingDue > 0,
      source:        'calculated',
    };
  } catch (err) {
    console.error('[BalanceCalculator] Error:', err.message);
    // Worst case: zero balance (safe default — better than crash)
    return {
      totalFee: 0, totalDiscount: 0, netFee: 0,
      totalPaid: 0, fineCharged: 0, fineWaived: 0, netFine: 0,
      remainingDue: 0, isDefaulter: false,
      source: 'error',
    };
  }
}

/**
 * Ek class ke saare students ka balance ek saath fetch karta hai.
 * Defaulters list ke liye use karo — individual calls se fast hai.
 *
 * @param {string} cls          - Class name, e.g. "10A" or "10"
 * @param {string} academicYear
 * @returns {Promise<Array<{ student, balance: BalanceResult }>>}
 */
async function getClassBalances(cls, academicYear) {
  const yr = academicYear || currentAcademicYear();
  try {
    const Student      = require('../models/Student');
    const FeeStructure = require('../models/FeeStructure');
    const FeeDiscount  = require('../models/FeeDiscount');
    const FeePayment   = require('../models/FeePayment');

    const students = await Student.find({ class: cls, isActive: true }).lean();
    if (!students.length) return [];

    const structure = await FeeStructure.findOne({ class: cls, academicYear: yr }).lean();
    const totalFee  = structure?.totalAnnualFee || 0;

    const studentIds = students.map(s => s.studentId);

    // Ek hi query mein saare payments aur discounts
    const [allPayments, allDiscounts] = await Promise.all([
      FeePayment.find({
        studentId:    { $in: studentIds },
        academicYear: yr,
        isCancelled:  { $ne: true },
      }).lean(),
      FeeDiscount.find({
        studentId:    { $in: studentIds },
        academicYear: yr,
        isActive:     true,
      }).lean(),
    ]);

    // Group by studentId
    const paymentMap  = {};
    const discountMap = {};
    for (const p of allPayments) {
      (paymentMap[p.studentId] = paymentMap[p.studentId] || []).push(p);
    }
    for (const d of allDiscounts) {
      (discountMap[d.studentId] = discountMap[d.studentId] || []).push(d);
    }

    return students.map(student => {
      const sid      = student.studentId;
      const payments = paymentMap[sid]  || [];
      const dscounts = discountMap[sid] || [];

      let totalDiscount = 0;
      for (const d of dscounts) {
        if (d.discountPercent > 0) totalDiscount += Math.round((totalFee * d.discountPercent) / 100);
        else                        totalDiscount += d.discountAmount || 0;
      }
      totalDiscount = Math.min(totalDiscount, totalFee);

      const netFee     = Math.max(0, totalFee - totalDiscount);
      const totalPaid  = payments.reduce((s, p) => s + (p.totalAmount || 0), 0);
      const fineCharged = payments.reduce((s, p) => s + (p.fineAmount || 0), 0);
      const fineWaived  = payments.reduce((s, p) => p.fineWaived ? s + (p.fineAmount || 0) : s, 0);
      const netFine    = Math.max(0, fineCharged - fineWaived);
      const remaining  = Math.max(0, netFee + netFine - totalPaid);

      return {
        student,
        balance: {
          totalFee, totalDiscount, netFee,
          totalPaid, fineCharged, fineWaived, netFine,
          remainingDue: remaining,
          isDefaulter:  remaining > 0,
          source:       'calculated',
        },
      };
    });
  } catch (err) {
    console.error('[BalanceCalculator] getClassBalances error:', err.message);
    return [];
  }
}

module.exports = { getStudentBalance, getClassBalances };
