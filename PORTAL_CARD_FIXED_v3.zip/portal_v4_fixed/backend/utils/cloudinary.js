// backend/utils/cloudinary.js
const cloudinary = require('cloudinary').v2;
const fs = require('fs');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// Category → Cloudinary folder mapping
const FOLDER_MAP = {
  'logo':           'school/logo',
  'principal':      'school/principal',
  'banners':        'school/banners',
  'teachers':       'school/teachers',
  'class-teachers': 'school/class-teachers',
  'leadership':     'school/leadership',
  'events':         'school/events',
  'gallery':        'school/gallery',
  'students':       'school/students',
  'houses':         'school/houses',
  'house-logo':     'school/houses',
};

/**
 * Upload a file from disk to Cloudinary
 * @param {string} filePath - local file path
 * @param {string} category - image category
 * @param {string} [publicId] - optional custom public_id
 * @returns {Promise<{url: string, publicId: string}>}
 */
async function uploadToCloudinary(filePath, category, publicId) {
  const folder = FOLDER_MAP[category] || 'school/misc';
  const options = {
    folder,
    resource_type: 'image',
    overwrite: true,
    transformation: [{ quality: 'auto', fetch_format: 'auto' }],
  };
  if (publicId) options.public_id = publicId;

  const result = await cloudinary.uploader.upload(filePath, options);

  // Delete local file after upload
  try { fs.unlinkSync(filePath); } catch (_) {}

  return {
    url:      result.secure_url,
    publicId: result.public_id,
  };
}

/**
 * Delete an image from Cloudinary by publicId
 * @param {string} publicId
 */
async function deleteFromCloudinary(publicId) {
  if (!publicId) return;
  try {
    await cloudinary.uploader.destroy(publicId, { resource_type: 'image' });
  } catch (e) {
    console.warn('[Cloudinary] Delete failed:', e.message);
  }
}

module.exports = { uploadToCloudinary, deleteFromCloudinary, FOLDER_MAP };
