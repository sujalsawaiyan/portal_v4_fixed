// =============================================================
//  utils/sanitize.js — Input Sanitization Helpers v2.2.0
//  SCHOOL PORTAL
//
//  Prevents XSS and HTML injection in user-submitted text.
//  Does NOT use external deps — pure string operations.
// =============================================================

/**
 * Strip dangerous HTML/script patterns from a string.
 * Removes: <script>, <iframe>, <object>, onerror=, etc.
 */
function sanitizeString(value) {
  if (typeof value !== 'string') return value;
  return value
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '')
    .replace(/<iframe[\s\S]*?>[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object[\s\S]*?>[\s\S]*?<\/object>/gi, '')
    .replace(/<embed[^>]*>/gi, '')
    .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '')   // inline event handlers
    .replace(/javascript\s*:/gi, '')                 // javascript: URLs
    .replace(/data\s*:\s*text\/html/gi, '');         // data: HTML URLs
}

/**
 * Recursively sanitize all string values in an object.
 * Safe to call on req.body before any processing.
 */
function sanitizeObject(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  const clean = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string') {
      clean[k] = sanitizeString(v);
    } else if (Array.isArray(v)) {
      clean[k] = v.map(item =>
        typeof item === 'string' ? sanitizeString(item)
        : typeof item === 'object' ? sanitizeObject(item)
        : item
      );
    } else if (typeof v === 'object' && v !== null) {
      clean[k] = sanitizeObject(v);
    } else {
      clean[k] = v;
    }
  }
  return clean;
}

/**
 * Express middleware: sanitizes req.body strings in-place.
 * Apply globally in server.js after body parser.
 * Handles both plain objects AND arrays (e.g. installments POST body).
 */
function sanitizeMiddleware(req, _res, next) {
  if (req.body) {
    if (Array.isArray(req.body)) {
      // Keep as array — sanitize each element individually
      req.body = req.body.map(item =>
        typeof item === 'string'             ? sanitizeString(item)
        : (typeof item === 'object' && item) ? sanitizeObject(item)
        : item
      );
    } else if (typeof req.body === 'object') {
      req.body = sanitizeObject(req.body);
    }
  }
  next();
}

module.exports = { sanitizeString, sanitizeObject, sanitizeMiddleware };
