// =============================================================
//  smsService.js — SMS Notification Service
//  SCHOOL PORTAL — Production Grade
//
//  Providers supported:
//    SMS_PROVIDER=msg91   → MSG91 (India - Recommended, ₹0.15/SMS)
//    SMS_PROVIDER=twilio  → Twilio SMS (International)
//    SMS_PROVIDER=fast2sms → Fast2SMS (India - ₹0.10/SMS)
//
//  Setup in .env:
//    SMS_PROVIDER=msg91
//    MSG91_API_KEY=your_key
//    MSG91_SENDER_ID=SCHOOL  (6 chars)
//    MSG91_TEMPLATE_ID=your_template_id
//
//    OR for Twilio SMS:
//    SMS_PROVIDER=twilio
//    TWILIO_ACCOUNT_SID=ACxxxxx
//    TWILIO_AUTH_TOKEN=xxxxx
//    TWILIO_SMS_FROM=+1xxxxxxxxxx   (different from WhatsApp number)
//
//    OR for Fast2SMS:
//    SMS_PROVIDER=fast2sms
//    FAST2SMS_API_KEY=your_key
// =============================================================

'use strict';

const SchoolSettings = require('../models/SchoolSettings');

// ── Config Loader ─────────────────────────────────────────────
async function getSmsConfig() {
  const doc = await SchoolSettings.findOne({ key: 'smsConfig' }).catch(() => null);
  const db  = doc?.value || {};

  return {
    provider:        process.env.SMS_PROVIDER        || db.provider        || 'msg91',
    // MSG91
    msg91ApiKey:     process.env.MSG91_API_KEY        || db.msg91ApiKey     || '',
    msg91SenderId:   process.env.MSG91_SENDER_ID      || db.msg91SenderId   || 'SCHOOL',
    msg91TemplateId: process.env.MSG91_TEMPLATE_ID    || db.msg91TemplateId || '',
    // Twilio SMS
    twilioSid:       process.env.TWILIO_ACCOUNT_SID   || db.twilioSid       || '',
    twilioToken:     process.env.TWILIO_AUTH_TOKEN     || db.twilioToken     || '',
    twilioFrom:      process.env.TWILIO_SMS_FROM       || db.twilioFrom      || '',
    // Fast2SMS
    fast2smsKey:     process.env.FAST2SMS_API_KEY      || db.fast2smsKey    || '',
    // School info
    schoolName:      process.env.SCHOOL_NAME           || db.schoolName     || 'School',
  };
}

// ── Format Indian phone number ────────────────────────────────
function formatPhone(phone, provider = 'msg91') {
  if (!phone) return '';
  const digits = phone.toString().replace(/\D/g, '');
  const ten    = digits.slice(-10);
  if (provider === 'twilio') return `+91${ten}`;
  return ten; // MSG91 & Fast2SMS use 10-digit
}

// ── Sanitize message text ─────────────────────────────────────
function clean(str) {
  return String(str || '').replace(/[<>&"]/g, '').trim();
}

// =============================================================
// ── SEND via MSG91 ───────────────────────────────────────────
// =============================================================
async function sendViaMSG91(config, phone, message) {
  if (!config.msg91ApiKey) throw new Error('MSG91 API key not configured.');
  const to = formatPhone(phone, 'msg91');
  if (!to || to.length !== 10) throw new Error(`Invalid phone: ${phone}`);

  const payload = {
    sender:   config.msg91SenderId || 'SCHOOL',
    route:    '4',   // transactional route
    country:  '91',
    sms: [{
      message: message,
      to: [to],
    }],
  };

  const resp = await fetch('https://api.msg91.com/api/sendhttp.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'authkey': config.msg91ApiKey,
    },
    body: JSON.stringify(payload),
  });
  const text = await resp.text();
  if (!resp.ok) throw new Error(`MSG91 error: ${text}`);
  return { provider: 'msg91', to, response: text };
}

// =============================================================
// ── SEND via Twilio SMS ──────────────────────────────────────
// =============================================================
async function sendViaTwilio(config, phone, message) {
  if (!config.twilioSid || !config.twilioToken || !config.twilioFrom) {
    throw new Error('Twilio SMS not configured (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_SMS_FROM).');
  }
  const to = formatPhone(phone, 'twilio');

  const body = new URLSearchParams({ To: to, From: config.twilioFrom, Body: message });
  const resp = await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${config.twilioSid}/Messages.json`,
    {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${config.twilioSid}:${config.twilioToken}`).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    }
  );
  const data = await resp.json();
  if (!resp.ok) throw new Error(`Twilio error: ${data.message || JSON.stringify(data)}`);
  return { provider: 'twilio', to, sid: data.sid };
}

// =============================================================
// ── SEND via Fast2SMS ────────────────────────────────────────
// =============================================================
async function sendViaFast2SMS(config, phone, message) {
  if (!config.fast2smsKey) throw new Error('Fast2SMS API key not configured.');
  const to = formatPhone(phone, 'fast2sms');

  const resp = await fetch('https://www.fast2sms.com/dev/bulkV2', {
    method: 'POST',
    headers: {
      'authorization': config.fast2smsKey,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      route:    'q',
      message:  message,
      language: 'english',
      flash:    0,
      numbers:  to,
    }),
  });
  const data = await resp.json();
  if (!data.return) throw new Error(`Fast2SMS error: ${data.message || JSON.stringify(data)}`);
  return { provider: 'fast2sms', to, response: data };
}

// =============================================================
// ── MAIN SEND FUNCTION ───────────────────────────────────────
// =============================================================
async function sendSMS(phone, message, providerOverride = null) {
  const config   = await getSmsConfig();
  const provider = providerOverride || config.provider;

  try {
    let result;
    if (provider === 'twilio')   result = await sendViaTwilio(config, phone, message);
    else if (provider === 'fast2sms') result = await sendViaFast2SMS(config, phone, message);
    else                         result = await sendViaMSG91(config, phone, message);  // default msg91

    return { success: true, ...result };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

// =============================================================
// ── MESSAGE TEMPLATES ────────────────────────────────────────
// =============================================================

// Receipt confirmation SMS
async function sendReceiptSMS({ studentName, guardianPhone, amount, receiptNo, balance, schoolName }) {
  const msg = `Dear Parent, fee receipt #${receiptNo} of Rs.${amount} received for ${clean(studentName)}. Balance: Rs.${balance}. - ${clean(schoolName)}`;
  return sendSMS(guardianPhone, msg);
}

// Fee reminder SMS
async function sendFeeReminderSMS({ studentName, guardianPhone, amountDue, dueDate, schoolName }) {
  const msg = `Reminder: Fees of Rs.${amountDue} pending for ${clean(studentName)}. Due: ${dueDate || 'Immediately'}. Please pay soon. - ${clean(schoolName)}`;
  return sendSMS(guardianPhone, msg);
}

// Bulk reminders to defaulters
async function sendBulkReminderSMS(defaulters, schoolName = 'School') {
  const results = [];
  for (const d of defaulters) {
    if (!d.phone && !d.guardianPhone) {
      results.push({ studentName: d.studentName, status: 'skipped', reason: 'No phone number' });
      continue;
    }
    const phone = d.phone || d.guardianPhone;
    const res   = await sendFeeReminderSMS({
      studentName:   d.studentName,
      guardianPhone: phone,
      amountDue:     d.pending || d.amount || 0,
      dueDate:       d.dueDate || '',
      schoolName,
    });
    results.push({ studentName: d.studentName, phone, ...res });
    // 300ms delay between messages to avoid rate limiting
    await new Promise(r => setTimeout(r, 300));
  }
  return results;
}

// Cheque bounce alert SMS
async function sendChequeBounceAlertSMS({ studentName, guardianPhone, chequeNo, amount, schoolName }) {
  const msg = `IMPORTANT: Cheque No.${chequeNo} of Rs.${amount} for ${clean(studentName)} has been returned/bounced. Please contact school immediately. - ${clean(schoolName)}`;
  return sendSMS(guardianPhone, msg);
}

module.exports = {
  sendSMS,
  getSmsConfig,
  sendReceiptSMS,
  sendFeeReminderSMS,
  sendBulkReminderSMS,
  sendChequeBounceAlertSMS,
};
