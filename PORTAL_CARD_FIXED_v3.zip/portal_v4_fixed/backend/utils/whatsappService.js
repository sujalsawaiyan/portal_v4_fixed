// =============================================================
//  whatsappService.js — WhatsApp Notification Service v3.0.0
//  SCHOOL PORTAL — Production Grade
//
//  Providers:
//    WHATSAPP_PROVIDER=meta    → Meta Cloud API (FREE, 1000 msg/month)
//    WHATSAPP_PROVIDER=twilio  → Twilio WhatsApp (PAID)
//
//  Config sources (highest → lowest priority):
//    1. .env file
//    2. MongoDB SchoolSettings (Admin Panel)
// =============================================================

'use strict';

const WhatsappLog    = require('../models/WhatsappLog');
const SchoolSettings = require('../models/SchoolSettings');

// =============================================================
// ── CONFIG LOADER ─────────────────────────────────────────────
// =============================================================
async function getWhatsappConfig() {
  const [waCfgDoc, schoolDoc] = await Promise.all([
    SchoolSettings.findOne({ key: 'whatsappConfig' }).catch(() => null),
    SchoolSettings.findOne({ key: 'schoolInfo'     }).catch(() => null),
  ]);

  const dbCfg    = waCfgDoc?.value  || {};
  const dbSchool = schoolDoc?.value || {};

  const provider = process.env.WHATSAPP_PROVIDER || dbCfg.provider || 'meta';

  // Meta fields
  const metaPhoneNumberId = process.env.META_PHONE_NUMBER_ID || dbCfg.metaPhoneNumberId || '';
  const metaAccessToken   = process.env.META_ACCESS_TOKEN    || dbCfg.metaAccessToken   || '';
  const metaApiVersion    = process.env.META_API_VERSION     || dbCfg.metaApiVersion    || 'v19.0';

  // Twilio fields
  const accountSid = process.env.TWILIO_ACCOUNT_SID   || dbCfg.twilioAccountSid     || '';
  const authToken  = process.env.TWILIO_AUTH_TOKEN    || dbCfg.twilioAuthToken      || '';
  const fromNumber = process.env.TWILIO_WHATSAPP_FROM || dbCfg.twilioWhatsappNumber || '';

  // School info
  const schoolName    = process.env.SCHOOL_NAME || dbSchool.schoolName    || dbCfg.schoolName    || 'School';
  const schoolPhone   =                            dbSchool.schoolPhone   || dbCfg.schoolPhone   || '';
  const paymentLink   =                            dbSchool.paymentLink   || dbCfg.paymentLink   || '';
  const principalName =                            dbSchool.principalName || dbCfg.principalName || '';

  const feeReminderMode = dbCfg.feeReminderMode || 'manual';
  const feeReminderTime = dbCfg.feeReminderTime || '08:00';

  return {
    provider,
    metaPhoneNumberId, metaAccessToken, metaApiVersion,
    accountSid, authToken, fromNumber,
    schoolName, schoolPhone, paymentLink, principalName,
    feeReminderMode, feeReminderTime,
    metaConfigured:   !!(metaPhoneNumberId && metaAccessToken),
    twilioConfigured: !!(accountSid && authToken && fromNumber),
  };
}

// =============================================================
// ── HELPERS ───────────────────────────────────────────────────
// =============================================================
function formatPhone(phone) {
  let clean = String(phone || '').replace(/\D/g, '');
  if (!clean) return null;
  if (clean.length === 10) clean = '91' + clean;
  if (!clean.startsWith('91')) clean = '91' + clean;
  return clean;
}

function formatPhoneTwilio(phone) {
  const clean = formatPhone(phone);
  return clean ? `whatsapp:+${clean}` : null;
}

function inr(amount) {
  return '₹' + Number(amount || 0).toLocaleString('en-IN');
}

function currentAcademicYear() {
  const now = new Date(), m = now.getMonth() + 1, y = now.getFullYear();
  return m >= 4 ? `${y}-${String(y + 1).slice(2)}` : `${y - 1}-${String(y).slice(2)}`;
}

// =============================================================
// ── SEND VIA META CLOUD API (FREE) ───────────────────────────
// =============================================================
async function sendViaMeta({ to, body, config }) {
  const phone = formatPhone(to);
  if (!phone) throw new Error('Invalid phone number: ' + to);

  const url = `https://graph.facebook.com/${config.metaApiVersion}/${config.metaPhoneNumberId}/messages`;

  const response = await fetch(url, {
    method:  'POST',
    headers: {
      'Authorization': `Bearer ${config.metaAccessToken}`,
      'Content-Type':  'application/json',
    },
    body: JSON.stringify({
      messaging_product: 'whatsapp',
      recipient_type:    'individual',
      to:                phone,
      type:              'text',
      text:              { preview_url: false, body },
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    const errMsg  = data?.error?.message || JSON.stringify(data);
    const errCode = data?.error?.code    || response.status;
    throw new Error(`Meta API Error [${errCode}]: ${errMsg}`);
  }

  return { success: true, messageId: data?.messages?.[0]?.id, provider: 'meta' };
}

// =============================================================
// ── SEND VIA TWILIO ───────────────────────────────────────────
// =============================================================
async function sendViaTwilio({ to, body, config }) {
  let twilio;
  try { twilio = require('twilio'); }
  catch (_) { throw new Error('Twilio package not installed. Run: npm install twilio'); }

  const toFormatted = formatPhoneTwilio(to);
  if (!toFormatted) throw new Error('Invalid phone number: ' + to);

  const fromFormatted = config.fromNumber.startsWith('whatsapp:')
    ? config.fromNumber
    : `whatsapp:${config.fromNumber}`;

  const client = twilio(config.accountSid, config.authToken);
  const msg    = await client.messages.create({ from: fromFormatted, to: toFormatted, body });

  return { success: true, messageId: msg.sid, provider: 'twilio' };
}

// =============================================================
// ── CORE SEND FUNCTION ────────────────────────────────────────
// =============================================================
async function sendWhatsApp({ to, body, logData = {} }) {
  const config = await getWhatsappConfig();

  const logEntry = {
    parentPhone:  to,
    messageBody:  body,
    status:       'failed',
    errorMessage: '',
    provider:     config.provider,
    ...logData,
  };

  let useProvider = null;
  if (config.provider === 'twilio' && config.twilioConfigured) useProvider = 'twilio';
  else if (config.provider === 'meta' && config.metaConfigured) useProvider = 'meta';
  else if (config.metaConfigured)   useProvider = 'meta';
  else if (config.twilioConfigured) useProvider = 'twilio';

  if (!useProvider) {
    logEntry.errorMessage =
      'WhatsApp not configured. Add API keys to .env or Admin Panel → WhatsApp Settings.';
    await WhatsappLog.create(logEntry).catch(() => {});
    return { success: false, error: logEntry.errorMessage };
  }

  try {
    const result = useProvider === 'meta'
      ? await sendViaMeta({ to, body, config })
      : await sendViaTwilio({ to, body, config });

    logEntry.status   = 'sent';
    logEntry.provider = useProvider;
    await WhatsappLog.create(logEntry).catch(() => {});
    return result;

  } catch (err) {
    logEntry.errorMessage = err.message || 'Send failed';
    await WhatsappLog.create(logEntry).catch(() => {});
    console.error(`[WhatsApp/${useProvider}] Failed for ${to}:`, err.message);
    return { success: false, error: logEntry.errorMessage };
  }
}

// =============================================================
// ── LEDGER SUMMARY FETCHER ────────────────────────────────────
//  Fetches complete fee breakdown from MongoDB ledger
// =============================================================
async function getLedgerSummary(studentId, academicYear) {
  let LedgerEntry;
  try { LedgerEntry = require('../models/LedgerEntry'); }
  catch (e) { return null; }

  const year = academicYear || currentAcademicYear();

  const entries = await LedgerEntry.find({
    studentId:    studentId.toUpperCase(),
    academicYear: year,
    isDeleted:    false,
  }).sort({ date: 1, createdAt: 1 });

  if (!entries.length) return null;

  const currentMonth = new Date().toISOString().slice(0, 7);

  const totalCharged = entries.filter(e => e.type === 'charge').reduce((s, e)  => s + e.amount, 0);
  const totalPaid    = entries.filter(e => e.type === 'payment').reduce((s, e) => s + e.amount, 0);
  const balance      = entries[entries.length - 1].balance;

  const prevCharges  = entries
    .filter(e => e.type === 'charge'  && (e.month || e.date.slice(0, 7)) < currentMonth)
    .reduce((s, e) => s + e.amount, 0);
  const prevPayments = entries
    .filter(e => e.type === 'payment' && (e.month || e.date.slice(0, 7)) < currentMonth)
    .reduce((s, e) => s + e.amount, 0);
  const prevDue = Math.max(0, prevCharges - prevPayments);

  const currentMonthFees = entries
    .filter(e => e.type === 'charge' && (e.month || e.date.slice(0, 7)) === currentMonth)
    .reduce((s, e) => s + e.amount, 0);

  const lastPayment = [...entries].reverse().find(e => e.type === 'payment');

  return {
    totalCharged,
    totalPaid,
    balance,
    prevDue,
    currentMonthFees,
    totalPayable: prevDue + currentMonthFees,
    remainingDue: Math.max(0, balance),
    lastPayment:  lastPayment
      ? {
          amount:        lastPayment.amount,
          date:          lastPayment.date,
          method:        lastPayment.method || 'Cash',
          receiptNumber: lastPayment.receiptNumber || '',
        }
      : null,
    academicYear: year,
  };
}

// =============================================================
// ── MESSAGE TEMPLATES ─────────────────────────────────────────
// =============================================================

// 1. Admission Approved
async function sendAdmissionApproved({ admission, sentBy = 'admin' }) {
  const config     = await getWhatsappConfig();
  const parentName = admission.fatherName || admission.motherName || 'Parent';
  const session    = admission.session ||
    `${new Date().getFullYear()}-${new Date().getFullYear() + 1}`;
  const schoolAddr = config.schoolAddress || config.address || '';

  const body =
`✅ *Admission Approved — ${config.schoolName}*

Dear ${parentName},

Congratulations! 🎉 We are delighted to inform you that your child's admission application has been *approved*.

👤 *Student Name:* ${admission.studentName}
📚 *Class Admitted:* ${admission.applyingClass}${admission.section ? ' - ' + admission.section : ''}
🆔 *Application No:* ${admission.applicationId}
📅 *Academic Session:* ${session}

━━━━━━━━━━━━━━━━━━━━━━━
📌 *Important — Next Steps*
Please visit the school office with the following documents:

  ✔️ Original Birth Certificate
  ✔️ Transfer Certificate (if from another school)
  ✔️ 4 Recent Passport Size Photographs
  ✔️ Address Proof (Aadhar Card / Voter ID)
  ✔️ Previous Year Report Card
  ✔️ Caste Certificate (if applicable)

━━━━━━━━━━━━━━━━━━━━━━━
📅 *Office Hours:* Monday – Saturday
⏰ *Timing:* 9:00 AM – 2:00 PM

📞 *Contact:* ${config.schoolPhone || 'School Office'}
${config.schoolEmail ? '📧 *Email:* ' + config.schoolEmail : ''}
${schoolAddr ? '📍 *Address:* ' + schoolAddr : ''}

🏫 *${config.schoolName}*

_We look forward to welcoming *${admission.studentName}* to our school family!_ 🌟

_— Admissions Team, ${config.schoolName}_`;

  return sendWhatsApp({
    to: admission.phone, body,
    logData: {
      studentName:  admission.studentName,
      studentClass: admission.applyingClass,
      messageType:  'admission_approved',
      sentBy,
    },
  });
}

// 2. Admission Rejected
async function sendAdmissionRejected({ admission, reason = '', sentBy = 'admin' }) {
  const config       = await getWhatsappConfig();
  const parentName   = admission.fatherName || admission.motherName || 'Parent';
  const rejectReason = reason || admission.notes || 'Seats not available at this time.';

  const body =
`ℹ️ *Admission Update — ${config.schoolName}*

Dear ${parentName},

Thank you for your interest in our school.

Regarding admission of *${admission.studentName}* for Class *${admission.applyingClass}*:

📋 *Status:* Not Approved
📝 *Reason:* ${rejectReason}

Please contact our office for more details.
📞 *Phone:* ${config.schoolPhone || 'School Office'}
🏫 *School:* ${config.schoolName}

_We appreciate your understanding._`;

  return sendWhatsApp({
    to: admission.phone, body,
    logData: {
      studentName:  admission.studentName,
      studentClass: admission.applyingClass,
      messageType:  'admission_rejected',
      sentBy,
    },
  });
}

// 3. New Student Welcome (when added to student roll)
async function sendNewStudentWelcome({ student, sentBy = 'admin' }) {
  const config     = await getWhatsappConfig();
  const parentName = student.guardianName || student.motherName || 'Parent';
  const phone      = student.guardianPhone || '';

  if (!phone) return { success: false, error: 'No guardian phone for: ' + student.fullName };

  const body =
`🎓 *Welcome to ${config.schoolName}!*

Dear ${parentName},

Your child has been successfully enrolled.

👤 *Student Name:* ${student.fullName}
🆔 *Student ID:* ${student.studentId}
📚 *Class:* ${student.class}-${student.section || 'A'}
🔢 *Roll Number:* ${student.rollNumber || 'To be assigned'}
📅 *Admission Date:* ${student.admissionDate || new Date().toLocaleDateString('en-IN')}

For any queries, please contact:
📞 *Phone:* ${config.schoolPhone || 'School Office'}

_Welcome to the ${config.schoolName} family! 🌟_`;

  return sendWhatsApp({
    to: phone, body,
    logData: {
      studentId:    student.studentId,
      studentName:  student.fullName,
      studentClass: student.class,
      rollNumber:   student.rollNumber || '',
      messageType:  'admission_approved',
      sentBy,
    },
  });
}

// 4. Fees Payment Received
async function sendFeesPaymentReceived({ student, payment, ledgerSummary = null, sentBy = 'admin' }) {
  const config     = await getWhatsappConfig();
  const parentName = student.guardianName || student.motherName || 'Parent';
  const phone      = student.guardianPhone || student.phone || '';

  if (!phone) return { success: false, error: 'No phone number for: ' + student.fullName };

  let summary = ledgerSummary;
  if (!summary && student.studentId) {
    summary = await getLedgerSummary(student.studentId, payment.academicYear).catch(() => null);
  }

  const payDate = payment.date
    ? new Date(payment.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  let breakdownBlock = '';
  if (summary) {
    breakdownBlock =
`
📊 *Fee Account Summary:*
  ↳ Previous Due:    ${inr(summary.prevDue)}
  ↳ Current Fees:    ${inr(summary.currentMonthFees)}
  ↳ Total Charged:   ${inr(summary.totalCharged)}
  ↳ Total Paid:      ${inr(summary.totalPaid)}
  ━━━━━━━━━━━━━━━━━━━━━━━
  ↳ Remaining Due:   ${inr(summary.remainingDue)}
`;
  } else {
    breakdownBlock = `\n💰 *Amount Paid:* ${inr(payment.amount)}\n`;
  }

  const receiptLine = payment.receiptNumber
    ? `🧾 *Receipt No:* ${payment.receiptNumber}\n`
    : '';

  const clearanceMsg = (summary && summary.remainingDue > 0)
    ? `⚠️ Remaining due: ${inr(summary.remainingDue)} — please clear at the earliest.`
    : '🎉 All fees cleared! Thank you for timely payment.';

  const body =
`✅ *Payment Received — ${config.schoolName}*

Dear ${parentName},

We have received your fee payment. Details:

👤 *Student:* ${student.fullName}
📚 *Class:* ${student.class}-${student.section || 'A'}
🔢 *Roll No:* ${student.rollNumber || 'N/A'}
📅 *Payment Date:* ${payDate}
💳 *Method:* ${payment.method || 'Cash'}
💵 *Amount Paid:* ${inr(payment.amount)}
${receiptLine}${breakdownBlock}
${clearanceMsg}

📞 *School:* ${config.schoolName} | ${config.schoolPhone || ''}

_Please keep this as payment confirmation._`;

  return sendWhatsApp({
    to: phone, body,
    logData: {
      studentId:    student.studentId,
      studentName:  student.fullName,
      studentClass: student.class,
      rollNumber:   student.rollNumber || '',
      messageType:  'fee_reminder',
      sentBy,
    },
  });
}

// 5. Fee Reminder (Due Reminder)
async function sendFeeReminder({ student, amountDue, dueDate = '', sentBy = 'admin', ledgerSummary = null }) {
  const config     = await getWhatsappConfig();
  const parentName = student.guardianName || student.motherName || 'Parent';
  const phone      = student.guardianPhone || student.phone || '';

  if (!phone) return { success: false, error: 'No phone number for: ' + student.fullName };

  let summary = ledgerSummary;
  if (!summary && student.studentId) {
    summary = await getLedgerSummary(student.studentId).catch(() => null);
  }

  const dueDateStr = dueDate
    ? new Date(dueDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    : 'As soon as possible';

  const payLine = config.paymentLink
    ? `💳 *Pay Online:* ${config.paymentLink}`
    : '💳 Please visit the school office to make payment.';

  let breakdownBlock = '';
  if (summary) {
    breakdownBlock =
`
📋 *Fee Breakdown:*
  ↳ Previous Due:       ${inr(summary.prevDue)}
  ↳ Current Month Fees: ${inr(summary.currentMonthFees)}
  ↳ Total Charged:      ${inr(summary.totalCharged)}
  ↳ Total Paid:         ${inr(summary.totalPaid)}
  ━━━━━━━━━━━━━━━━━━━━━━━━━
  ↳ 🔴 Remaining Due:   ${inr(summary.remainingDue || amountDue)}
`;
  } else {
    breakdownBlock = `\n💰 *Pending Amount:* ${inr(amountDue)}\n`;
  }

  const body =
`⚠️ *Fee Reminder — ${config.schoolName}*

Dear ${parentName},

This is a friendly reminder that school fees are pending.

👤 *Student:* ${student.fullName}
📚 *Class:* ${student.class}-${student.section || 'A'}
🔢 *Roll No:* ${student.rollNumber || 'N/A'}
${breakdownBlock}
📅 *Due Date:* ${dueDateStr}

${payLine}

📞 *School:* ${config.schoolName} | ${config.schoolPhone || ''}

_Please ignore if payment has already been made. Thank you!_`;

  return sendWhatsApp({
    to: phone, body,
    logData: {
      studentId:    student.studentId,
      studentName:  student.fullName,
      studentClass: student.class,
      rollNumber:   student.rollNumber || '',
      messageType:  'fee_reminder',
      sentBy,
    },
  });
}

// =============================================================
// ── EXPORTS
// =============================================================
// =============================================================
// ── FEE RECEIPT WHATSAPP — Auto-send on fee collection ────────
// Non-blocking — never fails the main fee collection flow
// =============================================================
async function sendFeeReceiptWhatsApp(payment, student) {
  // 1. Check if fee receipt WA is enabled (setting key: 'whatsappFeeReceipt')
  const settingDoc = await SchoolSettings.findOne({ key: 'whatsappFeeReceipt' }).catch(() => null);
  if (settingDoc && settingDoc.value === false) {
    console.log('[WhatsApp Receipt] Disabled by admin, skipping.');
    return;
  }

  // 2. Get parent phone — use guardianPhone (primary field in Student model)
  const phone = student.guardianPhone || student.parentPhone || student.fatherPhone || student.motherPhone || student.phone;
  if (!phone) {
    console.log('[WhatsApp Receipt] No parent phone for student:', student.studentId || student.admissionNumber);
    return;
  }

  // 3. Format the message
  const feeDetails = (payment.feeHeads || []).map(h => `  • ${h.headName}: ${inr(h.amount)}`).join('\n');
  const config = await getWhatsappConfig();

  const message =
`✅ *Fee Receipt — ${payment.receiptNumber}*

Dear Parent,

Fee received for *${payment.studentName}* (Class ${payment.class}-${payment.section || 'A'}).

📋 *Payment Details:*
${feeDetails}${payment.fineAmount > 0 ? `\n  • Late Fine: ${inr(payment.fineAmount)}` : ''}

💰 *Total Paid: ${inr(payment.totalAmount)}*
📅 Date: ${payment.paymentDate}
💳 Mode: ${payment.paymentMode}${payment.academicYear ? `\n📚 Year: ${payment.academicYear}` : ''}

Thank you for your payment! 🙏

_${config.schoolName}_
_This is an automated message from school._`;

  // 4. Send via unified sendWhatsApp (handles Meta/Twilio automatically)
  return sendWhatsApp({
    to: phone,
    body: message,
    logData: {
      studentId:    student.studentId || '',
      studentName:  payment.studentName,
      studentClass: payment.class,
      messageType:  'fee_receipt',
      sentBy:       'auto',
    },
  });
}

module.exports = {
  sendWhatsApp,
  getWhatsappConfig,
  getLedgerSummary,
  sendAdmissionApproved,
  sendAdmissionRejected,
  sendNewStudentWelcome,
  sendFeesPaymentReceived,
  sendFeeReminder,
  sendFeeReceiptWhatsApp,
};
