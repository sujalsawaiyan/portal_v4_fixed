/* ================================================================
   SCHOOL PORTAL — ANIMATIONS.JS v5.0
   Premium glassmorphism animations — complete rewrite
   ================================================================ */
'use strict';

document.addEventListener('DOMContentLoaded', () => {
  _initScrollReveal();
  _initCardTilt();
  _initSparkles();
  _initSectionStagger();
  if (document.getElementById('page-loader')) _initLoader();
});

// ── Scroll Reveal ──────────────────────────────────────────────
function _initScrollReveal() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add('animated'); obs.unobserve(e.target); }
    });
  }, { threshold: 0.10, rootMargin: '0px 0px -50px 0px' });
  document.querySelectorAll('.aos').forEach(el => obs.observe(el));
}
window.refreshAnimations = () => {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('animated'); obs.unobserve(e.target); } });
  }, { threshold: 0.10, rootMargin: '0px 0px -50px 0px' });
  document.querySelectorAll('.aos:not(.animated)').forEach(el => obs.observe(el));
  if (typeof window.initProgressBars === 'function') window.initProgressBars();
  if (typeof window.initCounters     === 'function') window.initCounters();
};

// ── Loader ─────────────────────────────────────────────────────
function _initLoader() {
  const loader = document.getElementById('page-loader');
  if (!loader) return;
  window.addEventListener('load', () => setTimeout(() => loader.classList.add('hidden'), 500));
  setTimeout(() => loader?.classList.add('hidden'), 2500);
}

// ── Card 3D Tilt (desktop only, reduced motion respected) ──────
function _initCardTilt() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.innerWidth < 768) return;
  document.querySelectorAll('.glass-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r  = card.getBoundingClientRect();
      const x  = e.clientX - r.left, y = e.clientY - r.top;
      const cx = r.width / 2, cy = r.height / 2;
      const rX = ((y - cy) / cy * -5).toFixed(1);
      const rY = ((x - cx) / cx *  5).toFixed(1);
      card.style.transform  = `perspective(900px) rotateX(${rX}deg) rotateY(${rY}deg) translateY(-4px)`;
      card.style.transition = 'transform 0.08s linear';
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform  = '';
      card.style.transition = 'all 0.35s cubic-bezier(0.4,0,0.2,1)';
    });
  });
}

// ── Floating Sparkles on Hero ──────────────────────────────────
function _initSparkles() {
  const hero = document.querySelector('.hero-section');
  if (!hero) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const canvas = document.createElement('canvas');
  canvas.style.cssText = 'position:absolute;inset:0;pointer-events:none;z-index:0;opacity:0.45';
  canvas.width  = hero.offsetWidth;
  canvas.height = hero.offsetHeight;
  hero.insertBefore(canvas, hero.firstChild);
  const ctx = canvas.getContext('2d');
  const pts  = Array.from({ length: 45 }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 2.2 + 0.5,
    dx:(Math.random() - 0.5) * 0.35,
    dy:-(Math.random() * 0.45 + 0.15),
    a: Math.random() * 0.55 + 0.2,
  }));
  let running = true;
  function draw() {
    if (!running) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    pts.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${p.a})`;
      ctx.fill();
      p.x += p.dx; p.y += p.dy; p.a -= 0.0018;
      if (p.y < 0 || p.a <= 0) { p.x = Math.random() * canvas.width; p.y = canvas.height + 10; p.a = Math.random() * 0.55 + 0.2; }
    });
    requestAnimationFrame(draw);
  }
  draw();
  window.addEventListener('resize', () => { canvas.width = hero.offsetWidth; canvas.height = hero.offsetHeight; }, { passive:true });
  // Stop when page hidden
  document.addEventListener('visibilitychange', () => { running = !document.hidden; if (running) draw(); });
}

// ── Stagger entrance for grid children ────────────────────────
function _initSectionStagger() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.querySelectorAll('.stagger-child').forEach((child, i) => {
        child.style.animationDelay = `${i * 0.07}s`;
        child.classList.add('animate-fade-up');
      });
      obs.unobserve(entry.target);
    });
  }, { threshold: 0.15 });
  document.querySelectorAll('.stagger-parent').forEach(el => obs.observe(el));
}
