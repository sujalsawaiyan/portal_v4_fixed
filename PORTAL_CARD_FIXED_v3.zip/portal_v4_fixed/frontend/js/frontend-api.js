// ================================================================
// frontend-api.js — Public Website API Bridge
// SCHOOL PORTAL
//
// IMPORTANT: Add this script to EVERY frontend page
// so all pages read live data from MongoDB, not localStorage.
// ================================================================

(function () {
  'use strict';

  var BASE = '';  // same-origin

  async function fetchJSON(path) {
    try {
      var r = await fetch(BASE + path);
      if (!r.ok) return null;
      return r.json();
    } catch (e) {
      return null;
    }
  }

  // ── Load all public data from MongoDB API ─────────────────────
  async function loadPublicData() {
    var results = await Promise.allSettled([
      fetchJSON('/api/settings/schoolInfo'),        // 0
      fetchJSON('/api/settings/homepageContent'),   // 1
      fetchJSON('/api/settings/schoolTiming'),      // 2
      fetchJSON('/api/settings/stats'),             // 3
      fetchJSON('/api/settings/topStudents'),       // 4
      fetchJSON('/api/settings/admissions'),        // 5
      fetchJSON('/api/settings/socialLinks'),       // 6
      fetchJSON('/api/settings/feeStructure'),      // 7
      fetchJSON('/api/settings/lockdown'),          // 8
      fetchJSON('/api/settings/heroImage'),         // 9
      fetchJSON('/api/announcements'),              // 10
      fetchJSON('/api/events'),                     // 11 — ALL events (not just featured)
      fetchJSON('/api/houses'),                     // 12
      fetchJSON('/api/gallery'),                    // 13
      fetchJSON('/api/images/logo'),                // 14
      fetchJSON('/api/images/principal'),           // 15
      fetchJSON('/api/images/banners'),             // 16
      fetchJSON('/api/images/students'),            // 17
      fetchJSON('/api/images/houses'),              // 18
      fetchJSON('/api/teachers'),                   // 19 — ✅ Teachers list
      fetchJSON('/api/classes'),                    // 20 — ✅ Class-teacher assignments
      fetchJSON('/api/topstudents'),               // 21 — ✅ Top Students (new collection)
      fetchJSON('/api/topstudents/years'),          // 22 — ✅ Top Student years list
    ]);

    var val = function(r) { return r.status === 'fulfilled' ? r.value : null; };

    var data = {};

    // Settings
    var si = val(results[0]);  if (si) data.schoolInfo      = si.value;
    var hc = val(results[1]);  if (hc) data.homepageContent = hc.value;
    var st = val(results[2]);  if (st) data.schoolTiming    = st.value;
    var ss = val(results[3]);  if (ss) data.stats           = ss.value;
    var ts = val(results[4]);  if (ts) data.topStudents     = ts.value;
    var ad = val(results[5]);  if (ad) data.admissions      = ad.value;
    var sl = val(results[6]);  if (sl) data.socialLinks     = sl.value;
    var fs = val(results[7]);  if (fs) data.feeStructure    = fs.value;
    var ld = val(results[8]);  if (ld) data.lockdown        = ld.value;
    var hi = val(results[9]);  if (hi) data.heroImage       = hi.value || '';

    // Announcements
    var anns = val(results[10]);
    if (anns) data.announcements = anns.data || [];

    // Events — ALL events, pages filter as needed
    var evs = val(results[11]);
    if (evs) data.events = evs.data || [];

    // Houses
    var houses = val(results[12]);
    if (houses) {
      data.houses = (houses.data || []).map(function(h) {
        return Object.assign({}, h, {
          id:           h.id || h._id,
          points:       (h.sports||0)+(h.study||0)+(h.activities||0)+(h.discipline||0),
          contributors: h.contributors || [],
        });
      });
    }

    // Gallery
    var gal = val(results[13]);
    if (gal) {
      data.gallery = (gal.data || []).map(function(g) {
        return { id: g._id, title: g.title, category: g.category, url: g.url || g.imageUrl, emoji: g.emoji || '🖼️' };
      });
    }

    // ✅ Image URLs from Cloudinary
    var logoData = val(results[14]);
    if (logoData && logoData.imageUrl) data.schoolLogo = logoData.imageUrl;

    var principalData = val(results[15]);
    if (principalData && principalData.imageUrl) data.principalImage = principalData.imageUrl;

    var bannerData = val(results[16]);
    if (bannerData && bannerData.imageUrl) {
      data.admissionBannerImage = bannerData.imageUrl;
      // If Cloudinary has a banner, inject it into admissions.imageData so homepage shows it
      if (!data.admissions) data.admissions = {};
      if (!data.admissions.imageData) data.admissions.imageData = bannerData.imageUrl;
    }

    var topStudentImgs = val(results[17]);
    if (topStudentImgs && topStudentImgs.data) data.topStudentImages = topStudentImgs.data;

    var houseImgs = val(results[18]);
    if (houseImgs && houseImgs.data && data.houses) {
      var houseLogoMap = {};
      houseImgs.data.forEach(function(h) { houseLogoMap[String(h.houseId)] = h.imageUrl; });
      data.houses = data.houses.map(function(h) {
        var hid = String(h._id || h.id);
        return Object.assign({}, h, { logo: houseLogoMap[hid] || h.logo || '' });
      });
    }

    // ✅ Teachers — normalize to format classes.html and teachers.html expect
    var teachersRes = val(results[19]);
    if (teachersRes) {
      data.teachers = (teachersRes.data || []).map(function(t) {
        return Object.assign({}, t, {
          id:          t._id || t.id,
          _id:         t._id,
          full_name:   t.name || t.fullName || '',
          name:        t.name || t.fullName || '',
          dept:        t.department || t.dept || '',
          exp:         t.experience || t.exp || 0,
          experience:  t.experience || t.exp || 0,
          qual:        t.qualification || t.qual || '',
          photo:       t.photo || '',
        });
      });
    }

    // ✅ Classes — normalize into classTeachers map (cls_5_A format)
    var classesRes = val(results[20]);
    if (classesRes) {
      var classTeachers = {};
      (classesRes.data || []).forEach(function(c) {
        var key = 'cls_' + c.className + '_' + c.section;
        classTeachers[key] = {
          teacherName:    c.teacherName    || '',
          teacherPhoto:   c.teacherPhoto   || '',
          teacherExp:     c.teacherExp     || 0,
          teacherSubject: c.teacherSubject || '',
          teacherQual:    c.teacherQual    || '',
          totalStudents:  c.totalStudents  || 0,
          room:           c.room           || '',
        };
        // ✅ If teacherPhoto is empty, try to find it from teachers list
        if (!classTeachers[key].teacherPhoto && data.teachers) {
          var matchedTeacher = data.teachers.find(function(t) {
            return (t.name || t.full_name || '').toLowerCase() === (c.teacherName || '').toLowerCase();
          });
          if (matchedTeacher && matchedTeacher.photo) {
            classTeachers[key].teacherPhoto = matchedTeacher.photo;
          }
        }
      });
      data.classTeachers = classTeachers;
    }

    // Top Students (new year-wise collection)
    var topStudentsNewRes = val(results[21]);
    if (topStudentsNewRes) {
      data.topStudentsNew = topStudentsNewRes.data || [];
      data.topStudentsLatestYear = data.topStudentsNew.length
        ? data.topStudentsNew[0].year
        : new Date().getFullYear().toString();
    }
    var tsYearsRes = val(results[22]);
    if (tsYearsRes) { data.topStudentYears = tsYearsRes.years || []; }


    // ── Merge into SchoolDB so all pages can read it ──────────
    if (window.SchoolDB && typeof window.SchoolDB.load === 'function') {
      var existing = window.SchoolDB.load();
      Object.keys(data).forEach(function(k) {
        if (data[k] !== null && data[k] !== undefined) existing[k] = data[k];
      });
      window.SchoolDB._cachedData = existing;
      // Override load() to return MongoDB data (not just localStorage)
      window.SchoolDB.load = function() {
        return JSON.parse(JSON.stringify(window.SchoolDB._cachedData || existing));
      };
      window.SchoolDB.get = function(k) { return window.SchoolDB.load()[k]; };
    }

    return data;
  }

  // ── Re-render page after data loads ──────────────────────────
  function reRenderPage(data) {
    if (!data || !Object.keys(data).length) return;

    // School name
    var schoolName = (data.schoolInfo && data.schoolInfo.name) || '';
    if (schoolName) {
      document.querySelectorAll('.school-name, [data-school-name], #navSchoolName, .nav-brand span').forEach(function(el) {
        el.textContent = schoolName;
      });
      document.title = document.title.replace('Your School', schoolName);
    }

    // School Logo
    if (data.schoolLogo) {
      document.querySelectorAll('.school-logo, img[data-school-logo], #school-logo, #navLogo, .brand-icon').forEach(function(el) {
        if (el.tagName === 'IMG') {
          el.src = data.schoolLogo;
        } else {
          el.innerHTML = '<img src="' + data.schoolLogo + '" style="width:100%;height:100%;object-fit:cover;border-radius:10px"/>';
        }
      });
    }

    // Principal image
    if (data.principalImage) {
      document.querySelectorAll('.principal-img, img[data-principal], #principal-photo').forEach(function(el) {
        el.src = data.principalImage;
      });
    }

    // Admission banner
    if (data.admissionBannerImage) {
      document.querySelectorAll('.admission-banner img, [data-admission-banner]').forEach(function(el) {
        el.src = data.admissionBannerImage;
      });
    }

    // Call page-specific render functions if they exist
    var fns = [
      'render',                    // classes.html main render
      'renderLeaders', 'renderStaff',  // teachers.html
      'renderAll',                 // houses.html
      'renderFeaturedEvents', 'renderTimeline', // events.html
      'loadSchoolLogo', 'loadSchoolInfo', 'loadTimings', 'loadAdmissionsSection',
      'renderAnnouncements', 'renderEventsPreview', 'renderStudentLeaderboard',
      'renderHousesPreview', 'initFooterSocialLinks', 'checkLockdownBanner',
      'loadStats', 'loadCalendar', 'loadGallery', 'loadEvents',
      'renderHouses', 'applyBranding', 'loadAttendanceDisplay',
    ];
    fns.forEach(function(fn) {
      if (typeof window[fn] === 'function') {
        try { window[fn](); } catch(e) { /* ignore */ }
      }
    });
  }

  // ── Admission form patch ──────────────────────────────────────
  function patchAdmissionForm() {
    var form = document.getElementById('admission-form') || document.querySelector('form.admission-form');
    if (!form) return;

    form.addEventListener('submit', function(e) {
      e.preventDefault();
      var formData = {};
      new FormData(form).forEach(function(v, k) { formData[k] = v; });

      var payload = {
        studentName:    formData.studentName    || formData.student_name || formData['student-name'] || '',
        dateOfBirth:    formData.dateOfBirth    || formData.dob          || '',
        gender:         formData.gender         || '',
        applyingClass:  formData.applyingClass  || formData.class        || formData['applying-class'] || '',
        previousSchool: formData.previousSchool || formData.prev_school  || '',
        fatherName:     formData.fatherName     || formData.father       || '',
        motherName:     formData.motherName     || formData.mother       || '',
        phone:          formData.phone          || formData.mobile       || '',
        email:          formData.email          || '',
        address:        formData.address        || '',
        session:        formData.session        || new Date().getFullYear() + '-' + (new Date().getFullYear()+1).toString().slice(-2),
      };

      fetch('/api/admissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      .then(function(r) { return r.json(); })
      .then(function(r) {
        if (r.applicationId) {
          alert('✅ Application submitted!\nYour Application ID: ' + r.applicationId + '\nSave this ID to track your application.');
          form.reset();
        } else {
          alert('❌ Submission failed: ' + (r.error || 'Try again'));
        }
      })
      .catch(function() { alert('❌ Network error. Check your connection.'); });
    }, { once: false });
  }

  // ── Boot ──────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function() {
    loadPublicData()
      .then(function(data) {
        reRenderPage(data);
        patchAdmissionForm();
        console.log('[frontend-api] ✅ Live data loaded from MongoDB');
      })
      .catch(function(err) {
        console.warn('[frontend-api] Could not load from backend:', err.message);
      });
  });

})();
