/* ================================================================
   SCHOOL PORTAL — MAIN.JS v6.0
   REFACTORED: All school data now reads/writes via MongoDB REST API.
   localStorage is ONLY used for school_theme (light/dark preference).
   sessionStorage is used for admin_token and admin_user.
   ================================================================ */
'use strict';

// ── Safe Storage Wrapper (Edge Tracking Prevention fix) ───────
const safeStorage = {
  get(key)      { try { return sessionStorage.getItem(key);    } catch(e) { return null; } },
  set(key, val) { try { sessionStorage.setItem(key, val);      } catch(e) {}               },
  remove(key)   { try { sessionStorage.removeItem(key);        } catch(e) {}               }
};

// ── DOM Ready ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Apply theme immediately (localStorage allowed for theme only)
  const theme = safeStorage.get('school_theme') || 'light';
  document.documentElement.setAttribute('data-theme', theme);

  initLoader();
  initNavbar();
  initScrollAnimations();
  initCounters();
  initParallax();
  initTooltips();
  markActiveNav();
  initDarkMode();
  window.SchoolSync.init();
});

// ── Page Loader ────────────────────────────────────────────────
function initLoader() {
  const loader = document.getElementById('page-loader');
  if (!loader) return;
  window.addEventListener('load', () => setTimeout(() => loader.classList.add('hidden'), 500));
  setTimeout(() => loader?.classList.add('hidden'), 2500);
}

// ── Navbar ─────────────────────────────────────────────────────
function initNavbar() {
  const navbar   = document.querySelector('.navbar');
  const toggle   = document.querySelector('.nav-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (!navbar) return;
  const onScroll = () => navbar.classList.toggle('scrolled', window.scrollY > 60);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
  // ── Hamburger: touchend for instant mobile response ──────────
  let _toggleTouched = false;
  function _doToggle(e) {
    e.preventDefault();
    e.stopPropagation();
    const open = navLinks?.classList.toggle('open');
    const bars = toggle.querySelectorAll('span');
    bars[0].style.transform = open ? 'rotate(45deg) translate(5px,5px)' : '';
    bars[1].style.opacity   = open ? '0' : '';
    bars[2].style.transform = open ? 'rotate(-45deg) translate(5px,-5px)' : '';
  }
  toggle?.addEventListener('touchend', e => { _toggleTouched = true; _doToggle(e); }, { passive: false });
  toggle?.addEventListener('click',    e => { if (_toggleTouched) { _toggleTouched = false; return; } _doToggle(e); });

  // FIX: Only close menu on plain page-links — NOT on dropdown toggles
  navLinks?.querySelectorAll('a').forEach(a => {
    if (!a.classList.contains('nav-dropdown-toggle')) {
      a.addEventListener('click', () => {
        navLinks.classList.remove('open');
        const bars = toggle?.querySelectorAll('span');
        if (bars) { bars[0].style.transform=''; bars[1].style.opacity=''; bars[2].style.transform=''; }
      });
    }
  });

  // Mobile dropdown toggles — touchend + stopPropagation so document handler doesn't close immediately
  function _handleDropdownToggle(e, btn) {
    if (window.innerWidth > 960) return;
    e.preventDefault();
    e.stopPropagation(); // CRITICAL: prevents document click from closing dropdown right away
    const li = btn.closest('.nav-dropdown');
    const wasOpen = li.classList.contains('open');
    document.querySelectorAll('.nav-dropdown').forEach(d => d.classList.remove('open'));
    if (!wasOpen) li.classList.add('open');
  }
  document.querySelectorAll('.nav-dropdown-toggle').forEach(btn => {
    let _dropTouched = false;
    btn.addEventListener('touchend', e => { _dropTouched = true; _handleDropdownToggle(e, btn); }, { passive: false });
    btn.addEventListener('click',    e => { if (_dropTouched) { _dropTouched = false; return; } _handleDropdownToggle(e, btn); });
  });

  // FIX: Dropdown menu items — touchend se fast navigate on mobile
  document.querySelectorAll('.nav-dropdown-menu a').forEach(a => {
    let _navTouched = false;
    a.addEventListener('touchend', e => {
      _navTouched = true;
      e.preventDefault();
      e.stopPropagation();
      const href = a.getAttribute('href');
      // Close menu
      navLinks?.classList.remove('open');
      document.querySelectorAll('.nav-dropdown').forEach(d => d.classList.remove('open'));
      const bars = toggle?.querySelectorAll('span');
      if (bars) { bars[0].style.transform=''; bars[1].style.opacity=''; bars[2].style.transform=''; }
      // Navigate
      if (href && href !== '#') {
        setTimeout(() => { window.location.href = href; }, 30);
      }
    }, { passive: false });
    // Prevent ghost click after touchend
    a.addEventListener('click', e => {
      if (_navTouched) { _navTouched = false; e.preventDefault(); }
    });
  });

  // Close dropdowns on outside click/touch
  function _closeDropdowns(e) {
    if (!e.target.closest('.nav-dropdown') && !e.target.closest('.nav-toggle')) {
      document.querySelectorAll('.nav-dropdown').forEach(d => d.classList.remove('open'));
    }
  }
  document.addEventListener('touchend', _closeDropdowns, { passive: true });
  document.addEventListener('click',    _closeDropdowns);
}

function markActiveNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    const href = (link.getAttribute('href') || '').split('/').pop();
    if (href === path || (path === '' && href === 'index.html')) link.classList.add('active');
  });
}

// ── Scroll Animations ──────────────────────────────────────────
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.style.opacity = '1';
        e.target.style.transform = 'translateY(0)';
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  document.querySelectorAll('.aos').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(28px)';
    el.style.transition = `opacity 0.6s ease ${el.dataset.delay || '0s'}, transform 0.6s ease ${el.dataset.delay || '0s'}`;
    observer.observe(el);
  });
}
window.initScrollAnimations = initScrollAnimations;

// ── Counters ───────────────────────────────────────────────────
function initCounters() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { animateCounter(e.target); obs.unobserve(e.target); } });
  }, { threshold: 0.5 });
  document.querySelectorAll('[data-count]').forEach(c => obs.observe(c));
}

function animateCounter(el) {
  const target = parseInt(el.dataset.count, 10);
  const start  = performance.now();
  const update = (ts) => {
    const p = Math.min((ts - start) / 2200, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    el.textContent = Math.floor(eased * target).toLocaleString();
    if (p < 1) requestAnimationFrame(update);
  };
  requestAnimationFrame(update);
}
window.animateCounter = animateCounter;
window.initCounters  = initCounters;

// ── Progress Bars ──────────────────────────────────────────────
function initProgressBars() {
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const w = e.target.dataset.width;
        if (w) setTimeout(() => { e.target.style.width = w + '%'; }, 200);
        obs.unobserve(e.target);
      }
    });
  }, { threshold: 0.4 });
  document.querySelectorAll('.progress-fill[data-width]').forEach(bar => {
    bar.style.width = '0%';
    obs.observe(bar);
  });
}
window.initProgressBars = initProgressBars;
document.addEventListener('DOMContentLoaded', initProgressBars);

// ── Parallax ───────────────────────────────────────────────────
function initParallax() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const hero = document.querySelector('.hero-section');
  if (!hero) return;
  let ticking = false;
  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        hero.querySelectorAll('.orb').forEach((orb, i) => {
          orb.style.transform = `translateY(${window.scrollY * (0.12 + i * 0.06)}px)`;
        });
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

// ── Tooltips ───────────────────────────────────────────────────
function initTooltips() {
  document.querySelectorAll('[data-tooltip]').forEach(el => {
    el.style.position = 'relative';
    el.addEventListener('mouseenter', () => {
      const tip = document.createElement('div');
      tip.className = 'tooltip-popup';
      tip.textContent = el.dataset.tooltip;
      tip.style.cssText = 'position:absolute;bottom:calc(100% + 8px);left:50%;transform:translateX(-50%);background:rgba(30,0,20,0.9);border:1px solid rgba(255,255,255,0.2);color:white;padding:4px 10px;border-radius:8px;font-size:0.75rem;white-space:nowrap;z-index:100;pointer-events:none;';
      el.appendChild(tip);
    });
    el.addEventListener('mouseleave', () => el.querySelector('.tooltip-popup')?.remove());
  });
}

// ── Toast ──────────────────────────────────────────────────────
window.showToast = function(message, type = 'info', duration = 3200) {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'toastIn 0.3s ease reverse';
    setTimeout(() => toast.remove(), 320);
  }, duration);
};

// ── Smooth Scroll ──────────────────────────────────────────────
document.addEventListener('click', e => {
  const link = e.target.closest('a[href^="#"]');
  if (!link) return;
  const target = document.querySelector(link.getAttribute('href'));
  if (target) {
    e.preventDefault();
    const navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nav-h') || '72');
    window.scrollTo({ top: target.getBoundingClientRect().top + window.scrollY - navH - 8, behavior: 'smooth' });
  }
});

// ── Ripple ─────────────────────────────────────────────────────
document.addEventListener('click', e => {
  const btn = e.target.closest('.btn');
  if (!btn) return;
  const rect   = btn.getBoundingClientRect();
  const size   = Math.max(rect.width, rect.height) * 2;
  const ripple = document.createElement('span');
  ripple.style.cssText = `position:absolute;width:${size}px;height:${size}px;border-radius:50%;background:rgba(255,255,255,0.25);top:${e.clientY - rect.top - size/2}px;left:${e.clientX - rect.left - size/2}px;transform:scale(0);animation:rippleAnim 0.55s ease-out forwards;pointer-events:none;z-index:0;`;
  if (!document.getElementById('ripple-style')) {
    const s = document.createElement('style');
    s.id = 'ripple-style';
    s.textContent = '@keyframes rippleAnim{to{transform:scale(1);opacity:0}}';
    document.head.appendChild(s);
  }
  if (getComputedStyle(btn).position === 'static') btn.style.position = 'relative';
  btn.style.overflow = 'hidden';
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
});

// ── Dark Mode Toggle ───────────────────────────────────────────
// NOTE: school_theme localStorage key is intentionally kept — it is a
// pure UI preference, not school data.
window.initDarkMode = function() {
  const saved = safeStorage.get('school_theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  const isDashboard = window.location.pathname.includes('dashboard') ||
                      window.location.pathname.includes('admin_panel');
  if (isDashboard) return;
  if (document.getElementById('darkModeToggle')) return;
  const btn = document.createElement('button');
  btn.className = 'dark-mode-toggle';
  btn.id = 'darkModeToggle';
  btn.title = 'Toggle Dark/Light Mode';
  btn.textContent = saved === 'dark' ? '☀️' : '🌙';
  btn.addEventListener('click', () => {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    safeStorage.set('school_theme', next); // ALLOWED — UI preference only
    btn.textContent = next === 'dark' ? '☀️' : '🌙';
  });
  document.body.appendChild(btn);
};

// ── Utilities ──────────────────────────────────────────────────
window.formatDate = d => new Date(d).toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' });
window.truncate   = (s, n = 80) => s.length > n ? s.slice(0, n) + '...' : s;

// ══════════════════════════════════════════════════════════════
//  API HELPER
//  All school data reads/writes go through this helper.
//  Sends admin_token from sessionStorage on every request.
// ══════════════════════════════════════════════════════════════

function _authHeaders() {
  return {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + (safeStorage.get('admin_token') || ''),
  };
}

window.api = {
  async get(endpoint) {
    try {
      const res = await fetch('/api' + endpoint, {
        headers: _authHeaders(),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        console.error('[API] GET /api' + endpoint + ' failed: ' + res.status);
        return null;
      }
      return res.json();
    } catch (err) {
      console.error('[API] GET /api' + endpoint + ' error:', err.message);
      return null;
    }
  },

  async post(endpoint, body) {
    try {
      const res = await fetch('/api' + endpoint, {
        method: 'POST',
        headers: _authHeaders(),
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        console.error('[API] POST /api' + endpoint + ' failed: ' + res.status);
        return null;
      }
      return res.json();
    } catch (err) {
      console.error('[API] POST /api' + endpoint + ' error:', err.message);
      return null;
    }
  },

  async put(endpoint, body) {
    try {
      const res = await fetch('/api' + endpoint, {
        method: 'PUT',
        headers: _authHeaders(),
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        console.error('[API] PUT /api' + endpoint + ' failed: ' + res.status);
        return null;
      }
      return res.json();
    } catch (err) {
      console.error('[API] PUT /api' + endpoint + ' error:', err.message);
      return null;
    }
  },

  async del(endpoint) {
    try {
      const res = await fetch('/api' + endpoint, {
        method: 'DELETE',
        headers: _authHeaders(),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        console.error('[API] DELETE /api' + endpoint + ' failed: ' + res.status);
        return null;
      }
      return res.json();
    } catch (err) {
      console.error('[API] DELETE /api' + endpoint + ' error:', err.message);
      return null;
    }
  },
};

// ══════════════════════════════════════════════════════════════
//  DEFAULT DATA (in-memory fallback structure — NOT saved to localStorage)
//  Used only as shape reference / fallback when API is unavailable.
// ══════════════════════════════════════════════════════════════

const DEFAULT_DATA = {
  schoolInfo: {
    name: "School Portal", tagline: "Excellence in Education",
    established: "2000", cbseCode: "0000000", website: "www.schoolportal.edu.in",
    phone: "+91 00000 00000", email: "info@schoolportal.edu.in",
    address: "12, School Road, City - 400001", logoData: '',
  },
  heroImage: '',
  homepageContent: {
    heroTitle:      "Shaping Minds, Building Futures",
    heroSubtitle:   "School Portal is committed to holistic education — nurturing academic excellence, moral character, and creative potential in every student.",
    aboutUs:        "Founded in 1980, School Portal has been a beacon of quality education for over four decades. Our CBSE-affiliated institution offers comprehensive education from LKG through Class XII.",
    academicText:   "We believe every child is unique. Our dedicated faculty, state-of-the-art facilities, and nurturing environment empower students to discover their potential.",
    principalName:  "Dr. Margaret D'Souza",
    principalTitle: "Principal, School Portal",
    principalQual:  "M.Ed., Ph.D. | 28 Years Experience",
    principalMsg:   "At School Portal, we believe that education is not merely the transfer of knowledge, but the transformation of character.",
    principalMsg2:  "We provide an environment where every child is encouraged to ask questions, explore ideas, and develop a lifelong love of learning.",
    principalPhoto: '',
  },
  calendar: { text: 'Download or view our academic calendar for the complete schedule of events, exams, and holidays.', imageData: '' },
  schoolTiming: {
    workingDays: "Monday – Saturday", schoolHours: "7:45 AM – 2:30 PM",
    lkgUkgHours: "8:00 AM – 11:15 AM", lunchBreak: "12:30 PM – 1:00 PM", officeHours: "9:00 AM – 4:00 PM",
  },
  stats: { students: 1240, teachers: 68, classes: 28, years: 45, alumni: 12400, awards: 320, passRate: 95 },
  announcements: [],
  events: [],
  examSchedule: { Term1: [], Term2: [], Board: [] },
  topStudents: [],
  houses: [],
  teachers: [],
  students: [],
  attendance: {},
  classTeachers: {},
  feeStructure: {
    heading: "Annual Fee Structure 2025-26",
    categories: [],
  },
  gallery: [],
  admissions: {
    visible: false, heading: 'Admissions Open 2025-26', session: '2025-2026',
    subtext: '', classes: 'LKG, UKG, Class I to XII',
    deadline: '', phone: '', imageData: '', glowEnabled: false, updatedAt: '',
  },
  upiPayment: {
    upiId: '', accountName: '', bankName: '', qrData: '',
    phonepeId: '', phonepeQr: '', gpayId: '', gpayQr: '',
  },
  socialLinks: { facebook:'', instagram:'', youtube:'', twitter:'', telegram:'', linkedin:'' },
  onlineLinks: {},
  lockdown:    { active: false, title: 'School Closed — Online Classes Active', message: '' },
  scores:      {},
};

// ══════════════════════════════════════════════════════════════
//  SCHOOL DB — MongoDB REST API-backed data store
//
//  REMOVED: All localStorage.setItem / localStorage.getItem for school data.
//  load()  → fetches from /api/settings/:key (async)
//  save()  → POSTs to   /api/settings/:key (async)
//  get()   → async, fetches single section from API
//  set()   → async, POSTs single section to API
// ══════════════════════════════════════════════════════════════

window.SchoolDB = {

  // ── Sync load() — returns DEFAULT_DATA immediately ──────────
  // Kept sync so frontend-api.js and api-layer.js can call it safely.
  // They will immediately override SchoolDB.load() with their own cached version.
  // For real MongoDB data use loadAsync() directly.
  load() {
    // Return in-memory cache if already populated by loadAsync()
    if (this._cache) return JSON.parse(JSON.stringify(this._cache));
    // Otherwise return defaults — frontend-api.js/api-layer.js will populate real data
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  },

  // ── Async load — fetches all data from MongoDB API ───────────
  // Call this when you need fresh data from the server.
  async loadAsync() {
    const sections = [
      'schoolInfo', 'homepageContent', 'schoolTiming', 'stats',
      'topStudents', 'admissions', 'socialLinks', 'feeStructure',
      'lockdown', 'heroImage', 'calendar', 'examSchedule',
      'upiPayment', 'onlineLinks', 'classTeachers', 'scores',
    ];

    const results = await Promise.allSettled(
      sections.map(key => window.api.get('/settings/' + key))
    );

    const data = JSON.parse(JSON.stringify(DEFAULT_DATA));

    sections.forEach((key, i) => {
      const r = results[i];
      if (r.status === 'fulfilled' && r.value && r.value.value !== undefined) {
        data[key] = r.value.value;
      }
    });

    // Load dynamic collections
    try {
      const [anns, evts, houses, gallery, teachers] = await Promise.all([
        window.api.get('/announcements'),
        window.api.get('/events'),
        window.api.get('/houses'),
        window.api.get('/gallery'),
        window.api.get('/teachers'),
      ]);
      if (anns)    data.announcements = anns.data    || [];
      if (evts)    data.events        = evts.data    || [];
      if (houses)  data.houses        = (houses.data || []).map(h => Object.assign({}, h, {
        id: h.id || h._id,
        points: (h.sports||0)+(h.study||0)+(h.activities||0)+(h.discipline||0),
        contributors: h.contributors || [],
      }));
      if (gallery) data.gallery = (gallery.data || []).map(g => ({
        id: g._id || g.id, title: g.title, category: g.category,
        url: g.url || g.imageUrl || '', emoji: g.emoji || '🖼️',
      }));
      if (teachers) data.teachers = teachers.data || [];
    } catch (err) {
      console.error('[SchoolDB] load — collection fetch error:', err.message);
    }

    // Populate sync cache so subsequent load() calls return real data
    this._cache = data;
    return data;
  },

  // ── Save a full data object by writing every settings key ──
  // Mirrors the old save(data) signature but writes to MongoDB.
  async save(data) {
    const settingsKeys = [
      'schoolInfo', 'homepageContent', 'schoolTiming', 'stats',
      'topStudents', 'admissions', 'socialLinks', 'feeStructure',
      'lockdown', 'heroImage', 'calendar', 'examSchedule',
      'upiPayment', 'onlineLinks', 'classTeachers', 'scores',
    ];

    try {
      await Promise.all(
        settingsKeys.map(key => {
          if (data[key] !== undefined) {
            return window.api.post('/settings/' + key, { value: data[key] });
          }
          return Promise.resolve();
        })
      );
      return true;
    } catch (err) {
      console.error('[SchoolDB] save error:', err.message);
      if (typeof window.showToast === 'function') {
        window.showToast('❌ Data could not be saved. Check your network or server.', 'error');
      }
      return false;
    }
  },

  // ── Get a single section from the API ─────────────────────
  async get(section) {
    // Dynamic collections
    if (section === 'announcements') {
      const r = await window.api.get('/announcements');
      return r ? (r.data || []) : DEFAULT_DATA.announcements;
    }
    if (section === 'events') {
      const r = await window.api.get('/events');
      return r ? (r.data || []) : DEFAULT_DATA.events;
    }
    if (section === 'houses') {
      const r = await window.api.get('/houses');
      if (!r) return DEFAULT_DATA.houses;
      return (r.data || []).map(h => Object.assign({}, h, {
        id: h.id || h._id,
        points: (h.sports||0)+(h.study||0)+(h.activities||0)+(h.discipline||0),
        contributors: h.contributors || [],
      }));
    }
    if (section === 'teachers') {
      const r = await window.api.get('/teachers');
      return r ? (r.data || []) : DEFAULT_DATA.teachers;
    }
    if (section === 'students') {
      const r = await window.api.get('/students');
      return r ? (r.data || []) : [];
    }
    if (section === 'gallery') {
      const r = await window.api.get('/gallery');
      if (!r) return DEFAULT_DATA.gallery;
      return (r.data || []).map(g => ({
        id: g._id || g.id, title: g.title, category: g.category,
        url: g.url || g.imageUrl || '', emoji: g.emoji || '🖼️',
      }));
    }

    // Settings-based sections
    try {
      const r = await window.api.get('/settings/' + section);
      if (r && r.value !== undefined) return r.value;
    } catch (err) {
      console.error('[SchoolDB] get(' + section + ') error:', err.message);
    }
    if (typeof window.showToast === 'function') {
      window.showToast('⚠️ Data could not be loaded. Check the server.', 'error', 4000);
    }
    return DEFAULT_DATA[section] !== undefined
      ? JSON.parse(JSON.stringify(DEFAULT_DATA[section]))
      : null;
  },

  // ── Set a single section via the API ──────────────────────
  async set(section, value) {
    try {
      const res = await window.api.post('/settings/' + section, { value });
      if (!res) {
        if (typeof window.showToast === 'function') {
          window.showToast('❌ "' + section + '" could not be saved. Check the server.', 'error');
        }
        console.error('[SchoolDB] set(' + section + ') — API returned null');
        return false;
      }
      return true;
    } catch (err) {
      console.error('[SchoolDB] set(' + section + ') error:', err.message);
      if (typeof window.showToast === 'function') {
        window.showToast('❌ Data could not be saved. Check your network or server.', 'error');
      }
      return false;
    }
  },

  // ── Update a single key inside a section ──────────────────
  async update(section, key, val) {
    try {
      const current = await this.get(section);
      const updated = (current && typeof current === 'object') ? Object.assign({}, current, { [key]: val }) : { [key]: val };
      return this.set(section, updated);
    } catch (err) {
      console.error('[SchoolDB] update(' + section + ', ' + key + ') error:', err.message);
      if (typeof window.showToast === 'function') {
        window.showToast('❌ Update failed. Check your network or server.', 'error');
      }
      return false;
    }
  },

  // ── Storage usage — always 0 (no localStorage) ────────────
  getStorageUsageKB() { return 0; },

  // ── Reset — no-op for MongoDB (data lives on server) ──────
  reset() {
    console.warn('[SchoolDB] reset() called — no-op in MongoDB mode. Delete data via admin panel.');
  },

  // ── Deep merge utility ────────────────────────────────────
  _deepMerge(target, source) {
    for (const key in source) {
      if (source[key] !== null && typeof source[key] === 'object' && !Array.isArray(source[key]) &&
          target[key] !== null && typeof target[key] === 'object' && !Array.isArray(target[key])) {
        target[key] = this._deepMerge(target[key], source[key]);
      } else {
        target[key] = source[key];
      }
    }
    return target;
  },
};

// Backward compat — demoData now fetches from API asynchronously
Object.defineProperty(window, 'demoData', {
  get() {
    console.warn('[demoData] Deprecated: Use await SchoolDB.load() or await SchoolDB.get(section) instead.');
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  },
});

// ── GalleryDB — IndexedDB for local image caching ─────────────
// NOTE: GalleryDB is kept for client-side image caching only.
// Permanent gallery data is stored in MongoDB via /api/gallery.
window.GalleryDB = {
  _db: null,
  _DB_NAME: 'school_gallery_db',
  _STORE: 'gallery_images',
  _VERSION: 1,

  open() {
    return new Promise((resolve, reject) => {
      if (this._db) { resolve(this._db); return; }
      const req = indexedDB.open(this._DB_NAME, this._VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(this._STORE)) {
          db.createObjectStore(this._STORE, { keyPath: 'id' });
        }
      };
      req.onsuccess = (e) => { this._db = e.target.result; resolve(this._db); };
      req.onerror = (e) => reject(e.target.error);
    });
  },

  saveAll(items) {
    return this.open().then(db => {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(this._STORE, 'readwrite');
        const store = tx.objectStore(this._STORE);
        store.clear();
        items.forEach(item => store.put(item));
        tx.oncomplete = () => resolve(true);
        tx.onerror = (e) => reject(e.target.error);
      });
    }).catch(e => { console.error('[GalleryDB] saveAll error:', e); return false; });
  },

  loadAll() {
    return this.open().then(db => {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(this._STORE, 'readonly');
        const req = tx.objectStore(this._STORE).getAll();
        req.onsuccess = (e) => resolve(e.target.result || []);
        req.onerror = (e) => reject(e.target.error);
      });
    }).catch(e => { console.error('[GalleryDB] loadAll error:', e); return []; });
  },

  addItem(item) {
    return this.open().then(db => {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(this._STORE, 'readwrite');
        tx.objectStore(this._STORE).put(item);
        tx.oncomplete = () => resolve(true);
        tx.onerror = (e) => reject(e.target.error);
      });
    }).catch(e => { console.error('[GalleryDB] addItem error:', e); return false; });
  },

  deleteItem(id) {
    return this.open().then(db => {
      return new Promise((resolve, reject) => {
        const tx = db.transaction(this._STORE, 'readwrite');
        tx.objectStore(this._STORE).delete(id);
        tx.oncomplete = () => resolve(true);
        tx.onerror = (e) => reject(e.target.error);
      });
    }).catch(e => { console.error('[GalleryDB] deleteItem error:', e); return false; });
  },

  // Migration stub — no longer needed (no localStorage gallery data to migrate)
  migrateFromLocalStorage() {
    // No-op: gallery data now lives in MongoDB only.
    console.log('[GalleryDB] migrateFromLocalStorage: skipped — MongoDB is the source of truth.');
  },
};

window.GalleryDB.open().then(() => {
  if (typeof window.GalleryDB.migrateFromLocalStorage === 'function') {
    window.GalleryDB.migrateFromLocalStorage();
  }
});

// ══════════════════════════════════════════════════════════════
//  ADMIN AUTH
//
//  REMOVED: All localStorage reads/writes for credentials.
//  login()     → POST /api/auth/login
//  isLoggedIn()→ checks sessionStorage.admin_token
//  logout()    → clears sessionStorage only
//  update()    → POST /api/auth/update-credentials
// ══════════════════════════════════════════════════════════════

window.AdminAuth = {

  // ── Login via MongoDB API ──────────────────────────────────
  async login(username, password) {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId: username, password, role: 'admin' }),
        signal: AbortSignal.timeout(8000),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        console.error('[AdminAuth] login failed:', res.status, errData);
        return {
          success: false,
          error: errData.message || 'Invalid credentials. Please check username and password.',
        };
      }

      const data = await res.json();
      const token = data.token || data.access_token || ('session_' + Date.now());
      const user  = data.user || { username, full_name: data.full_name || username, role: data.role || 'admin' };

      safeStorage.set('admin_token', token);
      safeStorage.set('admin_user', JSON.stringify(user));

      return { success: true, user };
    } catch (err) {
      console.error('[AdminAuth] login error:', err.message);
      if (typeof window.showToast === 'function') {
        window.showToast('❌ Login failed. Check the server and try again.', 'error');
      }
      return { success: false, error: 'Unable to connect to the server. Please try again.' };
    }
  },

  // ── Check login state via sessionStorage ──────────────────
  isLoggedIn() {
    return !!safeStorage.get('admin_token');
  },

  // ── Logout — clear sessionStorage only ────────────────────
  logout() {
    safeStorage.remove('admin_token');
    safeStorage.remove('admin_user');
  },

  // ── Get current user from sessionStorage ──────────────────
  getCurrentUser() {
    try {
      const u = safeStorage.get('admin_user');
      return u ? JSON.parse(u) : null;
    } catch (e) {
      return null;
    }
  },

  // ── Update admin credentials via API ──────────────────────
  async update(newUsername, newPassword, currentPassword) {
    try {
      const res = await fetch('/api/auth/update-credentials', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + (safeStorage.get('admin_token') || ''),
        },
        body: JSON.stringify({
          currentPassword,
          newUsername: newUsername || undefined,
          newPassword: newPassword || undefined,
        }),
        signal: AbortSignal.timeout(8000),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        return { success: false, error: errData.message || 'Credentials update failed.' };
      }

      const data = await res.json();

      // Update session user info if username changed
      if (newUsername) {
        const user = this.getCurrentUser() || {};
        user.username = newUsername;
        safeStorage.set('admin_user', JSON.stringify(user));
      }

      return { success: true, data };
    } catch (err) {
      console.error('[AdminAuth] update error:', err.message);
      return { success: false, error: 'Unable to connect to the server.' };
    }
  },

  // ── Legacy sync shims — kept for backward compatibility ───
  verify(u, p) {
    console.warn('[AdminAuth] verify() is deprecated. Use async login() instead.');
    return false;
  },
  getCredentials() {
    console.warn('[AdminAuth] getCredentials() is deprecated. Credentials are stored server-side.');
    return null;
  },
};

// ══════════════════════════════════════════════════════════════
//  IMAGE UTILITIES
// ══════════════════════════════════════════════════════════════
window.ImageUtil = {
  compress(file, maxW, maxH, quality, callback) {
    if (!file) return;
    const reader = new FileReader();
    reader.onerror = () => window.showToast('File read error', 'error');
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => window.showToast('Invalid image file', 'error');
      img.onload = () => {
        let w = img.width, h = img.height;
        if (w > maxW) { h = Math.round(h * maxW / w); w = maxW; }
        if (h > maxH) { w = Math.round(w * maxH / h); h = maxH; }
        const canvas = document.createElement('canvas');
        canvas.width  = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        try {
          callback(canvas.toDataURL('image/jpeg', quality));
        } catch(err) {
          callback(e.target.result);
        }
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  },

  compressProfile(file, cb)  { this.compress(file, 200, 200, 0.68, cb); },
  compressGallery(file, cb)  { this.compress(file, 600, 450, 0.62, cb); },
  compressQR(file, cb)       { this.compress(file, 380, 380, 0.80, cb); },
  compressLarge(file, cb)    { this.compress(file, 800, 600, 0.62, cb); },
  compressTeacher(file, cb)  { this.compress(file, 220, 280, 0.68, cb); },
};

// ══════════════════════════════════════════════════════════════
//  REAL-TIME SYNC — Cross-tab instant update via BroadcastChannel
//  (Storage event fallback removed — no localStorage school data)
// ══════════════════════════════════════════════════════════════
window.SchoolSync = {
  _ch: null,

  init() {
    if (typeof BroadcastChannel !== 'undefined') {
      try {
        this._ch = new BroadcastChannel('school_portal_v6');
        this._ch.addEventListener('message', (e) => {
          if (e.data?.type === 'UPDATE') this._apply(e.data.section);
        });
      } catch(e) {}
    }
  },

  broadcast(section) {
    try { this._ch?.postMessage({ type: 'UPDATE', section }); } catch(e) {}
  },

  _apply(section) {
    const safe = (fn) => { try { if (typeof fn === 'function') fn(); } catch(e) { console.warn('[SchoolSync._apply]', e.message); } };
    const runners = {
      announcements:    () => { const el = document.getElementById('announcements-list');      if (el && typeof renderAnnouncements    === 'function') { el.innerHTML = ''; renderAnnouncements(); }    },
      events:           () => { const el = document.getElementById('events-preview-grid');     if (el && typeof renderEventsPreview    === 'function') { el.innerHTML = ''; renderEventsPreview(); }     },
      houses:           () => { const el = document.getElementById('houses-preview-grid');     if (el && typeof renderHousesPreview    === 'function') { el.innerHTML = ''; renderHousesPreview(); }     },
      topStudents:      () => { const el = document.getElementById('student-leaderboard-body');if (el && typeof renderStudentLeaderboard=== 'function') { el.innerHTML = ''; renderStudentLeaderboard(); }},
      homepageContent:  () => { safe(loadSchoolInfo); safe(loadSchoolLogo); safe(loadStats); safe(loadTimings); },
      schoolInfo:       () => { safe(loadSchoolInfo); safe(loadSchoolLogo); safe(loadStats); safe(loadTimings); },
      calendar:         () => { safe(loadCalendar); },
      admissions:       () => { safe(loadAdmissionsSection); },
      stats:            () => { safe(loadStats); },
      gallery:          () => {
        const el = document.getElementById('gallery-grid');
        if (el && typeof renderGallery === 'function') { el.innerHTML = ''; renderGallery(); }
        safe(loadGalleryPage);
      },
      attendance:       () => { safe(loadAttendanceDisplay); },
      teachers:         () => { safe(loadAndRender); safe(renderTeachers); safe(loadSchoolInfo); safe(loadSchoolLogo); },
      upiPayment:       () => { safe(loadUpiQr); },
      classTeachers:    () => { safe(render); safe(loadAndRender); },
      subjects:         () => { safe(render); },
      examSchedule:     () => { safe(renderExamSection); },
      socialLinks:      () => { safe(initFooterSocialLinks); },
      lockdown:         () => { safe(checkLockdownBanner); },
    };
    if (section === 'all') {
      Object.values(runners).forEach(fn => { try { fn(); } catch(e) {} });
    } else {
      if (runners[section]) {
        try { runners[section](); } catch(e) { console.warn('[SchoolSync] apply error for', section, e.message); }
      } else {
        safe(loadSchoolInfo); safe(loadSchoolLogo);
      }
    }
  },
};
