# 📁 SCHOOL — Local Images Folder

## Folder Structure

```
images/
├── images-config.js         ← All image paths yahan define hain
├── README-IMAGES.md         ← Yeh file
│
├── logo/
│   └── school-logo.svg      ← School logo (hero image & settings)
│
├── banners/
│   ├── admission-banner.svg ← Admission section ka banner
│   └── sports-banner.svg    ← Sports day banner
│
├── principal/
│   └── principal.svg        ← Principal / leadership photo
│
├── students/
│   ├── top-student1.svg     ← Rank 1 – Aarav Sharma
│   ├── top-student2.svg     ← Rank 2 – Priya Gupta
│   ├── top-student3.svg     ← Rank 3 – Rohan Verma
│   ├── top-student4.svg     ← Rank 4 – Sneha Patel
│   └── top-student5.svg     ← Rank 5 – Arjun Singh
│
├── teachers/
│   ├── teacher1.svg         ← Mrs. Anita Sharma (English)
│   ├── teacher2.svg         ← Mr. Rajesh Kumar  (Math)
│   ├── teacher3.svg         ← Mrs. Sunita Devi  (Science)
│   ├── teacher4.svg         ← Mr. Anil Mishra   (Hindi)
│   └── teacher5.svg         ← Mrs. Kavita Singh (S.St.)
│
├── class-teachers/
│   ├── class1.svg           ← Class I  Teacher
│   ├── class2.svg           ← Class II Teacher
│   ├── class3.svg           ← Class III Teacher
│   └── class4.svg           ← Class IV Teacher
│
├── events/
│   ├── event1.svg           ← Annual Day 2025
│   ├── event2.svg           ← Science Fair
│   ├── event3.svg           ← Sports Day
│   └── event4.svg           ← Cultural Fest
│
├── houses/
│   ├── blue-house.svg       ← Blue House logo
│   ├── green-house.svg      ← Green House logo
│   ├── red-house.svg        ← Red House logo
│   └── yellow-house.svg     ← Yellow House logo
│
└── gallery/
    ├── gallery1.svg         ← School Building
    ├── gallery2.svg         ← Library
    └── gallery3.svg         ← Computer Lab
```

---

## ✅ Naya Image Kaise Add Karein?

### Step 1 — Image file rakh do sahi folder mein
```
Jaise: images/students/top-student6.jpg
```

### Step 2 — `images-config.js` mein entry add karo
```js
students: [
  // ... existing entries ...
  { label: 'Riya Mehta (Rank 6)', path: 'images/students/top-student6.jpg' },
],
```

### Step 3 — Done! ✅
Admin panel ke dropdown mein automatically aayega.
Backend ya server ki zaroorat nahi.

---

## ⚠️ Important Rules

| ✅ Karo                                  | ❌ Mat Karo                             |
|------------------------------------------|-----------------------------------------|
| Local folder paths use karo              | base64 encoded images store karo        |
| `images/` folder ke andar rakho          | localStorage mein image save karo       |
| `images-config.js` mein path register karo | Random URL se images link karo         |
| `loading="lazy"` use karo               | Badi images without compression use karo |

---

## 📐 Recommended Image Sizes

| Category       | Size         | Format     |
|----------------|--------------|------------|
| Logo           | 200×200 px   | PNG / SVG  |
| Banners        | 800×400 px   | JPG / SVG  |
| Principal      | 400×400 px   | JPG / PNG  |
| Students       | 400×400 px   | JPG / PNG  |
| Teachers       | 400×400 px   | JPG / PNG  |
| Events         | 600×400 px   | JPG / SVG  |
| Gallery        | 600×400 px   | JPG / PNG  |

---

*Demo purpose ke liye SVG placeholder images use ki gayi hain.*
*Production mein inhe real photos se replace karein.*
