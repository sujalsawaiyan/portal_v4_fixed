/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║         SCHOOL SCHOOL — LOCAL IMAGE CATALOG              ║
 * ║   All images are defined here (local folder paths) ║
 * ║   No localStorage or base64 — local paths only   ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * To add a new image:
 *  1. Place the image in the correct folder
 *  2. Add an entry in the relevant category below
 *  3. Done! It will appear automatically in the Admin dropdown
 */

window.ImageCatalog = {

  // ── LOGO ─────────────────────────────────────────────────────────
  logo: [
    { label: 'School Logo (Default)', path: 'images/logo/school-logo.svg' },
  ],

  // ── BANNERS ──────────────────────────────────────────────────────
  banners: [
    { label: 'Admission Banner 2025-26',  path: 'images/banners/admission-banner.svg' },
    { label: 'Annual Sports Day Banner',  path: 'images/banners/sports-banner.svg'    },
  ],

  // ── PRINCIPAL / LEADERSHIP ────────────────────────────────────────
  principal: [
    { label: 'Principal Photo',           path: 'images/principal/principal.svg' },
  ],

  // ── TOP STUDENTS / TOPPERS ────────────────────────────────────────
  students: [
    { label: 'Aarav Sharma  (Rank 1)',    path: 'images/students/top-student1.svg' },
    { label: 'Priya Gupta   (Rank 2)',    path: 'images/students/top-student2.svg' },
    { label: 'Rohan Verma   (Rank 3)',    path: 'images/students/top-student3.svg' },
    { label: 'Sneha Patel   (Rank 4)',    path: 'images/students/top-student4.svg' },
    { label: 'Arjun Singh   (Rank 5)',    path: 'images/students/top-student5.svg' },
  ],

  // ── TEACHERS ──────────────────────────────────────────────────────
  teachers: [
    { label: 'Mrs. Anita Sharma  (English)',  path: 'images/teachers/teacher1.svg' },
    { label: 'Mr. Rajesh Kumar   (Math)',     path: 'images/teachers/teacher2.svg' },
    { label: 'Mrs. Sunita Devi   (Science)',  path: 'images/teachers/teacher3.svg' },
    { label: 'Mr. Anil Mishra    (Hindi)',    path: 'images/teachers/teacher4.svg' },
    { label: 'Mrs. Kavita Singh  (S.St.)',    path: 'images/teachers/teacher5.svg' },
  ],

  // ── CLASS TEACHERS ────────────────────────────────────────────────
  classTeachers: [
    { label: 'Class I  Teacher',   path: 'images/class-teachers/class1.svg' },
    { label: 'Class II Teacher',   path: 'images/class-teachers/class2.svg' },
    { label: 'Class III Teacher',  path: 'images/class-teachers/class3.svg' },
    { label: 'Class IV Teacher',   path: 'images/class-teachers/class4.svg' },
  ],

  // ── EVENTS ────────────────────────────────────────────────────────
  events: [
    { label: 'Annual Day 2025',       path: 'images/events/event1.svg' },
    { label: 'Science Fair',          path: 'images/events/event2.svg' },
    { label: 'Sports Day',            path: 'images/events/event3.svg' },
    { label: 'Cultural Fest',         path: 'images/events/event4.svg' },
  ],

  // ── HOUSES ────────────────────────────────────────────────────────
  houses: [
    { label: 'Blue House Logo',       path: 'images/houses/blue-house.svg'   },
    { label: 'Green House Logo',      path: 'images/houses/green-house.svg'  },
    { label: 'Red House Logo',        path: 'images/houses/red-house.svg'    },
    { label: 'Yellow House Logo',     path: 'images/houses/yellow-house.svg' },
  ],

  // ── GALLERY ───────────────────────────────────────────────────────
  gallery: [
    { label: 'School Building',       path: 'images/gallery/gallery1.svg' },
    { label: 'Library',               path: 'images/gallery/gallery2.svg' },
    { label: 'Computer Lab',          path: 'images/gallery/gallery3.svg' },
  ],

  // ── HELPER: Dropdown HTML banana ────────────────────────────────
  /**
   * buildSelect(category, currentPath, onChange)
   * Returns an <select> element pre-filled with images from the category.
   */
  buildSelect(category, currentPath = '', onChange = null) {
    const list = this[category] || [];
    const sel  = document.createElement('select');
    sel.className = 'img-catalog-select';
    sel.style.cssText = [
      'width:100%', 'padding:7px 10px', 'border-radius:8px',
      'border:1px solid rgba(233,30,140,0.35)', 'background:var(--surface,#1e1e2e)',
      'color:var(--text,#fff)', 'font-family:Outfit,sans-serif',
      'font-size:0.82rem', 'cursor:pointer', 'outline:none',
    ].join(';');

    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = '— Select an image —';
    sel.appendChild(placeholder);

    list.forEach(item => {
      const opt = document.createElement('option');
      opt.value = item.path;
      opt.textContent = item.label;
      if (item.path === currentPath) opt.selected = true;
      sel.appendChild(opt);
    });

    if (onChange) sel.addEventListener('change', () => onChange(sel.value));
    return sel;
  },

  /**
   * buildPreview(imgPath, size, shape)
   * Returns an <img> or placeholder div.
   */
  buildPreview(imgPath, size = 100, shape = 'circle') {
    const wrap = document.createElement('div');
    wrap.style.cssText = [
      `width:${size}px`, `height:${size}px`,
      `border-radius:${shape === 'circle' ? '50%' : '10px'}`,
      'overflow:hidden', 'border:2px solid rgba(233,30,140,0.4)',
      'background:rgba(255,255,255,0.06)',
      'display:flex', 'align-items:center', 'justify-content:center',
      'font-size:2rem', 'flex-shrink:0',
    ].join(';');

    if (imgPath) {
      const img = document.createElement('img');
      img.src     = imgPath;
      img.alt     = 'Preview';
      img.loading = 'eager';
      img.crossOrigin = 'anonymous';
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block';
      wrap.appendChild(img);
    } else {
      wrap.textContent = '🖼️';
    }
    return wrap;
  },
};
